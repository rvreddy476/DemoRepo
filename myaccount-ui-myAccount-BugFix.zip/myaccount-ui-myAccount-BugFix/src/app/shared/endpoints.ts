import { environment } from '../../environments/environment';
import { ICreateAccount } from './interfaces/admin/create-account/create-accounts-state';


/**
 * List of MyAccounts Endpoints
 */
export class Endpoints {
  private static readonly appScope = '2f82';
  private static readonly BASE_URI = `${environment.apiRootUrl}`;

  // private static readonly TEMP_DEV_API = `https://myaccount-api-2f82-d.epaas.eu.airbus.corp/myaccount/v1`;

  //#region shared
  public static USER_IDENTITY_BY_UID(email, pirKey, uid): string {
    return `${Endpoints.BASE_URI}/identities?email=${email}&pir_key=${pirKey}&uid=${uid}`;
  }

  //#endregion
  //#region user

  public static USER_ACCOUNT_STATUS(id): string {
    return `${Endpoints.BASE_URI}/identities/${id}/accounts-stats`;
  }

  //#endregion
  //#region admin
  public static ADMIN_ACCOUNT_STATUS(): string {
    return `${Endpoints.BASE_URI}/stats`;
  }

  //#region superadmin
  public static SUPERADMIN_ACCOUNT_STATUS(numberOfDays): string {
    return `${Endpoints.BASE_URI}/stats?number_of_days=${numberOfDays}`;
  }
  //#endregion

  public static RESET_PASSWORD(id): string {
    return `${Endpoints.BASE_URI}/accounts/${id}/reset-password`;
  }

  public static RESET_BULK_PASSWORD(): string {
    return `${Endpoints.BASE_URI}/accounts/reset-passwords`;
  }
  //#endregion
  //#region accounts

  public static ACCOUNT_LIST({ uid = '', wildcard = false }) {
    // val = 5792 (2539 accounts)
    // val = 20552 (1541 accounts)
    // prod = 39883 {35000 accounts}
    // prod = 48395 {40 accounts}
    // preprod = 39883 {35000 accounts}
    // preprod = 35088 {40 accounts}
    // dev = 39742 / 276916 / 39803 / 39729

    // reqId = 229696

    let params = '';
    params += uid ? `&name=${uid}${wildcard ? '*' : ''}` : '';
    return `${Endpoints.BASE_URI}/accounts${params.length > 0 ? `?${params.substring(1, params.length)}` : ''}`;
  }

  public static ADMIN_ACCOUNT_LIST({ uid = '', identity = '', solution = '', wildcard = false }) {
    let params = '';
    params += uid ? `&name=${uid}${wildcard ? '*' : ''}` : '';
    params += identity ? `&identity_login=${identity}` : '';
    params += solution ? `&solution.code=${solution}` : '';
    params += `&from_token=false`;
    return `${Endpoints.BASE_URI}/accounts${params.length > 0 ? `?${params.substring(1, params.length)}` : ''}`;
  }

  public static ACCOUNT_BY_ID(id,fromToken) {
    // id = 229896
    return `${Endpoints.BASE_URI}/accounts/${id}?from_token=${fromToken}`;
    // return `${Endpoints.BASE_URI}/accounts?uid=TA-EUI-C870-RPI`;
  }

  public static ACCOUNT_HISTORY(id) {
    // id = 2566609
    return `${Endpoints.BASE_URI}/accounts/${id}/history`;
  }
  public static ACCOUNT_DEPUTIES(id) {
    // id = 229896
    return `${Endpoints.BASE_URI}/accounts/${id}/delegates`;
  }

  public static ACCOUNT_AUTO_SUGGEST(term) {
    return this.ACCOUNT_LIST({ uid: `*${term}*`, wildcard: false });
  }

  //#endregion
  //#region create account

  // TODO define endpoints for all CREATE_ACCOUNT endpoints
  public static CREATE_ACCOUNT_RULES(code, type): string {
    return `${Endpoints.BASE_URI}/rules?solution.code=${code}&context_type.name=${type}`;
  }

  public static GET_GLOBAL_RULES(): string {
    return `${Endpoints.BASE_URI}/global-rules`;
  }

  public static CREATE_ACCOUNT_CONTEXT_SEARCH(term: string, autologon_only: boolean | string = false): string {
    return `${Endpoints.BASE_URI}/solutions?q=${term}*&limit=100${autologon_only ? '&autologon_only=true' : ''}`;
  }
  public static CREATE_ACCOUNT_CONTEXT_BY_ID(id): string {
    return `${Endpoints.BASE_URI}/solutions/${id}`;
  }

  public static CREATE_ACCOUNT_IDENTIES_SEARCH(term: string, stat?: string, idType?: string): string {
    return `${Endpoints.BASE_URI}/identities?q=${term}*${stat ? `&lifecycleStatus=${stat}` : ''}&limit=100`;
  }

  public static CREATE_ACCOUNT_DEPUTY_BLACKLIST(context: number, domain: string): string {
    return `${Endpoints.BASE_URI}/solutions/${context}/delegates?domain=${domain}`;
  }

  public static CREATE_ACCOUNT_IDENTITY(id): string {
    return `${Endpoints.BASE_URI}/identities/${id}`;
  }
  public static CREATE_ACCOUNT_DOMAINS(domainQuery: string): string {
    return `${Endpoints.BASE_URI}/domains?name=${domainQuery}`;
  }
  public static CREATE_ACCOUNT_DOMAIN_BY_ID(id): string {
    return `${Endpoints.BASE_URI}/domains/?${id}`;
  }
  public static CREATE_ACCOUNT_MACHINE_NAMES(query: string): string {
    return `${Endpoints.BASE_URI}/computers?limit=20&name=*${query}*`;
  }
  public static CREATE_ACCOUNT_DOMAIN_POLICY(domainId): string {
    return `${Endpoints.BASE_URI}/domains/${domainId}/policy`;
  }
  public static CREATE_ACCOUNT(): string {
    return `${Endpoints.BASE_URI}/accounts`;
  }
  public static CREATE_BULK_ACCOUNTS(): string {
    return `${Endpoints.BASE_URI}/accounts/bulk`;
  }
  //#endregion

  //#region follow up


  public static FOLLOW_UP_ADMIN_ACTIONS(id): string {
    let params = '';
    params += `&from_token=true`;
    return `${Endpoints.BASE_URI}/identities/${id}/creation-followup${params.length > 0 ? `?${params.substring(1, params.length)}` : ''}`;
  }

  public static FOLLOW_UP_ACTIONS(id): string {
    return `${Endpoints.BASE_URI}/identities/${id}/creation-followup`;
  }
  public static FOLLOW_UP_SCHEDULED(id): string {
    return `${Endpoints.BASE_URI}/identities/${id}/scheduled-followup`;
  }

  public static CANCEL_CREATE_ACTION(actionId): string {
    return `${Endpoints.BASE_URI}/creation-requests/${actionId}/cancel`;
  }

  public static CANCEL_RESET_PASS_ACTION(accountId): string {
    return `${Endpoints.BASE_URI}/accounts/reset-passwords`;
  }

  //#endregion

  //#region orphan accounts

  public static ADMIN_ORPHAN_ACCOUNTS(uid: string, type: string): string {
    // let url=
    // if(uid)

    // url+=${}

    // return `${Endpoints.BASE_URI}/accounts/orphans?name=${uid}&type=${type}`;
    let params = '';
    params += uid ? `&name=${uid}` : '';
    params += type ? `&type=${type}` : '';
    return `${Endpoints.BASE_URI}/accounts/orphans${params.length > 0 ? `?${params.substring(1, params.length)}` : ''}`;




    //return `https://localhost:8443/myaccount/v1/accounts/orphan-accounts`;
  }

  public static ASSIGN_ORPHAN_ACCOUNTS(): string {

    return `${Endpoints.BASE_URI}/accounts/orphans`;
  }

  //#endregion

  //#region add remove deputies


  public static ADD_DEPUTIES(): string {
    return `${Endpoints.BASE_URI}/accounts/delegates/identities_delegate`;
  }

  public static REMOVE_DEPUTIES(accIds: number[], depLogins: string[]): string {

    const accIdsStr = Array.isArray(accIds) ? accIds.join(',') : accIds;
    const depLoginsStr = Array.isArray(depLogins) ? depLogins.join(',') : depLogins;

    return `${Endpoints.BASE_URI}/accounts/delegates/identities_delegate?account_ids=${accIdsStr}&identity_logins=${depLoginsStr}`;
  }

  //#endregion

  public static EDIT_LIFECYCLE_STATUS(): string {
    return `${Endpoints.BASE_URI}/accounts/lifecycle_status`;
  }

  public static EDIT_ACCOUNT_DETAILS(accId, updateParam): string {
    return `${Endpoints.BASE_URI}/accounts/${accId}?update_param=${updateParam}`;
  }

  public static ADD_PASSWORD_RECEIVER(accId): string {
    return `${Endpoints.BASE_URI}/accounts/password_receivers`;
  }

  public static DELETE_PASSWORD_RECEIVER(accId, email): string {
    return `${Endpoints.BASE_URI}/accounts/password_receivers?account_id=${accId}&passoword_receivers_email=${email}`;
  }

  public static GET_PASSWORD_RECEIVERS(accId): string {
    return `${Endpoints.BASE_URI}/accounts/${accId}/password_receivers`;
  }

  public static DIVISION(): string {
    return `${Endpoints.BASE_URI}/divisions`;
  }

  public static ENVIRONMENT(): string {
    return `${Endpoints.BASE_URI}/environments`;
  }

  public static DIRECTORY(division, airbusEnvironment) {
    return `${Endpoints.BASE_URI}/directories?division=${division}&environment=${airbusEnvironment}`;
  }

  public static DOMAIN(directory) {
    return `${Endpoints.BASE_URI}/domains?directory=${directory}`;
  }

  public static APPROVE_LIST(approver) {
    // 229896
    return `${Endpoints.BASE_URI}/creation-requests?approver_id=${approver}`;
  }
  public static CREATE_ACTION_REQUEST_BY_ID(actionId): string {
    return `${Endpoints.BASE_URI}/creation-requests/${actionId}`;
  }
  public static ACCEPT_ACCOUNT(id) {
    return `${Endpoints.BASE_URI}/creation-requests/${id}/approve`;
  }
  public static REJECT_ACCOUNT(id): string {
    return `${Endpoints.BASE_URI}/creation-requests/${id}/reject`;
  }

  public static GDPR_CHECK(uid): string {
    return `${environment.disclaimerRootUrl}/purposes/${environment.disclaimerPurposeName}/versions/active/validations/${uid}`;
  }
  public static ACCEPT_ACCOUNT_BULK() {
    return `${Endpoints.BASE_URI}/creation-requests/approve`;
  }
  public static REJECT_ACCOUNT_BULK(): string {
    return `${Endpoints.BASE_URI}/creation-requests/reject`;
  }
  public static GDPR_VALIDATE(uid): string {
    return `${environment.disclaimerRootUrl}/purposes/${environment.disclaimerPurposeName}/versions/active/validations/${uid}`;
  }
  public static GDPR_CONTENT(): string {
    return `${environment.disclaimerRootUrl}/purposes/${environment.disclaimerPurposeName}/versions/active`;
  }
}
