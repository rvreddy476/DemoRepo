import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-duplicate-icon',
  templateUrl: './duplicate-icon.component.html',
  styleUrls: ['./duplicate-icon.component.scss']
})
export class DuplicateIconComponent {}
