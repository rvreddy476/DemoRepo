import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-table-row-lg-icon',
  templateUrl: './table-row-lg-icon.component.html',
  styleUrls: ['./table-row-lg-icon.component.scss']
})
export class TableRowLgIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
