import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-deputy-icon',
  templateUrl: './add-deputy-icon.component.html',
  styleUrls: ['./add-deputy-icon.component.scss']
})
export class AddDeputyIconComponent {}
