import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question-icon',
  templateUrl: './question-icon.component.html',
  styleUrls: ['./question-icon.component.scss']
})
export class QuestionIconComponent {}
