import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-trash-icon',
  templateUrl: './trash-icon.component.html',
  styleUrls: ['./trash-icon.component.scss']
})
export class TrashIconComponent {
  constructor() { }
}
