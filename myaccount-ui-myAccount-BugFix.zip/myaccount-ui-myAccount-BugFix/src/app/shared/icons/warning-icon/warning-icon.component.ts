import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-warning-icon',
  templateUrl: './warning-icon.component.html',
  styleUrls: ['./warning-icon.component.scss']
})
export class WarningIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
