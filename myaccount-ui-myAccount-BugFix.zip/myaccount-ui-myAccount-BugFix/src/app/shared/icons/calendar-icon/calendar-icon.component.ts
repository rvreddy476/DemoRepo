import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-calendar-icon',
  templateUrl: './calendar-icon.component.html',
  styleUrls: ['./calendar-icon.component.scss']
})
export class CalendarIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
