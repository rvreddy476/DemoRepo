import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-failed-wire-icon',
  templateUrl: './failed-wire-icon.component.html',
  styleUrls: ['./failed-wire-icon.component.scss']
})
export class FailedWireIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
