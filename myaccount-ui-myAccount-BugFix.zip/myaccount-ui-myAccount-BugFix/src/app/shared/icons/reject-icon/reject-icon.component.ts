import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-reject-icon',
  templateUrl: './reject-icon.component.html',
  styleUrls: ['./reject-icon.component.scss']
})
export class RejectIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
