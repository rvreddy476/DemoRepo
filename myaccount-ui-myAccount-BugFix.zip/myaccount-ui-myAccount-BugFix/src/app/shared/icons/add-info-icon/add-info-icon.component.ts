import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-info-icon',
  templateUrl: './add-info-icon.component.html',
  styleUrls: ['./add-info-icon.component.scss']
})
export class AddInfoIconComponent {}
