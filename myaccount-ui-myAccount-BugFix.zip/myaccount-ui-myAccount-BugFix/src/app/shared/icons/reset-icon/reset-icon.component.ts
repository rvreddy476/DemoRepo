import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-reset-icon',
  templateUrl: './reset-icon.component.html',
  styleUrls: ['./reset-icon.component.scss']
})
export class ResetIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
