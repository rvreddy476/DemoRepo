import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetIconComponent } from './reset-icon.component';

describe('ResetIconComponent', () => {
  let component: ResetIconComponent;
  let fixture: ComponentFixture<ResetIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResetIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
