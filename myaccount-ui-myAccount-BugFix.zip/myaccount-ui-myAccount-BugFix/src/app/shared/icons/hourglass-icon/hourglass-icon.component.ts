import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-hourglass-icon',
  templateUrl: './hourglass-icon.component.html',
  styleUrls: ['./hourglass-icon.component.scss']
})
export class HourglassIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
