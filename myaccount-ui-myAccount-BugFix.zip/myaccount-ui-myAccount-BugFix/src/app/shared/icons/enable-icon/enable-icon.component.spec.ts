import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnableIconComponent } from './enable-icon.component';

describe('EnableIconComponent', () => {
  let component: EnableIconComponent;
  let fixture: ComponentFixture<EnableIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnableIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnableIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
