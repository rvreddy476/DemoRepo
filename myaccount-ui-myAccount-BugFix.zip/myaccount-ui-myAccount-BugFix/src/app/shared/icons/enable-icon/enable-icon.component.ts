import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-enable-icon',
  templateUrl: './enable-icon.component.html',
  styleUrls: ['./enable-icon.component.scss']
})
export class EnableIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
