import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-action-menu-icon',
  templateUrl: './action-menu-icon.component.html',
  styleUrls: ['./action-menu-icon.component.scss']
})
export class ActionMenuIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
