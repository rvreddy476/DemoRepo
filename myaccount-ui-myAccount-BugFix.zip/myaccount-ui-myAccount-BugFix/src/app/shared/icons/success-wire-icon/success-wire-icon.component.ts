import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-success-wire-icon',
  templateUrl: './success-wire-icon.component.html',
  styleUrls: ['./success-wire-icon.component.scss']
})
export class SuccessWireIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
