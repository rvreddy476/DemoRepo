import { Component } from '@angular/core';

@Component({
  selector: 'app-2f82-approve-icon',
  templateUrl: './approve-icon.component.html',
  styleUrls: ['./approve-icon.component.scss']
})
export class ApproveIconComponent {
  constructor() { }
}
