import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pen-icon',
  templateUrl: './pen-icon.component.html',
  styleUrls: ['./pen-icon.component.scss']
})
export class PenIconComponent {

}
