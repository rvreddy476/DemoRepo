import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-warning-wire-icon',
  templateUrl: './warning-wire-icon.component.html',
  styleUrls: ['./warning-wire-icon.component.scss']
})
export class WarningWireIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
