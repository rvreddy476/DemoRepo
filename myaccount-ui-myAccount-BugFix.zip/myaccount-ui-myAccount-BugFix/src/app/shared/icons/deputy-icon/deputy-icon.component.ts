import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-deputy-icon',
  templateUrl: './deputy-icon.component.html',
  styleUrls: ['./deputy-icon.component.scss']
})
export class DeputyIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
