import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-assign-icon',
  templateUrl: './assign-icon.component.html',
  styleUrls: ['./assign-icon.component.scss']
})
export class AssignIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
