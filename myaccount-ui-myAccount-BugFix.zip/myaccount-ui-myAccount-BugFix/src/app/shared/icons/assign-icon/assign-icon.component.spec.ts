import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignIconComponent } from './assign-icon.component';

describe('AssignIconComponent', () => {
  let component: AssignIconComponent;
  let fixture: ComponentFixture<AssignIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
