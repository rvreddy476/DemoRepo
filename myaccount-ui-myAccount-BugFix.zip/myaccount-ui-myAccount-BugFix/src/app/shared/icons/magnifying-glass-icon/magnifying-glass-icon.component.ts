import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-magnifying-glass-icon',
  templateUrl: './magnifying-glass-icon.component.html',
  styleUrls: ['./magnifying-glass-icon.component.scss']
})
export class MagnifyingGlassIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
