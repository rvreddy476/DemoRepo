import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-table-row-sm-icon',
  templateUrl: './table-row-sm-icon.component.html',
  styleUrls: ['./table-row-sm-icon.component.scss']
})
export class TableRowSmIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
