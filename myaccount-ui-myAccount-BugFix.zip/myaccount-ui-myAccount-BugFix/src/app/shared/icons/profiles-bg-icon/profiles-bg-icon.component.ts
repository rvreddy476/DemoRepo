import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-profiles-bg-icon',
  templateUrl: './profiles-bg-icon.component.html',
  styleUrls: ['./profiles-bg-icon.component.scss']
})
export class ProfilesBgIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
