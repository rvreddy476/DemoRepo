import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilesBgIconComponent } from './profiles-bg-icon.component';

describe('ProfilesBgIconComponent', () => {
  let component: ProfilesBgIconComponent;
  let fixture: ComponentFixture<ProfilesBgIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilesBgIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilesBgIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
