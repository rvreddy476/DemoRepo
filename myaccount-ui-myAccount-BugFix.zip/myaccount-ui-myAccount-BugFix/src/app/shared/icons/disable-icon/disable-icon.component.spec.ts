import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisableIconComponent } from './disable-icon.component';

describe('DisableIconComponent', () => {
  let component: DisableIconComponent;
  let fixture: ComponentFixture<DisableIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisableIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisableIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
