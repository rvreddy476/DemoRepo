import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-disable-icon',
  templateUrl: './disable-icon.component.html',
  styleUrls: ['./disable-icon.component.scss']
})
export class DisableIconComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
