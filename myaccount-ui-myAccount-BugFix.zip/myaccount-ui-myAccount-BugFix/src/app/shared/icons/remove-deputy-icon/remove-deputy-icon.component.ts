import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-deputy-icon',
  templateUrl: './remove-deputy-icon.component.html',
  styleUrls: ['./remove-deputy-icon.component.scss']
})
export class RemoveDeputyIconComponent {


}
