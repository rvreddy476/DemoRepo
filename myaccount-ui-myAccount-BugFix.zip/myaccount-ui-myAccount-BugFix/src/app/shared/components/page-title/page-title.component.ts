import { Component, OnInit, TemplateRef, ElementRef, ContentChild, Input } from '@angular/core';

@Component({
  selector: 'app-2f82-page-title',
  templateUrl: './page-title.component.html',
  styleUrls: ['./page-title.component.scss']

})
export class PageTitleComponent implements OnInit {

  @ContentChild('headerButtons') public headerButtons: TemplateRef<ElementRef>;

  @Input()
  public title = '';

  constructor() {
  }

  public ngOnInit() {
  }

}
