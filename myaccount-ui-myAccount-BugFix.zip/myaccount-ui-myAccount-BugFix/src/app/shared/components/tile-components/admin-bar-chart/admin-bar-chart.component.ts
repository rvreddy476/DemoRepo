import { Component, OnInit, Input } from '@angular/core';
import { Chart } from 'chart.js';
import { ISuperAdminAccountsStats } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats';
import { IAdminState } from 'src/app/core/admin/store';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-admin-bar-chart',
  templateUrl: './admin-bar-chart.component.html',
  styleUrls: ['./admin-bar-chart.component.scss']
})
export class AdminBarChartComponent implements OnInit {
  public chartId = '';
  public lineChart;
  private initialised = false;
  private accountdatacount=[];
  public barChartLabels=[];
  private accountdata=[];
  public barChartType = 'bar';
  public barChartLegend = false;
  private accountMappings=[{"accountName":"TECHNICAL","accountPrefix":"TA"},
  {"accountName":"SERVICE","accountPrefix":"SA"},
  {"accountName":"AUTOLOGON","accountPrefix":"AL"},
  {"accountName":"TRAINING","accountPrefix":"TR"},
  {"accountName":"TEST","accountPrefix":"TS"},
  {"accountName":"SHARED","accountPrefix":"SH"},
  {"accountName":"LEGACY","accountPrefix":"LA"},
  {"accountName":"LOGON","accountPrefix":"LOGON"}];

  @Input()
  private accounts:Observable<any[]>;

  constructor() { 
    this.chartId = new Date().getTime().toString() + Math.random();
  }
  
  

  public setAccountCount()
  {
    this.accountdatacount=[];
    this.barChartLabels=[];
    this.accountMappings.forEach(account=>{
      let accountType=this.accountdata.find(x=>x.accounttype_name===account.accountName);
      this.barChartLabels.push(account.accountPrefix);
      if(accountType){
       this.accountdatacount.push(accountType.count);
      }
      else{
        this.accountdatacount.push(0);
      }
    });
  }
  public ngAfterViewInit() {
    this.initialised = true;
      this.InitChart();
  }

  public InitChart()
  {

    if (!this.initialised) {
      return;
    }
    
    
    this.setAccountCount();
    this.lineChart = new Chart(this.chartId, {
      type: 'bar',
      
      data: {
        datasets: [
          {
           data:this.accountdatacount,
           barPercentage:0.5,
           backgroundColor:'#3482AC',
           categoryPercentage:1
          },
        ],

        labels: this.barChartLabels,
      },
      options:{
        responsive: true,
        legend: {
          position: 'right',
          labels: {
            fontSize: 10,
            usePointStyle: true
          },
          display:false
        },
        tooltips:{
          backgroundColor:'#001B4D'
    ,position:'average',displayColors: false
        },
        title: {
          text: 'Account Stats',
          display: true,
          fontSize: 18,
          position:'top',
          fontColor:'#3482AC',
        },
        scales: {
          xAxes: [{
            gridLines: {
              drawOnChartArea:false,
              zeroLineWidth:0
          }  ,
          // offset: true,
          //   gridLines: {
          //     offsetGridLines: false,
          //     color:'#647592'
          //   },
          scaleLabel: {
            display: true,
            labelString: 'Account type',
            fontColor:'#001B4D',
            fontFamily:'Roboto',
            fontSize:14
          }
          }],
            yAxes: [{
                offset: false,
            gridLines: {
              offsetGridLines: false,
              color:'#647592',
              borderDash:[8,4],
              zeroLineWidth:0
            },
                ticks: {
                  suggestedMin: 0,
                    suggestedMax:1000
                } ,
                scaleLabel: {
                  display: true,
                  labelString: 'in count',
                  fontColor:'#001B4D',
                  fontFamily:'Roboto',
                  fontSize:14
                } 
                 
            }]
        }
      }
    });
    //this.lineChart.update();
  }

  public barChartOptions  = {
    responsive: true,
    legend: {
      position: 'right',
      labels: {
        fontSize: 10,
        usePointStyle: true
      }
    },
    tooltips:{
      backgroundColor:'#001B4D'
,position:'nearest',displayColors: false    },
    title: {
      text: 'Account Stats',
      display: true,
      fontSize: 18,
      usePointStyle: true,
      position:'top',
      fontColor:'#3482AC',
    },
    scales: {
      xAxes: [{
        barPercentage: 0.5,
        gridLines: {
          drawOnChartArea:false,
          zeroLineWidth:0
      }  ,
      // offset: true,
      //   gridLines: {
      //     offsetGridLines: false,
      //     color:'#647592'
      //   },
      scaleLabel: {
        display: true,
        labelString: 'Account type',
        fontColor:'#001B4D',
        fontFamily:'Roboto',
        fontSize:14
      }
      }],
        yAxes: [{
            // gridLines: {
            //   drawOnChartArea:false
            // },
            scaleShowVerticalLines: false,
            offset: false,
        gridLines: {
          offsetGridLines: false,
          color:'#647592',
          borderDash:[8,4],
          zeroLineWidth:0
        },
            ticks: {
              
                suggestedMin: 0,
                suggestedMax: 10000000
            
            } ,
            scaleLabel: {
              display: true,
              labelString: 'in count',
              fontColor:'#001B4D',
              fontFamily:'Roboto',
              fontSize:14
            } 
             
        }]
    }
  }
  
  ngOnInit() {
    
  }
  public ngOnChanges() {
    this.accounts.subscribe(x=>this.accountdata=x);
    this.InitChart();
  }
}
