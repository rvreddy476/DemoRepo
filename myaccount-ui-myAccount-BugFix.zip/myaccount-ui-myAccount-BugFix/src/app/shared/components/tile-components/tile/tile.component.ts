import { AfterViewInit, Component, Input, OnChanges, OnInit, HostListener, Output, EventEmitter } from '@angular/core';
import { TileTypeEnum } from '../../../enums/tile-type.enum';
import { AccountDivisionEnum } from '../../../enums';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-2f82-tile',
  templateUrl: './tile.component.html',
  styleUrls: ['./tile.component.scss'],
})
export class TileComponent implements OnInit, OnChanges, AfterViewInit {
  // Normal Tile Only
  @Input()
  public value: number | string | boolean = 0;
  @Input()
  public title: string;
  @Input()
  public type = TileTypeEnum.Overview;
  @Input()
  public division: AccountDivisionEnum;
  // Both Tiles
  @Input()
  public enabledOnEmpty  = false;
  @Input()
  public forceDisabled = false;
  @Input()
  public loaded = true;
  @Input()
  public loading = true;
  @Input()
  public disabledTooltip = 'DASHBOARD.DEFAULT_TILE.TOOLTIP.UNAVAILABLE';

  public disabled = false;
  public bgImage = '';
  public tileClass = '';
  public pcEnabled = 0;
  public pcDisabled = 0;
  public lineChart: Chart;
  public chartId = '';
  // Summary Tile Only
  @Input()
  private enabledAcc: number;
  @Input()
  private disabledAcc: number;
  private initialised = false;

  @Output()
  public activeClick: EventEmitter<any>;

  constructor() {
    this.chartId = new Date().getTime().toString() + Math.random();
    this.activeClick = new EventEmitter();
  }

  @HostListener('click', ['$event']) public onClick(e) {
    if ((this.enabledOnEmpty || this.value) && !this.forceDisabled) {
      this.activeClick.emit();
    } else if (e.ctrlKey) {
      this.activeClick.emit();
    }
}

  public ngOnInit() {
    this.Init();
  }

  public ngOnChanges() {
    this.disabled = (!this.enabledOnEmpty && this.value === 0) || !this.loaded || this.forceDisabled;
    this.tileClass = `tile ${this.type.toString()}${this.disabled  ? ' disabled-tile' : ''}`;
    this.Init();
  }

  public ngAfterViewInit() {
    this.initialised = true;
    if (this.type === TileTypeEnum.Summary) {
      this.InitChart();
    }
  }

  public InitChart() {

    // don't init chart during unit-tests as no canvas is available
    // Netscape is navigator appName during jest unit tests
    if (/jsdom/.test(window.navigator.userAgent)) {
      return;
    }

    if (!this.initialised) {
      return;
    }
    const accSum = this.enabledAcc + this.disabledAcc;
    this.value = accSum;
    const greyMode = accSum === 0;
    this.pcEnabled = greyMode ? 0 : Math.round((this.enabledAcc / accSum) * 100);
    this.pcDisabled = greyMode ? 1 : Math.round((this.disabledAcc / accSum) * 100);
    this.lineChart = new Chart(this.chartId, {
      type: 'doughnut',
      data: {
        datasets: [
          {
            borderWidth: [0, 0],
            backgroundColor: greyMode ? ['#c8c9d2', '#c8c9d2'] : ['#83ba10', 'white'],
            data: [this.enabledAcc, this.disabledAcc],
          },
        ],

        labels: [`Enabled`, `Disabled`],
      },
      options: {
        animation: {
          duration: (!this.loading && this.loaded) ? 500 : 0
        },
        cutoutPercentage: 65,
        rotation: -0.775 * Math.PI,
        events: ['click'],
        legend: {
          display: false,
        },
        tooltips: {
          mode: 'nearest',
        },
        layout: {
          padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
          },
        },
      },
    });
  }

  private Init() {
    if (this.type === TileTypeEnum.Summary) {
      this.InitChart();
    }
  }
}
