import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { TileComponent } from './tile.component';

import { TileTypeEnum } from '../../../enums/tile-type.enum';
import { TestingModule } from '../../../../modules/testing/testing.module';
import { TooltipModule } from '@progress/kendo-angular-tooltip';

describe('Tile Component', () => {
  let component: TileComponent;
  let fixture: ComponentFixture<TileComponent>;
  let elem: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, TooltipModule],
      declarations: [TileComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(TileComponent);
      component = fixture.componentInstance;
      component.title = 'Disabled Accounts';
      elem = fixture.nativeElement;
      fixture.detectChanges();
    });
  }));

  it('should show loading message if not loaded', () => {
    component.loaded = false;
    fixture.detectChanges();
    expect(elem.querySelector('small').textContent).toEqual('DASHBOARD.LOADING');
  });

  it('should show correct value', () => {
    component.loaded = true;
    component.loading = false;
    component.value = 500;
    fixture.detectChanges();
    expect(elem.querySelector('.tile-value').textContent).toEqual('500');
    component.value = 42;
    fixture.detectChanges();
    expect(elem.querySelector('.tile-value').textContent).toEqual('42');
  });

  it('should show correct title', () => {
    expect(elem.querySelector('.label').textContent).toEqual(component.title);
  });
  it('should only show loading spinner when loading', () => {
    component.loaded = false;
    component.loading = true;
    fixture.detectChanges();
    const tilesValues = elem.querySelectorAll('.tile-value');
    expect(tilesValues.length).toBe(1);
    expect(tilesValues[0].classList).toContain('k-i-loading');
  });
  it('should never show both loading spinner and value', () => {
    component.loaded = true;
    component.loading = true;
    fixture.detectChanges();
    const tilesValues = elem.querySelectorAll('.tile-value');
    expect(tilesValues.length).toBe(1);
    expect(tilesValues[0].classList).toContain('k-i-loading');
  });
  it('should show error icon if not loading or loaded', () => {
    component.loaded = false;
    component.loading = false;
    component.disabled = false;
    fixture.detectChanges();
    const tilesValues = elem.querySelectorAll('.tile-value');
    expect(tilesValues.length).toBe(1);
    expect(tilesValues[0].classList).toContain('k-i-warning');
  });

  it('should show summary tile if type = summary', () => {
    component.type = TileTypeEnum.Summary;
    fixture.detectChanges();
    expect(elem.querySelector('#chart-container')).toBeTruthy();
  });
  it('should only emit on click when has value || enabledOnEmpty', () => {
    const component = fixture.componentInstance;
    component.enabledOnEmpty = false;
    component.value = 123;
    spyOn(component.activeClick, 'emit');
    expect(component.activeClick.emit).toHaveBeenCalledTimes(0);
    elem.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    expect(component.activeClick.emit).toHaveBeenCalledTimes(1);
    component.enabledOnEmpty = false;
    component.value = 0;
    fixture.detectChanges();
    expect(component.activeClick.emit).toHaveBeenCalledTimes(1);
    component.enabledOnEmpty = true;
    component.value = 0;
    fixture.detectChanges();
    elem.dispatchEvent(new Event('click'));
    expect(component.activeClick.emit).toHaveBeenCalledTimes(2);
 });

});
