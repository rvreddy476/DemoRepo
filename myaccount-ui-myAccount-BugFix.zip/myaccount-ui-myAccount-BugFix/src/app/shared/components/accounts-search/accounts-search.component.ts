// import { SearchbarComponent } from './../searchbar/searchbar.component';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AccountsService } from '../../services/accounts.service';
import { IAccountsState } from '../../../core/accounts/store';
import { getIdentityID } from '../../store/selectors';
import { select, Store } from '@ngrx/store';
import { observable, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-2f82-accounts-search',
  templateUrl: './accounts-search.component.html',
  styleUrls: ['./accounts-search.component.scss'],
})
export class AccountsSearchComponent implements OnInit, OnDestroy {
  public suggestions;
  public message;
  public searchButtonDisabled = true;

  constructor(private accountsService: AccountsService, private store: Store<IAccountsState>, private router: Router) {}

  private idSub: Subscription;
  private id: any;

  public ngOnInit() {
    this.idSub = this.store.pipe(select(getIdentityID)).subscribe((id) => {
      this.id = id;
    });
  }

  public ngOnDestroy() {
    this.idSub.unsubscribe();
  }

  public Search(term) {

    this.searchButtonDisabled = term.length <= 3

    if (term.length > 3 && this.id !== null) {
      this.accountsService.getAccountsAutoSuggest(term).subscribe((res) => {
        // limit to 50 accounts
        
        if (res.length > 50) {
          res = res.slice(0, 50);
        }

        this.suggestions = res.map((r) => {
          return { id: r.id, text: `${r.directory ? (r.directory.domain + '\\') : ''}${r.name}` };
        });
        if (this.suggestions.length === 0) {
          this.message = 'SEARCH.MESSAGE.NO_MATCH';
        } else {
          this.message = null;
        }
      });
    } else {
      this.message = 'SEARCH.MESSAGE.ENTER_MIN_CHARACTERS';
      this.suggestions = [];
      this.searchButtonDisabled = true
    }
  }

  public SelectList(list) {
    this.router.navigate(['./accounts', { viewonly: JSON.stringify(list.map((x) => x.id).join(',')) }]);
  }

  public SelectSearch(term) {
    this.router.navigate(['./accounts', { term }]);
  }
}
