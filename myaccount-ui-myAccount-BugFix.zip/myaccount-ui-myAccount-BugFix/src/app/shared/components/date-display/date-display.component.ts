import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-2f82-date-display',
  templateUrl: './date-display.component.html',
  styleUrls: ['./date-display.component.scss']
})
export class DateDisplayComponent implements OnInit {

  constructor() { }

  @Input() public date: Date;
  @Input() public showTime = true;

  public ngOnInit() {
  }

}
