import { Component, OnInit, ElementRef, Input } from '@angular/core';
import { IBaseState } from '../../interfaces/base-state';
import { Store, select } from '@ngrx/store';
import { TAccountDelegationType } from '../../interfaces/shared/account/account';
import { Observable, of } from 'rxjs';
import { SetGlobalDelegationMode } from '../../store';
import { getGlobalDelegationMode } from '../../store/selectors';
import { map, tap } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-delegation-selection-panel',
  templateUrl: './delegation-selection-panel.component.html',
  styleUrls: ['./delegation-selection-panel.component.scss']
})
export class DelegationSelectionPanelComponent implements OnInit {

  constructor(private store: Store<IBaseState>, private hostElement: ElementRef) { }

  @Input()
  public showHelp = false;

  public class$: Observable<{
    direct: string[],
    indirect: string[],
    all: string[],
  }> = of({
    direct: [],
    indirect: [],
    all: [],
  });

  public ngOnInit() {
    this.class$ = this.store.pipe(select(getGlobalDelegationMode)).pipe(
      tap((del) => {
        (this.hostElement as any).nativeElement.hidden = ((del === 'DISABLED') || !del);
      }),
      map((del) => {
        return {
          direct: del === 'DIRECT' ? ['active'] : [],
          indirect: del === 'INDIRECT' ? ['active'] : [],
          all: del === 'ALL' ? ['active'] : [],
        };
      })
    );
  }

  public selectDelegation(delegation: TAccountDelegationType) {

    this.store.dispatch(new SetGlobalDelegationMode(delegation));
  }

}
