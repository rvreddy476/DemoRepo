import { FormControl } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges, ViewChild, HostListener, ElementRef } from '@angular/core';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-toggle-switch',
  templateUrl: './toggleswitch.component.html',
  styleUrls: ['./toggleswitch.component.scss'],
})
export class ToggleSwitchComponent {

  constructor() { }

  @Output()
  public handleSelection = new EventEmitter();


  public selectionChanged(e: any) {
    this.handleSelection.emit(e.target.checked);
  }

}
