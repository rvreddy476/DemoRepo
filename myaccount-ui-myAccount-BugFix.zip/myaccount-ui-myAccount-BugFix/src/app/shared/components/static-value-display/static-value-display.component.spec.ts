import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaticValueDisplayComponent } from './static-value-display.component';

describe('StaticValueDisplayComponent', () => {
  let component: StaticValueDisplayComponent;
  let fixture: ComponentFixture<StaticValueDisplayComponent>;
  let elem: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StaticValueDisplayComponent],
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(StaticValueDisplayComponent);
        component = fixture.componentInstance;
        elem = fixture.nativeElement;
        fixture.detectChanges();
      });
  }));

  it('should have label', () => {
    component.label = 'test label';
    fixture.detectChanges();
    const label = elem.querySelector('.static-label-container p').innerHTML;
    expect(label).toBe('test label');
  });
  it('should have value', () => {
    component.value = 'test value';
    fixture.detectChanges();
    const value = elem.querySelector('.static-value').innerHTML;
    expect(value).toBe('test value');
  });
  it('should have value "-" if value is null / undefined', () => {
    const value = elem.querySelector('.static-value').innerHTML;
    expect(value).toBe('-');
  });
});
