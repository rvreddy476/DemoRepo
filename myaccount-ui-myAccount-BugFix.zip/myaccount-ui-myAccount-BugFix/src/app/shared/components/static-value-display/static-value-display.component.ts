import { Component, OnInit, Input, ContentChild, TemplateRef, ElementRef, OnChanges } from '@angular/core';

@Component({
  selector: 'app-2f82-static-value-display',
  templateUrl: './static-value-display.component.html',
  styleUrls: ['./static-value-display.component.scss']
})
export class StaticValueDisplayComponent implements OnChanges {

  @ContentChild('customValue') public customValue: TemplateRef<ElementRef>;

  @Input()
  public label = '';

  @Input()
  public value: any;

  @Input()
  public dark = false;
  @Input()
  public labelIcon = null;

  public classNames = {
    invert: this.dark
  };

  public ctx = null;



  constructor() {}

  public ngOnChanges() {
    this.ctx = {
      value: this.value
    };
  }

}
