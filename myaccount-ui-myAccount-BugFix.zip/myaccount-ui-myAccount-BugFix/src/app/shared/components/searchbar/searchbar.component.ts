import { FormControl } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, OnChanges, ViewChild, HostListener, ElementRef } from '@angular/core';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.scss'],
})
export class SearchbarComponent implements OnChanges, OnInit {

  constructor(private eRef: ElementRef) {}
  public searchTerm = new FormControl();

  @Output()
  public search = new EventEmitter(); // fired when a new search term is typed (and waited for 400ms)
  @Output()
  public selectList = new EventEmitter(); // fired when user confirms list selection
  @Output()
  public selectSearch = new EventEmitter(); // fired when user presses enter in the search input field
  @Input()
  public message; // suggestion list RECEIVEd from parent
  @Input()
  public searchButtonDisabled = false; // suggestion list RECEIVEd from parent
  @Input()
  public preserveSelection = false; // suggestion list RECEIVEd from parent

  @Input()
  public list;
  @Input()
  public primaryField; // suggestion list RECEIVEd from parent
  @Input()
  public displayField;

  public checkedItems = [];
  public term;
  public dropdownOpen = false;
  public isLoading = false;

  @HostListener('document:click', ['$event'])
  public clickout(event) {
    if (this.eRef.nativeElement.contains(event.target)) {
      this.dropdownOpen = this.list.length > 0;
    } else {
      this.dropdownOpen = false;
    }
  }

  public ngOnInit() {
    this.searchTerm.valueChanges
      .pipe(debounceTime(400))
      .pipe(distinctUntilChanged())
      .subscribe((term) => {
        this.term = term;
        this.isLoading = true;
        this.search.emit(term);
      });
  }

  public ngOnChanges(changes: SimpleChanges) {
    this.isLoading = false;
    this.list = this.list || [];
    const previous = [];

    if (this.preserveSelection) {
      // set any previously selected list items to "checked"

      this.list = this.list.map((li) => {
        const checked = this.checkedItems.filter((sel) => sel[this.primaryField] === li[this.primaryField]).length > 0;
        if (checked) {
          previous.push(li[this.primaryField]);
        }
        return Object.assign(li, { checked });

        // create array of previously selected items which are not in the current list (add a previous:true state)
        const concat = this.checkedItems.filter((x) => previous.indexOf(x[this.primaryField]) === -1).map((x) => Object.assign(x, { previous: true }));

        // append previously selected items before the current list
        this.list = [...concat, ...this.list];
      });
    }

    this.dropdownOpen = this.list.length > 0;
  }

  public HandleChecked(event, suggestion) {
    if (event.srcElement.checked) {
      // add suggestion
      this.checkedItems.push(suggestion);
    } else {
      // remove suggestion
      this.checkedItems = this.checkedItems.filter((x) => x[this.primaryField] !== suggestion[this.primaryField]);
    }
  }

  public onClearSelection() {
    this.list = this.list.map((x) => Object.assign(x, { checked: false }));
    this.checkedItems = [];
  }
  public onConfirmSelection() {
    const selected = this.list.filter((x) => x.checked);
    this.selectList.emit(selected);
  }
}
