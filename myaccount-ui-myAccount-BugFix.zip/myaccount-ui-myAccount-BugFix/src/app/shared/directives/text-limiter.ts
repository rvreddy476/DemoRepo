import { Directive, ElementRef, OnInit, Output, EventEmitter, Renderer2, AfterViewInit, Input } from '@angular/core';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[limitLength]',
})
export class LimitLengthDirective implements AfterViewInit {
  private element: ElementRef;

  @Input()
  private limitLength = 10;

  constructor(elRef: ElementRef, renderer: Renderer2) {
    this.element = elRef;
  }

  public ngAfterViewInit() {
    const text: String = this.element.nativeElement.innerText;
    if (text.length > this.limitLength) {
      this.element.nativeElement.innerText = text.slice(0, this.limitLength) + '...';
    }
  }
}
