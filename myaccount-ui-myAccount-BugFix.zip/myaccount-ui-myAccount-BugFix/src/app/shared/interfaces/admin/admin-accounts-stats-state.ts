import { IAdminAccountsStats } from './admin-accounts-stats';

export interface IAdminAccountsStatsState {
  loading: boolean;
  loaded: boolean;
  data: IAdminAccountsStats;
}
