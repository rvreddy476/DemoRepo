import { IAdminAccountsStats } from './admin-accounts-stats';

export interface IAdminAccountsStatsAPI {
  status: {
    code: number;
    error: boolean;
    message: string;
    type: string;
  };
  data: IAdminAccountsStats;
}
