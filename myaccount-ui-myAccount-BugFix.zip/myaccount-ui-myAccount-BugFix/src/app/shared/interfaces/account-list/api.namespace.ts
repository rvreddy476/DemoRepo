export namespace AccList_API {
    export namespace IUpdateLifecycleStatus {
        export interface IReq {
            id: number;
            lifecycle_status: TLifecycleStatus;
            end_of_lifecycle_date: Date;
        }
        export interface IRes {
            error: boolean;
            message: string;
            type: string;
        }
    }
    export type TLifecycleStatus = 'enabled' | 'disabled' | 'created' | 'updated';
}
