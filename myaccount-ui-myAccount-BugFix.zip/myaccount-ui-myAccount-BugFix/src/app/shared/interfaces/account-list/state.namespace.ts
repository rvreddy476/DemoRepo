export interface AccList {

}
