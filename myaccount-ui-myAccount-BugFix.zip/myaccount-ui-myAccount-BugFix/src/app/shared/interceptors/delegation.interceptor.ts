import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, Subject, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { IBaseState } from '../interfaces/base-state';
import { Store, select } from '@ngrx/store';
import { TAccountDelegationType } from '../interfaces/shared/account/account';
import { getGlobalDelegationMode } from '../store/selectors';

/**
 * Attached the delegation header to requests for endpoints with values determined by the users delegation type selection
 * Normal acounts list is not included as all accounts are fetched in this case and labeled as direct or indirect during post-processing
 */
@Injectable({
  providedIn: 'root',
})
export class DelegationInterceptorService implements HttpInterceptor {
  constructor(private store: Store<IBaseState>) {
    store.pipe(select(getGlobalDelegationMode)).subscribe(delType => {
      this.DelegationType = delType;
    });
  }

  private DelegationWhitelist = [
    // /\/creation-followup/,
    /\/creation-requests/,
    /\/accounts-stats/,
    /\/accounts\/?$/,
    // /\/scheduled-followup/
  ];

  private DelegationType: TAccountDelegationType;


  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (this.DelegationWhitelist.some(wl => wl.test(request.url))) {

      const containsDelegationParam = /\?delegation=INDIRECT/.test(request.url);
      const delegationStatusLoaded = Boolean(this.DelegationType);

      // if (!delegationStatusLoaded && !containsDelegationParam) {
      //   return of(null)
      // }

      if (containsDelegationParam) {
        return next.handle(request);
      }

      if (this.DelegationType === 'DIRECT' || this.DelegationType === 'INDIRECT') {
        request = request.clone({
          setParams: {
            'delegation': this.DelegationType
          }
        });
      }

      return next.handle(request);
    }

    return next.handle(request);
  }
}
