import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { IBaseState } from '../interfaces/base-state';
import { ReceiveApiError } from '../store';
import { ApiErrorHandlerService } from '../services/api-error-handler.service';

@Injectable()
export class ErrorInterceptorService implements HttpInterceptor {
    constructor(private store: Store<IBaseState>, private apiErrorHandler: ApiErrorHandlerService) { }


    private handleRequest(event: HttpResponse<any>, method): HttpResponse<any> {

        if (!event) {
            return;
        }

        if (event.body ? event.body.status === undefined : true) {
            return event;
        }

        const match = this.apiErrorHandler.matchResponseToErrorMessage({
            url: event.url,
            code: event.status,
            type: event.body.status.type,
            method
        });

        // if the request corrosponded to no existng error messages in the error-configuration file
        // let the event pass through the interseptor unmodified
        if (!match) {
            return event;
        }
        if (!match.message) {
            return event;
        }

        let modifiedRequest: HttpResponse<any>

        // if request DOES corrospond to an error message:
        if (match.message) {
            
            if (!match.popup) {
                // redirect to error page. error-configuration file says SHOWPOPUP=FALSE for this type of request
                this.store.dispatch(new ReceiveApiError({ code: event.status, message: match.message, url: event.url }));
                return event
            }

            modifiedRequest = new HttpResponse({
                ...event,
                body: {
                    ...event.body,
                    status: {
                        ...event.body.status,
                        message: match.message,
                    }
                }
            })
        }
        return modifiedRequest
    }

    public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        return next.handle(req).pipe(

            map(
                (event: HttpResponse<any>, index) => {

                    // return this.handleRequest(event, req.method)
                    return this.handleRequest(event, req.method);
                },
                (err: HttpResponse<any>) => {

                    return this.handleRequest(err, req.method);
                }
            ),

            catchError(e => {
                e.body = e.error;
                const converted = this.handleRequest(e, req.method);
                throw converted;
            })
        );
    }
}
