import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';



@Injectable()
export class TimezoneOffsetInterceptorService implements HttpInterceptor {
  constructor() {}
  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (request.url.indexOf(environment.apiRootUrl.split('/api')[0]) !== -1) {
      request = request.clone({
        setHeaders: {
          'X-Timezone-Offset': new Date().getTimezoneOffset().toString(),
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
        }
      });
    }

    return next.handle(request);
  }
}
