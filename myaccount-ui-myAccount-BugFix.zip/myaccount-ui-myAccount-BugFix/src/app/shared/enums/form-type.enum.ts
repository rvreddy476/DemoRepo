export enum FormTypeEnum {
  Delete = 'Delete',
  Creation = 'Creation',
  Duplication = 'Duplication',
  Update = 'Update',
}
