export enum AccountTypeEnum {
  Service_Account = 'SA',
  Technical_Account = 'TA',
}
