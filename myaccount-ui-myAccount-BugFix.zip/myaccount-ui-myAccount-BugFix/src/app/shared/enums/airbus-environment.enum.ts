export enum AirbusEnvironmentEnum {
  PROD_LAN = 'PROD LAN',
  PROD_DMZ = 'PROD DMZ',
  VAL_LAN = 'VAL LAN',
  VAL_DMZ = 'VAL DMZ',
  INT_LAN = 'INT LAN',
  INT_DMZ = 'INT DMZ',
}
