export type TPreferredLanguage = 'EN' | 'FR' | 'DE' |'ES';
