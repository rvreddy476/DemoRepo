export enum TileTypeEnum {
  Summary = 'summary',
  Overview = 'overview',
  Action = 'action',
  Task = 'task',
}
