export enum AirbusDivisionEnum {
  CA = 'Airbus Commercial Aircraft',
  AH = 'Airbus Helicopter',
  ADS = 'Airbus Defense & Space',
}
