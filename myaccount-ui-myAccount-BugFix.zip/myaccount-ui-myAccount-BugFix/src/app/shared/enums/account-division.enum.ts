export enum AccountDivisionEnum {
  Commercial_Aircraft = 'ca',
  Helicopters = 'ah',
  Defence_and_Space = 'ads',
}
