
if (!String.prototype.padStart) {
    String.prototype.padStart = function padStart(targetLength,padString) {
        targetLength = targetLength>>0; //truncate if number or convert non-number to 0;
        padString = String((typeof padString !== 'undefined' ? padString : ' '));
        if (this.length > targetLength) {
            return String(this);
        }
        else {
            targetLength = targetLength-this.length;
            if (targetLength > padString.length) {
                padString += padString.repeat(targetLength/padString.length); //append to original to ensure we are longer than needed
            }
            return padString.slice(0,targetLength) + String(this);
        }
    };
}

(() => {
    const date = Date as any

    date.prototype.stdTimezoneOffset = function () {
        var jan = new Date(this.getFullYear(), 0, 1);
        var jul = new Date(this.getFullYear(), 6, 1);
        return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
    }
    
    date.prototype.dst = function() {
        return this.getTimezoneOffset() < this.stdTimezoneOffset();
    }
})()

export const dateToString = (date: Date = new Date()): string => {
    let [d, m, y, hr, min, tz] = [date.getDate(), date.getMonth(), date.getFullYear(), date.getHours(), date.getMinutes(), date.getTimezoneOffset()];
    const mStr = (m + 1).toString().padStart(2, '0');
    const minStr = min.toString().padStart(2, '0');
    const ampm = hr >= 12 ? 'PM' : 'AM';
    hr = (hr > 12) ? hr - 12 : hr;
    const tzStr = `${Math.floor(Math.abs(tz) / 60)}${tz % 60 > 0 ? `:${tz % 60}` : ''}`;
    const tzSign = (tz > 0) ? `-${tzStr}` : `+${tzStr}`;
    return `${d}/${mStr}/${y} ${hr}:${minStr} ${ampm} (GMT${tzSign})`;
};

/**
 * returns LASTNAME Firstname
 * @param displayName LASTNAME, Firstname (COMPANY)
 */
export const formatDisplayName = (displayName:string) => {
    // make sure the incomming string matches the expected display name format
    if(/\w*\,\s\w*(\s\([\w|\s]*\))?/g.test(displayName)){
        return displayName.replace(/(\w*)\,\s(\w*).*/g, (a,ln,fn) => {

            const lastName = ln ? ln.toLocaleUpperCase() : ''
            const firstName = fn ? `${fn[0].toLocaleUpperCase()}${fn.slice(1,fn.length).toLowerCase()}` : ''

            return `${lastName} ${firstName}`
        })
    }
    // else return origional string
    return displayName
}
