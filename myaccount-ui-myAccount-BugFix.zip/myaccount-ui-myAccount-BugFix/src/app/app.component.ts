import { AfterViewInit, Component, OnInit } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { select, Store } from '@ngrx/store';
import { IBaseState, TAPIError } from './shared/interfaces/base-state';
import { getApiErrors, getInitErrors, hasAdminOnlyRole, getIdentity, hasAdminRole } from './shared/store/selectors';
import { first, skip } from 'rxjs/operators';
import { NavigationStart, Router } from '@angular/router';
import { environment } from '../environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { LoadAccountsStats, ClearApiErrors } from './shared/store';
import { pipe } from 'rxjs';
import { functHasAdminRole } from './shared/store/selectors/base.selector';


//test
@Component({
  selector: 'app-2f82-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements AfterViewInit, OnInit {
  public mode:string='Enter Admin mode';
  public admin$ = this.store.select(hasAdminRole);
  constructor(private notificationService: NotificationService, private store: Store<IBaseState>, private router: Router, private translate: TranslateService) {
    (window as any).store = this.store;
  }

  public ngOnInit() {
    /*this.router.events.subscribe((url: any) =>{
      console.log(url);
      if(url.includes('admin')){
      this.mode=url; 
      console.log(url);
      }
    });*/
    // try retrieve the browser language from myx
    let myxLang = ''
    try {
      myxLang = (window as any).myx.languages.filter(l => l.selected)[0].key.toLocaleLowerCase()
    } catch {
      myxLang = null
      console.warn(`browser language not detected. using user identity prefferred language instead`)
    }

    this.store.pipe(select(getIdentity)).pipe(
      // if myx lang is valid then skip the first identity language emission
      skip(myxLang ? 1 : 0)
    ).subscribe((identity) => {
      const lang = identity.preferred_language.toLocaleLowerCase();
      this.translate.getTranslation(lang);
      this.translate.use(lang);
    });
    if (myxLang) {
      this.translate.getTranslation(myxLang);
      this.translate.use(myxLang);
    }

    // dont load delegation stats on homepage, the stats component will handle that.
    if (window.location.pathname !== '/') {

      this.store.dispatch(new LoadAccountsStats());
    }

    window.addEventListener('offline', () => {
      const queryParams: TAPIError = {
        code: 0,
        title: 'You are Offline',
        message: 'You appear to have been disconnected. Please check your connection and try again.',
      }
      this.router.navigate(['/error'], { queryParams });
    });

    window.addEventListener('online', () => {
      window.location.reload()
    });

  }
  public ngAfterViewInit() {
    // Show errors which occured during Initilisation
    setTimeout(() => {
      this.store
        .pipe(select(getInitErrors))
        .pipe(first())
        .subscribe((errors) => {
          if ((environment.enableErrorRedirect && errors.length > 0)) {
            this.router.navigate(['/error'], { queryParams: { msg: errors[0], title: 'Failed to retrieve all critical data required to load application' } });
          } else if (errors.length > 0) {
            this.openErrorPopup(errors.reverse());
          }
        });
    }, 500);

    this.store.pipe(select(getApiErrors)).subscribe((errors) => {
      if (environment.enableErrorRedirect && errors.length > 0) {
        this.router.navigate(['/error'], { queryParams: errors[0] });
        this.store.dispatch(new ClearApiErrors());
      } else if (errors.length > 0) {
        this.openErrorPopup(errors.reverse());
        this.store.dispatch(new ClearApiErrors());
      }
      if (errors.length > 0) {
        this.store.dispatch(new ClearApiErrors());
      }
    });

    // Redirect to Admin Section if user has ADMIN roles AND is root url (/)
    /* this.router.events.pipe(first()).subscribe((event) => {
       if (event instanceof NavigationStart && event.url === '/') {
         this.store.pipe(select(hasAdminOnlyRole)).subscribe((adminOnly) => {
           if (adminOnly) {
             this.router.navigate(['/admin']);
           }
         });
       }
     });*/
  }

  private openErrorPopup(errArray: TAPIError[]) {
    errArray.forEach((error) => {
      this.notificationService.show({
        content: `Error ${error.code ? error.code.toString() : ''}, ${error.message}`,
        position: { horizontal: 'right', vertical: 'bottom' },
        animation: { type: 'fade', duration: 500 },
        hideAfter: 10000,
        type: { style: 'error', icon: true },
      });
    });
  }
  public getState(outlet) {
    return outlet.activatedRouteData.state;
  }

  onAdminMode(val) {    
    this.router.navigate(['/admin']);
  }
}
