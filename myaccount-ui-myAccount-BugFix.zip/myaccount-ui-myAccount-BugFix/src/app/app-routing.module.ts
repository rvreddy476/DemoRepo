import { AccessUser } from './shared/route-guards/access-user';
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { HelpComponent } from './shared/views/help/help.component';
import { ErrorPageComponent } from './core/error-page/error-page.component';
import { AccessAdmin } from './shared/route-guards/access-admin';
import { Error404Component } from './core/error404/error404.component';
import { DocComponent } from './doc.component';
import { GdprPageComponent } from './core/gdpr-page/gdpr-page.component';
import { AccessDisclaimer } from './shared/route-guards/access-disclaimer';
import { PrivacyPolicyPageComponent } from './core/privacy-policy-page/privacy-policy-page.component';

export const APP_ROUTES: Routes = [
  {
    path: 'accounts',
    loadChildren: './core/accounts/accounts.module#AccountsModule',
    data: { state: 'accounts' },
    canLoad: [AccessUser, AccessDisclaimer],
  },
  {
    path: 'disclaimer',
    component: GdprPageComponent,
    canLoad: [],
  },
  {
    path: 'create',
    loadChildren: './core/create-account/create-account.module#CreateAccountModule',
    data: { state: 'createAccount' },
    canLoad: [AccessUser, AccessDisclaimer],
  },
  {
    path: 'help',
    component: HelpComponent,
    data: { state: 'help' },
  },
  {
    path: 'error',
    component: ErrorPageComponent,
    data: { state: 'error' },
  },
  {
    path: 'privacypolicy',
    component: PrivacyPolicyPageComponent,
  },
  {
    path: 'userguide',
    loadChildren: './core/user-guide/user-guide.module#UserGuideModule',
  },
  {
    path: 'doc',
    component: DocComponent,
    data: { state: 'doc' },
  },
  {
    path: 'admin',
    loadChildren: './core/admin/admin.module#AdminModule',
    canLoad:[AccessAdmin]
  },
  {
    path: '',
    loadChildren: './core/landing-page/landing-page.module#LandingPageModule',
    data: { state: 'user' },
    canLoad: [AccessUser, AccessDisclaimer],
  },
  {
    path: '**',
    component: Error404Component,
    data: { state: '404' },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(APP_ROUTES, { preloadingStrategy: PreloadAllModules })],
  // imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  exports: [RouterModule],
  providers: [AccessAdmin, AccessUser, AccessDisclaimer],
})
export class AppRoutingModule {}
