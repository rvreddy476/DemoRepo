/** GET FIELD KEY VALUE PATH */
export const GET_FIELD_KEY_VALUE_PATH = '../../assets/json/field_key_value.json';
