import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Field } from '../../shared/interfaces/field';

@Injectable({ providedIn: 'root' })
export class AppConfig {
  private fields: Field[];

  constructor(private readonly http: HttpClient) {}

  /** load application config */
  public load() {
    return this.http.get<Field[]>('src/app/config/errors-display/error_messages.json').subscribe((data) => {
      this.fields = data;
    });
  }

  public getValueByKey(key: string): string {
    return this.fields.find((t) => t.key === key).value;
  }
}
