import { IBaseState } from './shared/interfaces/base-state';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';

import { AppRoutingModule } from './app-routing.module';

import { NotificationModule } from '@progress/kendo-angular-notification';

import { AppComponent } from './app.component';

import { HomeComponent } from './shared/views/home/home.component';
import { SharedModule } from './modules/shared.module';

import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import * as store from './shared/store';
import { Store, StoreModule } from '@ngrx/store';
import { reducers } from './shared/store/reducers';

import { HelpComponent } from './shared/views/help/help.component';
import { Error404Component } from './core/error404/error404.component';
import { ErrorPageComponent } from './core/error-page/error-page.component';
import { environment } from '../environments/environment';
import { JWT_OPTIONS, JwtModule } from '@auth0/angular-jwt';
import { BrowserModule } from '@angular/platform-browser';
import { LoaderComponent } from './core/loader/loader.component';
import { LoaderInterceptorService } from './shared/interceptors/loader-interceptor';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { DocComponent } from './doc.component';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { initialise } from './shared/services/my-x';
import { TimezoneOffsetInterceptorService } from './shared/interceptors/timezone-interceptor';
import { ErrorInterceptorService } from './shared/interceptors/error.interceptor';
import { DelegationInterceptorService } from './shared/interceptors/delegation.interceptor';
import { ApiErrorHandlerService } from './shared/services/api-error-handler.service';
import { LanguageLoader } from './shared/services/language-loader';
import { GdprPageComponent } from './core/gdpr-page/gdpr-page.component';
import { PrivacyPolicyPageComponent } from './core/privacy-policy-page/privacy-policy-page.component';

@NgModule({
  declarations: [AppComponent, HomeComponent, HelpComponent, Error404Component, ErrorPageComponent, LoaderComponent, DocComponent, GdprPageComponent, PrivacyPolicyPageComponent],
  exports: [Error404Component],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    NotificationModule,
    SharedModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: LanguageLoader
      },
      isolate: false,
    }),
    EffectsModule.forRoot(store.effects),
    StoreModule.forRoot(reducers),
    StoreDevtoolsModule.instrument({
      name: 'My Account App',
      maxAge: 15,
    }),
    JwtModule.forRoot({
      jwtOptionsProvider: {
        provide: JWT_OPTIONS,
        useFactory: jwtOptionsFactory,
      },
    })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorInterceptorService,
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: authFactory,
      deps: [Store, HttpClient, ApiErrorHandlerService],
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TimezoneOffsetInterceptorService,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: DelegationInterceptorService,
      multi: true,
    },


  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

export function jwtOptionsFactory() {
  return {
    tokenGetter: () => {
      const token =  (window as any).sso.getAccessToken().then();
      return token;
    },
    throwNoTokenError: environment.isAuthActivated,
    skipWhenExpired: false,

    whitelistedDomains: environment.whitelist,
    blacklistedRoutes: environment.blacklist,
  };
}

export function authFactory(store: Store<IBaseState>, http: HttpClient, apiParser: ApiErrorHandlerService) {
  return () => initialise(store, http, apiParser);
}
