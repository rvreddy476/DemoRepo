import { IFollowUpState, TScheduledPasswordFollowUp, TActionFollowUp } from './../../../../shared/interfaces/shared/account/follow-up';
import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { getFollowUpActions, getFollowUpScheduled, OpenResetPassModal, SetSelectedAccounts, LoadAccountByIdFail, LoadAccountDetail } from '../../store';
import { openFollowUpModal, requestScheduledFollowUp } from '../../store/actions/follow-up-list.actions';
import { tap, filter } from 'rxjs/operators';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';

/**
 * This Component shows the list of accounts with scheduled password resets pending.
 */
@Component({
  selector: 'app-2f82-reset-password-scheduled-follow-up',
  templateUrl: './reset-password-scheduled-follow-up.component.html',
  styleUrls: ['./reset-password-scheduled-follow-up.component.scss'],
})
export class ResetPasswordScheduledFollowUpComponent implements OnInit, OnDestroy {

  constructor(private store: Store<IFollowUpState>) { }

  public $actions: Observable<TScheduledPasswordFollowUp[]>;

  private subs: Subscription[];

  public cols = {
    accountName: true,
    domain: true,
    requestor: true,
    validator: false,
    type: false,
    creationDate: true,
    scheduledDate: true,
    status: false,
    cancellable: true
  };


  public ngOnInit() {
    this.subs = [
      this.store.pipe(select(getGlobalDelegationMode)).pipe(
        filter(d => {
          return Boolean(d);
        }),
        tap(() => {
          this.store.dispatch(new requestScheduledFollowUp);
        })
      ).subscribe()
    ];

    this.$actions = this.store.pipe(select(getFollowUpScheduled));
  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }

  /**
   * default false for the kendu grid component as rows are not selectable in this table
  */
  public isRowSelected() {
    return () => false;
  }
  public rowClass(row) {
    return { followuprow: true };
  }

  /**
   * triggered when the user clicks the trash icon
   */
  public cancelAction = action => {
    this.store.dispatch(new openFollowUpModal(action));
  }

  /**
   * trigged when the user clicks the scheduled date
   * opens the re-sechdule modal with calander
   */
  public reschedule = (x) => {
    this.store.dispatch(new SetSelectedAccounts({ids: [x.accountId], isAll: false}));
    this.store.dispatch(new LoadAccountDetail(x.accountId))
    this.store.dispatch(new OpenResetPassModal());
  }

}
