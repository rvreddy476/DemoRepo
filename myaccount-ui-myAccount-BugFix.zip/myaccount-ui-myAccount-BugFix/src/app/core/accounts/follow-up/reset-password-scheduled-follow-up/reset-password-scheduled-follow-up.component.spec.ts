import { getAccountDetail } from './../../store/selectors/index';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { FollowUpModalComponent } from '../../components/follow-up-modal/follow-up-modal.component';
import { HourglassIconComponent } from 'src/app/shared/icons/hourglass-icon/hourglass-icon.component';
import { IconModule } from 'src/app/modules/icon.module';
import { PageTitleComponent } from 'src/app/shared/components/page-title/page-title.component';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { FollowUpBaseComponent } from '../follow-up-base/follow-up-base.component';
import { followUpStatus, followActionType, TScheduledPasswordFollowUp, TActionFollowUp } from 'src/app/shared/interfaces/shared/account/follow-up';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ResetPasswordScheduledFollowUpComponent } from './reset-password-scheduled-follow-up.component';
import { mockFollowUp } from '../follow-up-base/follow-up-base.component.spec';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { DelegationSelectionPanelComponent } from 'src/app/shared/components/delegation-selection-panel/delegation-selection-panel.component';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';

const scheduledResets: TScheduledPasswordFollowUp[] = [
  {
    id: 1374,
    accountId: 2590207,
    accountName: 'SA-2F82-SCHEDULED2-I',
    creationDate: new Date('2019-11-20T08:01:25.520Z'),
    scheduledDate: new Date('2019-11-30T19:30:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1375,
    accountId: 2581319,
    accountName: 'SA-2F82-TEST555-I',
    creationDate: new Date('2019-11-20T08:01:39.606Z'),
    scheduledDate: new Date('2019-11-29T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1376,
    accountId: 2186660,
    accountName: 'SA-2F82-TTT111-I',
    creationDate: new Date('2019-11-20T08:01:53.100Z'),
    scheduledDate: new Date('2019-11-30T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1377,
    accountId: 2591330,
    accountName: 'SA-2F82-TOBEAPPRO3-I',
    creationDate: new Date('2019-11-20T08:01:53.130Z'),
    scheduledDate: new Date('2019-11-30T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  }
];

const modalOpenState = {
  action: {
    id: 1274,
    accountId: 2186828,
    accountName: 'SA-2F82-DEMOSPRINT-I',
    creationDate: new Date('2019-11-05T14:51:07.360Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    justification:'',
    lastUpdatedDate: new Date('2019-11-05T14:51:07.360Z'),
    requestor: {
      displayName: 'BIDA, Djamal (COMPUTACENTER AG COOHG)',
      id: 229696
    },
    status: 'SCHEDULED' as followUpStatus,
    message: 'No Comment Available',
    type: 'ACCOUNT_RESET_PASSWORD' as followActionType,
    validators: [],
    cancellable: true
  },
  loading: false,
  res: null,
  open: true
};

describe('ResetScheduledComponent', () => {
  let component: ResetPasswordScheduledFollowUpComponent;
  let fixture: ComponentFixture<ResetPasswordScheduledFollowUpComponent>;
  let elem: HTMLElement;
  const initialState: AppState = {...defaultTestStore, accountsModule: {...defaultTestStore.accountsModule, followUpList: {...defaultTestStore.accountsModule.followUpList, scheduledResets: mockFollowUp.scheduledResets}}};

  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule, NoopAnimationsModule],
      providers: [
        provideMockStore({ initialState })
      ],
      declarations: [ResetPasswordScheduledFollowUpComponent, FollowUpModalComponent, PageTitleComponent, BaseModalComponent, FollowUpBaseComponent, DateDisplayComponent, DelegationSelectionPanelComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(ResetPasswordScheduledFollowUpComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      store = TestBed.get(Store);
      fixture.detectChanges();
      // console.log(elem.innerHTML)
    });
  }));
  it('has the correct title', () => {
    fixture.detectChanges();
    expect(elem.querySelectorAll('h1')[0].innerHTML).toBe('FOLLOW_UP.SCHEDULED.PAGE_TITLE');
  });
  it('check trash icon appears for every action', () => {
    store.setState({...initialState, accountsModule: {...initialState.accountsModule, followUpList: {...initialState.accountsModule.followUpList, scheduledResets}}});
    fixture.detectChanges();
    expect(elem.querySelectorAll('app-2f82-trash-icon').length).toBe(scheduledResets.length);
  });
  it('check cancel modal Appears', () => {
    fixture.detectChanges();
    defaultTestStore.accountsModule.followUpList.modal = modalOpenState;
    store.setState(defaultTestStore);
    fixture.detectChanges();
    expect(elem.querySelectorAll('.k-content.k-window-content.k-dialog-content').length).toBe(1);
  });
});
