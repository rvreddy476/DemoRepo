import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { getFollowUpActions } from '../../store';
import { requestActionFollowUp, openFollowUpModal } from '../../store/actions/follow-up-list.actions';
import { tap, filter } from 'rxjs/operators';
import { TActionFollowUp, IFollowUpState } from '../../../../shared/interfaces/shared/account/follow-up';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';

@Component({
  selector: 'app-2f82-action-follow-up',
  templateUrl: './action-follow-up.component.html',
  styleUrls: ['./action-follow-up.component.scss'],
})
export class ActionFollowUpComponent implements OnInit, OnDestroy {

  constructor(private store: Store<IFollowUpState>) { }

  public $actions: Observable<TActionFollowUp[]>;

  private subs: Subscription[];

  public cols = {
    accountName: true,
    domain: true,
    requestor: true,
    validator: true,
    type: true,
    creationDate: true,
    scheduledDate: false,
    status: true,
    justification:true,
    cancellable: true
  };


  public ngOnInit() {
    this.subs = [
      this.store.pipe(select(getGlobalDelegationMode)).pipe(
        filter((d) => {
          return Boolean(d);
        }),
        tap(() => {
          this.store.dispatch(new requestActionFollowUp);
        })
      ).subscribe()
    ];
    
    this.$actions = this.store.pipe(
      select(getFollowUpActions)
    );
  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }

  public isRowSelected() {
    return () => false;
  }
  public rowClass(row) {
    return { followuprow: true };
  }

  public cancelAction = action => {
    this.store.dispatch(new openFollowUpModal(action));
  }

  public showDetail = elem => {
    elem.srcElement.closest('.detail-wrapper').classList.toggle('detail-open');
  }
}
