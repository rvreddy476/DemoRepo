import { getAccountDetail } from './../../store/selectors/index';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { ActionFollowUpComponent } from './action-follow-up.component';
import { FollowUpModalComponent } from '../../components/follow-up-modal/follow-up-modal.component';
import { HourglassIconComponent } from 'src/app/shared/icons/hourglass-icon/hourglass-icon.component';
import { IconModule } from 'src/app/modules/icon.module';
import { PageTitleComponent } from 'src/app/shared/components/page-title/page-title.component';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { FollowUpBaseComponent } from '../follow-up-base/follow-up-base.component';
import { followUpStatus, followActionType } from 'src/app/shared/interfaces/shared/account/follow-up';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { openFollowUpModal } from '../../store/actions/follow-up-list.actions';
import { mockFollowUp } from '../follow-up-base/follow-up-base.component.spec';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { DelegationSelectionPanelComponent } from 'src/app/shared/components/delegation-selection-panel/delegation-selection-panel.component';

const modalOpenState = {
  action: {
    id: 1274,
    accountId: 2186828,
    accountName: 'SA-2F82-DEMOSPRINT-I',
    creationDate: new Date('2019-11-05T14:51:07.360Z'),
    justification: '',
    domain: {
      id: 1,
      name: 'EU-I'
    },
    lastUpdatedDate: new Date('2019-11-05T14:51:07.360Z'),
    requestor: {
      displayName: 'BIDA, Djamal (COMPUTACENTER AG COOHG)',
      id: 229696
    },
    status: 'SCHEDULED' as followUpStatus,
    message: 'No Comment Available',
    type: 'ACCOUNT_RESET_PASSWORD' as followActionType,
    validators: [],
    cancellable: true,
  },
  loading: false,
  res: null,
  open: true
};

describe('ActionFollowUpComponent', () => {
  let component: ActionFollowUpComponent;
  let fixture: ComponentFixture<ActionFollowUpComponent>;
  let elem: HTMLElement;
  const initialState: AppState = {...defaultTestStore, accountsModule: {...defaultTestStore.accountsModule, followUpList: {...defaultTestStore.accountsModule.followUpList, actions: mockFollowUp.actions}}};
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule, NoopAnimationsModule],
      providers: [
        provideMockStore({ initialState })
      ],
      declarations: [ActionFollowUpComponent, FollowUpModalComponent, PageTitleComponent, BaseModalComponent, FollowUpBaseComponent, DateDisplayComponent, DelegationSelectionPanelComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(ActionFollowUpComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      store = TestBed.get(Store);
      spyOn(store, 'dispatch').and.callThrough();
      fixture.detectChanges();
    });
  }));
  it('has the correct title', () => {
    fixture.detectChanges();
    expect(elem.querySelectorAll('h1')[0].innerHTML).toBe('FOLLOW_UP.ACTION.PAGE_TITLE');
  });
  it('check correct number of rows exist', () => {
    fixture.detectChanges();
    expect(elem.querySelectorAll('.followuprow').length).toBe(mockFollowUp.actions.length);
  });
  it('check cancellable icon extsts', () => {
    fixture.detectChanges();
    const cancellable = mockFollowUp.actions.filter(a => a.cancellable);
    expect(cancellable.length).toBeGreaterThan(0);
    expect(elem.querySelectorAll('app-2f82-trash-icon').length).toBe(cancellable.length);
  });
  it('check cancel modal Appears', () => {
    fixture.detectChanges();
    defaultTestStore.accountsModule.followUpList.modal = modalOpenState;
    store.setState(defaultTestStore);
    fixture.detectChanges();
    expect(elem.querySelectorAll('.k-content.k-window-content.k-dialog-content').length).toBe(1);
  });
  it('dispatch on cancel action', () => {
    const actionItem = defaultTestStore.accountsModule.followUpList.actions.filter(a => a.cancellable)[0];
    const storeAction = new openFollowUpModal(actionItem);
    component.cancelAction(actionItem);
    expect(store.dispatch).toHaveBeenCalledWith(storeAction);
  });
});
