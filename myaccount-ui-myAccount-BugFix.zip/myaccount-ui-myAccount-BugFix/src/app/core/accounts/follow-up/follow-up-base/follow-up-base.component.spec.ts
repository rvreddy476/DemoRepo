
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KendoModule } from 'src/app/modules/kendo.module';
import { FollowUpModalComponent } from '../../components/follow-up-modal/follow-up-modal.component';
import { HourglassIconComponent } from 'src/app/shared/icons/hourglass-icon/hourglass-icon.component';
import { IconModule } from 'src/app/modules/icon.module';
import { PageTitleComponent } from 'src/app/shared/components/page-title/page-title.component';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { FollowUpBaseComponent } from '../follow-up-base/follow-up-base.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore } from '@ngrx/store/testing';
import { AppState } from 'src/app/shared/store';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { of } from 'rxjs';
import { TScheduledPasswordFollowUp, TActionFollowUp } from '../../../../shared/interfaces/shared/account/follow-up';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { DelegationSelectionPanelComponent } from 'src/app/shared/components/delegation-selection-panel/delegation-selection-panel.component';

const scheduledResets: TScheduledPasswordFollowUp[] = [
  {
    id: 1374,
    accountId: 2590207,
    accountName: 'SA-2F82-SCHEDULED2-I',
    creationDate: new Date('2019-11-20T08:01:25.520Z'),
    scheduledDate: new Date('2019-11-30T19:30:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1375,
    accountId: 2581319,
    accountName: 'SA-2F82-TEST555-I',
    creationDate: new Date('2019-11-20T08:01:39.606Z'),
    scheduledDate: new Date('2019-11-29T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1376,
    accountId: 2186660,
    accountName: 'SA-2F82-TTT111-I',
    creationDate: new Date('2019-11-20T08:01:53.100Z'),
    scheduledDate: new Date('2019-11-30T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  },
  {
    id: 1377,
    accountId: 2591330,
    accountName: 'SA-2F82-TOBEAPPRO3-I',
    creationDate: new Date('2019-11-20T08:01:53.130Z'),
    scheduledDate: new Date('2019-11-30T04:25:00.000Z'),
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    type: 'ACCOUNT_RESET_PASSWORD',
    cancellable: true
  }
];
const actions: TActionFollowUp[] = [
  {
    id: 1292,
    accountId: 2591224,
    accountName: 'SA-2F82-APPROVED4-I',
    creationDate: new Date('2019-11-06T10:57:25.663Z'),
    justification:'test justification message',
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    status: 'DONE',
    message: 'The account SA-2F82-APPROVED4-I was successfully created.',
    validators: [
      {
        displayName: 'DEVANT, Stephane (COMPUTACENTER AG COOHG)',
        id: 276749
      }
    ],
    type: 'ACCOUNT_CREATION',
    cancellable: false
  },
  {
    id: 1294,
    accountId: null,
    accountName: 'SA-2F82-REJECTED4-I',
    creationDate: new Date('2019-11-06T10:57:45.803Z'),
    justification:'test justification message',
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    status: 'REJECTED',
    message: 'TEST',
    validators: [
      {
        displayName: 'DEVANT, Stephane (COMPUTACENTER AG COOHG)',
        id: 276749
      }
    ],
    type: 'ACCOUNT_CREATION',
    cancellable: false
  },
  {
    id: 1296,
    accountId: null,
    accountName: 'SA-2F82-TOBEAPPRO4-I',
    creationDate: new Date('2019-11-06T10:58:06.026Z'),
    justification:'test justification message',
    domain: {
      id: 1,
      name: 'EU-I'
    },
    requestor: {
      displayName: 'MCBRYDE, Justin (DEVOTEAM)',
      id: 367825
    },
    status: 'TO_BE_APPROVED',
    message: 'No Comment Available',
    validators: [
      {
        displayName: 'DIEUL, Alexandre (INFOTEL CONSEIL)',
        id: 174901
      },
      {
        displayName: 'BIDA, Djamal (COMPUTACENTER AG COOHG)',
        id: 229696
      },
      {
        displayName: 'CALMELS, Thierry (CAPGEMINI TECHNOLOGY SERVICES DIVISION AEROSPATIALE ET DEFEN)',
        id: 140453
      },
      {
        displayName: 'DEVANT, Stephane (COMPUTACENTER AG COOHG)',
        id: 276749
      },
      {
        displayName: 'JAOUEN, JULIEN',
        id: 282976
      },
      {
        displayName: 'GASPERI, Benjamin',
        id: 358480
      },
      {
        displayName: 'MERGHOUB, Yacine (INFOTEL CONSEIL)',
        id: 358480
      }
    ],
    type: 'ACCOUNT_CREATION',
    cancellable: true
  },
];
export const mockFollowUp = {
  scheduledResets,
  actions
};

const initialState: AppState = defaultTestStore;

describe('FollowUpBaseComponent', () => {
  let component: FollowUpBaseComponent;
  let fixture: ComponentFixture<FollowUpBaseComponent>;
  let elem: HTMLElement;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule, NoopAnimationsModule],
      providers: [
        provideMockStore({ initialState })
      ],
      declarations: [FollowUpBaseComponent, FollowUpModalComponent, PageTitleComponent, BaseModalComponent, FollowUpBaseComponent, DateDisplayComponent, DelegationSelectionPanelComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(FollowUpBaseComponent);
      component = fixture.componentInstance;
      component.$actions = of(actions);
      elem = fixture.nativeElement;
      fixture.detectChanges();

    });
  }));
  it('displays the title', () => {
    const title = 'Test Title';
    component.title = title;
    fixture.detectChanges();
    expect(elem.querySelectorAll('h1')[0].textContent).toBe(title);
  });
  it('displays correct colunms title for action list data', () => {
    component.$actions = of(actions);
    component.colunms = {
      accountName: true,
      domain: true,
      requestor: true,
      validator: false,
      type: true,
      creationDate: true,
      justification:true,
      scheduledDate: false,
      status: true,
      cancellable: true
    };
    fixture.detectChanges();
    const titleCells = elem.querySelectorAll('th[role="columnheader"]');
    const titleTextArr = [];
    titleCells.forEach(title => titleTextArr.push(title.textContent));
    expect(titleTextArr).toEqual([
      'FOLLOW_UP.TABLE_LABEL.DOMAIN',
      'FOLLOW_UP.TABLE_LABEL.NAME',
      'FOLLOW_UP.TABLE_LABEL.INITIATOR',
      'FOLLOW_UP.TABLE_LABEL.DATE',
      "FOLLOW_UP.TABLE_LABEL.JUSTIFICATION",
      'FOLLOW_UP.TABLE_LABEL.STATUS',
    ]);
    // const titleCells = elem.querySelectorAll('th[role="columnheader"]')
    // expect(titleCells[0].textContent).toBe('FOLLOW_UP.TABLE_LABEL.NAME');
    // expect(titleCells[1].textContent).toBe('FOLLOW_UP.TABLE_LABEL.DOMAIN');
    // expect(titleCells[2].textContent).toBe('FOLLOW_UP.TABLE_LABEL.INITIATOR');
    // expect(titleCells[3].textContent).toBe('FOLLOW_UP.TABLE_LABEL.TYPE');
    // expect(titleCells[4].textContent).toBe('FOLLOW_UP.TABLE_LABEL.DATE');
    // expect(titleCells[5].textContent).toBe('FOLLOW_UP.TABLE_LABEL.STATUS');
  });
  it('displays correct colunm titles for action scheduled list data', () => {
    component.$actions = of(scheduledResets);
    component.colunms = {
      accountName: true,
      domain: true,
      requestor: true,
      validator: false,
      type: true,
      creationDate: true,
      justification:true,
      scheduledDate: true,
      status: false,
      cancellable: true
    };
    component.ngOnInit();
    fixture.detectChanges();
    expect(elem.querySelectorAll('.followuprow').length).toBe(scheduledResets.length);
    const titleCells = elem.querySelectorAll('th[role="columnheader"]');
    const titleTextArr = [];
    titleCells.forEach(title => titleTextArr.push(title.textContent));
    expect(titleTextArr).toEqual([
      'FOLLOW_UP.TABLE_LABEL.DOMAIN',
      'FOLLOW_UP.TABLE_LABEL.NAME',
      'FOLLOW_UP.TABLE_LABEL.INITIATOR',
      'FOLLOW_UP.TABLE_LABEL.DATE',
      'FOLLOW_UP.TABLE_LABEL.SCHEDULED_DATE',
      'FOLLOW_UP.TABLE_LABEL.JUSTIFICATION',
      ''
    ]);
  });
  it('displays content in all table cell rows for action followup data', () => {
    component.$actions = of(actions);
    component.colunms = {
      accountName: true,
      domain: true,
      requestor: true,
      validator: false,
      type: true,
      creationDate: true,
      justification:true,
      scheduledDate: false,
      status: true,
      cancellable: true
    };
    fixture.detectChanges();
    const firstRowCells = elem.querySelectorAll('.followuprow')[0].querySelectorAll('[role=gridcell]');
    expect(firstRowCells[0].textContent).toBe(actions[0].domain.name);
    expect(firstRowCells[1].textContent).toBe(actions[0].accountName);
    expect(firstRowCells[2].textContent).toBe("MCBRYDE Justin");
    expect(firstRowCells[3].textContent).toMatch(/^\d{2}\/\d{2}\/\d{4}\s\d{1,2}:\d{2}\s[PAM]{2}\s\(GMT\+\d\)/);
    expect(firstRowCells[4].textContent).toBe('test justification message');
    // expect(firstRowCells[5].textContent).toMatch(/^\d{2}\/\d{2}\/\d{4}\s\d{2}:\d{2}$/)
    expect(firstRowCells[5].textContent).toContain(actions[0].status);
  });
  it('check correct number of rows exist', () => {
    component.$actions = of(actions);
    component.colunms = {
      accountName: true,
      domain: true,
      requestor: true,
      validator: false,
      type: true,
      creationDate: true,
      justification:true,
      scheduledDate: false,
      status: true,
      cancellable: true
    };
    fixture.detectChanges();
    expect(elem.querySelectorAll('.followuprow').length).toBe(actions.length);
  });

  it('check emits "cancelAction" event on click of trach icon', () => {
    component.$actions = of(actions);
    component.colunms = {
      accountName: true,
      domain: true,
      requestor: true,
      validator: false,
      type: true,
      creationDate: true,
      justification:true,
      scheduledDate: false,
      status: true,
      cancellable: true
    };
    fixture.detectChanges();
    spyOn(component.cancelAction, 'emit');
    expect(component.cancelAction.emit).toHaveBeenCalledTimes(0);
    const firstTrashIcon = elem.querySelectorAll('app-2f82-trash-icon')[0];
    firstTrashIcon.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    expect(component.cancelAction.emit).toHaveBeenCalledTimes(1);
  });
});
