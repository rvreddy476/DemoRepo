import { Component, OnInit, ViewChild, ElementRef, AfterContentInit, AfterViewInit, Input } from '@angular/core';
import { IAccountsListState, IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { EditAccountDescription, getEditDescriptionModal, getAccountDetail, CloseEditDescriptionModal, getPasswordReceiverModal, EditPasswordReceiver, ClosePasswordReceiverModal } from '../../store';
import { map, tap } from 'rxjs/operators';
import { Observable, fromEvent, combineLatest, of } from 'rxjs';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';

@Component({
  selector: 'app-edit-password-receiver-modal',
  templateUrl: './edit-password-receiver-modal.component.html',
  styleUrls: ['./edit-password-receiver-modal.component.scss']
})
export class EditPasswordReceiverComponent implements OnInit, AfterViewInit {

  @Input('email') emailToBeDeleted: string;

  @ViewChild('email') emailElem: ElementRef
  public editPasswordModal$: Observable<{
    open: boolean;
    response: IResStatus;
    loading: boolean;
    action: 'ADD' | 'DELETE'
  }>;
  public account$: Observable<IAccount>;

  public descInput$;
  public saveBtnActive$ = of(false);
  public localModal$ = of({ title: 'ACCOUNT_DETAIL.EDIT_DESCRIPTION.MODAL.TITLE', icon: null, inputMode: true });


  constructor(private store: Store<IAccountsListState>) {
    this.editPasswordModal$ = this.store.pipe(select(getPasswordReceiverModal));
    this.account$ = this.store.pipe(select(getAccountDetail));
    this.localModal$ = this.editPasswordModal$.pipe(
      map(modal => {
        if (modal.loading) {
          return {
            title: 'DASHBOARD.LOADING',
            icon: 'Loading',
            inputMode: false
          };
        }
        if (modal.response ? modal.response.error === false : false) {
          return {
            title: modal.response.message,
            icon: 'Success',
            inputMode: false
          };
        }
        if (modal.response ? modal.response.error === true : false) {
          return {
            title: modal.response.message,
            icon: 'Failed',
            inputMode: false
          };
        }
        return {
          title: 'ACCOUNT_DETAIL.PASSWORD_RECEIVER.MODAL.TITLE',
          icon: null,
          inputMode: true,
          action: modal.action
        };
      })
    );
  }

  public ngAfterViewInit() {
    this.descInput$ = fromEvent(this.emailElem.nativeElement, 'input');
    this.saveBtnActive$ = combineLatest(this.descInput$, this.store.pipe(select(getAccountDetail))).pipe(
      map(([inputElem, acc]) => {
        let regexp = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
        const val = (inputElem as any).target.value;

        return !acc.password_receivers.includes(val) && regexp.test(val)
      })
    );
  }



  public saveDesc(action) {
    const email = this.emailElem.nativeElement.value
    this.store.dispatch(new EditPasswordReceiver({ email, action }));
  }
  public DeletePasswordReceiver(action) {
    this.store.dispatch(new EditPasswordReceiver({ email: this.emailToBeDeleted, action }));
  }

  public closeModal() {
    this.store.dispatch(new ClosePasswordReceiverModal());
  }

  public ngOnInit() {
  }

}
