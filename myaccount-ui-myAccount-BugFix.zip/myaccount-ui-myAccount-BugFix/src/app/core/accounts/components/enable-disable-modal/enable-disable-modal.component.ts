import { Component, OnInit, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { BehaviorSubject, combineLatest, Subscription, timer } from 'rxjs';
import { getEnableDisableModal, getSelectedAccountsList, CloseEnableDisableModal, EnableAccounts, DisableAccounts } from '../../store';
import { select, Store } from '@ngrx/store';
import { IAccountsListState, IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { map, withLatestFrom, takeWhile } from 'rxjs/operators';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';

@Component({
  selector: 'app-enable-disable-modal',
  templateUrl: './enable-disable-modal.component.html',
  styleUrls: ['./enable-disable-modal.component.scss']
})
export class EnableDisableModalComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('Modal') private modalElement: BaseModalComponent;

  constructor(private store: Store<IAccountsListState>) { }

  private subs: Subscription[] = [];

  private $modal = this.store.pipe(select(getEnableDisableModal));
  private viewSelection$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private $selected = this.store.pipe(select(getSelectedAccountsList));

  private previousSelection: IAccount[] = [];

  public remainimgSeconds$ = combineLatest(timer(15, 1000), this.$selected).pipe(
    takeWhile(([t, sel]) => t < 16),
    map(([t, sel]) => {
      return sel.length > 1 ? (15 - t) : 0;
    }),
  );

  public modalState$ = combineLatest(this.$modal, this.$selected, this.viewSelection$).pipe(
    map(([modal, selected, viewSelection]) => {

      // Dont overrite Selected list if it is empty. (becuase deselection occurs after successful request)
      if (selected.length > 0) { this.previousSelection = selected; }
      selected = this.previousSelection;

      let screen: 'view-selection' | 'enable-confirm' | 'enable-success' | 'enable-success-status' | 'disable-confirm' | 'disable-success' | 'disable-success-status' = null;
      let title = '';
      let largeIcon = null;
      const titleIcon = null;
      const loading = false;
      let messageParams = {};
      let message = null;
      const status: {
        acc: string;
        msg: string;
        outcome: 'FAILED' | 'SUCCESS'
      }[] = [];

      messageParams = {

        acc: selected[0] ? `${selected[0].directoryDomain}\\${selected[0].uid}` : 0,
        accs: selected.length.toString(),
      };

      if (viewSelection) {
        // show VIEW SELECTION page
        title = modal.mode === 'Enable' ? 'ENABLE_ACC.MODAL.VIEW_SELECTION.TITLE' : 'DISABLE_ACC.MODAL.VIEW_SELECTION.TITLE';
        screen = 'view-selection';

      } else if (!modal.response) {
        // there is no response
        if (!modal.loading) {

          // CONFIRM page
          const multiAccs = selected.length > 1;
          switch (multiAccs) {
            case true:
              message = modal.mode === 'Enable' ? 'ENABLE_ACC.MODAL.CONFIRM.MESSAGE.MULTI' : 'DISABLE_ACC.MODAL.CONFIRM.MESSAGE.MULTI';
              break;
            case false:
              message = modal.mode === 'Enable' ? 'ENABLE_ACC.MODAL.CONFIRM.MESSAGE.SINGLE' : 'DISABLE_ACC.MODAL.CONFIRM.MESSAGE.SINGLE';
              break;
          }

          title = modal.mode === 'Enable' ? 'ENABLE_ACC.MODAL.CONFIRM.TITLE' : 'DISABLE_ACC.MODAL.CONFIRM.TITLE';
          screen = modal.mode === 'Enable' ? 'enable-confirm' : 'disable-confirm';


        } else {
          // LOADING page
          title = 'GLOBAL.LOADING';
          largeIcon = 'Loading';
        }
      } else {
        if (modal.response.error !== false) {
          // request FAILED page
          title = modal.mode === 'Enable' ? 'ENABLE_ACC.MODAL.FAILED_TITLE' : 'DISABLE_ACC.MODAL.FAILED_TITLE';
          largeIcon = 'Failed';
        } else {
          // Request Success Page
          const singleMulti = selected.length > 1 ? 'MULTI' : 'SINGLE';
          title = modal.mode === 'Enable' ? `ENABLE_ACC.MODAL.SUCCESS.TITLE` : `DISABLE_ACC.MODAL.SUCCESS.TITLE`;
          message = modal.mode === 'Enable' ? `ENABLE_ACC.MODAL.SUCCESS.MESSAGE.${singleMulti}` : `DISABLE_ACC.MODAL.SUCCESS.MESSAGE.${singleMulti}`;
          screen = modal.mode === 'Enable' ? 'enable-success' : 'disable-success';
          largeIcon = 'Success';
        }
      }

      return {
        screen,
        title,
        largeIcon,
        loading,
        titleIcon,
        message,
        messageParams,
        status
      };
    })
  );

  public screen$: BehaviorSubject<'view-selection' | 'enable-confirm' | 'enable-success' | 'disable-confirm' | 'disable-success'>;

  public ngAfterViewInit() {
    this.subs.push(
      this.modalElement.close.pipe(
        withLatestFrom(this.viewSelection$),
        map(([a, selection]) => {
          if (!selection) {
            this.store.dispatch(new CloseEnableDisableModal());
            return;
          }
          if (selection) {
            this.viewSelection$.next(false);
            return;
          }
        })
      ).subscribe()
    );
  }

  public ngOnDestroy() {
    this.subs;
  }

  public ngOnInit() {
  }


  public showSelection(open = true) {
    this.viewSelection$.next(open);
  }
  public closeModal() {
    this.store.dispatch(new CloseEnableDisableModal());
  }

  public enableAccs() {
    this.store.dispatch(new EnableAccounts());
  }
  public disableAccs() {
    this.store.dispatch(new DisableAccounts());
  }

}
