import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAccountsState, CloseSelectionLimitModal } from '../../store';
import { CloseSelectionLimitModalApprRej } from '../../store/actions/approve-list.actions';

@Component({
  selector: 'app-selection-limit-modal',
  templateUrl: './selection-limit-modal.component.html',
  styleUrls: ['./selection-limit-modal.component.scss']
})
export class SelectionLimitModalComponent implements OnInit {

  constructor(private store:Store<IAccountsState>) { }

  ngOnInit() {
  }

  public closeModal(){
    this.store.dispatch( new CloseSelectionLimitModal)
    this.store.dispatch( new CloseSelectionLimitModalApprRej)
  }

}
