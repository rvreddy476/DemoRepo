import { CloseAddRemoveDeputyModal, searchAccountDeputityForModal, setSelectedDeputitiesModal, AddAccountDeputies, RemoveAccountDeputies } from './../../store/actions/accounts-list.actions';
import { Component, OnInit, EventEmitter, OnDestroy, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { getAddRemoveDeputiesModal, getSelectedAccountsList } from '../../store';
import { pluck, map, debounceTime, withLatestFrom } from 'rxjs/operators';
import { Observable, of, BehaviorSubject, combineLatest, Subscription, fromEvent } from 'rxjs';
import { IBulkAddDeputyApiElem } from 'src/app/shared/interfaces/shared/common/identity';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { TranslateService } from '@ngx-translate/core';
import { formatDisplayName } from 'src/app/shared/helper-functions';

@Component({
  selector: 'app-2f82-add-remove-deputies-modal',
  templateUrl: './add-remove-deputies-modal.component.html',
  styleUrls: ['./add-remove-deputies-modal.component.scss']
})
export class AddRemoveDeputiesModalComponent implements OnInit, OnDestroy, AfterViewInit {

  constructor(private store: Store<IAccountsListState>, private translateService: TranslateService) {
    this.close = new EventEmitter();
  }
  @ViewChild('Modal') private modalElement: BaseModalComponent;

  // ADD_DEPUTY.MODAL.TITLE
  // REMOVE_DEPUTY.MODAL.TITLE

  public close: EventEmitter<any>;

  private showStats$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private showConfirm$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private viewSelection$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  private searchTerm$: BehaviorSubject<string> = new BehaviorSubject('');

  public title = 'ADD_REMOVE_DEPUTY.MODAL.TITLE';
  public message = 'ADD_REMOVE_DEPUTY.MODAL.DESCRIPTION';
  public messageParams = null;
  public largeIcon = null;
  public titleIcon = null;
  public hasError = false;
  public hasWarning = false;

  private $modal = this.store.pipe(select(getAddRemoveDeputiesModal));

  private $selected = this.store.pipe(select(getSelectedAccountsList));

  public $deputies = this.$modal.pipe(map(m => m.currentDeputies));
  public $deputyOptions = this.$modal.pipe(map(m => m.deputyOptions));
  public blacklist$ = this.$modal.pipe(map(m => m.blacklist));
  public $open = this.$modal.pipe(map(m => m.open));
  public $loadingDeputies = this.$modal.pipe(map(m => m.loadingSearch));
  public $loading = this.$modal.pipe(map(m => m.loading));
  public $res = this.$modal.pipe(map(m => m.response));
  public $mode = this.$modal.pipe(map(m => m.mode));

  public modalState$ = combineLatest(this.$modal, this.showStats$, this.showConfirm$, this.$selected, this.viewSelection$).pipe(
    map(([modal, statsOpen, confirmOpen, selected, viewSelection]) => {

      let screen: 'view-selection' | 'delegation-warning' | 'add-input' | 'add-confirm' | 'remove-confirm' | 'add-success' | 'add-success-status' | 'remove-input' | 'remove-success' | 'remove-success-status' = null;
      let title = '';
      let largeIcon = null;
      const loading = false;
      let messageParams = {};
      let message = null;
      let status: {
        dep: string;
        acc: string;
        msg: string;
        outcome: 'FAILED' | 'SUCCESS'
      }[] = [];

      if (viewSelection) {
        // show VIEW SELECTION page
        title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.VIEW_SELECTION.TITLE' : 'REMOVE_DEPUTY.MODAL.VIEW_SELECTION.TITLE';
        screen = 'view-selection';

      } else if (!modal.response) {
        // there is no response
        if (!modal.loading) {
          // request has not been sent yet
          if (!confirmOpen) {
            // INPUT page
            title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.TITLE' : 'REMOVE_DEPUTY.MODAL.TITLE';
            screen = modal.mode === 'Add' ? 'add-input' : 'remove-input';
          } else {
            // CONFIRM page
            const multiDeps = modal.currentDeputies.length > 1;
            const multiAccs = selected.length > 1;
            switch (`${multiDeps} ${multiAccs}`) {
              case 'true true':
                message = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.CONFIRM.MESSAGE.DEPS_ACCS' : 'REMOVE_DEPUTY.MODAL.CONFIRM.MESSAGE.DEPS_ACCS';
                break;
              case 'true false':
                message = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.CONFIRM.MESSAGE.DEPS_ACC' : 'REMOVE_DEPUTY.MODAL.CONFIRM.MESSAGE.DEPS_ACC';
                break;
              case 'false true':
                message = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.CONFIRM.MESSAGE.DEP_ACCS' : 'REMOVE_DEPUTY.MODAL.CONFIRM.MESSAGE.DEP_ACCS';
                break;
              case 'false false':
                message = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.CONFIRM.MESSAGE.DEP_ACC' : 'REMOVE_DEPUTY.MODAL.CONFIRM.MESSAGE.DEP_ACC';
                break;
            }
            messageParams = {
              dep: modal.currentDeputies[0] ? formatDisplayName(modal.currentDeputies[0].displayName) : ' - ',
              deps: modal.currentDeputies.length.toString(),
              acc: selected[0] ? `${selected[0].directoryDomain}\\${selected[0].uid}` : 0,
              accs: selected.length.toString(),
            };
            title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.CONFIRM.TITLE' : 'REMOVE_DEPUTY.MODAL.CONFIRM.TITLE';
            screen = modal.mode === 'Add' ? 'add-confirm' : 'remove-confirm';

          }
        } else {
          // LOADING page
          title = 'GLOBAL.LOADING';
          largeIcon = 'Loading';
        }
      } else {
        if (modal.response.error !== false) {
          // request FAILED page
          title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.FAILED_TITLE' : 'REMOVE_DEPUTY.MODAL.FAILED_TITLE';
          largeIcon = 'Failed';
        } else {
          if (statsOpen) {
            // request STATUS page
            title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.STATUS.TITLE' : 'REMOVE_DEPUTY.MODAL.STATUS.TITLE';
            screen = modal.mode === 'Add' ? 'add-success-status' : 'remove-success-status';
            status = modal.responseList.map(res => {
              const accObj = selected.find(acc => acc.id === res.account_id);
              return {
                dep: formatDisplayName(modal.currentDeputies.find(dep => dep.login === res.identity_login).displayName),
                acc: `${accObj.directoryDomain}\\${accObj.uid}`,
                msg: this.translateService.instant(`${modal.mode === 'Add' ? 'ADD' : 'REMOVE'}_DEPUTY.API_MESSAGE_TYPE.${res.type}`),
                outcome: res.type === 'SUCCESS' ? 'SUCCESS' : 'FAILED' as 'FAILED' | 'SUCCESS'
              };
            });
          } else {
            // Request Success Page
            title = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.SUCCESS.TITLE' : 'REMOVE_DEPUTY.MODAL.SUCCESS.TITLE';
            message = modal.mode === 'Add' ? 'ADD_DEPUTY.MODAL.SUCCESS.MESSAGE' : 'REMOVE_DEPUTY.MODAL.SUCCESS.MESSAGE';
            screen = modal.mode === 'Add' ? 'add-success' : 'remove-success';
            largeIcon = 'Success';
          }
        }
      }

      return {
        screen,
        title,
        largeIcon,
        loading,
        message,
        messageParams,
        status
      };
    })
  );

  public screen$: BehaviorSubject<'view-selection' | 'delegation-warning' | 'add-input' | 'add-confirm' | 'add-success' | 'add-success-status' | 'remove-input' | 'remove-success' | 'remove-success-status'>;

  public disabled$ = this.$modal.pipe(
    map(m => {
      if (m.previousDeputies.length !== m.currentDeputies.length) {
        return false;
      }
      return m.previousDeputies.every(
        pd => m.currentDeputies.map(
          cd => cd.id)
          .indexOf(pd.id) !== -1);
    })
  );

  public loading = false;
  public finished = false;

  public rejectMessage = '';

  private subs: Subscription[];

  public disabledDeps = (blacklist) => (dep) => {
    return blacklist.indexOf(dep.dataItem.id) !== -1;
  }

  public ngOnInit() {
    this.$modal.subscribe(res => {
      this.hasError = res.response ? res.response.type !== 'SUCCESS' : false;
      this.hasWarning = res.response ? /^WARNING/.test(res.response.type) : false;
      this.finished = !!res.response;
      this.title = this.finished ? (this.hasError || this.hasWarning) ? 'ADD_REMOVE_DEPUTY.MODAL.FAILED_TITLE' : 'ADD_REMOVE_DEPUTY.MODAL.SUCCESS_TITLE' : 'ADD_REMOVE_DEPUTY.MODAL.TITLE';
      this.largeIcon = this.hasError ? this.hasWarning ? 'Warning' : 'Failed' : res.loading ? 'Loading' : this.finished ? 'Success' : null;
      this.message = !this.finished ? 'ADD_REMOVE_DEPUTY.MODAL.DESCRIPTION' : (this.hasWarning || this.hasError) ? res.response.message : 'ADD_REMOVE_DEPUTY.MODAL.SUCCESS_MESSAGE';
    });

    this.subs = [
      this.searchTerm$.pipe(
        debounceTime(300),
        map(term => {
          this.store.dispatch(new searchAccountDeputityForModal(term));
        })
      ).subscribe()
    ];
  }



  public ngOnDestroy() {

  }

  public ngAfterViewInit() {
    this.subs.push(
      this.modalElement.close.pipe(
        withLatestFrom(this.showConfirm$, this.viewSelection$),
        map(([a, conf, selection]) => {
          if (!conf && !selection) {
            this.store.dispatch(new CloseAddRemoveDeputyModal());
            return;
          }
          if (conf) {
            this.showConfirm$.next(false);
            return;
          }
          if (selection) {
            this.viewSelection$.next(false);
            return;
          }
        })
      ).subscribe()
    );
  }

  public showConfirm(open = true) {
    this.showConfirm$.next(open);
  }
  public showSelection(open = true) {
    this.viewSelection$.next(open);
  }
  public showStats(open = true) {
    this.showStats$.next(open);
  }

  public selectDeputiesHandler(deputityList) {
    this.store.dispatch(new setSelectedDeputitiesModal(deputityList));
  }

  public searchDeputiesHandler(term) {
    this.searchTerm$.next(term);
  }

  public formatDN(name){
    return formatDisplayName(name)
  }

  public addDeps() {
    this.store.dispatch(new AddAccountDeputies());
    this.showConfirm$.next(false);
  }
  public removeDeps() {
    this.store.dispatch(new RemoveAccountDeputies());
    this.showConfirm$.next(false);
  }

  public closeModal() {
    this.store.dispatch(new CloseAddRemoveDeputyModal());
  }

}
