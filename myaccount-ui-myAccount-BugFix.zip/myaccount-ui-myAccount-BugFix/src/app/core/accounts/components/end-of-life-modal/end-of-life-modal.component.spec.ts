// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ResetPasswordModalComponent } from './reset-password-modal.component';
// import { TestingModule } from 'src/app/modules/testing/testing.module';

describe('EndOfLifeModalComponent', () => {
  // let component: ResetPasswordModalComponent;
  // let fixture: ComponentFixture<ResetPasswordModalComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [ ResetPasswordModalComponent ],
  //     imports: [ TestingModule],
  //   })
  //   .compileComponents();
  // }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(ResetPasswordModalComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  it('temp test', () => {
    expect(1).toBeTruthy();
  });
});
