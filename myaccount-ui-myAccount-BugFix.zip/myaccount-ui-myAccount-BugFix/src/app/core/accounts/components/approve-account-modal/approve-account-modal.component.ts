import { IApproveListState, IApproveAccount } from './../../../../shared/interfaces/shared/account/approve';
import { Component, OnInit, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { getApproveModal, getApproveSelectedIds, getSelectedApproveAccounts } from '../../store';
import { closeApproveAccountModal, rejectSelectedApproveAccounts, approveSelectedApproveAccountFail, approveSelectedApproveAccounts } from '../../store/actions/approve-list.actions';
import { BehaviorSubject, combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-2f82-approve-account-modal',
  templateUrl: './approve-account-modal.component.html',
  styleUrls: ['./approve-account-modal.component.scss']
})
export class ApproveAccountModalComponent implements OnInit {

  constructor(private store: Store<IApproveListState>, private translateService: TranslateService) {
    this.close = new EventEmitter();
  }

  public close: EventEmitter<any>;

  public open;
  public mode;
  public title = '';
  public message = '';
  public largeIcon = null;

  public loading = false;
  public finished = false;

  public rejectMessage = '';

  private modal$ = this.store.pipe(select(getApproveModal))
  private selection$ = this.store.pipe(select(getSelectedApproveAccounts))
  private viewSelection$ = new BehaviorSubject(false);
  private viewStatus$ = new BehaviorSubject(false);
  private rejectMessageConfirmed$ = new BehaviorSubject(false);

  private selection: IApproveAccount[]


  public state$ = combineLatest(this.modal$, this.selection$, this.viewSelection$, this.viewStatus$, this.rejectMessageConfirmed$).pipe(
    map(([modal, selected, viewSelection, viewStatus, rejectConfirmed]) => {
      const mode = modal.mode


      // Keep reference to previously selected accounts after they have been successfuly removed
      if (selected.length > 0) {
        this.selection = selected
      }

      let res: {
        screen: 'reject-input' | 'confirm-single' | 'confirm-multi' | 'view-selection' | 'loading' | 'success-single' | 'success-multi' | 'stats',
        title: string,
        message: string,
        messageParams: object,
        mode: 'approve' | 'reject',
        largeIcon: 'Loading' | 'Success' | 'Failed',
        status: {
          body: string;
          acc: string;
          msg: string;
          outcome: 'FAILED' | 'SUCCESS'
        }[]
      } = {
        screen: null,
        title: '',
        message: '',
        messageParams: null,
        mode: modal.mode,
        largeIcon: null,
        status: []
      }

      const multi = this.selection.length > 1

      res.messageParams = {
        acc: multi ? null : this.selection[0] ? `${this.selection[0].domain.name}\\${this.selection[0].accountName}` : null,
        accs: multi ? this.selection.length : null
      }

      // LOADING SCREEN
      if (modal.loading) {
        res.screen = 'loading';
        res.title = 'GLOBAL.LOADING'
        res.largeIcon = 'Loading'
        return res
      }

      // VIEW SELECTION
      if (viewSelection) {
        res.screen = 'view-selection'
        res.title = mode === 'approve' ? 'APPROVE_ACCOUNT.MODAL.VIEW_SELECTION.TITLE' : 'REJECT_ACCOUNT.MODAL.VIEW_SELECTION.TITLE'
        return res
      }


      // RESPONSE SCREENS
      if (modal.res) {
        const success = modal.res ? modal.res.error === false : false
        const resList = modal.responseList || []

        // RESPONSE STATUS
        if (viewStatus) {
          res.screen = 'stats'
          res.title = mode === 'approve' ? 'APPROVE_ACCOUNT.MODAL.STATUS.TITLE' : 'REJECT_ACCOUNT.MODAL.STATUS.TITLE'
          res.status = resList.map((res, i) => {
            const accObj = this.selection[i];
            let outcome
            if (/^WARNING/.test(res.type)) {
              outcome = 'ERROR'
            }
            if (/^ERROR/.test(res.type)) {
              outcome = 'ERROR'
            }
            if (/^SUCCESS/.test(res.type)) {
              outcome = 'SUCCESS'
            }
            return {
              body: mode === 'approve' ? success ? 'APPROVE_ACCOUNT.MODAL.STATUS.ITEM_SUCCESS' : 'APPROVE_ACCOUNT.MODAL.STATUS.ITEM_FAILED' : success ? 'REJECT_ACCOUNT.MODAL.STATUS.ITEM_SUCCESS' : 'REJECT_ACCOUNT.MODAL.STATUS.ITEM_FAILED',
              acc: `${accObj.domain.name}\\${accObj.accountName}`,
              msg: this.translateService.instant(`${modal.mode === 'approve' ? 'APPROVE' : 'REJECT'}_ACCOUNT.API_MESSAGE_TYPE.${res.type}`),
              outcome
            };
          })

          return res

          // RESPONSE SCREEN
        }

        if (success) {
          res.screen = multi ? 'success-multi' : 'success-single'
          res.largeIcon = 'Success'
          res.title = mode === 'approve' ? 'APPROVE_ACCOUNT.MODAL.SUCCESS.TITLE' : 'REJECT_ACCOUNT.MODAL.SUCCESS.TITLE'
          switch (`${mode === 'approve'} ${multi}`) {
            case 'true true':
              res.message = 'APPROVE_ACCOUNT.MODAL.SUCCESS.MESSAGE_MULTI'
              break;
            case 'true false':
              res.message = 'APPROVE_ACCOUNT.MODAL.SUCCESS.MESSAGE_SINGLE'
              break;
            case 'false true':
              res.message = 'REJECT_ACCOUNT.MODAL.SUCCESS.MESSAGE_MULTI'
              break;
            case 'false false':
              res.message = 'REJECT_ACCOUNT.MODAL.SUCCESS.MESSAGE_SINGLE'
              break;
          }
        } else {
          res.largeIcon = 'Failed'
          res.title = mode === 'approve' ? 'APPROVE_ACCOUNT.MODAL.FAILED.TITLE' : 'REJECT_ACCOUNT.MODAL.FAILED.TITLE'
        }

        return res
      }

      // REJECT INPUT SCREEN
      if (mode === 'reject' && !rejectConfirmed) {
        res.screen = 'reject-input'
        res.title = 'REJECT_ACCOUNT.MODAL.CONFIRM.TITLE'
        res.message = 'REJECT_ACCOUNT.MODAL.INPUT.MESSAGE'
        return res
      }

      // CONFIRM SCREEN
      if (true) {
        res.screen = multi ? 'confirm-multi' : 'confirm-single'
        res.title = mode === 'approve' ? 'APPROVE_ACCOUNT.MODAL.CONFIRM.TITLE' : 'REJECT_ACCOUNT.MODAL.CONFIRM.TITLE'
        switch (`${mode === 'approve'} ${multi}`) {
          case 'true true':
            res.message = 'APPROVE_ACCOUNT.MODAL.CONFIRM.MESSAGE_MULTI'
            break;
          case 'true false':
            res.message = 'APPROVE_ACCOUNT.MODAL.CONFIRM.MESSAGE_SINGLE'
            break;
          case 'false true':
            res.message = 'REJECT_ACCOUNT.MODAL.CONFIRM.MESSAGE_MULTI'
            break;
          case 'false false':
            res.message = 'REJECT_ACCOUNT.MODAL.CONFIRM.MESSAGE_SINGLE'
            break;
        }
        return res
      }





      return res

    })
  );

  public ngOnInit() {
  }



  public submitAccept() {
    this.store.dispatch(new approveSelectedApproveAccounts)
  }
  public submitReject() {
    this.store.dispatch(new rejectSelectedApproveAccounts(this.rejectMessage))
  }
  public viewSelection(x) {
    this.viewSelection$.next(x)
  }
  public viewStatus(x) {
    console.log({x})
    this.viewStatus$.next(x)
  }
  public rejectMessageConfirm(x) {
    this.rejectMessageConfirmed$.next(x)
  }

  public closeModal() {
    this.store.dispatch(new closeApproveAccountModal());
    this.rejectMessage = '';
  }

  public reject() {
    this.store.dispatch(new rejectSelectedApproveAccounts(this.rejectMessage));
  }




}
