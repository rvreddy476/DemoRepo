import { getAccountDetail } from './../../store/selectors/index';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { FollowUpModalComponent } from '../../components/follow-up-modal/follow-up-modal.component';
import { HourglassIconComponent } from 'src/app/shared/icons/hourglass-icon/hourglass-icon.component';
import { IconModule } from 'src/app/modules/icon.module';
import { PageTitleComponent } from 'src/app/shared/components/page-title/page-title.component';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { followUpStatus } from 'src/app/shared/interfaces/shared/account/follow-up';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

defaultTestStore.accountsModule.followUpList.modal = {
    action: {
      id: 387,
      accountName: 'SA-2F82-TEST2-I',
      creationDate: new Date('2019-09-10T12:28:15.074Z'),
      domain: {
        id: 1,
        name: 'EU-I'
      },
      lastUpdatedDate: null,
      requestor: {
        displayName: 'MCBRYDE, Justin (DEVOTEAM)',
        id: 367966
      },
      accountId: 123,
      cancellable: true,
      status: 'TO_BE_APPROVED',
      message: 'No Comment Available',
      justification:'',
      type: 'ACCOUNT_CREATION',
      validators: [
        {
          displayName: 'CALMELS, Thierry (CAPGEMINI TECHNOLOGY SERVICES DIVISION AEROSPATIALE ET DEFEN)',
          id: 140437
        },
        {
          displayName: 'DEVANT, Stephane (COMPUTACENTER AG COOHG)',
          id: 276916
        },
        {
          displayName: 'GASPERI, Benjamin',
          id: 358622
        },
        {
          displayName: 'JAOUEN, JULIEN',
          id: 358622
        }
      ]
    },
    loading: false,
    res: null,
    open: true
};

describe('FollowUpModalComponent', () => {
  let component: FollowUpModalComponent;
  let fixture: ComponentFixture<FollowUpModalComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule, NoopAnimationsModule],
      providers: [
        provideMockStore({ initialState })
      ],
      declarations: [FollowUpModalComponent, BaseModalComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(FollowUpModalComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
      fixture.detectChanges();
      elem = fixture.nativeElement;
    //   console.log(elem.outerHTML)
    });
  }));
  it('check cancel state has trash icon and cancel title', () => {
    fixture.detectChanges();
    expect(elem.querySelector('app-2f82-trash-icon')).toBeTruthy();
    expect(elem.querySelector('.k-window-title.k-dialog-title>span').innerHTML).toBe('FOLLOW_UP.CANCEL_MODAL.TITLE');
  });
  it('check cancel state has yes and no button', () => {
    fixture.detectChanges();
    expect(elem.querySelectorAll('.btn-panel>button')[0].innerHTML).toBe('BUTTON.NO');
    expect(elem.querySelectorAll('.btn-panel>button')[1].innerHTML).toBe('BUTTON.YES');
  });
  it('check modal has close button', () => {
    fixture.detectChanges();
    expect(elem.querySelector('.k-button.k-dialog-close>span.k-icon.k-i-x')).toBeTruthy();
  });
});
