import { OpenResetPassModal, OpenAddRemoveDeputyModal, EnableAccounts, DisableAccounts, OpenEnableDisableModal, OpenEndOfLifeModal, OpenTASAModal, SetSelectedAccounts } from './../../store/actions/accounts-list.actions';
import { getSelectedAccounts, getEditDeputiesEnabled, getEnableAccountEnabled, getDisableAccountEnabled, getResetPasswordEnabled, getVisibleAccounts, getGridFilters, getAccountsDetail, getSelectedAccountsList, getSelectedAccountType, getAboutToExpireAccounts } from './../../store/selectors/index';
import { IAccountsListState } from './../../../../shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, combineLatest, Subject } from 'rxjs';
import { map, withLatestFrom, takeUntil } from 'rxjs/operators';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';
import { CSVExporter } from 'src/app/shared/services/csv-exporter';

@Component({
  selector: 'app-2f82-accounts-actionbar',
  templateUrl: './accounts-actionbar.component.html',
  styleUrls: ['./accounts-actionbar.component.scss']
})
export class AccountsActionbarComponent implements OnDestroy {
  ngOnDestroy(): void {
    this.destroy$.next(false);
    this.destroy$.unsubscribe();
  }

  constructor(private store: Store<IAccountsListState>, private exporter: CSVExporter) { }
  public allSelected = false;
  public anySelected = false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  public resetWindowOpen = false;
  public compressed = false;

  public selectedCount = this.store.select(getSelectedAccounts).pipe(map((sa) => sa.length));
  public selectedAccountType = null;
  public selectedAccountType$ = this.store.select(getSelectedAccountType).pipe(takeUntil(this.destroy$)).subscribe((val) => this.selectedAccountType = val);
  public totalCount = this.store.select(getVisibleAccounts).pipe(map((va) => va.total));
  // public maximumCount = this.store.select(getVisibleAccounts).pipe(map((va) => va.maximum));
  public resetEnabled = this.store.select(getResetPasswordEnabled);
  public depsEnabled = this.store.select(getEditDeputiesEnabled);
  public accountsAboutToExpireCount$ = this.store.select(getAboutToExpireAccounts).pipe(map((sa) => sa.length));
  public accountsAboutToExpire$ = this.store.select(getAboutToExpireAccounts);
  public enableAccEnabled = this.store.select(getEnableAccountEnabled);
  public disableAccEnabled = this.store.select(getDisableAccountEnabled);
  public userInDelegation = this.store.select(getGlobalDelegationMode).pipe(map(del => del !== 'DISABLED'))

  public kebabBtns$ = combineLatest(this.depsEnabled, this.selectedCount).pipe(
    map(([depEnabled, selected]) => {
      return [{
        actionName: 'openAddDeputiesWindow',
        disabled: !depEnabled
      }, {
        actionName: 'openRemoveDeputiesWindow',
        disabled: !depEnabled
      },
      {
        actionName: 'downloadCSV',
        disabled: false
      }, {
        actionName: 'downloadSelectedCSV',
        disabled: !selected
      }]
    })
  )



  public resetWindow = {
    open: false,
    calanderOpen: false,
    calanderDate: new Date(),
    otherOptionOpen: false,
    excludeChars: '',
  };

  public accountAction(e) {
    switch (e) {
      case 'openResetWindow':
        this.store.dispatch(new OpenResetPassModal());
        break;
      case 'openAddDeputiesWindow':
        this.store.dispatch(new OpenAddRemoveDeputyModal('Add'));
        break;
      case 'openRemoveDeputiesWindow':
        this.store.dispatch(new OpenAddRemoveDeputyModal('Remove'));
        break;
      case 'enableAccounts':
        console.log(this.selectedAccountType);

        if (this.selectedAccountType === 'TECHNICAL')
          this.store.dispatch(new OpenEndOfLifeModal("Enable"));
        else if (this.selectedAccountType === 'SERVICE')
          this.store.dispatch(new OpenEnableDisableModal('Enable'));
        else
          this.store.dispatch(new OpenTASAModal());
        break;
      case 'disableAccounts':
        this.store.dispatch(new OpenEnableDisableModal('Disable'));
        break;
      case 'downloadCSV':
        this.exporter.downloadAccounts(false)
        break;
      case 'downloadSelectedCSV':
        this.exporter.downloadAccounts(true)
        break;
      case 'OpenEndOfLifeModalFromAccountsToExpire':
        let ids: number[] = [];
        this.accountsAboutToExpire$.subscribe(accounts => accounts.map(account => {
          ids.push(account.id);
        }))
        this.store.dispatch(new SetSelectedAccounts({ ids: ids, isAll: false }))
        this.store.dispatch(new OpenEndOfLifeModal("Notification"));
    }
  }
}