import { ModifyAccountsFilter, SetAccountsFilter, OpenCloseAdvancedSearch } from './../../store/actions/accounts-list.actions';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { getGridFilters, getAccountsUniqueDirectoryType, getAccountsUniqueDirectoryEnvironment, getAccountsUniqueDivision, getAccountsUniqueLifeCycleStatus, getAccountsUniqueType, getUIDFilterValue, getSelectedAccounts, getAdvancedFilterPanelOpen } from './../../store/selectors/index';
import { IAccountsState } from './../../store/reducers/index';
import { Component, OnInit, ElementRef } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Subscription, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

interface tabContent { text: string; value: string | number; }

@Component({
  selector: 'app-2f82-accounts-search-panel',
  templateUrl: './accounts-search-panel.component.html',
  styleUrls: ['./accounts-search-panel.component.scss'],
  host: {
    '(document:click)': 'onClick($event)',
  },
})
export class AccountsSearchPanelComponent implements OnInit {

  constructor(private store: Store<IAccountsState>, private _eref: ElementRef) {


    this.uniqueDirectoryType$ = this.store.pipe(select(getAccountsUniqueDirectoryType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDirectoryEnvironment$ = this.store
      .pipe(select(getAccountsUniqueDirectoryEnvironment))
      .pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDivision$ = this.store.pipe(select(getAccountsUniqueDivision)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueLifeCycleStatus$ = this.store.pipe(select(getAccountsUniqueLifeCycleStatus)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueType$ = this.store.pipe(select(getAccountsUniqueType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));

    this.uidFilterValue$ = this.store.pipe(select(getUIDFilterValue));



  }

  public uniqueDirectoryType$: Observable<any[]>;
  public uniqueDirectoryEnvironment$: Observable<any[]>;
  public uniqueDivision$: Observable<any[]>;
  public uniqueLifeCycleStatus$: Observable<any[]>;
  public uniqueType$: Observable<any[]>;

  public uidFilterValue$: Observable<any>;
  public globalMessage = 'this is a drill';

  private subs: Subscription[] = [];

  public filters: CompositeFilterDescriptor;
  public pills: tabContent[];

  public $detailPanelOpen = this.store.pipe(select(getAdvancedFilterPanelOpen));

  private tabConfig = {
    uid: {
      title: 'Account Name',
      field: 'uid',
    },
    lifeCycleStatus: {
      title: 'Account Status',
      field: 'lifeCycleStatus',
    },
    pwdRemainingDays: {
      title: 'Password Lifetime',
      field: 'pwdRemainingDays',
    },
    pwdStatus: {
      title: 'Password Status',
      field: 'pwdStatus',
    },
    contextName: {
      title: 'Solution',
      field: 'contextName',
    },
    type: {
      title: 'Account Type',
      field: 'type',
    },
    directoryEnvironment: {
      title: 'Environment',
      field: 'directoryEnvironment',
    },
    directoryDomain: {
      title: 'Directory',
      field: 'directoryDomain',
    },
    division: {
      title: 'Division',
      field: 'division',
    },
    scheduledResetPwdDateUTC: {
      title: 'Password Reset Scheduled',
      field: 'scheduledResetPwdDateUTC',
    }
  };

  public ngOnInit() {
    this.subs.push(
      this.store.pipe(select(getGridFilters)).pipe(
        tap(filters => {
          this.filters = filters;
          this.pills = filters ? this.getFilterNames(filters) : [];
        }),
      ).subscribe()
    );

  }

  public onClick(event) {
    // detect clicks ouside of search panel (to close on blur)
    if (!this._eref.nativeElement.contains(event.target)) {
      // ignore open/close button
      if (event.target.parentNode ? event.target.parentNode.classList ? !event.target.parentNode.classList.contains('adv-search-btn') : false : false) {
        this.store.dispatch(new OpenCloseAdvancedSearch('close'));
      }
    }
  }

  public openPanel() {
    this.store.dispatch(new OpenCloseAdvancedSearch('open'));
  }
  public closePanel() {
    this.store.dispatch(new OpenCloseAdvancedSearch('close'));
  }
  public removePill(e) {
    this.store.dispatch(new ModifyAccountsFilter({ field: e, filter: null }));
  }

  public clearPills() {
    this.store.dispatch(new SetAccountsFilter({
      logic: 'and',
      filters: []
    }));
  }

  public UIDinput(v) {
    this.store.dispatch(new ModifyAccountsFilter({
      field: 'uid',
      filter: {
        operator: 'contains',
        field: 'uid',
        value: v
      }
    }));
  }


  public getFilterNames(filterDescriptor): tabContent[] {
    return filterDescriptor.filters
      .map(f => f.field ? f.field : f.filters[0] ? f.filters[0].field ? f.filters[0].field : null : null)
      .filter(f => Boolean(f))
      .map(value => {
        return {
          text: this.tabConfig[value].title,
          value
        };
      });
  }
}
