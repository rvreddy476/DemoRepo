import { SetAccountsFilter, ModifyAccountsFilter } from './../../../store/actions/accounts-list.actions';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { getAccountsUniqueDirectoryType, getAccountsUniqueDivision, getAccountsUniqueLifeCycleStatus, getAccountsUniqueDirectoryEnvironment, getAccountsUniqueType, getGridFilters, getContextFilterValue, getTypeFilterValue, getDirectoryEnvironmentFilterValue, getLifeCycleStatusFilterValue, getDirectoryTypeFilterValue, getAccountsUniqueDirectoryDomain, getDirectoryDomainFilterValue, getAccountsUniquePwdStatus, getPwdStatusFilterValue, getFilterPwdRemainingDays, getPasswordLifetimeFilterValue } from './../../../store/selectors/index';
import { Store, select } from '@ngrx/store';
import { IAccountsState } from './../../../store/reducers/index';
import { FormControl, FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { of } from 'rxjs';
@Component({
  selector: 'app-2f82-accounts-detail-search',
  templateUrl: './accounts-detail-search.component.html',
  styleUrls: ['./accounts-detail-search.component.scss']
})
export class AccountsDetailSearchComponent implements OnInit {

  constructor(private store: Store<IAccountsState>) {
    this.uniqueDirectoryDomain$ = this.store.pipe(select(getAccountsUniqueDirectoryDomain)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDirectoryType$ = this.store.pipe(select(getAccountsUniqueDirectoryType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDirectoryEnvironment$ = this.store
      .pipe(select(getAccountsUniqueDirectoryEnvironment))
      .pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDivision$ = this.store.pipe(select(getAccountsUniqueDivision)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueLifeCycleStatus$ = this.store.pipe(select(getAccountsUniqueLifeCycleStatus)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueType$ = this.store.pipe(select(getAccountsUniqueType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniquePwdStatus$ = this.store.pipe(select(getAccountsUniquePwdStatus)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
  }

  public uniqueDirectoryDomain$: Observable<any[]>;
  public uniqueDirectoryType$: Observable<any[]>;
  public uniqueDirectoryEnvironment$: Observable<any[]>;
  public uniqueDivision$: Observable<any[]>;
  public uniqueLifeCycleStatus$: Observable<any[]>;
  public uniquePwdStatus$: Observable<any[]>;
  public uniquePwdRemainingDays$: Observable<any[]>;
  public uniqueType$: Observable<any[]>;

  public filter: CompositeFilterDescriptor;
  public uid: string;

  public contextFilterValue$: Observable<any>;
  public directoryEnvironmentFilterValue$: Observable<any>;
  public lifeCycleStatusFilterValue$: Observable<any>;
  public typeFilterValue$: Observable<any>;
  public pwdStatusFilterValue$: Observable<any>;
  public directoryDomainFilterValue$: Observable<any>;
  public pwdRemainingDaysFilterValue$: Observable<any>;

  public ngOnInit() {
    this.contextFilterValue$ = this.store.pipe(select(getContextFilterValue));
    this.directoryEnvironmentFilterValue$ = this.store.pipe(select(getDirectoryEnvironmentFilterValue));
    this.lifeCycleStatusFilterValue$ = this.store.pipe(select(getLifeCycleStatusFilterValue));
    this.typeFilterValue$ = this.store.pipe(select(getTypeFilterValue));
    this.pwdStatusFilterValue$ = this.store.pipe(select(getPwdStatusFilterValue));
    this.pwdRemainingDaysFilterValue$ = this.store.pipe(select(getPasswordLifetimeFilterValue));
    this.directoryDomainFilterValue$ = this.store.pipe(select(getDirectoryDomainFilterValue));

    // special case for uniquePwdRemainingDays
    this.uniquePwdRemainingDays$ = of([
      {
        name: 'expired more than 50 days',
        value: '< -50'
      },      {
        name: 'expired less than 50 days',
        value: '>= -50'
      },      {
        name: 'expired less than 7 days',
        value: '> -7'
      },      {
        name: 'expired more than 50 days',
        value: '< 7'
      },      {
        name: 'expired more than 50 days',
        value: '<= 50'
      },      {
        name: 'expired more than 50 days',
        value: '> 50'
      }
    ]);
  }

  public change(e, field) {
    const newFilter: FilterDescriptor = {
      field,
      operator: 'contains',
      value: e.target.value
    };

    this.store.dispatch(new ModifyAccountsFilter({ field, filter: newFilter }));
  }

  public changeNestedFilter(e, field) {
    let filter = JSON.parse(e);
    filter = filter.filters ? filter : null;
    this.store.dispatch(new ModifyAccountsFilter({ field, filter }));
  }

}
