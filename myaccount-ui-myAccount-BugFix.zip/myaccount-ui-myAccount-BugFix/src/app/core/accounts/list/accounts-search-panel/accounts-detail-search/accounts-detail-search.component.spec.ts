import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountsDetailSearchComponent } from './accounts-detail-search.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestingModule } from 'src/app/modules/testing/testing.module';

describe('AccountsDetailSearchComponent', () => {
  let component: AccountsDetailSearchComponent;
  let fixture: ComponentFixture<AccountsDetailSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountsDetailSearchComponent ],
      imports: [ TestingModule],
      schemas: [ NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsDetailSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
