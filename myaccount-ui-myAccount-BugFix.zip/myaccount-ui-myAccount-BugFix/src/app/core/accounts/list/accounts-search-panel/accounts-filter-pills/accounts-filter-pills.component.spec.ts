import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountsFilterPillsComponent } from './accounts-filter-pills.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('AccountsFilterPillsComponent', () => {
  let component: AccountsFilterPillsComponent;
  let fixture: ComponentFixture<AccountsFilterPillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountsFilterPillsComponent ],
      schemas: [ NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountsFilterPillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
