import { BaseFilterCellComponent, FilterService } from '@progress/kendo-angular-grid';
import { Input, Component, ViewChild, OnChanges, SimpleChange, Output, EventEmitter, ViewEncapsulation, OnInit } from '@angular/core';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-2f82-form-filter-multi-dropdown',
  template: `
    <app-2f82-multi-dropdown-list
      #dropdown
      [data]="data"
      (selectionChange)="onChange($event)"
      [textField]="textField"
      [valueField]="valueField"
      [emptyOnAll]="true"
      [emptyTitle]="'None'"
      [fullTitle]="'All'"
      [textPrefix] ='textPrefix'
      [filterable]="filterable"
      [selection]="selectedValue || []"
      [sortOptions]="sortOptions"
    ></app-2f82-multi-dropdown-list>
  `,
  styles: [
    `
    :host{
      width: 100%;
    }
    kendo-dropdownlist.k-widget.k-dropdown.k-header {
      width: 100%;
    }`,
  ],
  encapsulation: ViewEncapsulation.None,
})
export class FormFilterMultiDropdownComponent {
  constructor() {
    this.applyFilter = new EventEmitter();
  }

  @ViewChild('dropdown') public dropdown: any;

  @Input()
  public filter: CompositeFilterDescriptor;

  @Input()
  public data: any[];
  @Input()
  public textField = 'name';
  @Input()
  public valueField = 'value';
  @Input()
  public filterField: string;
  @Input()
  public textPrefix: string = null;
  @Input()
  public filterable = true;
  @Input()
  public selectedValue: string[] = [];
  @Input()
  public sortOptions = false

  @Output()
  public applyFilter: EventEmitter<any>;

  public showClear = false;
  public nestFilter: CompositeFilterDescriptor = null;



  public onChange(value: any): void {
    const newFilter: FilterDescriptor[] = value.length > 0 ?
      value.map((v) => {
        return {
          field: this.filterField,
          operator: 'eq',
          value: v
        };
      }) : null;

    this.applyFilter.emit(JSON.stringify({
      filters: newFilter,
      logic: 'or',
    }));
  }
}
