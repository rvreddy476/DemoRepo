
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
// import { SetAccountsFilter } from '../../../landing-page/store/actions/accounts-list.actions';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { IBaseState } from '../../../../shared/interfaces/base-state';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { SetAccountsFilter } from '../../store';

@Component({
  selector: 'app-2f82-accounts-breadcrumb',
  templateUrl: './accounts-breadcrumb.component.html',
  styleUrls: ['./accounts-breadcrumb.component.scss'],
})

export class AccountsBreadcrumbComponent implements OnInit {
  constructor(private store: Store<IBaseState>, private active: ActivatedRoute, private route: Router) {}

  private subs: Subscription[];
  public currentRoute: string[] = [];

  public ngOnInit() {
    this.subs = [
      this.route.events.pipe(filter(evt => evt instanceof NavigationEnd)).subscribe((x: any) => {
        this.currentRoute = x.urlAfterRedirects.replace(/;.*$/, '').split('/').filter(x => x !== '');
      })
    ];
  }

  public navigate(i) {
    if (i === 0) {
      this.route.navigate(['/']);
    } else {
      const filtered = this.currentRoute.slice(0, i);
      this.route.navigate([...filtered]);
    }
  }

  public clearFilters() {
    const x: CompositeFilterDescriptor = {
      logic: 'or',
      filters: [],
    };
    this.store.dispatch(new SetAccountsFilter(x));
  }

  // this.store.dispatch(new SetAccountsFilter(filter));
}
