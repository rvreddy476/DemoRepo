import { Component, OnInit } from '@angular/core';
import { IAccountsState, SetSelectedAccounts, getSelectedAccounts, getAccountsViewState, SetViewOnlySelectedAccounts } from '../../store';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { pluck } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-view-clear-acc-selection',
  templateUrl: './view-clear-acc-selection.component.html',
  styleUrls: ['./view-clear-acc-selection.component.scss']
})
export class ViewClearAccSelectionComponent implements OnInit {

  constructor(private store: Store<IAccountsState>) { }

  public selection: Observable<number[]>;
  public viewSelected: Observable<boolean>;

  public ngOnInit() {
    this.selection = this.store.pipe(select(getSelectedAccounts));
    this.viewSelected = this.store.pipe(select(getAccountsViewState), pluck('showOnlySelected'));
  }

  public clearSelection() {
    this.store.dispatch(new SetSelectedAccounts({ids: [], isAll: false}));
    this.store.dispatch(new SetViewOnlySelectedAccounts(false));
  }

  public setViewOnlySelected(e: boolean) {
    this.store.dispatch(new SetViewOnlySelectedAccounts(e));
  }

}
