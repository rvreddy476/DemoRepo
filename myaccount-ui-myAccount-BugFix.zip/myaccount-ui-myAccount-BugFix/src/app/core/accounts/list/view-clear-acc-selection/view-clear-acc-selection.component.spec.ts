import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewClearAccSelectionComponent } from './view-clear-acc-selection.component';

describe('ViewClearAccSelectionComponent', () => {

  it('should create', () => {
    expect(true).toBeTruthy();
  });
});
