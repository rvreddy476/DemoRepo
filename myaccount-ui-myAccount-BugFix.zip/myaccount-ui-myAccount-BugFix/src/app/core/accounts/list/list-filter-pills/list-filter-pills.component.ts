import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-2f82-list-filter-pills',
  templateUrl: './list-filter-pills.component.html',
  styleUrls: ['./list-filter-pills.component.scss'],
})
export class ListFilterPillsComponent implements OnInit {
  constructor() {}

  public ngOnInit() {}
}
