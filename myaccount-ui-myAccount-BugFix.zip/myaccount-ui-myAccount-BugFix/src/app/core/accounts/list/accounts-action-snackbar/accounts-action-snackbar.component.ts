import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getSelectedAccounts } from '../../../../core/accounts/store';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { IBaseState } from '../../../../shared/interfaces/base-state';

@Component({
  selector: 'app-2f82-accounts-action-snackbar',
  animations: [
    trigger('changeState', [
      state(
        'open',
        style({
          bottom: '40px',
        })
      ),
      transition('*=>open', animate('200ms ease-out')),
    ]),
  ],
  templateUrl: './accounts-action-snackbar.component.html',
  styleUrls: ['./accounts-action-snackbar.component.scss'],
})
export class AccountsActionSnackbarComponent implements OnInit {
  public toState = 'open';

  public total: Observable<Number>;
  public selected: Observable<number[]>;
  public selectedCount: Observable<Number>;

  public changeState(newState: any) {
    this.toState = newState;
  }

  constructor(private store: Store<IBaseState>) {
    this.selected = this.store.select(getSelectedAccounts);
    this.selectedCount = this.selected.pipe(map((res) => res.length));
  }

  public ngOnInit() {}
}
