import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-2f82-account-action-icon-bar',
  templateUrl: './account-action-icon-bar.component.html',
  styleUrls: ['./account-action-icon-bar.component.scss']
})
export class AccountActionIconBarComponent implements OnInit {

  constructor() {
    this.action = new EventEmitter();
  }

  @Input()
  public disabled = false;

  @Input()
  public kebabBtns$: {actionName:string, icon:string, disabled:boolean}[];

  @Input()
  public enableAccountEnabled = false;
  @Input()
  public disableAccountEnabled = false;

  @Input()
  public showKebabButton = true

  @Output()
  public action: EventEmitter<string>;

  public selectKebab(e) {
    this.action.emit(e.actionName);
  }

  public allDisabled(btns:any[]){
    return btns ? btns.every(btn => btn.disabled) : true
  }

  public ngOnInit() {
  }

}
