import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountActionIconBarComponent } from './account-action-icon-bar.component';
import { IconModule } from 'src/app/modules/icon.module';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

describe('AccountActionIconBarComponent', () => {
  let component: AccountActionIconBarComponent;
  let fixture: ComponentFixture<AccountActionIconBarComponent>;
  let elem: HTMLElement;
  let buttons: NodeListOf<Element>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountActionIconBarComponent ],
      imports: [IconModule, TranslateModule.forRoot(), ButtonsModule]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(AccountActionIconBarComponent);
      component = fixture.componentInstance;
      component.disabled = true;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      buttons = elem.querySelectorAll('.btn-action');
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have 3 disabled buttons by default', () => {
    expect(elem.querySelectorAll('.btn-action[disabled]').length).toBe(3); // including burger menu
  });
  it('should enable reset' , () => {
    expect(elem.querySelector('.btn-action.btn-action-reset-password[disabled]')).toBeTruthy();
    component.disabled = false;
    fixture.detectChanges();
    expect(elem.querySelector('.btn-action.btn-action-reset-password[disabled]')).toBeFalsy();
  });
  it('should enable "enable" action' , () => {
    expect(elem.querySelector('.btn-action.btn-action-activate[disabled]')).toBeTruthy();
    component.enableAccountEnabled = true;
    fixture.detectChanges();
    expect(elem.querySelector('.btn-action.btn-action-activate[disabled]')).toBeFalsy();
  });
});
