import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAccount } from '../../../../shared/interfaces/shared/account/account';
import { Observable } from 'rxjs';
import { getSelectedAccounts } from '../../store';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-user-accounts-list',
  templateUrl: './user-accounts-list.component.html',
  styleUrls: ['./user-accounts-list.component.scss'],
})
export class UserAccountsListComponent implements OnInit {
  constructor(private store: Store<IAccount[]>) {}

  public selected = this.store.select(getSelectedAccounts);

  public selectedCount = this.selected.pipe(map((res) => res.length));

  public hasSelected = this.selected.pipe(map((res) => res.length > 0));

  public userAccList$: Observable<IAccount[]>;

  public ngOnInit() {
    // this.userAccList$ = this.store.pipe(select(getUserAccList));
  }
}
