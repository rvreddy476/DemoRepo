
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-2f82-accounts-reset-popup',
  templateUrl: './accounts-reset-popup.component.html',
  styleUrls: ['./accounts-reset-popup.component.scss']
})
export class AccountsResetPopupComponent {

  constructor() {
    this.action = new EventEmitter();
  }

  public resetWindow = {
    calanderOpen: false,
    calanderDate: new Date(),
    otherOptionOpen: false,
    excludeChars: '',
  };

  @Input()
  public resetWindowOpen = false;

  @Output()
  public action: EventEmitter<string>;

  public submit() {
    this.action.emit('resetSubmit');
  }
  public close() {
    this.action.emit('closeResetWindow');
  }

}
