import { getAccountDetail } from './../../store/selectors/index';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { VirtualScrollListComponent } from './virtual-scroll-list.component';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';

describe('Virtual Scroll List Component', () => {
  let component: VirtualScrollListComponent;
  let fixture: ComponentFixture<VirtualScrollListComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule],
      providers: [
        provideMockStore({ initialState })
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(VirtualScrollListComponent);
      component = fixture.componentInstance;
      component.testMode = true;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      store = TestBed.get(Store);
    });
  }));

  it('one kendo-grid element to exist', () => {

    expect(elem.querySelectorAll('kendo-grid').length).toBe(1);

  });

  it('at least 6 rows in the table', () => {
    expect(elem.querySelectorAll('tr[role=row]').length).toBeGreaterThan(6);
  });
  it('locked accounts to have a locked class applied', () => {
    const lockedRows = elem.querySelectorAll('tr[role=row].locked');
    expect(lockedRows.length).toBe(1);
    expect(lockedRows[0].querySelector('app-2f82-hourglass-icon')).toBeTruthy();
  });
  it('scheduled reset password accounts have a calander icon', () => {
    const firstRow = elem.querySelectorAll('tr[role=row]')[1];
    expect(firstRow.querySelector('app-2f82-calendar-icon')).toBeTruthy();
  });
  it('there are 9 colounm headers with title and sort-order icon', () => {
    const headerBar = elem.querySelector('.k-grid-header');
    const headerTitles = headerBar.querySelectorAll('th[role=columnheader]');
    expect(headerTitles.length).toBe(10);
    headerTitles.forEach((headerTitleElem, i) => {
      if (i < 1 || i > 8) { return; }
      expect(headerTitleElem.querySelector('.colunm-title').innerHTML).toMatch(/^ACCOUNT_LIST.ROW_NAME./);
      expect(headerTitleElem.querySelector('.sort-icon-container').innerHTML).toBeTruthy();
    });
  });
  it('should derive the correct password status', () => {

    expect(component.derivePasswordStatus({
      directoryType: 'AD',
      pwdRemainingDays: 0
    } as IAccount)).toEqual({'text': 'ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN', 'value': {'d': 0}});

    expect(component.derivePasswordStatus({
      directoryType: 'AD',
      pwdRemainingDays: -1
    } as IAccount)).toEqual({'text': 'ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN', 'value': {'d': 1}});
    expect(component.derivePasswordStatus({
      directoryType: 'AD',
      pwdRemainingDays: 1
    } as IAccount)).toEqual({'text': 'ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN', 'value': {'d': 1}});
  });
});
