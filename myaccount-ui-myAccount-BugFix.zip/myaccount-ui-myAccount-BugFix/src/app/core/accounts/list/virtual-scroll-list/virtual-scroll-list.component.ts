import { getAdvancedFilterPanelOpen, getAccountsListState, getVisibleAccounts, getAccountsViewState, getSortedFilteredAccountList, getSelectAllStatus } from './../../store/selectors/index';
//#region imports
import { Component, OnInit, OnDestroy, ViewChild, ViewEncapsulation, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {
  LoadAccountsList,
  SetAccountsSort,
  SetAccountsFilter,
  SetAccountsPage,
  SetAccountsShowUidList,
  SetAccountsFilterByTile,
  AddBenchmark,
  SetSelectedAccounts,
  OpenResetPassModal,
  SetViewOnlySelectedAccounts,
  SelectAllAccounts,
} from '../../../../core/accounts/store/actions/accounts-list.actions';
import {
  getAccountsListLoading,
  getSelectedAccounts,
  getAccountsVisibleColumns,
  getAccountsGridState,
  getAccountsEnabledColumns,
  getAccountsUniqueDirectoryType,
  getAccountsUniqueDirectoryEnvironment,
  getAccountsUniqueDivision,
  getAccountsUniqueLifeCycleStatus,
  getAccountsUniqueType,
  getGridFilters,
  getGridSort,
} from '../../../../core/accounts/store';
import { Observable, Subscription } from 'rxjs';
import { State, SortDescriptor, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { map, delay, distinctUntilChanged, tap, withLatestFrom, filter } from 'rxjs/operators';
import { IAccountGridData, IEnabledColunms, IAccountsListState, IAccount } from '../../../../shared/interfaces/shared/account/account';
import { TranslateService } from '@ngx-translate/core';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';

//#endregion

@Component({
  selector: 'app-2f82-virtual-scroll-list',
  templateUrl: './virtual-scroll-list.component.html',
  styleUrls: ['./virtual-scroll-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class VirtualScrollListComponent implements OnInit, OnDestroy {

  constructor(private store: Store<IAccountsListState>, private active: ActivatedRoute, private router: Router, private translate: TranslateService) {
    this.getColumnConfig();
  }
  @ViewChild('grid') private grid;

  @Input()
  public testMode = false;

  //#region grid configuration

  public gridHeight = 0;
  public columnConfig;

  private colunmVisibilityPriority = [
    'uid',
    'directoryDomain',
    'lifeCycleStatus',
    'pwdStatus',
    'pwdRemainingDays',
    'contextName',
    'type',
    'directoryEnvironment',
    'division',
  ];

  public sortMultiple = false;
  public allowUnsort = true;

  public passwordStatusOptions = [
    {
      name: 'Expired',
      value: [
        {
          operator: 'lte',
          value: 0,
        },
      ],
    },
    {
      name: '0 - 3 days',
      value: [
        {
          operator: 'ge',
          value: 0,
        },
        {
          operator: 'lte',
          value: 3,
        },
      ],
    },
    {
      name: '4 - 7 days',
      value: [
        {
          operator: 'ge',
          value: 3,
        },
        {
          operator: 'lte',
          value: 7,
        },
      ],
    },
    {
      name: '8 - 30 days',
      value: [
        {
          operator: 'ge',
          value: 7,
        },
        {
          operator: 'lte',
          value: 30,
        },
      ],
    },
    {
      name: '31 - 90 days',
      value: [
        {
          operator: 'ge',
          value: 30,
        },
        {
          operator: 'lte',
          value: 90,
        },
      ],
    },
    {
      name: '91 - 180 days',
      value: [
        {
          operator: 'ge',
          value: 90,
        },
        {
          operator: 'lte',
          value: 180,
        },
      ],
    },
  ];

  //#endregion

  //#region variables

  public colMedia: any; // Derived from Screen Resulution and "enabled colunms"
  public selectedAccounts: number[] = [];

  public subscriptions: Subscription[] = [];

  public benchmarksViewRenderTimestamp: Date;
  public benchmarks$: Observable<string>;
  public data$: Observable<IAccountGridData>;
  public uniqueDirectoryType$: Observable<any[]>;
  public uniqueDirectoryEnvironment$: Observable<any[]>;
  public uniqueDivision$: Observable<any[]>;
  public uniqueLifeCycleStatus$: Observable<any[]>;
  public uniqueType$: Observable<any[]>;

  public isLoading$: Observable<boolean>;
  public sort: SortDescriptor[] = [];
  public filter: CompositeFilterDescriptor = { filters: [], logic: 'and' };
  public filterable = true;

  private detailRowID: string;
  private visibleColumns: string[];
  private enabledColumns: IEnabledColunms;
  public gridState: State;

  public selectAllBtnState$ = this.store.pipe(select(getSelectAllStatus));


  public rescheduleReset = (acc => {
    if (!acc.locked && !acc.hp) {
      this.store.dispatch(new OpenResetPassModal());
    }
  });

  private getColumnConfig = () => {
    this.columnConfig = {
      id: {
        title: 'ID',
        field: 'id',
        width: 0,
      },
      uid: {
        title: 'ACCOUNT_LIST.ROW_NAME.UID',
        field: 'uid',
        width: 280,
      },
      lifeCycleStatus: {
        title: 'ACCOUNT_LIST.ROW_NAME.ACC_STATUS',
        field: 'lifeCycleStatus',
        width: 150,
      },
      pwdStatus: {
        title: 'ACCOUNT_LIST.ROW_NAME.PASS_STATUS',
        field: 'pwdStatus',
        width: 150,
      },
      pwdRemainingDays: {
        title: 'ACCOUNT_LIST.ROW_NAME.PASS_LIFETIME',
        field: 'pwdRemainingDays',
        width: 180,
      },
      contextName: {
        title: 'ACCOUNT_LIST.ROW_NAME.SOLUTION',
        field: 'contextName',
        width: 120,
      },
      type: {
        title: 'ACCOUNT_LIST.ROW_NAME.TYPE',
        field: 'type',
        width: 140,
      },
      directoryEnvironment: {
        title: 'ACCOUNT_LIST.ROW_NAME.ENVIRONMENT',
        field: 'directoryEnvironment',
        width: 130,
      },
      directoryDomain: {
        title: 'ACCOUNT_LIST.ROW_NAME.DOMAIN',
        field: 'directoryDomain',
        width: 120,
      },
      division: {
        title: 'ACCOUNT_LIST.ROW_NAME.DIVISION',
        field: 'division',
        width: 230,
      },
      locked: {
        title: '',
        field: 'locked',
        width: 70,
      },
    };
  }


  //#endregion

  //#region grid event handlers

  public sortChangeHandler(sort: SortDescriptor[]): void {
    this.sort = sort;

    this.store.dispatch(new SetAccountsSort(sort));
  }

  public onSelectAllChange() {
    this.store.dispatch(new SelectAllAccounts());
  }

  public getSortDirection(field) {
    const filter = this.sort ? this.sort.filter(s => s.field === field)[0] : null;
    return filter ? filter.dir : null;
  }

  public pageChangeHandler(state: State): void {
    this.store.dispatch(new SetAccountsPage(state));
    this.closeCurrentDetail();
  }

  //#endregion

  //#region Initialise Subscriptions and Observables

  public ngOnInit() {
    // Create Subscriptions

    this.subscriptions.push(

      this.store.pipe(select(getGlobalDelegationMode)).pipe(
        filter(d => {
          return Boolean(d);
        }),
        withLatestFrom(this.active.params),
        tap(([delegation, params]) => {
          this.loadAccounts(params);
        })
      ).subscribe(),

      this.store.pipe(select(getGridFilters)).subscribe((filter) => {
        this.grid.filterService.changes.next(filter);
        this.filter = filter;
      }),

      this.translate.onLangChange.subscribe(() => {
        this.getColumnConfig();
        // trigger a change in state to trigger a page update to show new languages
        // this.store.dispatch(new SetAccountsSort(this.sort));
      }),

      this.store.pipe(select(getGridSort)).subscribe((sort) => {
        this.sort = sort;
      }),

      this.store.pipe(select(getSelectedAccounts)).subscribe((selected) => {
        this.selectedAccounts = selected;
      }),
      this.store.pipe(select(getAccountsEnabledColumns)).subscribe((cols) => {
        this.enabledColumns = cols;
      }),
      this.store.pipe(select(getAccountsVisibleColumns)).subscribe((visible) => {
        this.visibleColumns = visible;
        this.calculateColMedia();
      }),
      this.store.pipe(select(getAccountsGridState)).subscribe((gridState) => {
        this.gridState = gridState;
      }),

      this.grid.selectionChange.pipe(
        // dont act on locked or hp accounts selection
        filter((e: any) => {
          return [...e.selectedRows, ...e.deselectedRows].every(row => (!row.dataItem.hp && !row.dataItem.locked));
        }),
        filter((e: any) => {
          const wasSelectAllBtn = (e.ctrlKey && e.shiftKey);
          // prevent default behaviour when clicking on the "select all" button
          return !wasSelectAllBtn;
        }),
        withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getSortedFilteredAccountList))),
        map(([change, selected, filtered]) => {
          const added = change.selectedRows.filter(row => !row.dataItem.locked).map(acc => acc.dataItem.id);
          const removed = change.deselectedRows.map(acc => acc.dataItem.id);
          const newSelection = [...selected, ...added].filter(cur => removed.indexOf(cur) === -1);
          const isAll = filtered.filter(acc => !acc.locked).every(acc => newSelection.indexOf(acc.id) !== -1);
          console.log(newSelection);
          this.store.dispatch(
            new SetSelectedAccounts({ ids: newSelection, isAll })
          );
        })
      ).subscribe()
    );

    this.isLoading$ = this.store.pipe(select(getAccountsListLoading));
    this.data$ = this.store.pipe(select(getVisibleAccounts));
    this.uniqueDirectoryType$ = this.store.pipe(select(getAccountsUniqueDirectoryType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDirectoryEnvironment$ = this.store
      .pipe(select(getAccountsUniqueDirectoryEnvironment))
      .pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDivision$ = this.store.pipe(select(getAccountsUniqueDivision)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueLifeCycleStatus$ = this.store.pipe(select(getAccountsUniqueLifeCycleStatus)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueType$ = this.store.pipe(select(getAccountsUniqueType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));

    this.store.pipe(select(getAdvancedFilterPanelOpen)).pipe(delay(200)).subscribe(() => {
      this.resetGridHeight();
    });

    this.resetGridHeight();

  }

  private resetGridHeight() {
    const footerHieght = 30;
    const height = this.grid.wrapper.nativeElement.parentElement.clientHeight;
    this.gridHeight = height - footerHieght;
  }

  public ngOnDestroy() {
    this.store.dispatch(new SetAccountsFilterByTile(null));
    this.subscriptions.forEach((sub) => {
      sub.unsubscribe();
    });
  }

  //#endregion

  //#region grid component functions

  private getVisibleColumns() {
    return this.grid.visibleColumns._results.map((colName) => colName.field).filter((f) => f);
  }

  private calculateColMedia() {
    let accum = 82;
    this.colMedia = this.colunmVisibilityPriority.reduce((prev, cur) => {
      accum += this.enabledColumns[cur] ? this.columnConfig[cur].width : 0;
      prev[cur] = this.testMode ? `` : `(min-width: ${accum}px)`;
      return prev;
    }, {});
  }

  private loadAccounts(urlParams: Params) {
    if (urlParams.term) {
      // apply filters found in URL
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new LoadAccountsList());
      this.store.dispatch(new SetAccountsFilter({
        filters: [
          {
            field: 'uid',
            operator: 'contains',
            value: urlParams.term,
            ignoreCase: true,
          },
        ],
        logic: 'and'
      }));
    } else if (urlParams.viewonly) {
      // Load all and view and select only "viewOnly" accounts
      const viewList: number[] = JSON.parse(urlParams.viewonly).split(',').map(id => parseInt(id));
      this.store.dispatch(new LoadAccountsList());
      this.store.dispatch(new SetSelectedAccounts({ ids: viewList, isAll: true }));
      this.store.dispatch(new SetViewOnlySelectedAccounts(true));
    } else if (urlParams.tile) {
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new SetAccountsFilterByTile(urlParams.tile));
      this.store.dispatch(new LoadAccountsList());
    } else {
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new AddBenchmark({ event: 'Request Accounts List', time: new Date() }));
      this.store.dispatch(new LoadAccountsList());
    }
  }

  public rowClass(e) {
    let res = 'row';
    if (e.dataItem.locked) {
      res += ' locked';
    }
    if (e.dataItem.hp) {
      res += ' hp';
    }
    return res;
  }

  public isRowSelected(selected) {
    return (row) => {
      return selected.indexOf(row.dataItem.id) !== -1;
    };
  }

  public shouldShowColunm(field) {
    if (field === 'id') {
      return false;
    }
    return this.enabledColumns[field];
  }

  public derivePasswordStatus(acc: IAccount) {
    if (acc.pwdStatus === 'NO_PASSWORD') {
      return {
        text: `-`,
        value: null
      };
    }
    if (acc.pwdStatus === 'EXPIRED') {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRED_SINCE`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    } else {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    }
  }

  public hasDetail(input) {
    return true;
  }
  public detailLoadedForAcc(acc) {
    for (const key in acc) {
      if (acc.hasOwnProperty(key)) {
        if (acc[key] === undefined) {
          return false;
        }
      }
    }
    return true;
  }

  private openDetail(accId) {
    this.closeCurrentDetail();
    this.detailRowID = accId;
    this.grid.expandRow(accId);
  }

  private closeCurrentDetail() {
    if (this.detailRowID !== null) {
      this.grid.collapseRow(this.detailRowID);
    }
  }

  public navigate(id) {
    this.router.navigate([`accounts/${id}`]);
  }

  //#endregion
}
