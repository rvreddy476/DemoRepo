import { AccountApprovePageComponent } from './approve/account-approve-page/account-approve-page.component';
import { AccountDetailHistoryComponent } from './detail/account-detail-history/account-detail-history.component';
import { AccountDetailInfoComponent } from './detail/account-detail-info/account-detail-info.component';
import { AccountDetailPageComponent } from './detail/account-detail-page/account-detail-page.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountsComponent } from './accounts.component';
import { UserAccountsListComponent } from './list/user-accounts-list/user-accounts-list.component';
import { ActionFollowUpComponent } from './follow-up/action-follow-up/action-follow-up.component';
import { ResetPasswordScheduledFollowUpComponent } from './follow-up/reset-password-scheduled-follow-up/reset-password-scheduled-follow-up.component';
import { AccountDetailDelegationComponent } from './detail/account-detail-delegation/account-detail-delegation.component';

export const ACCOUNT_ROUTES: Routes = [
  {
    path: '',
    component: AccountsComponent,
    children: [
      {
        path: '',
        component: UserAccountsListComponent,
        data: { state: 'accounts' },
      },
      {
        path: 'approve',
        component: AccountApprovePageComponent,
      },
      {
        path: 'actions',
        component: ActionFollowUpComponent,
      },
      {
        path: 'scheduled',
        component: ResetPasswordScheduledFollowUpComponent,
      },
      {
        path: ':id',
        component: AccountDetailPageComponent,
        children: [
          {
            path: 'info',
            component: AccountDetailInfoComponent,
          },
          {
            path: 'history',
            component: AccountDetailHistoryComponent,
          },
          {
            path: 'delegation',
            component: AccountDetailDelegationComponent,
          },
          {
            path: '**',
            redirectTo: 'info',
          },
        ],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(ACCOUNT_ROUTES)],
  exports: [RouterModule],
})
export class AccountsRoutingModule { }
