import { getAccountDetail, getEditDeputiesEnabled, getDisableAccountEnabled, getEnableAccountEnabled, getResetPasswordEnabled, getSelectedAccountType } from './../../store/selectors/index';
import { LoadAccountDetail, ResetPassword, OpenResetPassModal, SetSelectedAccounts, OpenAddRemoveDeputyModal, EnableAccounts, DisableAccounts, OpenEndOfLifeModal, OpenEnableDisableModal, OpenTASAModal } from './../../store/actions/accounts-list.actions';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { IAccountsListState, IAccount } from './../../../../shared/interfaces/shared/account/account';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Subscription, combineLatest, Observable, BehaviorSubject, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-account-detail-page',
  templateUrl: './account-detail-page.component.html',
  styleUrls: ['./account-detail-page.component.scss'],

})
export class AccountDetailPageComponent implements OnInit, OnDestroy {

  constructor(private store: Store<IAccountsListState>, private active: ActivatedRoute, private router: Router) { }

  public account$ = this.store.pipe(select(getAccountDetail));
  destroy$: Subject<boolean> = new Subject<boolean>();
  private id: number = null;

  public depsEnabled = this.store.select(getEditDeputiesEnabled);
  public enableAccEnabled = this.store.select(getEnableAccountEnabled);
  public disableAccEnabled = this.store.select(getDisableAccountEnabled);
  public resetEnabled = this.store.select(getResetPasswordEnabled);
  public selectedAccountType = null;
  public selectedAccountType$ = this.store.select(getSelectedAccountType).pipe(takeUntil(this.destroy$)).subscribe((val) => this.selectedAccountType = val);

  public activetab = new BehaviorSubject('')

  public kebabBtns$ = combineLatest(this.depsEnabled, this.activetab).pipe(
    map(([depEnabled, tab]) => {
      return [{
        actionName: 'openAddDeputiesWindow',
        disabled: !(depEnabled && tab === 'delegation')
      }, {
        actionName: 'openRemoveDeputiesWindow',
        disabled: !(depEnabled && tab === 'delegation')
      }, {
        actionName: 'downloadCSV',
        disabled: true
      }, {
        actionName: 'downloadSelectedCSV',
        disabled: true
      }]
    })
  )

  public resetOpen = false;


  private subFirstChild: Subscription
  public getChildRoute() {
    if (this.subFirstChild) {
      this.subFirstChild.unsubscribe()
    }
    if (this.active.firstChild)
      this.active.firstChild.url.subscribe(url => {
        this.activetab.next(url[0] ? url[0].path : null)
      });
  }

  public ngOnInit() {
    this.active.paramMap.subscribe((r: any) => {
      this.id = parseInt(r.params.id);
      this.store.dispatch(new LoadAccountDetail(this.id));
      this.store.dispatch(new SetSelectedAccounts({ ids: [this.id], isAll: false }));
    });

    this.getChildRoute()

    this.router.events.subscribe(e => {
      if (e instanceof NavigationEnd) {
        this.getChildRoute()
      }
    });
  }

  ngOnDestroy() {
    if (this.subFirstChild) {
      this.subFirstChild.unsubscribe()
    }
    this.destroy$.next(false);
    this.destroy$.unsubscribe();
  }

  public close() {

  }

  public math = Math;

  public accountAction(e) {
    switch (e) {
      case 'openResetWindow':
        this.store.dispatch(new OpenResetPassModal());
        break;
      case 'openAddDeputiesWindow':
        this.store.dispatch(new OpenAddRemoveDeputyModal('Add'));
        break;
      case 'openRemoveDeputiesWindow':
        this.store.dispatch(new OpenAddRemoveDeputyModal('Remove'));
        break;
      case 'enableAccounts':

        if (this.selectedAccountType === 'TECHNICAL')
          this.store.dispatch(new OpenEndOfLifeModal("Enable"));
        else if (this.selectedAccountType === 'SERVICE')
          this.store.dispatch(new OpenEnableDisableModal('Enable'));
        else
          this.store.dispatch(new OpenTASAModal());
        break;
      case 'disableAccounts':
        this.store.dispatch(new DisableAccounts());
        break;
    }
  }

  public expiryAction(e) {
    switch (e) {
      case 'DISABLE':
        this.store.dispatch(new OpenEndOfLifeModal("Enable"))
        break;
      default:
        this.store.dispatch(new OpenEndOfLifeModal("Self"))
        break;

    }
  }
  expiryMessageInfo(account: IAccount): 'expired' | 'about-to-expire' | 'expiration-not-near' | 'no-expiration' {
    if (account.type === 'TECHNICAL') {

      if (account.AccountExpirationDays === 0 && account.end_of_lifecycle_date) {
        return "expired";
      }
      if (account.AccountExpirationDays === 0 && !account.end_of_lifecycle_date) {
        return "no-expiration";
      }
      else if (account.AccountExpirationDays < 0) {
        return "expired";
      }
      else if (account.AccountExpirationDays <= 30) {
        return "about-to-expire";
      }
      else if (account.AccountExpirationDays > 30) {
        return "expiration-not-near";
      }
    }
    else
      return undefined;
  }

}
