import { getAccountDetail } from './../../store/selectors/index';
import { AppState } from './../../../../shared/store/reducers/index';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { AccountDetailInfoComponent } from './account-detail-info.component';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { CommonModule } from '@angular/common';
import { StaticValueDisplayComponent } from 'src/app/shared/components/static-value-display/static-value-display.component';
import { By } from '@angular/platform-browser';
import { EditAccountDescription } from '../../store';
import { timeout } from 'rxjs/operators';
import { of } from 'rxjs';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { PenIconComponent } from 'src/app/shared/icons/pen-icon/pen-icon.component';
import { IconModule } from 'src/app/modules/icon.module';

describe('AccountDetailInfoComponent', () => {
    let component: AccountDetailInfoComponent;
    let fixture: ComponentFixture<AccountDetailInfoComponent>;
    let elem: HTMLElement;
    const initialState: AppState = defaultTestStore;
    let store: MockStore<AppState>;

    window.matchMedia = jest.fn().mockImplementation(query => {
        return {
            matches: false,
            media: query,
            onchange: null,
            addListener: jest.fn(),
            removeListener: jest.fn(),
        };
    });

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, TranslateModule.forRoot(), RouterTestingModule, IconModule],
            providers: [
                provideMockStore({ initialState })
            ],
            declarations: [AccountDetailInfoComponent, StaticValueDisplayComponent, DateDisplayComponent]
        }).compileComponents().then(() => {
            fixture = TestBed.createComponent(AccountDetailInfoComponent);
            component = fixture.componentInstance;
            fixture.detectChanges();
            elem = fixture.nativeElement;
            store = TestBed.get(Store);
        });
    }));

    it('expect 23 values to be displayed', () => {
        expect(elem.querySelectorAll('app-2f82-static-value-display').length).toBe(23);
    });
    it('expect account description to be displayed', () => {
        const descriptionText = initialState.accountsModule.accountsList.detailAccount.description;
        expect(descriptionText.length).toBeGreaterThan(20);
        expect(elem.querySelector('#acc-usage').innerHTML).toBe(descriptionText);
    });
    it('editable description text', async () => {
        const newDescription = 'this is a drill';
        elem.querySelector('#acc-usage').innerHTML = newDescription;
        expect(elem.querySelector('#acc-usage').innerHTML).toBe(newDescription);
    });
    // it('save description button to be present', async () => {
    //     const btn = elem.querySelector('#save-description')
    //     expect(btn).toBeTruthy()
    // });
    // it('shows reset scheduled date and time in correct format', async () => {
    //     component.$account = of(initialState.accountsModule.accountsList.detailAccount);
    //     fixture.detectChanges();
    //     const resetElem = elem.querySelector('app-2f82-static-value-display[label="Schedule Reset Password"] .static-value');
    //     expect(resetElem).toBeTruthy();
    //     expect(resetElem.textContent).toMatch(/^\d{2}\/\d{2}\/\d{4}\s\d{1,2}:\d{2}\s[PAM]{2}\sGMT\+\d/);
    // });
});
