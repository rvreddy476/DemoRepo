import { Observable, BehaviorSubject, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { LoadAccountDetail, EditAccountDescription, OpenEditDescriptionModal, OpenPasswordReceiverModal, EditPasswordReceiver } from './../../store/actions/accounts-list.actions';
import { getAccountDetail, getAccountComplianceStatus, permissionToEditPasswordReceiver } from './../../store/selectors/index';
import { ActivatedRoute } from '@angular/router';
import { IAccountsListState, IAccountComplianceStatus } from './../../../../shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { environment } from './../../../../../environments/environment.prod';
import { Component, OnInit, Input, OnDestroy, ViewChild, AfterViewChecked, ElementRef, ViewEncapsulation } from '@angular/core';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { tap, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { formatDisplayName } from 'src/app/shared/helper-functions';

@Component({
  selector: 'app-2f82-account-detail-info',
  templateUrl: './account-detail-info.component.html',
  styleUrls: ['./account-detail-info.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AccountDetailInfoComponent {

  public $account: Observable<IAccount>;
  public $complianceStatus: Observable<IAccountComplianceStatus>;
  public showDetails = false;
  $CanEditPasswordReceiver: any;

  constructor(private store: Store<IAccountsListState>, private active: ActivatedRoute) {
    this.$account = this.store.pipe(select(getAccountDetail))
  }


  ngOnInit() {
    this.$complianceStatus = this.store.pipe(select(getAccountComplianceStatus))
    this.$CanEditPasswordReceiver = this.store.pipe(select(permissionToEditPasswordReceiver))
  }

  public openReason(event: Event, isCompliant) {
    var popup = (<HTMLTextAreaElement>event.currentTarget).firstElementChild;
    if (!popup.classList.contains("show-reason")) {
      var lights = document.getElementsByClassName("show-reason");
      while (lights.length)
        lights[0].className = lights[0].className.replace(/\bshow-reason\b/g, "")
    }
    if (!popup.classList.contains("Compliant"))
      popup.classList.toggle("show-reason");
  }



  public openDetails(event: Event) {
    var innerDiv = (<HTMLTextAreaElement>event.currentTarget).parentElement.lastElementChild;
    this.showDetails = !this.showDetails;
    innerDiv.classList.toggle("show");
  }

  public openEditModal() {
    this.store.dispatch(new OpenEditDescriptionModal());
  }
  public AddPasswordReceiver() {
    this.store.dispatch(new OpenPasswordReceiverModal({ email: null, action: 'ADD' }));
  }
  public DeletePasswordReceiverModal(email) {
    this.store.dispatch(new OpenPasswordReceiverModal({ email, action: 'DELETE' }));
  }

  public formatDN(dn) {
    return formatDisplayName(dn)
  }
  public deletePasswordReceiver(email) {
    console.log(email);
    this.store.dispatch(new EditPasswordReceiver({ email, action: 'DELETE' }))
  }

  public derivePasswordStatus(acc: IAccount) {
    if (acc.pwdStatus === 'NO_PASSWORD') {
      return {
        text: `-`,
        value: null
      };
    }
    if (acc.pwdStatus === 'EXPIRED') {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRED_SINCE`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    } else {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    }
  }

}
