import { getAccountDetail } from './../../store/selectors/index';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { IAccountsListState, IAccountHistory } from './../../../../shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, ViewEncapsulation, ViewChild, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { map, delay } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-account-detail-history',
  templateUrl: './account-detail-history.component.html',
  styleUrls: ['./account-detail-history.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: {
    style: `
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    `
  }
})
export class AccountDetailHistoryComponent implements OnInit, OnDestroy {
  @ViewChild('gridSizer') private gridSizer;

  constructor(private store: Store<IAccountsListState>) { }

  /**
 * default height of grid while waiting for calculation
 */
  public gridHeight = 500;

  /**
   * history list observale to populate the grid
   */
  public $history: Observable<IAccountHistory[]>;
  private subs: Subscription[];

  public ngOnInit() {
    this.$history = this.store.pipe(select(getAccountDetail)).pipe(
      map(acc => (acc ? acc.history || [] : []).sort((a,b) => a.dateUtc < b.dateUtc ? 1 : -1))
    );
    this.subs = [
      this.$history.pipe(delay(100)).subscribe(() => {
        this.gridHeight = this.gridSizer.nativeElement.clientHeight;
      })
    ];
  }

  public ngOnDestroy() {
    this.subs.forEach(sub => sub.unsubscribe());
  }
}
