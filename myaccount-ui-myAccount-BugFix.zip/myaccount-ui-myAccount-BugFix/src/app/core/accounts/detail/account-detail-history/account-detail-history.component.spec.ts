import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Chart } from 'chart.js';
import { defaultTestStore } from './../../../../shared/mock-data';

import { AppState } from '../../../../shared/store';
import { Store } from '@ngrx/store';
import { AccountDetailHistoryComponent } from './account-detail-history.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { IAccountHistory } from 'src/app/shared/interfaces/shared/account/account';
import { of } from 'rxjs';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';

describe('AccountDetailHistoryComponent', () => {
  const makeHistState = (statsState: Partial<IAccountHistory[]>): AppState => {
    return {
      ...defaultTestStore, accountsModule:
      {
        ...defaultTestStore.accountsModule,
        accountsList: {
          ...defaultTestStore.accountsModule.accountsList,
          detailAccount: {
            ...defaultTestStore.accountsModule.accountsList.detailAccount,
            history: defaultTestStore.accountsModule.accountsList.detailAccount.history
          }
        }
      }
    };
  };
  const mockData = {
    sampleAction: [{
      action: 'ACCOUNT_CREATION',
      dateUtc: new Date('2019-11-06T10:57:59.343Z'),
      scheduledDateUtc: null,
      messageParams: [],
      message: '',
      description: 'this is the description',
      owner: 'MCBRYDE, Justin (DEVOTEAM)'
    }],
  };

  let component: AccountDetailHistoryComponent;
  let fixture: ComponentFixture<AccountDetailHistoryComponent>;
  let elem: HTMLElement;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  const initialState: AppState = makeHistState(mockData.sampleAction);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, NoopAnimationsModule, GridModule],
      providers: [
        provideMockStore({ initialState }),
      ],
      declarations: [AccountDetailHistoryComponent, DateDisplayComponent]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(AccountDetailHistoryComponent);
      component = fixture.componentInstance;
      elem = fixture.nativeElement;
      fixture.detectChanges();
      store = TestBed.get(Store);
      // console.log(elem.outerHTML.replace(/(?=<!--)([\s\S]*?)-->/g,''))
    });
  }));

  it('displays the correct colunm titles', () => {
    const header = elem.querySelector('.k-grid-header');
    expect(header).toBeTruthy();
    const titles = header.querySelectorAll('th[role=columnheader]');
    expect(titles.length).toBe(4);
    expect(titles[0].textContent).toBe('ACCOUNT_DETAIL.HISTORY.TABLE_LABEL.DATE');
    expect(titles[1].textContent).toBe('ACCOUNT_DETAIL.HISTORY.TABLE_LABEL.ACTION');
    expect(titles[2].textContent).toBe('ACCOUNT_DETAIL.HISTORY.TABLE_LABEL.ACTION_OWNER');
    expect(titles[3].textContent).toBe('ACCOUNT_DETAIL.HISTORY.TABLE_LABEL.COMMENT');
  });

  it('displays fields to display correctly', () => {
    component.$history = of(mockData.sampleAction);
    fixture.detectChanges();
    const firstRow = elem.querySelectorAll('table.k-grid-table')[0];
    expect(firstRow).toBeTruthy();
    // console.log(firstRow.outerHTML.replace(/(?=<!--)([\s\S]*?)-->/g,''))
    const cells = firstRow.querySelectorAll('[role=gridcell]');
    expect(cells.length).toBe(4);
    expect(cells[0].textContent).toMatch(/^\d{2}\/\d{2}\/\d{4}\s\d{1,2}:\d{2}\s[PAM]{2}\s\(GMT\+\d\)/);
    expect(cells[1].textContent).toBe(`ACCOUNT_DETAIL.HISTORY.ACTION.${mockData.sampleAction[0].action}`);
    expect(cells[2].textContent).toBe(mockData.sampleAction[0].owner);
    expect(cells[3].textContent).toBe('ACCOUNT_DETAIL.HISTORY.ACTION.MESSAGE.');
  });

});
