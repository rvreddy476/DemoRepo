import { AccountsResetPopupComponent } from './list/accounts-reset-popup/accounts-reset-popup.component';
import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from '../../modules/shared.module';
import { AccountsRoutingModule } from './accounts-routing.module';
import { AccountsComponent } from './accounts.component';
import { UserAccountsListComponent } from './list/user-accounts-list/user-accounts-list.component';
import { effects, reducers } from './store';
import { AccountsActionbarComponent } from './list/accounts-actionbar/accounts-actionbar.component';
import { AccountsSearchPanelComponent } from './list/accounts-search-panel/accounts-search-panel.component';
import { AccountsDetailSearchComponent } from './list/accounts-search-panel/accounts-detail-search/accounts-detail-search.component';
import { AccountsGlobalSearchComponent } from './list/accounts-search-panel/accounts-global-search/accounts-global-search.component';
import { AccountsFilterPillsComponent } from './list/accounts-search-panel/accounts-filter-pills/accounts-filter-pills.component';
import { AccountDetailPageComponent } from './detail/account-detail-page/account-detail-page.component';
import { AccountDetailInfoComponent } from './detail/account-detail-info/account-detail-info.component';
import { AccountDetailHistoryComponent } from './detail/account-detail-history/account-detail-history.component';
import { AccountActionIconBarComponent } from './list/account-action-icon-bar/account-action-icon-bar.component';
import { AccountApprovePageComponent } from './approve/account-approve-page/account-approve-page.component';
import { ResetPasswordModalComponent } from './components/reset-password-modal/reset-password-modal.component';
import { ApproveAccountModalComponent } from './components/approve-account-modal/approve-account-modal.component';
import { ActionFollowUpComponent } from './follow-up/action-follow-up/action-follow-up.component';
import { FollowUpModalComponent } from './components/follow-up-modal/follow-up-modal.component';
import { AddRemoveDeputiesModalComponent } from './components/add-remove-deputies-modal/add-remove-deputies-modal.component';
import { FollowUpBaseComponent } from './follow-up/follow-up-base/follow-up-base.component';
import { ResetPasswordScheduledFollowUpComponent } from './follow-up/reset-password-scheduled-follow-up/reset-password-scheduled-follow-up.component';
import { ViewClearAccSelectionComponent } from './list/view-clear-acc-selection/view-clear-acc-selection.component';
import { FormPasswordExpDropdown } from './list/accounts-search-panel/filters/form-password-exp-dropdown';
import { SharedTranslateModule } from 'src/app/modules/shared-translate.module';
import { EditDescriptionModalComponent } from './components/edit-description-modal/edit-description-modal.component';
import { EnableDisableModalComponent } from './components/enable-disable-modal/enable-disable-modal.component';
import { SelectionLimitModalComponent } from './components/selection-limit-modal/selection-limit-modal.component';
import { AccountDetailDelegationComponent } from './detail/account-detail-delegation/account-detail-delegation.component';
import { CSVExporter } from 'src/app/shared/services/csv-exporter';
import { EndOfLifeModalComponent } from './components/end-of-life-modal/end-of-life-modal.component';
import { EditPasswordReceiverComponent } from './components/edit-password-receiver-modal/edit-password-receiver-modal.component';
import { KendoModule } from 'src/app/modules/kendo.module';
import { ButtonsModule } from '@progress/kendo-angular-buttons';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('accountsModule', reducers),
    EffectsModule.forFeature(effects),
    AccountsRoutingModule,
    SharedTranslateModule,

  ],
  providers: [
    CSVExporter
  ],
  declarations: [AccountsResetPopupComponent, AccountsComponent, UserAccountsListComponent, AccountsActionbarComponent, AccountsGlobalSearchComponent, AccountsSearchPanelComponent, AccountsDetailSearchComponent, AccountsFilterPillsComponent, AccountDetailPageComponent, AccountDetailInfoComponent, AccountDetailHistoryComponent, AccountActionIconBarComponent, AccountApprovePageComponent, ResetPasswordModalComponent, ApproveAccountModalComponent, ActionFollowUpComponent, FollowUpModalComponent, AddRemoveDeputiesModalComponent, FollowUpBaseComponent, ResetPasswordScheduledFollowUpComponent, ActionFollowUpComponent, ViewClearAccSelectionComponent, FormPasswordExpDropdown, EditDescriptionModalComponent, EnableDisableModalComponent, SelectionLimitModalComponent, EndOfLifeModalComponent, AccountDetailDelegationComponent, EditPasswordReceiverComponent],
})

export class AccountsModule { }
