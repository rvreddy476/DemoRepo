import { createFeatureSelector, createSelector, select } from '@ngrx/store';
import { IAccountsState } from '../reducers';
import { pwdRemainingDaysFilterFunct } from './filters';
import { orderBy, SortDescriptor, filterBy, CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { getIdentity } from 'src/app/shared/store/selectors';
import { EntityState } from '@ngrx/entity';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { accountsListAdaptor } from '../reducers/list.reducer';

// high level selectors

const getAccountsState = createFeatureSelector<IAccountsState>('accountsModule');

//#region accounts LIST


export const getAccountsListState = createSelector(
  getAccountsState,
  (state: IAccountsState) => state.accountsList
);

export const getAccountList = createSelector(
  getAccountsState,
  (state: IAccountsState) => state.accountsList.accounts
);


export const getAccountsViewState = createSelector(
  getAccountsListState,
  (state) => state.viewState
);

export const getAccountsGridState = createSelector(
  getAccountsViewState,
  (state) => state.gridState
);
export const getGridSort = createSelector(
  getAccountsGridState,
  (state) => state.sort
);
export const getGridFilters = createSelector(
  getAccountsGridState,
  (state) => state.filter
);
export const getSelectedAccounts = createSelector(
  getAccountsListState,
  (state) => state.selectedAccounts
);

/**
 * List of account ids which should be only shown
 */
const getAccountsShowOnlyList = createSelector(
  getAccountsViewState,
  getSelectedAccounts,
  (view, selected) => view.showOnlySelected ? selected : []
);


/**
 * Sorted raw full accounts list without filtering
 */
export const getSortedAccountList = createSelector(
  getAccountList,
  getGridSort,
  (list = [], sort) => {
    return sort ? orderBy(list, sort) : list;
  }
);

export const getAboutToExpireAccounts = createSelector(
  getSortedAccountList,
  (accountList) => {
    const currentDate = new Date();

    const filteredAccounts = accountList.filter(account => (account.type === 'TECHNICAL' && (account.AccountExpirationDays !== 0 ? account.AccountExpirationDays < 31 : false) && !account.locked && account.lifeCycleStatus !== 'DISABLE'));
    return filteredAccounts;
  }
)

/**filtered and sorted full accounts list */
export const getSortedFilteredAccountList = createSelector(
  getSortedAccountList,
  getGridFilters,
  (list = [], filter) => {
    return filter ? filterBy(list, filter) : list;
  }
);

/**Currenty visible chunk of accounts */
export const getVisibleAccounts = createSelector(
  getSortedAccountList,
  getSortedFilteredAccountList,
  getAccountsGridState,
  getAccountsShowOnlyList,
  (fullList, filteredList, gridState, showOnly) => {
    const list = showOnly.length > 0 ? fullList.filter(acc => showOnly.indexOf(acc.id) !== -1) : filteredList;
    const data = list.slice(gridState.skip, gridState.take + gridState.skip);
    return {
      data,
      total: list.length,
      maximum: data.length
    };
  }
);
export const getAccountDetail = createSelector(
  getAccountsListState,
  (state) => state.detailAccount
);

export const getAccountComplianceStatus = createSelector(
  getAccountDetail,
  (state) => state.compliance_status
);


/**Currenty selected  accounts */
export const getSelectedAccountsList = createSelector(
  getAccountList,
  getSelectedAccounts,
  getAccountDetail,
  (list, selected, detail) => {
    if (detail && list.length === 0 && selected.length === 1) {
      return selected[0] === detail.id ? [detail] : []
    }
    return list.filter(acc => selected.indexOf(acc.id) !== -1);
  }
);

export const getSelectAllStatus = createSelector(
  getSortedFilteredAccountList,
  getSelectedAccounts,
  (filtered, selected) => {
    filtered = filtered.filter(acc => (!acc.locked && !acc.hp));
    // 'unchecked' | 'indeterminate' | 'checked'

    // none are selected
    if (selected.length === 0) {
      return 'unchecked';
    }

    // less selected than filtered
    if (selected.length < filtered.length) {
      return 'indeterminate';
    }

    // some of the filtered accounts are not selected
    if (filtered.some(acc => selected.indexOf(acc.id) === -1)) {
      return 'indeterminate';
    }
    return 'checked';
  }
);

export const getSelectedAccountType = createSelector(
  getSelectedAccountsList,
  (list) => {
    if (list.every(a => a.type == 'TECHNICAL')) {
      return 'TECHNICAL'
    }
    if (list.every(a => a.type == 'SERVICE')) {
      return 'SERVICE'
    }
    if (list.some(a => a.type == 'SERVICE') && list.some(a => a.type == 'TECHNICAL')) {
      return 'TASA'
    }
  }
);

//#endregion

const getApproveListState = createSelector(
  getAccountsState,
  (state: IAccountsState) => state.approveList
);

const getFollowUpState = createSelector(
  getAccountsState,
  (state: IAccountsState) => state.followUpList
);

const getfilterValueByField = (filters: (CompositeFilterDescriptor | FilterDescriptor)[], field: string): string | number | FilterDescriptor[] => {
  // check if there are filters
  if (!filters) {
    return null;
  }

  const values = filters.filter(f => {

    const fd = f as FilterDescriptor;
    const fcfd = f as CompositeFilterDescriptor;

    if (fd.field) {
      return fd.field === field;
    }
    if (fcfd.filters) {
      return fcfd.filters.every((nf: FilterDescriptor) => nf.field ? nf.field === field : false);
    }
  });

  if (values.length === 0) {
    return '';
  }

  if (values[0].hasOwnProperty('value')) {
    return (values[0] as FilterDescriptor).value;
  } else {
    return (values[0] as CompositeFilterDescriptor).filters.map(cf => {
      return (cf as FilterDescriptor).value;
    });
  }

};

// low level selectors

// export const getAreAllSelected = createSelector(
//   getAccountsListState,
//   (state) => (state.visibleAccounts.total === state.selectedAccounts.length && state.visibleAccounts.total > 0)
// );
// export const getAreSomeSelected = createSelector(
//   getAccountsListState,
//   (state) => state.selectedAccounts.length > 0
// );
// export const getVisibleAccountsList = createSelector(
//   getAccountsListState,
//   (state) => state.visibleAccounts
// );
export const getAccountsListLoaded = createSelector(
  getAccountsListState,
  (state) => state.loaded
);
export const getAccountsAllIds = createSelector(
  getAccountsListState,
  (state) => state.allAccounts
);
export const getAccountsListLoading = createSelector(
  getAccountsListState,
  (state) => state.loading
);



export const getAccountsEnabledColumns = createSelector(
  getAccountsListState,
  (state) => state.enabledColumns
);

export const getBenchmarks = createSelector(
  getAccountsListState,
  (state) => state.benchmarks
);



export const getAccountsDetail = createSelector(
  getAccountsListState,
  (state) => state.selectedAccountsDetails
);

// very low level selectors!


export const getAccountsVisibleColumns = createSelector(
  getAccountsViewState,
  (state) => state.visibleColumns
);
export const getAccountsDetailRowUID = createSelector(
  getAccountsViewState,
  (state) => state.detailRowID
);
export const getAccountsShowOnlyUID = createSelector(
  getAccountsViewState,
  (state) => state.showOnlyUID
);



export const getAdvancedFilterPanelOpen = createSelector(
  getAccountsListState,
  (state) => state.advancedFilterPanelOpen
);


//#region Filter Selectors

export const getUIDFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'uid')
);

export const getContextFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'contextName')
);

export const getDirectoryEnvironmentFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'directoryEnvironment')
);

export const getLifeCycleStatusFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'lifeCycleStatus')
);

export const getTypeFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'type')
);

export const getDirectoryTypeFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'directoryType')
);
export const getPwdStatusFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'pwdStatus')
);
export const getDirectoryDomainFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'directoryDomain')
);
export const getPasswordLifetimeFilterValue = createSelector(
  getGridFilters,
  (filters) => getfilterValueByField(filters ? filters.filters : [], 'pwdRemainingDays')
);

//#endregion



export const getFilterPwdRemainingDays = createSelector(
  getAccountsGridState,
  (state) => pwdRemainingDaysFilterFunct(state)
);

export const getAccountsUniqueLifeCycleStatus = createSelector(
  getAccountsListState,
  (state) => state.unique.lifeCycleStatus
);
export const getAccountsUniqueType = createSelector(
  getAccountsListState,
  (state) => state.unique.type
);
export const getAccountsUniquePwdStatus = createSelector(
  getAccountsListState,
  (state) => state.unique.pwdStatus
);
export const getAccountsUniqueDirectoryEnvironment = createSelector(
  getAccountsListState,
  (state) => state.unique.directoryEnvironment
);
export const getAccountsUniqueDirectoryType = createSelector(
  getAccountsListState,
  (state) => state.unique.directoryType
);
export const getAccountsUniqueDirectoryDomain = createSelector(
  getAccountsListState,
  (state) => state.unique.directoryDomain
);
export const getAccountsUniqueDivision = createSelector(
  getAccountsListState,
  (state) => state.unique.division
);

export const getAccountsResetModal = createSelector(
  getAccountsState,
  (state) => state.accountsList.resetPassModal
);

export const getAccountsEnfOfLifeModal = createSelector(
  getAccountsState,
  (state) => state.accountsList.endOfLifeModal
);

export const getBusinessHours = createSelector(
  getAccountsState,
  (state) => state.accountsList.businessHrsUTC
);


//#region approve account selectors

export const getApproveAccounts = createSelector(
  getApproveListState,
  (state) => state.accounts
);

export const getSelectedApproveAccounts = createSelector(
  getApproveListState,
  (state) => state.accounts.filter(acc => state.selected.indexOf(acc.id) !== -1)
);

export const getApproveSelectedIds = createSelector(
  getApproveListState,
  (state) => state.selected
);

export const getApproveModal = createSelector(
  getApproveListState,
  (state) => state.modal
);

//#endregion

//#region add-remove deputies


export const getAddRemoveDeputiesModal = createSelector(
  getAccountsListState,
  (state) => state.addRemoveDeputyModal
);

const permissionToEditDeputiesOfSelection = createSelector(
  getAddRemoveDeputiesModal,
  (state) => state.permissionToEditSelection
);
export const getPasswordReceiverModal = createSelector(
  getAccountsListState,
  (state) => state.editPasswordReceiverModal
);

export const permissionToEditPasswordReceiver = createSelector(
  getPasswordReceiverModal,
  (state) => state.canEdit
);

export const getEditDeputiesEnabled = createSelector(
  getSelectedAccountsList,
  permissionToEditDeputiesOfSelection,
  (selected, permission) => {

    if (selected.length === 0) {
      return false;
    }
    if (selected.some(sel => (sel.locked || sel.hp))) {
      return false;
    }
    if (selected.length > 1) {
      return true;
    }

    if (selected.length === 1 && permission) {
      return true;
    }

    return false;
  }
);


//#endregion

//#region enable disable account

export const getEnableDisableModal = createSelector(
  getAccountsListState,
  (state) => state.enableDisableAccModal
);

export const getEnableAccountEnabled = createSelector(
  getSelectedAccountsList,
  getIdentity,
  (selected = [], identity) => {

    if (selected.length === 0) {
      return false;
    }

    if (selected.some(sel => (sel.locked || sel.hp))) {
      return false;
    }

    if (selected.some(sel => sel.lifeCycleStatus !== 'DISABLE')) {
      return false;
    }

    return true;
  }
);

export const getResetPasswordEnabled = createSelector(
  getSelectedAccountsList,
  (selected = []) => {

    if (selected.length === 0) {
      return false;
    }

    if (selected.length > 1) {
      return true
    }

    if (selected.some(sel => (sel.locked || sel.hp))) {
      return false;
    }

    if (selected.some(sel => !sel.canReset)) {
      return false;
    }

    if (selected.some(sel => sel.pwdRemainingDays === null)) {
      return false;
    }
    return true;
  }
);

export const getDisableAccountEnabled = createSelector(
  getSelectedAccountsList,
  getIdentity,
  (selected = [], identity) => {

    if (selected.length === 0) {
      return false;
    }

    if (selected.some(sel => (sel.locked || sel.hp))) {
      return false;
    }

    if (selected.some(sel => sel.lifeCycleStatus !== 'ENABLE')) {
      return false;
    }

    return true;
  }
);

//#region follow up selectors

export const getFollowUpActions = createSelector(
  getFollowUpState,
  (state) => state.actions
);
export const getFollowUpScheduled = createSelector(
  getFollowUpState,
  (state) => {
    return state.scheduledResets.filter(a => a.scheduledDate instanceof Date).sort((a, b) => a.scheduledDate.getTime() > b.scheduledDate.getTime() ? 1 : -1);
  }
);

// export const getShowMaxSelectionWarningModal = createSelector(
//   getAccountsListState,
//   (state) => state.showMaxLengthWarning
// );
// export const getShowMaxSelectionWarningModalApprRej = createSelector(
//   getApproveListState,
//   (state) => state.showMaxLengthWarning
// );

export const getSelectedFollowUpActions = createSelector(
  getFollowUpState,
  (state) => state.selected
);

export const getFollowUpModal = createSelector(
  getFollowUpState,
  (state) => state.modal
);

export const getEditDescriptionModal = createSelector(
  getAccountsListState,
  (state) => state.editDescriptionModal
);


//#endregion

export const getEndofLifeModal = createSelector(
  getAccountsListState,
  (state) => state.endOfLifeModal
);

export const getEndOfLifeCycleDateExpirationDays = createSelector(
  getSelectedAccountsList,

);

export const getApprovedSelectAllStatus = createSelector(
  getApproveAccounts,
  getSelectedAccounts,
  (filtered, selected) => {
    // filtered = filtered.filter(acc => (!acc.locked && !acc.hp));
    // 'unchecked' | 'indeterminate' | 'checked'

    // none are selected
    if (filtered.length === 0) {
      return 'unchecked';
    }

    // less selected than filtered
    if (selected.length < filtered.length) {
      return 'indeterminate';
    }

    // some of the filtered accounts are not selected
    if (filtered.some(acc => selected.indexOf(acc.id) === -1)) {
      return 'indeterminate';
    }
    return 'checked';
  }
);

