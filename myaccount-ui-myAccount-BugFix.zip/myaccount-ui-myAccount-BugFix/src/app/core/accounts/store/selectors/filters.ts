import { State, CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';

export const pwdRemainingDaysFilterFunct = (state: State) => {
  let res: CompositeFilterDescriptor[];
  try {
    res = state.filter.filters.filter((f) => {
      const cfd = f as CompositeFilterDescriptor;
      return cfd.filters ? cfd.filters.every((fieldF: FilterDescriptor) => fieldF.field === 'pwdRemainingDays') : false;
    }) as CompositeFilterDescriptor[];
    return res[0].filters;
  } catch (err) {
    return null;
  }
};
