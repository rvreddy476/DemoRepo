import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { Action } from '@ngrx/store';
import { TActionFollowUp, TScheduledPasswordFollowUp } from 'src/app/shared/interfaces/shared/account/follow-up';


export const REQUEST_ACTION_FOLLOW_UP_LIST = '[follow-up-list] get follow-up actions';
export const REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS = '[follow-up-list] get follow-up actions successful';
export const REQUEST_ACTION_FOLLOW_UP_LIST_FAIL = '[follow-up-list] get follow-up actions failed';

export const REQUEST_SCHEDULED_FOLLOW_UP_LIST = '[follow-up-list] get follow-up resets scheduled';
export const REQUEST_SCHEDULED_FOLLOW_UP_LIST_SUCCESS = '[follow-up-list] get follow-up resets scheduled successful';
export const REQUEST_SCHEDULED_FOLLOW_UP_LIST_FAIL = '[follow-up-list] get follow-up resets scheduled failed';

export const SELECT_FOLLOW_UP = '[follow-up-list] select account pending approvial';
export const DESELECT_FOLLOW_UP = '[follow-up-list] deselect account pending approvial';

export const OPEN_FOLLOW_UP_MODAL = '[follow-up-list] Open Cancel Request Modal';
export const CLOSE_FOLLOW_UP_MODAL = '[follow-up-list] Close Cancel Request Modal';

export const CANCEL_PENDING_REQUEST = '[follow-up-list] Cancel Pending Requst';
export const CANCEL_PENDING_REQUEST_SUCCESS = '[follow-up-list] Cancel Pending Requst successful';
export const CANCEL_PENDING_REQUEST_FAILED = '[follow-up-list] Cancel Pending Requst failed';

export const CANCEL_SCHEDULED_PASSWORD_RESET = '[follow-up-list] Cancel Scheduled Password Reset';
export const CANCEL_SCHEDULED_PASSWORD_RESET_SUCCESS = '[follow-up-list] Cancel Scheduled Password Reset successful';
export const CANCEL_SCHEDULED_PASSWORD_RESET_FAILED = '[follow-up-list] Cancel Scheduled Password Reset failed';

export class requestActionFollowUp implements Action {
    public readonly type = REQUEST_ACTION_FOLLOW_UP_LIST;
}
export class requestActionFollowUpSuccess implements Action {
    public readonly type = REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS;
    constructor(public payload: {status: IResStatus, data: TActionFollowUp[]}) {}
}
export class requestActionFollowUpFail implements Action {
    public readonly type = REQUEST_ACTION_FOLLOW_UP_LIST_FAIL;
    constructor(public payload: IResStatus) {}
}
export class requestScheduledFollowUp implements Action {
    public readonly type = REQUEST_SCHEDULED_FOLLOW_UP_LIST;
}
export class requestScheduledFollowUpSuccess implements Action {
    public readonly type = REQUEST_SCHEDULED_FOLLOW_UP_LIST_SUCCESS;
    constructor(public payload: {status: IResStatus, data: TScheduledPasswordFollowUp[]}) {}
}
export class requestScheduledFollowUpFail implements Action {
    public readonly type = REQUEST_SCHEDULED_FOLLOW_UP_LIST_FAIL;
    constructor(public payload: IResStatus) {}
}

export class selectFollowUpAction implements Action {
    public readonly type = SELECT_FOLLOW_UP;
    constructor(public payload: number[]) {}
}
export class deselectFollowUpAction implements Action {
    public readonly type = DESELECT_FOLLOW_UP;
    constructor(public payload: number[]) {}
}
export class openFollowUpModal implements Action {
    public readonly type = OPEN_FOLLOW_UP_MODAL;
    constructor(public payload: TScheduledPasswordFollowUp | TActionFollowUp) {}
}
export class closeFollowUpModal implements Action {
    public readonly type = CLOSE_FOLLOW_UP_MODAL;
}

export class cancelPendingRequest implements Action {
    public readonly type = CANCEL_PENDING_REQUEST;
    constructor(public payload: number) {}
}

export class cancelPendingRequestSuccess implements Action {
    public readonly type = CANCEL_PENDING_REQUEST_SUCCESS;
    constructor(public payload: {id: number}) {}
}

export class cancelPendingRequestFailed implements Action {
    public readonly type = CANCEL_PENDING_REQUEST_FAILED;
    constructor(public payload: IResStatus) {}
}

export class cancelScheduledPasswordReset implements Action {
    public readonly type = CANCEL_SCHEDULED_PASSWORD_RESET;
    constructor(public payload: number) {}
}

export class cancelScheduledPasswordResetSuccess implements Action {
    public readonly type = CANCEL_SCHEDULED_PASSWORD_RESET_SUCCESS;
    constructor(public payload: number) {}
}

export class cancelScheduledPasswordResetFailed implements Action {
    public readonly type = CANCEL_SCHEDULED_PASSWORD_RESET_FAILED;
    constructor(public payload: IResStatus) {}
}

export type AcceptListAction =
    | requestActionFollowUp
    | requestActionFollowUpSuccess
    | requestActionFollowUpFail
    | requestScheduledFollowUp
    | requestScheduledFollowUpSuccess
    | requestScheduledFollowUpFail
    | selectFollowUpAction
    | deselectFollowUpAction
    | openFollowUpModal
    | closeFollowUpModal
    | cancelPendingRequest
    | cancelPendingRequestSuccess
    | cancelPendingRequestFailed
    | cancelScheduledPasswordReset
    | cancelScheduledPasswordResetSuccess
    | cancelScheduledPasswordResetFailed;
