import { IAccountDeputity, IBusinessHrsUTC } from './../../../../shared/interfaces/shared/account/account';
import { Action } from '@ngrx/store';
import { State, CompositeFilterDescriptor, SortDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { IAccount, IUniqueGridData, IAvailableActions } from '../../../../shared/interfaces/shared/account/account';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { IBulkAddDeputyApiElem } from 'src/app/shared/interfaces/shared/common/identity';
import { AccList_API } from 'src/app/shared/interfaces/account-list/api.namespace';
import { API } from 'src/app/shared/interfaces/shared/api';

export const LOAD_ACCOUNTS_LIST = '[Account] Load Accounts';
export const LOAD_ACCOUNTS_LIST_FAIL = '[Account] Load Accounts Fail';
export const LOAD_ACCOUNTS_LIST_SUCCESS = '[Account] Load Accounts Success';
export const LOAD_ACCOUNT_BY_ID_FAIL = '[Account] Load Account by ID Fail';
export const LOAD_ACCOUNT_BY_ID_SUCCESS = '[Account] Load Account by ID Success';

export const LOAD_ACCOUNT_DETAIL = '[Account] Load Account Detail';
export const LOAD_ACCOUNT_DETAIL_FAIL = '[Account] Load Account Detail Fail';
export const LOAD_ACCOUNT_DETAIL_SUCCESS = '[Account] Load Account Detail Success';

export const LOAD_ACCOUNT_DELEGATES = '[Account] Load Account Delegates';
export const LOAD_ACCOUNT_DELEGATES_FAIL = '[Account] Load Account Delegates Fail';
export const LOAD_ACCOUNT_DELEGATES_SUCCESS = '[Account] Load Account Delegates Success';

export const LOAD_ACCOUNT_HISTORY = '[Account] Load Account History';
export const LOAD_ACCOUNT_HISTORY_FAIL = '[Account] Load Account History Fail';
export const LOAD_ACCOUNT_HISTORY_SUCCESS = '[Account] Load Account History Success';

export const SET_ACCOUNTS_VISIBLE_ACCOUNTS = '[Account] Set Visible Accounts';

export const SET_SELECT_ALL = '[Account] Toggle All Accounts Selected';
export const SET_SELECTED_ACCOUNTS = '[Account] Set Selected Accounts';

export const MODIFY_ACCOUNTS_FILTER_STATE = '[Account] Modify Accounts Filter';
export const SET_ACCOUNTS_FILTER_STATE = '[Account] Set Accounts Filter';
export const SET_ACCOUNTS_FILTER_BY_TILE = '[Account] Set Accounts Tile Filter';
export const SET_ACCOUNTS_SORT_STATE = '[Account] Set Accounts Sort';
export const SET_ACCOUNTS_LIST = '[Account] Set Accounts List';
export const SET_ACCOUNTS_PAGE_STATE = '[Account] Set Accounts Page';
export const SET_ACCOUNTS_VISIBLE_COLUMNS = '[Account] Set Accounts Visible Colunms';
export const SET_ACCOUNTS_SHOW_UID_LIST = '[Account] Set accounts to show by ID';

export const SET_VIEW_ONLY_SELECTED = '[Account] Set view only selected accounts';

export const SET_UNIQUE_GRID_DATA = '[Account] Set unique grid data';

export const ADD_BENCHMARK = 'Add Benchmark';

export const LOAD_BUSINESS_HOURS = '[Account] Load business hours UTC';
export const LOAD_BUSINESS_HOURS_SUCCESS = '[Account] Load business hours UTC Success';
export const LOAD_BUSINESS_HOURS_FAIL = '[Account] Load business hours UTC Failed';

export const RESET_PASSWORD = '[Account] Reset password on selected account(s)';
export const RESET_PASSWORD_SUCCESS = '[Account] Reset password Success';
export const RESET_PASSWORD_FAIL = '[Account] Reset password on Failed';

export const LOAD_DEPUTY_BLACKLIST = '[Account] Load Deputy Blacklist for popup(s)';
export const LOAD_DEPUTY_BLACKLIST_SUCCESS = '[Account] Load Deputy Blacklist Success';
export const LOAD_DEPUTY_BLACKLIST_FAIL = '[Account] Load Deputy Blacklist on Failed';

export const ENABLE_ACCOUNT = '[Account] Enable account on selected account(s)';
export const ENABLE_ACCOUNT_SUCCESS = '[Account] Enable account Success';
export const ENABLE_ACCOUNT_FAIL = '[Account] Enable account on Failed';

export const DISABLE_ACCOUNT = '[Account] Disable account on selected account(s)';
export const DISABLE_ACCOUNT_SUCCESS = '[Account] Disable account Success';
export const DISABLE_ACCOUNT_FAIL = '[Account] Disable account on Failed';

export const OPEN_RESET_PASS_MODAL = '[Account] Open Reset password Modal';
export const CLOSE_RESET_PASS_MODAL = '[Account] Close Reset password Modal';

export const LOAD_PASSWORD_RECEIVERS = '[Account] Load password receivers';

export const ADD_ACCOUNT_DEPUTIES = '[Account] add account deputies';
export const ADD_ACCOUNT_DEPUTIES_SUCCESS = '[Account] add account deputies Success';
export const ADD_ACCOUNT_DEPUTIES_FAIL = '[Account] add account deputies on Failed';

export const REMOVE_ACCOUNT_DEPUTIES = '[Account] remove account deputies';
export const REMOVE_ACCOUNT_DEPUTIES_SUCCESS = '[Account] remove account deputies Success';
export const REMOVE_ACCOUNT_DEPUTIES_FAIL = '[Account] remove account deputies on Failed';

export const EDIT_ACCOUNT_DESCRIPTION = '[Account] edit account description';
export const EDIT_ACCOUNT_DESCRIPTION_SUCCESS = '[Account] edit account description Success';
export const EDIT_ACCOUNT_DESCRIPTION_FAIL = '[Account] edit account description on Failed';

export const UPDATE_ACCOUNT_ENDUSER = '[Account] update account enduser';
export const UPDATE_ACCOUNT_ENDUSER_SUCCESS = '[Account] update account enduser Success';
export const UPDATE_ACCOUNT_ENDUSER_FAIL = '[Account] update account enduser Failed';

export const OPEN_ADD_REMOVE_DEPUTY_MODAL = '[Account] Open Add Remove Deputy Modal';
export const CLOSE_ADD_REMOVE_DEPUTY_MODAL = '[Account] Close Add Remove Deputy Modal';

export const OPEN_ENABLE_DISABLE_MODAL = '[Account] Open Enable Ediable Modal';
export const CLOSE_ENABLE_DISABLE_MODAL = '[Account] Close Enable Ediable Modal';

export const OPEN_EDIT_DESCRIPTION_MODAL = '[Account] Open Edit description Modal';
export const CLOSE_EDIT_DESCRIPTION_MODAL = '[Account] Close Edit description Modal';

export const OPEN_PASSWORD_RECEIVER_MODAL = '[Account] Open Password receiver modal';
export const CLOSE_PASSWORD_RECEIVER_MODAL = '[Account] Close Password receiver modal';

export const EDIT_PASSWORD_RECEIVER = '[Account] edit password receiver';
export const EDIT_PASSWORD_RECEIVER_SUCCESS = '[Account] edit password receiver Success';
export const EDIT_PASSWORD_RECEIVER_FAIL = '[Account] edit password receiver on Failed';

export const OPEN_CLOSE_ADVANCED_SEARCH = '[Account] Open or Close Advanced Search Panel';

export const SEARCH_ACCOUNT_DEPUTITY = '[Account] Search Deputies for modal';
export const SEARCH_ACCOUNT_DEPUTITY_SUCCESS = '[Account] Search Deputies for modal Sucess';
export const SEARCH_ACCOUNT_DEPUTITY_FAIL = '[Account] Search Deputies for modal Failed';

export const SET_SELECTED_DEPUTIES_MODAL = '[Account] set selected deputies in modal';

export const SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED = '[Account] set can edit deputies of all selected accounts';
export const SET_CAN_EDIT_PASSWORD_RECEIVER = '[Account] set can edit password receiver';

export const CLOSE_SELECTION_LENGTH_WARNING_MODAL = 'close temp modal for selection limit';

export const OPEN_END_OF_LIFE_MODAL = '[Account] Open end of life modal';
export const CLOSE_END_OF_LIFE_MODAL = '[Account] close end of life modal';
export const ENABLE_ACCOUNT_END_OF_LIFE = '[Account] enable and update the EOL date';
export const ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS = '[Account] enable and update the EOL date - success';
export const ENABLE_ACCOUNT_END_OF_LIFE_FAILURE = '[Account] enable and update the EOL date - failure';
export const UPDATE_ACCOUNT_END_OF_LIFE = '[Account] update the EOL date';
export const UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS = '[Account] update the EOL date - success';
export const UPDATE_ACCOUNT_END_OF_LIFE_FAILURE = '[Account] update the EOL date - failure';
export const OPEN_TASA_MODAL = '[Account] open tasa modal';
export const CLOSE_TASA_MODAL = '[Account] close tasa modal';

export const NO_ACTION = 'No Action';

export class LoadAccountsList implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST;
}

export class LoadAccountsListFail implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST_FAIL;
  constructor(public payload: any) { }
}
export class SetUniqueGridData implements Action {
  public readonly type = SET_UNIQUE_GRID_DATA;
  constructor(public payload: IUniqueGridData) { }
}

export class LoadAccountsListSuccess implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST_SUCCESS;
  constructor(public payload: IAccount[]) { }
}

export class LoadDeputyBlacklist implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST;
  constructor(public payload: { contextId: number, domain: string }) { }
}
export class LoadDeputyBlacklistSuccess implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST_SUCCESS;
  constructor(public payload: number[]) { }
}
export class LoadDeputyBlacklistFail implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST_FAIL;
  constructor(public payload: IResStatus) { }
}

export class LoadAccountDetail implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL;
  constructor(public payload: number) { }
}
export class LoadAccountDetailSuccess implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL_SUCCESS;
  constructor(public payload: { id: number, data: IAccount }) { }
}
export class LoadAccountDetailFail implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL_FAIL;
  constructor(public payload: number) { }
}

export class LoadAccountDelegates implements Action {
  public readonly type = LOAD_ACCOUNT_DELEGATES;
  constructor(public payload: number) { }
}
export class LoadAccountDelegatesSuccess implements Action {
  public readonly type = LOAD_ACCOUNT_DELEGATES_SUCCESS;
  constructor(public payload: { id: number, deputies: IAccountDeputity[], indirectDeputies: IAccountDeputity[] }) { }
}
export class LoadAccountDelegatesFail implements Action {
  public readonly type = LOAD_ACCOUNT_DELEGATES_FAIL;
  constructor(public payload: number) { }
}

export class OpenCloseAdvancedSearch implements Action {
  public readonly type = OPEN_CLOSE_ADVANCED_SEARCH;
  constructor(public payload: 'open' | 'close' | 'toggle') { }
}

export class SetAccountsVisibleAccounts implements Action {
  public readonly type = SET_ACCOUNTS_VISIBLE_ACCOUNTS;
  constructor(public payload: { data: IAccount[]; total: number; maximum: number, allIds?: number[], allFilteredIds?: number[] }) { }
}

export class SelectAllAccounts implements Action {
  public readonly type = SET_SELECT_ALL;
}

export class SetViewOnlySelectedAccounts implements Action {
  public readonly type = SET_VIEW_ONLY_SELECTED;
  constructor(public payload: boolean) { }
}

export class SetSelectedAccounts implements Action {
  public readonly type = SET_SELECTED_ACCOUNTS;
  constructor(public payload: { ids: number[], isAll: boolean }) { }
}

export class SetAvailableActions implements Action {
  public readonly type = SET_SELECTED_ACCOUNTS;
  constructor(public payload: IAvailableActions) { }
}

export class LoadAccountByIdSuccess implements Action {
  public readonly type = LOAD_ACCOUNT_BY_ID_SUCCESS;
  constructor(public payload: IAccount) { }
}
export class LoadAccountByIdFail implements Action {
  public readonly type = LOAD_ACCOUNT_BY_ID_FAIL;
  constructor(public payload: number) { }
}

export class SetAccountsFilter implements Action {
  public readonly type = SET_ACCOUNTS_FILTER_STATE;
  constructor(public payload: CompositeFilterDescriptor) { }
}

export class ModifyAccountsFilter implements Action {
  public readonly type = MODIFY_ACCOUNTS_FILTER_STATE;
  constructor(public payload: { field: string, filter: CompositeFilterDescriptor | FilterDescriptor }) { }
}

export class SetAccountsFilterByTile implements Action {
  public readonly type = SET_ACCOUNTS_FILTER_BY_TILE;
  constructor(public payload: string) { }
}

export class SetAccountsSort implements Action {
  public readonly type = SET_ACCOUNTS_SORT_STATE;
  constructor(public payload: SortDescriptor[]) { }
}
export class SetAccountsList implements Action {
  public readonly type = SET_ACCOUNTS_LIST;
  constructor(public payload: IAccount[]) { }
}

export class SetAccountsPage implements Action {
  public readonly type = SET_ACCOUNTS_PAGE_STATE;
  constructor(public payload: State) { }
}

export class SetCanEditDeputiesOfAllSelected implements Action {
  public readonly type = SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED;
  constructor(public payload: boolean) { }
}

export class SetCanEditPasswordReceiver implements Action {
  public readonly type = SET_CAN_EDIT_PASSWORD_RECEIVER;
  constructor(public payload: boolean) { }
}


export class SetAccountsVisibleColumns implements Action {
  public readonly type = SET_ACCOUNTS_VISIBLE_COLUMNS;
  constructor(public payload: string[]) { }
}

export class SetAccountsShowUidList implements Action {
  public readonly type = SET_ACCOUNTS_SHOW_UID_LIST;
  constructor(public payload: string[]) { }
}

export class AddBenchmark implements Action {
  public readonly type = ADD_BENCHMARK;
  constructor(public payload: { event: string; time: Date }) { }
}

export class LoadBusinessHours implements Action {
  public readonly type = LOAD_BUSINESS_HOURS;
}
export class LoadBusinessHoursFail implements Action {
  public readonly type = LOAD_BUSINESS_HOURS_FAIL;
}
export class LoadBusinessHoursSuccess implements Action {
  public readonly type = LOAD_BUSINESS_HOURS_SUCCESS;
  constructor(public payload: IBusinessHrsUTC) { }
}

export class ResetPassword implements Action {
  public readonly type = RESET_PASSWORD;
  constructor(public payload: { schedule: Date, excludedChars: string, type: 'CANCEL' | 'NOW' | 'SCHEDULE', pre_scheduledhour: number }) { }
}
export class ResetPasswordSuccess implements Action {
  public readonly type = RESET_PASSWORD_SUCCESS;
  constructor(public payload: { status: API.BulkElemRes[], res: IResStatus }) { }
}
export class ResetPasswordFail implements Action {
  public readonly type = RESET_PASSWORD_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}

export class EnableAccounts implements Action {
  public readonly type = ENABLE_ACCOUNT;
}
export class EnableAccountSuccess implements Action {
  public readonly type = ENABLE_ACCOUNT_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class EnableAccountFail implements Action {
  public readonly type = ENABLE_ACCOUNT_FAIL;
}

export class DisableAccounts implements Action {
  public readonly type = DISABLE_ACCOUNT;
}
export class DisableAccountSuccess implements Action {
  public readonly type = DISABLE_ACCOUNT_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class DisableAccountFail implements Action {
  public readonly type = DISABLE_ACCOUNT_FAIL;
}

export class OpenResetPassModal implements Action {
  public readonly type = OPEN_RESET_PASS_MODAL;
}

export class CloseResetPassModal implements Action {
  public readonly type = CLOSE_RESET_PASS_MODAL;
}

export class OpenEnableDisableModal implements Action {
  public readonly type = OPEN_ENABLE_DISABLE_MODAL;
  constructor(public payload: 'Enable' | 'Disable') { }
}
export class CloseEnableDisableModal implements Action {
  public readonly type = CLOSE_ENABLE_DISABLE_MODAL;
}

export class CloseSelectionLimitModal implements Action {
  public readonly type = CLOSE_SELECTION_LENGTH_WARNING_MODAL;
}


export class AddAccountDeputies implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES;
}
export class AddAccountDeputiesSuccess implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES_SUCCESS;
  constructor(public payload: { accIds: number[], data: IBulkAddDeputyApiElem[], res: IResStatus }) { }
}
export class AddAccountDeputiesFail implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}

export class RemoveAccountDeputies implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES;
}
export class RemoveAccountDeputiesSuccess implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES_SUCCESS;
  constructor(public payload: { accIds: number[], data: IBulkAddDeputyApiElem[], res: IResStatus }) { }
}
export class RemoveAccountDeputiesFail implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}

export class EditAccountDescription implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION;
  constructor(public payload: string) { }
}
export class EditAccountDescriptionSuccess implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION_SUCCESS;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class EditAccountDescriptionFail implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class UpdateAccountEndUser implements Action {
  public readonly type = UPDATE_ACCOUNT_ENDUSER;
  constructor(public payload: string) { }
}
export class UpdateAccountEndUserSuccess implements Action {
  public readonly type = UPDATE_ACCOUNT_ENDUSER_SUCCESS;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class UpdateAccountEndUserFail implements Action {
  public readonly type = UPDATE_ACCOUNT_ENDUSER_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class LoadPasswordReceiver implements Action {
  public readonly type = LOAD_PASSWORD_RECEIVERS;
  constructor(public payload: { accId: number }) { }
}
export class EditPasswordReceiver implements Action {
  public readonly type = EDIT_PASSWORD_RECEIVER;
  constructor(public payload: { email: string, action: 'ADD' | 'DELETE' }) { }
}
export class EditPasswordReceiverSuccess implements Action {
  public readonly type = EDIT_PASSWORD_RECEIVER_SUCCESS;
  constructor(public payload: { id: number, res: IResStatus, action: 'ADD' | 'DELETE' }) { }
}
export class EditPasswordReceiverFail implements Action {
  public readonly type = EDIT_PASSWORD_RECEIVER_FAIL;
  constructor(public payload: { id: number, res: IResStatus, action: 'ADD' | 'DELETE' }) { }
}

export class OpenAddRemoveDeputyModal implements Action {
  public readonly type = OPEN_ADD_REMOVE_DEPUTY_MODAL;
  constructor(public payload: 'Add' | 'Remove') { }
}
export class CloseAddRemoveDeputyModal implements Action {
  public readonly type = CLOSE_ADD_REMOVE_DEPUTY_MODAL;
}

export class OpenEditDescriptionModal implements Action {
  public readonly type = OPEN_EDIT_DESCRIPTION_MODAL;
}
export class CloseEditDescriptionModal implements Action {
  public readonly type = CLOSE_EDIT_DESCRIPTION_MODAL;
}

export class OpenPasswordReceiverModal implements Action {
  public readonly type = OPEN_PASSWORD_RECEIVER_MODAL;
  constructor(public payload: { email: string, action: 'ADD' | 'DELETE' }) { }
}
export class ClosePasswordReceiverModal implements Action {
  public readonly type = CLOSE_PASSWORD_RECEIVER_MODAL;
}
export class searchAccountDeputityForModal implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY;
  constructor(public payload: string) { }
}
export class searchAccountDeputityForModalSuccess implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY_SUCCESS;
  constructor(public payload: IAccountDeputity[]) { }
}
export class searchAccountDeputityForModalFail implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY_FAIL;
  constructor(public payload: IResStatus) { }
}
export class setSelectedDeputitiesModal implements Action {
  public readonly type = SET_SELECTED_DEPUTIES_MODAL;
  constructor(public payload: IAccountDeputity[]) { }
}
export class OpenEndOfLifeModal implements Action {
  public readonly type = OPEN_END_OF_LIFE_MODAL;
  constructor(public payload: 'Enable' | 'Notification' | 'Self') { }
}
export class CloseEndOfLifeModal implements Action {
  public readonly type = CLOSE_END_OF_LIFE_MODAL;
}
export class EnableAccountsWithEndOfLife implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE;
  constructor(public payload: { end_of_lifecycle_date: Date, trigger: 'Enable' | 'Notification' | 'Self' }) { }
}
export class EnableAccountsWithEndOfLifeSuccess implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class EnableAccountsWithEndOfLifeFailure implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE_FAILURE;
}

export class UpdateEndOfLifeOfAccount implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE;
  constructor(public payload: { end_of_lifecycle_date: Date }) { }
}
export class UpdateEndOfLifeOfAccountSuccess implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class UpdateEndOfLifeOfAccountFailure implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE_FAILURE;
}
export class OpenTASAModal implements Action {
  public readonly type = OPEN_TASA_MODAL;
}
export class CloseTASAModal implements Action {
  public readonly type = CLOSE_TASA_MODAL;
}

export class NoAction implements Action {
  public readonly type = NO_ACTION;
}

export type AccountsListAction =
  | LoadAccountsList
  | LoadAccountsListFail
  | LoadAccountsListSuccess
  | LoadAccountDetail
  | LoadAccountDetailFail
  | LoadAccountDetailSuccess
  | OpenCloseAdvancedSearch
  // | LoadAccountHistory
  // | LoadAccountHistoryFail
  // | LoadAccountHistorySuccess
  | LoadAccountByIdSuccess
  | SetAccountsVisibleAccounts
  | SetSelectedAccounts
  | SelectAllAccounts
  | LoadAccountByIdFail
  | SetAccountsFilter
  | ModifyAccountsFilter
  | SetAccountsFilterByTile
  | SetAccountsSort
  | SetAccountsList
  | SetAccountsPage
  | SetAccountsVisibleColumns
  | SetAccountsShowUidList
  | SetUniqueGridData
  | SetViewOnlySelectedAccounts
  | AddBenchmark
  | ResetPassword
  | ResetPasswordSuccess
  | ResetPasswordFail
  | LoadBusinessHours
  | LoadBusinessHoursFail
  | LoadBusinessHoursSuccess
  | EnableAccounts
  | EnableAccountSuccess
  | EnableAccountFail
  | DisableAccounts
  | DisableAccountSuccess
  | DisableAccountFail
  | OpenResetPassModal
  | CloseResetPassModal
  | AddAccountDeputies
  | AddAccountDeputiesSuccess
  | AddAccountDeputiesFail
  | RemoveAccountDeputies
  | RemoveAccountDeputiesSuccess
  | RemoveAccountDeputiesFail
  | EditAccountDescription
  | EditAccountDescriptionSuccess
  | EditAccountDescriptionFail
  | OpenAddRemoveDeputyModal
  | CloseAddRemoveDeputyModal
  | OpenEditDescriptionModal
  | CloseEditDescriptionModal
  | OpenEnableDisableModal
  | CloseEnableDisableModal
  | LoadDeputyBlacklist
  | LoadDeputyBlacklistSuccess
  | LoadDeputyBlacklistFail
  | searchAccountDeputityForModal
  | searchAccountDeputityForModalSuccess
  | searchAccountDeputityForModalFail
  | setSelectedDeputitiesModal
  | SetCanEditDeputiesOfAllSelected
  | CloseSelectionLimitModal
  | OpenEndOfLifeModal
  | CloseEndOfLifeModal
  | OpenTASAModal
  | CloseTASAModal
  | EnableAccountsWithEndOfLife
  | EnableAccountsWithEndOfLifeSuccess
  | EnableAccountsWithEndOfLifeFailure
  | UpdateEndOfLifeOfAccount
  | UpdateEndOfLifeOfAccountSuccess
  | UpdateEndOfLifeOfAccountFailure
  | OpenPasswordReceiverModal
  | ClosePasswordReceiverModal
  | EditPasswordReceiver
  | EditPasswordReceiverSuccess
  | EditPasswordReceiverFail
  | LoadPasswordReceiver
  | SetCanEditPasswordReceiver
  | UpdateAccountEndUser
  | UpdateAccountEndUserSuccess
  | UpdateAccountEndUserFail
  | NoAction;
