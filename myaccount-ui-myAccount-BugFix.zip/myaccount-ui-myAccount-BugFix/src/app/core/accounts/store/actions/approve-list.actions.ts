import { IApproveAccount } from './../../../../shared/interfaces/shared/account/approve';
import { Action } from '@ngrx/store';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { API } from 'src/app/shared/interfaces/shared/api';

export const REQUEST_APPROVE_ACCOUNT_LIST = '[approve-list] get requests pending approvial';
export const REQUEST_APPROVE_ACCOUNT_LIST_SUCCESS = '[approve-list] get requests pending approvial successful';
export const REQUEST_APPROVE_ACCOUNT_LIST_FAIL = '[approve-list] get requests pending approvial failed';

export const SELECT_APPROVE_ACCOUNT = '[approve-list] select account pending approvial';

export const APPROVE_SELECTED_APPROVE_ACCOUNTS = '[approve-list] approve selected accounts pending approvial';
export const APPROVE_SELECTED_APPROVE_ACCOUNT_SUCCESS = '[approve-list] approval of one account successful';
export const APPROVE_SELECTED_APPROVE_ACCOUNT_FAIL = '[approve-list] approval of one account failed';

export const REJECT_SELECTED_APPROVE_ACCOUNTS = '[approve-list] reject selected accounts pending approvial';
export const REJECT_SELECTED_APPROVE_ACCOUNT_SUCCESS = '[approve-list] rejection of one account successful';
export const REJECT_SELECTED_APPROVE_ACCOUNT_FAIL = '[approve-list] rejection of one account failed';

export const MINIFY_APPROVE_ACCOUNT_ROWS = '[approve-list] shrink approve account row size';
export const MAGNIFY_APPROVE_ACCOUNT_ROWS = '[approve-list] expand approve account row size';

export const OPEN_APPROVE_ACCOUNT_MODAL = '[Account] Open Approve Account Modal';
export const CLOSE_APPROVE_ACCOUNT_MODAL = '[Account] Close Approve Account Modal';

export const OPEN_REJECT_ACCOUNT_MODAL = '[Account] Open Reject Account Modal';
export const CLOSE_REJECT_ACCOUNT_MODAL = '[Account] Close Reject Account Modal';

export const CLOSE_SELECTION_LENGTH_WARNING_MODAL_APPR_REJ = '[appr-rej] close temp modal for selection limit';

export class requestApproveAccountList implements Action {
    public readonly type = REQUEST_APPROVE_ACCOUNT_LIST;
}
export class requestApproveAccountListSuccess implements Action {
    public readonly type = REQUEST_APPROVE_ACCOUNT_LIST_SUCCESS;
    constructor(public payload: {status: IResStatus, data: IApproveAccount[]}) {}
}
export class requestApproveAccountListFail implements Action {
    public readonly type = REQUEST_APPROVE_ACCOUNT_LIST_FAIL;
    constructor(public payload: IResStatus) {}
}

export class selectApproveAccount implements Action {
    public readonly type = SELECT_APPROVE_ACCOUNT;
    constructor(public payload: number[]) {}
}

export class approveSelectedApproveAccounts implements Action {
    public readonly type = APPROVE_SELECTED_APPROVE_ACCOUNTS;
}
export class approveSelectedApproveAccountSuccess implements Action {
    public readonly type = APPROVE_SELECTED_APPROVE_ACCOUNT_SUCCESS;
    constructor(public payload: {status: IResStatus, res: API.BulkElemRes[]}) {}
}
export class approveSelectedApproveAccountFail implements Action {
    public readonly type = APPROVE_SELECTED_APPROVE_ACCOUNT_FAIL;
    constructor(public payload: {status: IResStatus}) {}
}
export class rejectSelectedApproveAccounts implements Action {
    public readonly type = REJECT_SELECTED_APPROVE_ACCOUNTS;
    constructor(public payload: string) {}
}
export class rejectSelectedApproveAccountSuccess implements Action {
    public readonly type = REJECT_SELECTED_APPROVE_ACCOUNT_SUCCESS;
    constructor(public payload: {status: IResStatus, res: API.BulkElemRes[]}) {}
}
export class rejectSelectedApproveAccountFail implements Action {
    public readonly type = REJECT_SELECTED_APPROVE_ACCOUNT_FAIL;
    constructor(public payload: {status: IResStatus}) {}
}
export class minifyApproveAccountRows implements Action {
    public readonly type = MINIFY_APPROVE_ACCOUNT_ROWS;
    constructor(public payload: string) {}
}
export class magnifyApproveAccountRows implements Action {
    public readonly type = MAGNIFY_APPROVE_ACCOUNT_ROWS;
    constructor(public payload: string) {}
}
export class openApproveAccountModal implements Action {
    public readonly type = OPEN_APPROVE_ACCOUNT_MODAL;
}
export class closeApproveAccountModal implements Action {
    public readonly type = CLOSE_APPROVE_ACCOUNT_MODAL;
}
export class openRejectAccountModal implements Action {
    public readonly type = OPEN_REJECT_ACCOUNT_MODAL;
}
export class closeRejectAccountModal implements Action {
    public readonly type = CLOSE_REJECT_ACCOUNT_MODAL;
    constructor(public payload: string) {}
}

export class CloseSelectionLimitModalApprRej implements Action {
    public readonly type = CLOSE_SELECTION_LENGTH_WARNING_MODAL_APPR_REJ;
  }

export type AcceptListAction =
    | requestApproveAccountList
    | requestApproveAccountListSuccess
    | requestApproveAccountListFail
    | selectApproveAccount
  
    | approveSelectedApproveAccounts
    | approveSelectedApproveAccountSuccess
    | approveSelectedApproveAccountFail
    | rejectSelectedApproveAccounts
    | rejectSelectedApproveAccountSuccess
    | rejectSelectedApproveAccountFail
    | minifyApproveAccountRows
    | magnifyApproveAccountRows
    | openApproveAccountModal
    | closeApproveAccountModal
    | openRejectAccountModal
    | closeRejectAccountModal
    | CloseSelectionLimitModalApprRej;
