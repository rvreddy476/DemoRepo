import { CANCEL_SCHEDULED_PASSWORD_RESET_FAILED } from './../actions/follow-up-list.actions';
import { IFollowUpState, TActionFollowUp, TScheduledPasswordFollowUp } from './../../../../shared/interfaces/shared/account/follow-up';
import { IApproveListState } from '../../../../shared/interfaces/shared/account/approve';
import * as fromActions from '../actions/follow-up-list.actions';


export const initialState: IFollowUpState = {
  scheduledResets: [],
  actions: [],
  selected: [],
  modal: {
    action: null,
    open: false,
    loading: false,
    res: null
  }
};

export function FollowUpReducer(state = initialState, action: fromActions.AcceptListAction): IFollowUpState {


  switch (action.type) {

    case fromActions.REQUEST_ACTION_FOLLOW_UP_LIST: {
      return {
        ...state
      };
    }
    case fromActions.REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS: {
      return {
        ...state,
        actions: action.payload.data as TActionFollowUp[]
      };
    }

    case fromActions.REQUEST_ACTION_FOLLOW_UP_LIST_FAIL: {
      return {
        ...state
      };
    }
    case fromActions.REQUEST_SCHEDULED_FOLLOW_UP_LIST_SUCCESS: {
      return {
        ...state,
        scheduledResets: action.payload.data as TScheduledPasswordFollowUp[]
      };
    }
    case fromActions.REQUEST_SCHEDULED_FOLLOW_UP_LIST_FAIL: {
      return {
        ...state
      };
    }
    case fromActions.SELECT_FOLLOW_UP: {
      return {
        ...state,
        selected: [action.payload[0]]
      };
    }
    case fromActions.DESELECT_FOLLOW_UP: {
      return {
        ...state,
        selected: state.selected.filter(x => action.payload.indexOf(x) === -1)
      };
    }

    case fromActions.OPEN_FOLLOW_UP_MODAL: {
      return {
        ...state,
        modal: {
          action: action.payload,
          loading: false,
          res: null,
          open: true
        }
      };
    }
    case fromActions.CLOSE_FOLLOW_UP_MODAL: {
      return {
        ...state,
        modal: {
          action: null,
          loading: false,
          res: null,
          open: state.modal.loading
        }
      };
    }
    case fromActions.CANCEL_SCHEDULED_PASSWORD_RESET:
    case fromActions.CANCEL_PENDING_REQUEST: {
      return {
        ...state,
        modal: {
          ...state.modal,
          loading: true,
          res: null,
        }
      };
    }
    case fromActions.CANCEL_SCHEDULED_PASSWORD_RESET_SUCCESS:
    case fromActions.CANCEL_PENDING_REQUEST_SUCCESS: {
      return {
        ...state,
        modal: {
          ...state.modal,
          loading: false,
          res: {
            code: null,
            type: null,
            error: false,
            message: 'Cancellation in Progress',
          },
        }
      };
    }
    case fromActions.CANCEL_SCHEDULED_PASSWORD_RESET_FAILED:
    case fromActions.CANCEL_PENDING_REQUEST_FAILED: {
      return {
        ...state,
        modal: {
          ...state.modal,
          loading: false,
          res: action.payload,
        }
      };
    }
  }

  return state;
}
