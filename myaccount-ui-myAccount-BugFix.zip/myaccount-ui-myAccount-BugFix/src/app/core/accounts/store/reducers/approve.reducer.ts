import { AcceptListAction, REQUEST_APPROVE_ACCOUNT_LIST } from './../actions/approve-list.actions';
import { IApproveListState } from './../../../../shared/interfaces/shared/account/approve';
import * as fromActions from '../actions/approve-list.actions';
import { MAX_ACCOUNT_SELECTION_LENGTH } from 'src/app/config/parameters';


export const initialState: IApproveListState = {
  accounts: [],
  selected: [],
  modal: {
    mode: null,
    open: false,
    loading: false,
    res: null,
    responseList:[]
  }
};

export function ApproveListReducer(state = initialState, action: fromActions.AcceptListAction): IApproveListState {


  switch (action.type) {

    case fromActions.REQUEST_APPROVE_ACCOUNT_LIST: {
      return {
        ...state
      };
    }
    case fromActions.REQUEST_APPROVE_ACCOUNT_LIST_SUCCESS: {
      return {
        ...state,
        accounts: action.payload.data
      };
    }
    case fromActions.REQUEST_APPROVE_ACCOUNT_LIST_FAIL: {
      return {
        ...state
      };
    }



    // case fromActions.SELECT_APPROVE_ACCOUNT: {
    //   return {
    //     ...state,
    //     selected: action.payload
    //   };
    // }

    case fromActions.SELECT_APPROVE_ACCOUNT: {
      let selected = []
      let showMaxLengthWarning = false
      // TEMP
      if(action.payload.length > MAX_ACCOUNT_SELECTION_LENGTH){
        showMaxLengthWarning = true
        let include = []
        let tryAd = []
        action.payload.forEach(acc => {
          if(state.selected.indexOf(acc) !== -1){
            include.push(acc)
          }else{
            tryAd.push(acc)
          }
        })


        selected = [...include, ...tryAd].splice(0,MAX_ACCOUNT_SELECTION_LENGTH)
      }
      else{
        selected = action.payload
      }

      return {
        ...state,
        selected,
        showMaxLengthWarning,
      };
    }










    case fromActions.APPROVE_SELECTED_APPROVE_ACCOUNTS: {
      return {
        ...state,
        modal:{
          ...state.modal,
          loading:true,
          res:null,
          responseList:[]
        }
      };
    }

    case fromActions.APPROVE_SELECTED_APPROVE_ACCOUNT_SUCCESS: {
      return {
        ...state,
        modal: {
          responseList:action.payload.res,
          res: action.payload.status,
          loading: false,
          open: true,
          mode: 'approve'
        },
        accounts: state.accounts.filter(acc => state.selected.indexOf(acc.id) === -1),
        selected: []
      };
    }
    case fromActions.APPROVE_SELECTED_APPROVE_ACCOUNT_FAIL: {
      return {
        ...state,
        modal: {
          ...state.modal,
          responseList:[],
          res: action.payload.status,
          loading: false,
          open: true,
          mode: 'approve'
        }
      };
    }
    case fromActions.REJECT_SELECTED_APPROVE_ACCOUNTS: {
      return {
        ...state,
        modal: {
          ...state.modal,
          responseList:[],
          loading: true,
          res: null,
          open: true,
          mode: 'reject'
        }
      };
    }
    case fromActions.REJECT_SELECTED_APPROVE_ACCOUNT_SUCCESS: {
      return {
        ...state,
        modal: {
          responseList:action.payload.res,
          loading: false,
          res: action.payload.status,
          open: true,
          mode: 'reject'
        },
        accounts: state.accounts.filter(acc => state.selected.indexOf(acc.id) === -1),
        selected: []
      };
    }
    case fromActions.REJECT_SELECTED_APPROVE_ACCOUNT_FAIL: {

      return {
        ...state,
        modal: {
          responseList:[],
          res: action.payload.status,
          loading: false,
          open: true,
          mode: 'reject'
        }
      };
    }

    case fromActions.OPEN_APPROVE_ACCOUNT_MODAL: {
      return {
        ...state,
        modal: {
          responseList:[],
          mode: 'approve',
          loading: false,
          res: null,
          open: true
        }
      };
    }

    case fromActions.OPEN_REJECT_ACCOUNT_MODAL: {
      return {
        ...state,
        modal: {
          responseList:[],
          mode: 'reject',
          loading: false,
          res: null,
          open: true
        }
      };
    }
    case fromActions.CLOSE_APPROVE_ACCOUNT_MODAL:
    case fromActions.CLOSE_REJECT_ACCOUNT_MODAL: {
      return {
        ...state,
        modal: {
          responseList:[],
          mode: null,
          loading: false,
          res: null,
          open: false
        }
      };
    }


    case fromActions.CLOSE_SELECTION_LENGTH_WARNING_MODAL_APPR_REJ:{
      return {
        ...state,
        showMaxLengthWarning:false
      }
    }

  }

  return state;
}
