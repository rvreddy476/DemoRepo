import { IApproveListState } from './../../../../shared/interfaces/shared/account/approve';
import { ActionReducerMap } from '@ngrx/store';
import { IAccountsListState } from '../../../../shared/interfaces/shared/account/account';

import { AccountsListReducer } from './list.reducer';
import { ApproveListReducer } from './approve.reducer';
import { IFollowUpState } from 'src/app/shared/interfaces/shared/account/follow-up';
import { FollowUpReducer } from './follow-up.reducer';

export interface IAccountsState {
  accountsList: IAccountsListState;
  approveList: IApproveListState;
  followUpList: IFollowUpState;
}

export const reducers: ActionReducerMap<IAccountsState> = {
  accountsList: AccountsListReducer,
  approveList: ApproveListReducer,
  followUpList: FollowUpReducer
};
