import { IAccountsListState, IAccount } from '../../../../shared/interfaces/shared/account/account';
import * as fromActions from '../actions/accounts-list.actions';
import { SortDescriptor, CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { createAccConfig } from 'src/app/core/create-account/create-account.config';
import { createEntityAdapter } from '@ngrx/entity';
import { MAX_ACCOUNT_SELECTION_LENGTH } from 'src/app/config/parameters';

export const accountsListAdaptor = createEntityAdapter<IAccount>();

export const initialState: IAccountsListState = {
  accounts: [],
  detailAccount: null,
  advancedFilterPanelOpen: false,
  unique: {
    lifeCycleStatus: [],
    directoryEnvironment: [],
    directoryType: [],
    pwdStatus: [],
    directoryDomain: [],
    type: [],
    division: [],
  },
  availableActions: {
    resetPassword: false,
    enableAccount: false,
    disableAccount: false,
    enableUnix: false,
    disableUnix: false,
    changeDeputies: false
  },
  allAccounts: [],
  allFilteredAccounts: [],
  enabledColumns: {
    ['uid']: true, // Account Name
    ['lifeCycleStatus']: true, // Account status
    ['pwdStatus']: true, // Password Lifetime
    ['pwdRemainingDays']: true, // Password Lifetime
    ['contextName']: true, // Context
    ['type']: true, // Account Type
    ['directoryEnvironment']: true, // Environment
    ['directoryDomain']: true, // Directory
    ['division']: true, // Division
  },
  benchmarks: [],
  viewState: {
    visibleColumns: [],
    detailRowID: 'SA-8614-elm-303033',
    showOnlyUID: [],
    showOnlySelected: false,
    gridState: {
      skip: 0,
      take: 50,
    },
    filterByTile: null,
  },
  selectedAccounts: [],
  selectedAccountsDetails: {},
  loading: true,
  loaded: false,
  resetPassModal: {
    open: false,
    loading: false,
    response: null,
    responseList: []
  },
  businessHrsUTC: null,
  editDescriptionModal: {
    open: false,
    response: null,
    loading: false
  },
  updateEndUserModal: {
    open: false,
    response: null,
    loading: false
  },
  editPasswordReceiverModal: {
    open: false,
    response: null,
    loading: false,
    action: 'ADD',
    email: null,
    canEdit: false
  },
  enableDisableAccModal: {
    open: false,
    mode: null,
    loading: false,
    response: null,
    responseList: [],
  },
  endOfLifeModal: {
    open: false,
    trigger: null,
    loading: false,
    response: null,
    responseList: [],
  },
  addRemoveDeputyModal: {
    open: false,
    mode: null,
    loading: false,
    response: null,
    responseList: [],
    previousDeputies: [],
    permissionToEditSelection: false,
    blacklist: [],
    currentDeputies: [],
    deputyOptions: [],
    loadingSearch: false,
  }
};

export function AccountsListReducer(state = initialState, action: fromActions.AccountsListAction): IAccountsListState {

  const defaultSort: SortDescriptor[] = [];

  switch (action.type) {

    //#region acounts list
    case fromActions.LOAD_ACCOUNTS_LIST: {
      return {
        ...state,
        loading: true,
        viewState: {
          ...state.viewState,
        },
      };
    }
    case fromActions.LOAD_ACCOUNTS_LIST_FAIL: {
      return {
        ...state,
        loading: false,
      };
    }
    case fromActions.SET_UNIQUE_GRID_DATA: {
      return {
        ...state,
        // selectedAccounts: [],
        unique: action.payload,
      };
    }
    case fromActions.LOAD_ACCOUNTS_LIST_SUCCESS: {
      const gs = state.viewState.gridState;
      const shouldResetFilters = gs.sort ? JSON.stringify(gs.sort) !== JSON.stringify(defaultSort) : true;
      // const nextFilter: CompositeFilterDescriptor = state.viewState.filterByTile ? state.viewState.gridState.filter : { filters: [], logic: 'and' };

      // dont keep selection on locked accounts
      const selected = state.selectedAccounts === [] ? [] : action.payload.filter(acc => ((state.selectedAccounts.indexOf(acc.id) !== -1) && !acc.locked)).map(acc => acc.id);
      if (shouldResetFilters) {
        return {
          ...state,
          loaded: true,
          loading: false,
          accounts: action.payload,
          selectedAccounts: selected,
          viewState: {
            ...state.viewState,
            gridState: {
              ...state.viewState.gridState,
              sort: defaultSort,
              // filter: nextFilter
            },
          },
        };
      } else {
        return {
          ...state,
          accounts: action.payload,
          selectedAccounts: selected,
          loaded: true,
          loading: false,
        };
      }
    }
    case fromActions.SET_ACCOUNTS_VISIBLE_ACCOUNTS: {
      const { data, total, maximum, allIds = null, allFilteredIds = null } = action.payload;
      return {
        ...state,
        allAccounts: allIds === null ? state.allAccounts : allIds,
        allFilteredAccounts: allFilteredIds === null ? state.allFilteredAccounts : allFilteredIds,

        // remove selection from accounts which have now been filtered from view
        selectedAccounts: state.selectedAccounts.filter(sel => allFilteredIds ? allFilteredIds.indexOf(sel) !== -1 : true),
        loading: false,
      };
    }

    // case fromActions.SET_SELECT_ALL: {
    //   const select = action.payload
    //   const selected = select ? state.visibleAccounts.data.filter(acc => !acc.locked).map(acc => acc.id).concat(state.selectedAccounts) : []
    //   return {
    //     ...state,
    //     selectedAccounts: selected
    //   };
    // }

    //#endregion

    //#region reset password

    case fromActions.OPEN_RESET_PASS_MODAL: {
      return {
        ...state,
        resetPassModal: {
          ...state.resetPassModal,
          open: true,
        }
      };
    }


    case fromActions.RESET_PASSWORD: {
      return {
        ...state,
        resetPassModal: {
          response: null,
          loading: true,
          open: true,
          responseList: null
        }
      };
    }

    case fromActions.RESET_PASSWORD_SUCCESS: {
      return {
        ...state,
        resetPassModal: {
          response: action.payload.res,
          responseList: action.payload.status,
          loading: false,
          open: true,
        }
      };
    }

    case fromActions.RESET_PASSWORD_FAIL: {
      return {
        ...state,
        resetPassModal: {
          response: action.payload.res,
          loading: false,
          open: true,
          responseList: null
        }
      };
    }

    case fromActions.LOAD_BUSINESS_HOURS_SUCCESS: {
      return {
        ...state,
        businessHrsUTC: action.payload
      };
    }

    case fromActions.CLOSE_RESET_PASS_MODAL: {
      return {
        ...state,
        resetPassModal: {
          response: null,
          loading: false,
          open: state.resetPassModal.loading, // prevent close if loading
          responseList: null
        }
      };
    }

    //#endregion

    //#region edit account description
    case fromActions.OPEN_EDIT_DESCRIPTION_MODAL: {
      return {
        ...state,
        editDescriptionModal: {
          ...state.editDescriptionModal,
          open: true,
          response: null
        }
      };
    }

    case fromActions.CLOSE_EDIT_DESCRIPTION_MODAL: {
      return {
        ...state,
        editDescriptionModal: {
          ...state.editDescriptionModal,
          open: false,
          response: null
        }
      };
    }
    case fromActions.OPEN_PASSWORD_RECEIVER_MODAL: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          open: true,
          response: null,
          action: action.payload.action,
          email: [action.payload.email]
        }
      };
    }

    case fromActions.CLOSE_PASSWORD_RECEIVER_MODAL: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          open: false,
          response: null
        }
      };
    }

    case fromActions.EDIT_ACCOUNT_DESCRIPTION: {
      return {
        ...state,
        editDescriptionModal: {
          ...state.editDescriptionModal,
          loading: true
        }
      };
    }

    case fromActions.EDIT_ACCOUNT_DESCRIPTION_SUCCESS: {
      return {
        ...state,
        editDescriptionModal: {
          ...state.editDescriptionModal,
          loading: false,
          response: action.payload.res
        }
      };
    }
    case fromActions.EDIT_ACCOUNT_DESCRIPTION_FAIL: {
      return {
        ...state,
        editDescriptionModal: {
          ...state.editDescriptionModal,
          loading: false,
          response: action.payload.res
        }
      };
    }

    case fromActions.UPDATE_ACCOUNT_ENDUSER: {
      return {
        ...state,
        updateEndUserModal: {
          ...state.updateEndUserModal,
          loading: true
        }
      };
    }

    case fromActions.UPDATE_ACCOUNT_ENDUSER_SUCCESS: {
      return {
        ...state,
        updateEndUserModal: {
          ...state.updateEndUserModal,
          loading: false,
          response: action.payload.res
        }
      };
    }
    case fromActions.UPDATE_ACCOUNT_ENDUSER_FAIL: {
      return {
        ...state,
        updateEndUserModal: {
          ...state.updateEndUserModal,
          loading: false,
          response: action.payload.res
        }
      };
    }

    case fromActions.EDIT_PASSWORD_RECEIVER: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          loading: true
        }
      };
    }

    case fromActions.EDIT_PASSWORD_RECEIVER_SUCCESS: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          loading: false,
          response: action.payload.res
        }
      };
    }
    case fromActions.EDIT_PASSWORD_RECEIVER_FAIL: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          loading: false,
          response: action.payload.res
        }
      };
    }

    //#endregion

    //#region add remove deputities
    case fromActions.OPEN_ADD_REMOVE_DEPUTY_MODAL: {
      // const currentDeps = state.selectedAccountsDetails[state.selectedAccounts[0]].deputies
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          mode: action.payload,
          // currentDeputies: currentDeps,
          // previousDeputies: currentDeps,
          open: true,
        }
      };
    }

    case fromActions.CLOSE_ADD_REMOVE_DEPUTY_MODAL: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          currentDeputies: [],
          deputyOptions: [],
          blacklist: [],
          open: state.addRemoveDeputyModal.loading,
          response: null,
          loadingSearch: false,
          loading: false
        }
      };
    }


    case fromActions.SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          permissionToEditSelection: action.payload
        }
      };
    }

    case fromActions.SET_CAN_EDIT_PASSWORD_RECEIVER: {
      return {
        ...state,
        editPasswordReceiverModal: {
          ...state.editPasswordReceiverModal,
          canEdit: action.payload
        }
      };
    }



    case fromActions.LOAD_DEPUTY_BLACKLIST_SUCCESS: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          blacklist: action.payload
        }
      };
    }

    case fromActions.LOAD_DEPUTY_BLACKLIST_FAIL: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal
        }
      };
    }

    case fromActions.SEARCH_ACCOUNT_DEPUTITY: {
      const shouldClearOption = action.payload.length <= createAccConfig.contextSearchMinChars;
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          loadingSearch: true,
          deputyOptions: shouldClearOption ? [] : state.addRemoveDeputyModal.deputyOptions
        }
      };
    }

    case fromActions.SEARCH_ACCOUNT_DEPUTITY_SUCCESS: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          deputyOptions: action.payload,
          loadingSearch: false
        }
      };
    }

    case fromActions.SEARCH_ACCOUNT_DEPUTITY_FAIL: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          deputyOptions: [],
          loadingSearch: false
        }
      };
    }

    case fromActions.SET_SELECTED_DEPUTIES_MODAL: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          currentDeputies: action.payload,
        }
      };
    }

    case fromActions.REMOVE_ACCOUNT_DEPUTIES:
    case fromActions.ADD_ACCOUNT_DEPUTIES: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          loading: true
        }
      };
    }
    case fromActions.REMOVE_ACCOUNT_DEPUTIES_SUCCESS:
    case fromActions.ADD_ACCOUNT_DEPUTIES_SUCCESS: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          loading: false,
          response: action.payload.res,
          responseList: action.payload.data
        }
      };
    }
    case fromActions.REMOVE_ACCOUNT_DEPUTIES_FAIL:
    case fromActions.ADD_ACCOUNT_DEPUTIES_FAIL: {
      return {
        ...state,
        addRemoveDeputyModal: {
          ...state.addRemoveDeputyModal,
          response: action.payload.res,
          loadingSearch: false,
          loading: false,
        }
      };
    }


    //#endregion


    //#region enable disable accounts

    case fromActions.OPEN_ENABLE_DISABLE_MODAL: {
      return {
        ...state,
        enableDisableAccModal: {
          ...state.enableDisableAccModal,
          open: true,
          mode: action.payload
        }
      };
    }
    case fromActions.CLOSE_ENABLE_DISABLE_MODAL: {
      return {
        ...state,
        enableDisableAccModal: {
          ...state.enableDisableAccModal,
          open: false,
          response: null,
          responseList: [],
          mode: null
        }
      };
    }
    case fromActions.DISABLE_ACCOUNT:
    case fromActions.ENABLE_ACCOUNT: {
      return {
        ...state,
        enableDisableAccModal: {
          ...state.enableDisableAccModal,
          loading: true,
          response: null,
          responseList: []
        }
      };
    }
    case fromActions.DISABLE_ACCOUNT_SUCCESS:
    case fromActions.ENABLE_ACCOUNT_SUCCESS: {
      return {
        ...state,
        enableDisableAccModal: {
          ...state.enableDisableAccModal,
          loading: false,
          response: action.payload.res,
          responseList: action.payload.stats
        }
      };
    }
    case fromActions.DISABLE_ACCOUNT_FAIL:
    case fromActions.ENABLE_ACCOUNT_FAIL: {
      return {
        ...state,
        enableDisableAccModal: {
          ...state.enableDisableAccModal,
          loading: false,
          responseList: []
        }
      };
    }

    //#endregion

    case fromActions.SET_SELECTED_ACCOUNTS: {
      // should assign loaded account to detail account?
      const isLoaded = action.payload.ids.length === 1 ? Boolean(state.selectedAccountsDetails[action.payload.ids[0]]) : false;
      let selectedAccounts = []
      let showMaxLengthWarning = false
      // TEMP
      if (action.payload.ids.length > MAX_ACCOUNT_SELECTION_LENGTH) {
        showMaxLengthWarning = true
        let include = []
        let tryAd = []
        action.payload.ids.forEach(acc => {
          if (state.selectedAccounts.indexOf(acc) !== -1) {
            include.push(acc)
          } else {
            tryAd.push(acc)
          }
        })


        selectedAccounts = [...include, ...tryAd].splice(0, MAX_ACCOUNT_SELECTION_LENGTH)
      }
      else {
        selectedAccounts = action.payload.ids
      }

      return {
        ...state,
        selectedAccounts,
        showMaxLengthWarning,
        detailAccount: isLoaded ? state.selectedAccountsDetails[action.payload.ids[0]] : null
      };
    }

    case fromActions.SET_VIEW_ONLY_SELECTED: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          showOnlySelected: action.payload,
          gridState: {
            ...state.viewState.gridState,
            skip: 0
          }
        }
      };
    }

    case fromActions.CLOSE_SELECTION_LENGTH_WARNING_MODAL: {
      return {
        ...state,
        showMaxLengthWarning: false
      }
    }

    case fromActions.LOAD_ACCOUNT_BY_ID_FAIL: {
      return {
        ...state,
        loaded: false,
        loading: false
      };
    }
    case fromActions.LOAD_ACCOUNT_DETAIL_SUCCESS: {

      return {
        ...state,
        detailAccount: action.payload.data,
        selectedAccountsDetails: { ...state.selectedAccountsDetails, [action.payload.data.id]: action.payload.data },
        selectedAccounts: action.payload.data.locked ? state.selectedAccounts.filter(acc => acc !== action.payload.data.id) : state.selectedAccounts
      };
    }

    //#region account filtering

    case fromActions.OPEN_CLOSE_ADVANCED_SEARCH: {
      return {
        ...state,
        advancedFilterPanelOpen: action.payload === 'toggle' ? !state.advancedFilterPanelOpen : action.payload === 'open' ? true : false
      };
    }

    case fromActions.SET_ACCOUNTS_FILTER_STATE: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          gridState: {
            ...state.viewState.gridState,
            filter: action.payload,
            skip: 0,
          },
        },
      };
    }
    case fromActions.MODIFY_ACCOUNTS_FILTER_STATE: {
      const f = action.payload.filter;
      const fd = f as FilterDescriptor;
      const cfd = f as CompositeFilterDescriptor;

      let newFilter: CompositeFilterDescriptor;
      let modified = false;

      // create if no filter exists
      if (!state.viewState.gridState.filter) {
        const hasAValue = (f as any).value !== ''
        newFilter = f ? {
          logic: 'and',
          filters: hasAValue ? [f] : []
        } : null;
      } else {
        newFilter = {
          logic: 'and',
          filters: state.viewState.gridState.filter.filters.map(statefilterElem => {
            const compElem = statefilterElem as CompositeFilterDescriptor;
            const filterElem = statefilterElem as FilterDescriptor;

            if (compElem.filters) {
              if (compElem.filters.every((cfe: FilterDescriptor) => {
                return cfe.field === action.payload.field;
              })) {
                modified = true;
                return cfd;
              } else {
                return statefilterElem;
              }
            } else if (filterElem.field) {
              if (filterElem.field === action.payload.field) {
                modified = true;
                return f;
              } else {
                return statefilterElem;
              }
            }
          }).filter(f => {
            return (f !== null) && (f.hasOwnProperty('value') ? (f as any).value !== '' : true);
          })
        };
        const hasAValue = (f as any).value !== ''
        if (!modified && f !== null && hasAValue) {
          newFilter.filters = [...newFilter.filters, f];
        }
      }

      return {
        ...state,
        viewState: {
          ...state.viewState,
          gridState: {
            ...state.viewState.gridState,
            filter: newFilter,
            skip: 0,
          },
        },
      };
    }
    case fromActions.SET_ACCOUNTS_FILTER_BY_TILE: {
      return {
        ...state,
        loading: true,
        viewState: {
          ...state.viewState,
          filterByTile: action.payload,
        },
      };
    }
    case fromActions.SET_ACCOUNTS_SORT_STATE: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          gridState: {
            ...state.viewState.gridState,
            sort: action.payload,
          },
        },
      };
    }

    //#endregion
    case fromActions.SET_ACCOUNTS_LIST: {
      return {
        ...state,
        loading: false,
      };
    }
    case fromActions.SET_ACCOUNTS_PAGE_STATE: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          gridState: {
            ...state.viewState.gridState,
            skip: action.payload.skip,
            take: action.payload.take,
          },
        },
      };
    }
    case fromActions.SET_ACCOUNTS_VISIBLE_COLUMNS: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          visibleColumns: action.payload,
        },
      };
    }
    case fromActions.SET_ACCOUNTS_SHOW_UID_LIST: {
      return {
        ...state,
        viewState: {
          ...state.viewState,
          showOnlyUID: [...new Set(action.payload)],
        },
        loaded: false,
        loading: true,
      };
    }
    case fromActions.ADD_BENCHMARK: {
      return {
        ...state,
        benchmarks: [...state.benchmarks, action.payload],
      };
    }

    //region end of life
    case fromActions.OPEN_END_OF_LIFE_MODAL: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          open: true,
          trigger: action.payload
        }
      };
    }
    case fromActions.CLOSE_END_OF_LIFE_MODAL: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          open: false,
          trigger: null,
          loading: false,
          response: null,
          responseList: [],

        }
      };
    }
    case fromActions.OPEN_TASA_MODAL: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          open: true,
          trigger: "Enable",
          loading: false,
          response: null,
          responseList: [],
        }
      };
    }
    case fromActions.CLOSE_TASA_MODAL: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          open: false,
          trigger: null,
          loading: false,
          response: null,
          responseList: [],
        }
      };
    }
    case fromActions.ENABLE_ACCOUNT_END_OF_LIFE:
    case fromActions.UPDATE_ACCOUNT_END_OF_LIFE: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          loading: true,
          response: null,
          responseList: []
        }
      };
    }
    case fromActions.ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS:
    case fromActions.UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          loading: false,
          response: action.payload.res,
          responseList: action.payload.stats
        }
      };
    }
    case fromActions.ENABLE_ACCOUNT_END_OF_LIFE_FAILURE:
    case fromActions.UPDATE_ACCOUNT_END_OF_LIFE_FAILURE: {
      return {
        ...state,
        endOfLifeModal: {
          ...state.endOfLifeModal,
          loading: false,
          responseList: []
        }
      };
    }
    // end region
  }
  return state;
}
