//#region imports

import { EDIT_ACCOUNT_DESCRIPTION, EditAccountDescriptionSuccess, EditAccountDescriptionFail, LoadAccountByIdFail, LOAD_BUSINESS_HOURS, LoadBusinessHoursSuccess, LoadBusinessHoursFail, SET_VIEW_ONLY_SELECTED, OPEN_ADD_REMOVE_DEPUTY_MODAL, LoadDeputyBlacklist, LoadDeputyBlacklistSuccess, LoadDeputyBlacklistFail, EDIT_ACCOUNT_DESCRIPTION_SUCCESS, LOAD_ACCOUNT_DELEGATES, LoadAccountDelegatesFail, LoadAccountDelegatesSuccess, ADD_ACCOUNT_DEPUTIES, AddAccountDeputiesSuccess, REMOVE_ACCOUNT_DEPUTIES, RemoveAccountDeputiesSuccess, ADD_ACCOUNT_DEPUTIES_SUCCESS, SetCanEditDeputiesOfAllSelected, SetSelectedAccounts, LOAD_ACCOUNT_DETAIL_SUCCESS, ENABLE_ACCOUNT_END_OF_LIFE, EnableAccountsWithEndOfLifeSuccess, EnableAccountsWithEndOfLifeFailure, ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS, EditPasswordReceiver, EDIT_PASSWORD_RECEIVER, EditPasswordReceiverSuccess, EditPasswordReceiverFail, EDIT_PASSWORD_RECEIVER_SUCCESS, SetCanEditPasswordReceiver, UpdateAccountEndUserSuccess, UpdateAccountEndUserFail, UPDATE_ACCOUNT_ENDUSER } from './../actions/accounts-list.actions';
import { IDelegateApiElem, IDelegateIndentityApiElem, IIdentityApiElem } from './../../../../shared/interfaces/shared/common/identity';
import { getAccountsDetail, getAddRemoveDeputiesModal, getAccountDetail, getSelectedAccountsList, getAccountsListState, getAccountList, getSortedFilteredAccountList, getSelectAllStatus } from './../selectors/index';
import { LoadAccountDetail, SEARCH_ACCOUNT_DEPUTITY, searchAccountDeputityForModalSuccess, ENABLE_ACCOUNT, EnableAccountSuccess, EnableAccountFail, DISABLE_ACCOUNT, DisableAccountSuccess, DisableAccountFail, RESET_PASSWORD_SUCCESS, ENABLE_ACCOUNT_SUCCESS, DISABLE_ACCOUNT_SUCCESS } from './../actions/accounts-list.actions';
import { requestActionFollowUpSuccess, requestActionFollowUpFail, CANCEL_PENDING_REQUEST, cancelPendingRequestFailed, cancelPendingRequestSuccess, CANCEL_PENDING_REQUEST_SUCCESS, requestActionFollowUp, CANCEL_SCHEDULED_PASSWORD_RESET, cancelScheduledPasswordResetFailed, cancelScheduledPasswordResetSuccess, REQUEST_ACTION_FOLLOW_UP_LIST, REQUEST_SCHEDULED_FOLLOW_UP_LIST, requestScheduledFollowUpFail, requestScheduledFollowUpSuccess, CANCEL_SCHEDULED_PASSWORD_RESET_SUCCESS, requestScheduledFollowUp } from './../actions/follow-up-list.actions';
import { TActionFollowUpApiElem, TScheduledFollowUpApiElem, IActionFollowUpAPI, IScheduledFollowUpAPI } from './../../../../shared/interfaces/shared/account/follow-upAPI';
import { TActionFollowUp, TScheduledPasswordFollowUp, followUpStatus, followActionType } from './../../../../shared/interfaces/shared/account/follow-up';
import { IApproveAccountAPI } from './../../../../shared/interfaces/shared/account/approveAPI';
import { IAccountHistoryAPIElem, IBusinessHoursAPIElem, IAccountPasswordReceiversAPI } from './../../../../shared/interfaces/shared/account/accountAPI';
import {
  APPROVE_SELECTED_APPROVE_ACCOUNTS,
  approveSelectedApproveAccountFail,
  REJECT_SELECTED_APPROVE_ACCOUNTS,
  rejectSelectedApproveAccountFail,
  rejectSelectedApproveAccountSuccess,
  REQUEST_APPROVE_ACCOUNT_LIST,
  requestApproveAccountListFail,
  requestApproveAccountListSuccess,
  approveSelectedApproveAccountSuccess
} from './../actions/approve-list.actions';
import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { LocalStorage } from '@ngx-pwa/local-storage';
import {
  MODIFY_ACCOUNTS_FILTER_STATE,
  LOAD_ACCOUNT_DETAIL,
  LoadAccountDetailSuccess,
  RESET_PASSWORD,
  ResetPassword,
  ResetPasswordSuccess,
  ResetPasswordFail,
  LoadAccountDetailFail,
  LOAD_ACCOUNT_HISTORY,
  SET_SELECTED_ACCOUNTS,
  SET_SELECT_ALL,
  LoadAccountsListSuccess,
  LoadAccountsListFail,
  LOAD_ACCOUNTS_LIST,
  SET_ACCOUNTS_SORT_STATE,
  LoadAccountsList,
  SetAccountsList,
  SET_ACCOUNTS_PAGE_STATE,
  SET_ACCOUNTS_FILTER_BY_TILE,
  SetAccountsFilter,
  SET_ACCOUNTS_SHOW_UID_LIST,
  LoadAccountByIdSuccess,
  SET_ACCOUNTS_VISIBLE_COLUMNS,
  NoAction,
  SET_ACCOUNTS_FILTER_STATE,
  LOAD_ACCOUNTS_LIST_SUCCESS,
  SetAccountsVisibleAccounts,
  AddBenchmark,
  LOAD_ACCOUNT_BY_ID_SUCCESS,
  SetUniqueGridData,
} from '../actions/accounts-list.actions';
import { switchMap, map, tap, catchError, withLatestFrom, mergeMap, mergeAll, debounceTime, combineLatest, concatMap, mapTo, flatMap, filter } from 'rxjs/operators';
import { of, merge, Observable } from 'rxjs';
import { AccountsService } from '../../../../shared/services/accounts.service';
import { Store, select, Action } from '@ngrx/store';
import { IAccountsState } from '../reducers';
import {
  getAccountsViewState,
  getAccountsShowOnlyUID,
  getAccountsVisibleColumns,
  getAccountsGridState,
  getSelectedAccounts,
  getApproveSelectedIds,
} from '../selectors';
import { orderBy, SortDescriptor, filterBy, CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { IAccount, IAccountHistory, IAccountDeputity, IBusinessHrsUTC } from '../../../../shared/interfaces/shared/account/account';
import { IAccountAPI, IAccountAPIElem } from '../../../../shared/interfaces/shared/account/accountAPI';
import { AirbusDivisionEnum } from '../../../../shared/enums/airbus-division-enum';
import { getIdentityID, getIdentity } from '../../../../shared/store/selectors';
import { createAccConfig } from 'src/app/core/create-account/create-account.config';
import { IApproveAccount } from 'src/app/shared/interfaces/shared/account/approve';


//#endregion

interface IAccAction extends Action {
  payload: SortDescriptor[];
}
interface IFilterByTileAction extends Action {
  payload: string;
}
interface IAccountByIdAction extends Action {
  payload: number[];
}

@Injectable()
export class AccountsListEffects {
  constructor(
    private actions$: Actions,
    private accountsListService: AccountsService,
    private store: Store<IAccountsState>,
    protected localStorage: LocalStorage
  ) { }

  //#region Make API request

  @Effect()
  public loadAccountsList$ = this.actions$.pipe(
    ofType(LOAD_ACCOUNTS_LIST),
    withLatestFrom(this.store.pipe(select(getAccountsViewState)), this.store.pipe(select(getIdentityID)))
  )
    .pipe(
      switchMap(([action, viewState]) => {
        return this.accountsListService.getMatchingAccountsList(viewState).pipe(
          mergeMap((response: IAccountAPI) => {
            const processed: IAccount[] = orderBy(response.data.map((acc) => this.formatAcc(acc)), [{ field: 'uid', dir: 'asc' }]);
            const unique = {
              lifeCycleStatus: this.getUnique(processed, 'lifeCycleStatus'),
              division: this.getUnique(processed, 'division'),
              type: this.getUnique(processed, 'type'),
              pwdStatus: this.getUnique(processed, 'pwdStatus'),
              directoryEnvironment: this.getUnique(processed, 'directoryEnvironment'),
              directoryType: this.getUnique(processed, 'directoryType'),
              directoryDomain: this.getUnique(processed, 'directoryDomain'),
            };
            return [new SetUniqueGridData(unique), new LoadAccountsListSuccess(processed)];
          }),
          catchError((error) => {
            console.error(error);
            return of(new LoadAccountsListFail(error));
          })
        );
      })
    );

  @Effect()
  public loadAccountByID$ = this.actions$
    .pipe(ofType(SET_ACCOUNTS_SHOW_UID_LIST))
    .pipe(
      switchMap((action) => {
        const a = action as IAccountByIdAction;
        // remove duplicates from account ID array
        const requests = [...new Set(a.payload)].map((id) => {
          return this.accountsListService.getAccountById(id,true);
        });
        return merge(...requests).pipe(
          tap(x => {

          }),
          map((account: any) => {
            const formatted = this.formatAcc(account.data);
            return new LoadAccountByIdSuccess(formatted);
          }),
        );
      }),
      catchError(e => {
        return [new LoadAccountByIdFail(-1)];
      })
    );

  @Effect()
  public resetAccounts$ = this.actions$
    .pipe(ofType(RESET_PASSWORD),
      map(a => a as { payload: { schedule: Date, excludedChars: string, type: 'CANCEL' | 'NOW' | 'SCHEDULE', pre_scheduledhour: number } }),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts))))
    .pipe(
      switchMap(([action, selection]) => {
        return this.accountsListService.resetBulkPassword(selection, action.payload.schedule, action.payload.type, action.payload.pre_scheduledhour).pipe(
          mergeMap(res => {

            return [new ResetPasswordSuccess({ status: res.data, res: res.status })];
          }),
          // catchError(err => {

          //   return [new ResetPasswordFail({ id: x.id, res: err })]
          // })
        );
      })
    );

  @Effect()
  public requestBusinessHours$ = this.actions$
    .pipe(ofType(LOAD_BUSINESS_HOURS),
      switchMap(action => {
        return this.accountsListService.getBusinessHours().pipe(
          map(hrs => {
            if (hrs.status.error !== false) {
              return new LoadBusinessHoursFail();
            } else {
              return new LoadBusinessHoursSuccess(this.formatBusinessHours(hrs.data.opening_hours));
            }
          })
        );
      })
    );

  // @Effect()
  // public requestDeputiesBlacklistForPopup$ = this.actions$
  //   .pipe(ofType(OPEN_ADD_REMOVE_DEPUTY_MODAL),
  //   withLatestFrom(this.store.pipe(select(getAccountDetail))),
  //     switchMap(([action, detail]) => {
  //       return this.accountsListService.getDeputityBlacklistList(detail.contextId, detail.directoryDomain).pipe(
  //         map(blacklist => {
  //           if(blacklist.status.error === false){
  //             return new LoadDeputyBlacklistSuccess(blacklist.data.identities_delegate.map(d => d.identity.id))
  //           }else{
  //             return new LoadDeputyBlacklistFail(blacklist.status)
  //           }
  //         })
  //       )
  //     })
  //   );


  @Effect()
  public enableAccounts$ = this.actions$
    .pipe(ofType(ENABLE_ACCOUNT),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        return this.accountsListService.editBulkLifecycleStatus(accounts, 'enabled').pipe(
          map(res => {
            return new EnableAccountSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new EnableAccountFail());
          })
        );
      })
    );

  @Effect()
  public enableAccountsWithEndOfLife$ = this.actions$
    .pipe(ofType(ENABLE_ACCOUNT_END_OF_LIFE),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        const end_of_lifecycle_date = (action as any).payload.end_of_lifecycle_date;
        const trigger = (action as any).payload.trigger;
        return this.accountsListService.editBulkLifecycleStatus(accounts, trigger == "Enable" ? 'enabled' : 'updated', end_of_lifecycle_date).pipe(
          map(res => {
            return new EnableAccountsWithEndOfLifeSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new EnableAccountsWithEndOfLifeFailure());
          })
        );
      })
    );


  @Effect()
  public disableAccounts$ = this.actions$
    .pipe(ofType(DISABLE_ACCOUNT),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        return this.accountsListService.editBulkLifecycleStatus(accounts, 'disabled').pipe(
          map(res => {
            return new DisableAccountSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new DisableAccountFail());
          })
        );
      })
    );

  @Effect()
  public editAccountDescription$ = this.actions$
    .pipe(ofType(EDIT_ACCOUNT_DESCRIPTION),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getAccountsDetail))))
    .pipe(
      switchMap(([action, selection, detail]) => {
        const acc = detail[selection[0]];
        const description = (action as any).payload;
        return this.accountsListService.editDescription(acc, description).pipe(
          mergeMap(res => {
            return [new EditAccountDescriptionSuccess({ id: acc.id, res: res.status })];
          }),
          catchError(err => {
            return [new EditAccountDescriptionFail({ id: acc.id, res: err })];
          })
        );
      })
    );
    @Effect()
  public updateAccountEndUser$ = this.actions$
    .pipe(ofType(UPDATE_ACCOUNT_ENDUSER),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getAccountsDetail))))
    .pipe(
      switchMap(([action, selection, detail]) => {
        const acc = detail[selection[0]];
        const endUserId = (action as any).payload;
        return this.accountsListService.updateEndUser(acc, endUserId).pipe(
          mergeMap(res => {
            return [new UpdateAccountEndUserSuccess({ id: acc.id, res: res.status })];
          }),
          catchError(err => {
            return [new UpdateAccountEndUserFail({ id: acc.id, res: err })];
          })
        );
      })
    );
  @Effect()
  public editPasswordReceiver$ = this.actions$
    .pipe(ofType(EDIT_PASSWORD_RECEIVER),
      withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getAccountsDetail))))
    .pipe(
      switchMap(([action, selection, detail]) => {
        const acc = detail[selection[0]];
        const addOrDelete = (action as any).payload.action;
        const email = (action as any).payload.email;
        return this.accountsListService.editPasswordReceiver(acc, addOrDelete, email).pipe(
          mergeMap(res => {
            return [new EditPasswordReceiverSuccess({ id: acc.id, res: res.status, action: addOrDelete })];
          }),
          catchError(err => {
            return [new EditPasswordReceiverFail({ id: acc.id, res: err.error.status, action: addOrDelete })];
          })
        );
      })
    ); 5

  @Effect()
  public afterEditDetail = this.actions$
    .pipe(
      ofType(EDIT_ACCOUNT_DESCRIPTION_SUCCESS),
      map(action => {
        return new LoadAccountDetail((action as any).payload.id);
      })
    );
  @Effect()
  public afterPasswordReceiverSuccess = this.actions$
    .pipe(
      ofType(EDIT_PASSWORD_RECEIVER_SUCCESS),
      map(action => {
        return new LoadAccountDetail((action as any).payload.id);
      })
    );

  @Effect()
  public loadAccountDelegates$ = this.actions$.pipe(ofType(LOAD_ACCOUNT_DELEGATES)).pipe(
    switchMap((action: { payload: number }) => {
      return this.accountsListService.getAccountDeputies(action.payload).pipe(
        map((deps) => {
          if (deps.status.error) {
            return new LoadAccountDelegatesFail(action.payload);
          } else {
            const allDeputies: IAccountDeputity[] = deps.data.identities_delegate.map(dep => this.formatAccDeputy(dep));
            const deputies = allDeputies.filter(dep => dep.profile === 'ACCOUNT_DEPUTY');
            const indirectDeputies = allDeputies.filter(dep => dep.profile !== 'ACCOUNT_DEPUTY');
            return new LoadAccountDelegatesSuccess({ id: action.payload, deputies, indirectDeputies });
          }
        })
      );
    })
  );


  @Effect()
  public loadAccountDetail$ = this.actions$.pipe(ofType(LOAD_ACCOUNT_DETAIL)).pipe(
    concatMap((action: { payload: number }) => {
      return this.accountsListService.getAccountDetail(action.payload,true).pipe(
        concatMap(detail => {
          return this.accountsListService.getAccountHistory(detail.data.id).pipe(
            concatMap(hist => {
              return this.accountsListService.getAccountDomainId(detail.data.directory.domain).pipe(
                concatMap(domain => {
                  return this.accountsListService.getAccountPolicy(domain.data[0].id).pipe(
                    concatMap(policy => {
                      return this.accountsListService.getAccountDeputies(detail.data.id).pipe(
                        concatMap(deps => {
                          let subs: Observable<IAccountPasswordReceiversAPI>
                          if (detail.data.type == 'SERVICE11') {
                            subs = this.accountsListService.getAccountPasswordReceivers(detail.data.id)
                          }
                          else {
                            subs = of<IAccountPasswordReceiversAPI>({ data: { password_receivers: null }, status: null });
                          }
                          return subs.pipe(
                            map((receivers) => {
                              if (deps.status.error) {
                                return new LoadAccountDetailFail(action.payload);
                              } else {
                                const allDeputies: IAccountDeputity[] = deps.data.identities_delegate.map(dep => this.formatAccDeputy(dep));
                                const history = this.formatAccHistory(hist.data);
                                const deputies = allDeputies.filter(dep => dep.profile === 'ACCOUNT_DEPUTY');
                                const indirectDeputies = allDeputies.filter(dep => dep.profile !== 'ACCOUNT_DEPUTY');
                                const combined: IAccount = { ...this.formatAcc(detail.data), history, deputies, indirectDeputies, max_description_length: policy.data.max_description_length, compliance_status: detail.data.compliance_status, password_receivers: receivers.data.password_receivers };
                                return new LoadAccountDetailSuccess({ id: action.payload, data: combined });
                              }
                            })
                          )
                        })
                      );
                    })
                  );
                })
              );
            })
          );
        })
      );
    })
  );

  @Effect()
  public loadFollowUpActions$ = this.actions$.pipe(
    ofType(REQUEST_ACTION_FOLLOW_UP_LIST),
    withLatestFrom(this.store.pipe(select(getIdentityID)))
  )
    .pipe(
      switchMap(([action, requestorId]) => {
        return this.accountsListService.getActionFollowUp(requestorId).pipe(
          map((response: IActionFollowUpAPI) => {
            if (response.status.error) {
              return new requestActionFollowUpFail(response.status);
            } else {
              // const processed = defaultTestStore.accountsModule.followUpList.actions
              const processed: TActionFollowUp[] = this.formatFollowUpActions(response.data, parseInt(requestorId));
              return new requestActionFollowUpSuccess({ status: response.status, data: processed });
            }
          }),
          catchError((error) => {
            return of(new requestActionFollowUpFail(error));
          })
        );
      })
    );

  @Effect()
  public loadFollowUpScheduled$ = this.actions$.pipe(
    ofType(REQUEST_SCHEDULED_FOLLOW_UP_LIST),
    withLatestFrom(this.store.pipe(select(getIdentityID)))
  )
    .pipe(
      switchMap(([action, requestorId]) => {
        return this.accountsListService.getScheduledFollowUp(requestorId).pipe(
          map((response: IScheduledFollowUpAPI) => {
            if (response.status.error) {
              return new requestScheduledFollowUpFail(response.status);
            } else {
              // const processed = defaultTestStore.accountsModule.followUpList.actions
              const processed: TScheduledPasswordFollowUp[] = this.formatFollowUpActions(response.data, parseInt(requestorId));
              return new requestScheduledFollowUpSuccess({ status: response.status, data: processed });
            }
          }),
          catchError((error) => {
            return of(new requestScheduledFollowUpFail(error));
          })
        );
      })
    );


  @Effect()
  public searchDeputies$ = this.actions$
    .pipe(
      ofType(SEARCH_ACCOUNT_DEPUTITY),
      filter((action: any) => action.payload.length >= createAccConfig.contextSearchMinChars),
    )
    .pipe(
      switchMap((action) => {
        return this.accountsListService.searchDeputies(action.payload).pipe(
          map((res) => {
            return new searchAccountDeputityForModalSuccess(res.data.map(d => this.formatDeputyFromIdentity(d)));
          }),
        );
      })
    );

  @Effect()
  public addDeputies$ = this.actions$
    .pipe(
      ofType(ADD_ACCOUNT_DEPUTIES),
      withLatestFrom(this.store.pipe(select(getAddRemoveDeputiesModal)), this.store.pipe(select(getSelectedAccountsList)))
    )
    .pipe(
      switchMap(([action, modal, selectedAcc]) => {
        return this.accountsListService.addDeputy(selectedAcc.map(acc => acc.id), modal.currentDeputies.map(dep => dep.login)).pipe(
          map((res) => {
            if (res.status.error) {
            } else {
              return new AddAccountDeputiesSuccess({ accIds: null, data: res.data, res: res.status });
            }
          }),
        );
      })
    );
  @Effect()
  public removeDeputies$ = this.actions$
    .pipe(
      ofType(REMOVE_ACCOUNT_DEPUTIES),
      withLatestFrom(this.store.pipe(select(getAddRemoveDeputiesModal)), this.store.pipe(select(getSelectedAccountsList)))
    )
    .pipe(
      switchMap(([action, modal, selectedAcc]) => {
        return this.accountsListService.removeDeputy(selectedAcc.map(acc => acc.id), modal.currentDeputies.map(dep => dep.login)).pipe(
          map((res) => {
            if (res.status.error) {
            } else {
              return new RemoveAccountDeputiesSuccess({ accIds: null, data: res.data, res: res.status });
            }
          }),
        );
      })
    );

  @Effect()
  public checkUserInSelectedDelegation$ = this.actions$
    .pipe(
      ofType(SET_SELECTED_ACCOUNTS, LOAD_ACCOUNT_DETAIL_SUCCESS),
      withLatestFrom(
        this.store.pipe(select(getSelectedAccountsList)),
        this.store.pipe(select(getIdentity)),
      )
    )
    .pipe(
      switchMap(([action, selectedAcc, id]) => {
        if (selectedAcc.length === 1) {
          return this.accountsListService.getAccountDeputies(selectedAcc[0].id).pipe(
            switchMap((deps) => {
              const allDeputies: IAccountDeputity[] = deps.data.identities_delegate.map(dep => this.formatAccDeputy(dep));
              let actions: any = [];
              actions.push(new SetCanEditDeputiesOfAllSelected(allDeputies.some(dep => (dep.id === parseInt(id.id)) && dep.profile !== 'ACCOUNT_DEPUTY')));
              actions.push(new SetCanEditPasswordReceiver(allDeputies.some(dep => (dep.id === parseInt(id.id)) && dep.profile !== 'ACCOUNT_DEPUTY' && dep.profile !== 'CONTEXT_DEPUTY')))
              return actions;
            }

            ));
        }
        return of(new SetCanEditDeputiesOfAllSelected(false));
      }
      )
    );

  @Effect()
  public selectAllAccountsTrigger$ = this.actions$
    .pipe(
      ofType(SET_SELECT_ALL),
      withLatestFrom(
        this.store.pipe(select(getSortedFilteredAccountList)),
        this.store.pipe(select(getSelectedAccounts)),
        this.store.pipe(select(getSelectAllStatus)),
      )
    )
    .pipe(
      map(([action, state, selected, selectAllStatus]) => {
        switch (selectAllStatus) {
          case 'checked':
            return new SetSelectedAccounts({ ids: [], isAll: false });
          case 'unchecked':
          case 'indeterminate':
            return new SetSelectedAccounts({ ids: state.filter(acc => (!acc.locked && !acc.hp)).map(acc => acc.id), isAll: true });
        }
      })
    );

  @Effect()
  public cancelFollowUpAction$ = this.actions$.pipe(
    ofType(CANCEL_PENDING_REQUEST),
  )
    .pipe(
      switchMap((action) => {
        return this.accountsListService.cancelActionFollowUp((action as any).payload).pipe(
          map((response) => {

            if (response.status.error) {
              return new cancelPendingRequestFailed(response.status);
            } else {
              return new cancelPendingRequestSuccess((action as any).payload);
            }
          }),
          catchError(error => {
            return of(new cancelPendingRequestFailed(error.error.status || 'an error has occured'));
          })
        );
      })
    );

  @Effect()
  public cancelScheduledResetPassword$ = this.actions$.pipe(
    ofType(CANCEL_SCHEDULED_PASSWORD_RESET),
  )
    .pipe(
      switchMap((action) => {
        return this.accountsListService.cancelScheduledResetPassword((action as any).payload).pipe(
          map((response) => {

            if (response.status.error) {
              return new cancelScheduledPasswordResetFailed(response.status);
            } else {
              return new cancelScheduledPasswordResetSuccess((action as any).payload);
            }
          }),
          catchError(error => {
            return of(new cancelScheduledPasswordResetFailed(error.error.status || 'an error has occured'));
          })
        );
      })
    );

  @Effect()
  public reloadAccountsAfterAction$ = this.actions$.pipe(
    ofType(RESET_PASSWORD_SUCCESS, ADD_ACCOUNT_DEPUTIES_SUCCESS, ENABLE_ACCOUNT_SUCCESS, DISABLE_ACCOUNT_SUCCESS, ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS),
    withLatestFrom(this.store.pipe(select(getAccountDetail)))
  )
    .pipe(
      switchMap(([action, detail]) => {

        const actions: any[] = [new LoadAccountsList()];
        if (!detail) {
          return actions;
        }
        if (detail) {
          actions.push(new LoadAccountDetail(detail.id));
        }
        if (detail.scheduledResetPwdDateUTC) {
          actions.push(new requestScheduledFollowUp());
        }
        return actions;
      })
    );

  @Effect()
  public reloadFollowUpAfterCancel$ = this.actions$.pipe(
    ofType(CANCEL_PENDING_REQUEST_SUCCESS),
  ).pipe(
    map(() => {
      return new requestActionFollowUp();
    })
  );

  @Effect()
  public reloadScheduledPasswordAfterCancel$ = this.actions$.pipe(
    ofType(CANCEL_SCHEDULED_PASSWORD_RESET_SUCCESS),
  ).pipe(
    map(() => {
      return new requestScheduledFollowUp();
    })
  );



  //#endregion

  //#region chained actions

  // UPDATE VISIBLE ACCOUNTS

  // @Effect()
  // public updateVisibleAccounts$ = of(null)
  //   .pipe(
  //     ofType(SET_ACCOUNTS_FILTER_STATE, SET_ACCOUNTS_SORT_STATE, SET_ACCOUNTS_PAGE_STATE, LOAD_ACCOUNTS_LIST_SUCCESS, MODIFY_ACCOUNTS_FILTER_STATE, SET_VIEW_ONLY_SELECTED),
  //     withLatestFrom(
  //       this.store.pipe(select(getAccountsGridState)),
  //       this.store.pipe(select(getAccountsShowOnlyUID)),
  //       this.store.pipe(select(getSelectedAccounts)),
  //       this.store.pipe(select(getAccountsViewState)),

  //       )
  //   )
  //   .pipe(
  //     switchMap(([action, gridState, showIDs, selected, viewState]) => {
  //       if (showIDs.length > 0) {
  //         return this.localStorage.getItem<IAccount[]>('accounts').pipe(
  //           map((loaded: IAccount[]) => {
  //             loaded = loaded || []
  //             // show "showIDs" from the ready loaded local storage accounts
  //             const visible = loaded.filter(acc => showIDs.some(id => parseInt(id) === acc.id))
  //             return new SetAccountsVisibleAccounts({ data: visible, total: visible.length, maximum: visible.length, allIds: visible.map(acc => acc.id) });
  //           })
  //         );
  //       } else {
  //         return this.localStorage.getItem<IAccount[]>('accounts').pipe(

  //           // filter "show only selected" accounts
  //           map(all => {
  //             if(viewState.showOnlySelected){

  //               return (all as IAccount[]).filter(acc => {
  //                 return selected.indexOf(acc.id) !== -1
  //               })
  //             }else{
  //               return all
  //             }
  //           }),

  //           map((acc: IAccount[]) => {
  //             const maximum = acc ? acc.length : 0;
  //             const allIds = acc ? acc.map(a => a.id) : []
  //             if (!acc) {
  //               return new SetAccountsVisibleAccounts({ data: [], total: 0, maximum: 0, allIds });
  //             }
  //             if (gridState.sort ? gridState.sort.some((sort) => sort.dir !== undefined) : false) {
  //               acc = orderBy(acc, gridState.sort);
  //             }
  //             if (gridState.filter ? gridState.filter.filters.length > 0 : false) {
  //               acc = filterBy(acc, gridState.filter);
  //             }
  //             const allFilteredIds = acc.map(a => a.id)
  //             const total = acc.length;
  //             acc = acc.slice(gridState.skip, gridState.take + gridState.skip);
  //             return new SetAccountsVisibleAccounts({ data: acc, total, maximum, allIds, allFilteredIds });
  //           })
  //         );
  //       }
  //     })
  //   );

  // SCREEN WIDTH CHANGE: After a "resultion change" (portrait to landscape on tablet, or Zooming on browser) Request new content from API
  // @Effect()
  // public changeVisiblePage$ = this.actions$
  //   .pipe(
  //     ofType(SET_ACCOUNTS_VISIBLE_COLUMNS),
  //     withLatestFrom(
  //       this.store.pipe(select(getAccountsShowOnlyUID)),
  //       // this.store.pipe(select(getVisibleAccountsList)),
  //       this.store.pipe(select(getAccountsVisibleColumns))
  //     )
  //   )
  //   .pipe(
  //     map(([action, uids, accounts, visible]) => {
  //       // Don't load accounts if showing by ID selection because all colunms are loaded already
  //       if (uids.length > 0) {
  //         return new NoAction();
  //       }

  //       const loadedAcc = accounts.data[0] || {};

  //       const hasMissingColunms =
  //         visible.filter((vis) => {
  //           return loadedAcc[vis] === undefined;
  //         }).length > 0;

  //       // Only Call API if there are colunms missing in the data ( -1 for the ID colunm) and the grid is loaded
  //       if (hasMissingColunms && visible.length > 0) {
  //         return new LoadAccountsList();
  //       } else {
  //         return new NoAction();
  //       }
  //     })
  //   );

  // TILE FILTER: After arriving on grid page, if a "tile" param is included in the URL, apply the approprate filters based on the value of the tile.
  @Effect()
  public filterByTile$ = this.actions$.pipe(ofType(SET_ACCOUNTS_FILTER_BY_TILE)).pipe(
    map((action) => {
      const x = action as IFilterByTileAction;
      const notLogin: CompositeFilterDescriptor = {
        logic: 'or',
        filters: [
          {
            field: 'type',
            operator: 'eq',
            value: 'TEST'
          },
          {
            field: 'type',
            operator: 'eq',
            value: 'AUTOLOGON'
          },
          {
            field: 'type',
            operator: 'eq',
            value: 'TECHNICAL'
          }, {
            field: 'type',
            operator: 'eq',
            value: 'SERVICE'
          }, {
            field: 'type',
            operator: 'eq',
            value: 'SHARED'
          }, {
            field: 'type',
            operator: 'eq',
            value: 'TRAINING'
          }
        ]
      };

      switch (x.payload) {
        case 'ca':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'or',
                filters: [
                  {
                    field: 'division',
                    operator: 'eq',
                    value: AirbusDivisionEnum.CA,
                  },
                ],
              },
            ],
            logic: 'and',
          });
        case 'ah':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'or',
                filters: [
                  {
                    field: 'division',
                    operator: 'eq',
                    value: AirbusDivisionEnum.AH,
                  },
                ],
              },
            ],
            logic: 'and',
          });
        case 'ads':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'or',
                filters: [
                  {
                    field: 'division',
                    operator: 'eq',
                    value: AirbusDivisionEnum.ADS,
                  },
                ],
              },
            ],
            logic: 'and',
          });
        case 'pending':
          return new SetAccountsFilter({ filters: [], logic: 'and' });
        case 'to_reset':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'and',
                filters: [
                  {
                    field: 'pwdRemainingDays',
                    operator: 'lte',
                    value: 7,
                  },
                  {
                    field: 'pwdRemainingDays',
                    operator: 'gte',
                    value: 1,
                  },
                  {
                    field: 'pwdRemainingDays',
                    operator: 'neq',
                    value: null,
                  },
                  {
                    field: 'scheduledResetPwdDateUTC',
                    operator: 'eq',
                    value: null,
                  },
                ],
              },
              {
                logic: 'and',
                filters: [
                  {
                    field: 'lifeCycleStatus',
                    operator: 'eq',
                    value: 'ENABLE'
                  }
                ]
              },
              // {...notLogin}
            ],
            logic: 'and',
          });
        case 'expired':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'and',
                filters: [
                  {
                    field: 'pwdRemainingDays',
                    operator: 'lte',
                    value: 0,
                  },
                  {
                    field: 'pwdRemainingDays',
                    operator: 'neq',
                    value: null,
                  }
                ],
              },
              {
                logic: 'and',
                filters: [
                  {
                    field: 'lifeCycleStatus',
                    operator: 'eq',
                    value: 'ENABLE'
                  }
                ]
              },
              // {...notLogin}
            ],
            logic: 'and',
          });
        case 'disabled':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'or',
                filters: [
                  {
                    field: 'lifeCycleStatus',
                    operator: 'eq',
                    value: 'DISABLE',
                  },
                ],
              },
              // {...notLogin}
            ],
            logic: 'and',
          });
        case 'change_pwd_scheduled':
          return new SetAccountsFilter({
            filters: [
              {
                logic: 'or',
                filters: [
                  {
                    field: 'scheduledResetPwdDateUTC',
                    operator: 'isnotnull',
                  },
                ],
              },
            ],
            logic: 'and',
          });
        case null:
          return new SetAccountsFilter({ filters: [], logic: 'and' });
        default:
          console.error(`No Tile Filter called: ${x.payload}`);
          return new NoAction();
      }
    })
  );

  //#endregion

  //#region Approve Accounts
  @Effect()
  public requestAccountRequestList$ = this.actions$
    .pipe(ofType(REQUEST_APPROVE_ACCOUNT_LIST),
      withLatestFrom(this.store.pipe(select(getIdentityID))))
    .pipe(
      switchMap(([action, approver]) => {
        return this.accountsListService.requestRequestAccountList(approver).pipe(
          map(res => {

            if (res.status.error) {
              // return new rejectSelectedApproveAccountSuccess({status:res.status, id:selection[0]})
              return new requestApproveAccountListFail(res.status);
            } else {
              const formatted = res.data.map(acc => this.formatAcceptAccount(acc));
              return new requestApproveAccountListSuccess({ ...res, data: formatted });
            }
          }),
          catchError(err => {

            // return of(new rejectSelectedApproveAccountSuccess({status:err, id:selection[0]}))
            return of(new requestApproveAccountListFail(err));
          })
        );
      })
    );


  @Effect()
  public rejectAccountCreation$ = this.actions$
    .pipe(ofType(REJECT_SELECTED_APPROVE_ACCOUNTS),
      withLatestFrom(this.store.pipe(select(getApproveSelectedIds))))
    .pipe(
      switchMap(([action, selection]) => {
        const comment = (action as any).payload;
        if (selection.length > 1) {
          return this.accountsListService.rejectAccountCreationBulk(selection, comment).pipe(
            map(res => {
              if (res.status.error) {
                return new rejectSelectedApproveAccountFail({ status: res.status, });
              } else {
                return new rejectSelectedApproveAccountSuccess({ status: res.status, res: res.data });
              }
            }),
            catchError(err => {
              return of(new rejectSelectedApproveAccountFail({ status: err }));
            })
          );
        } else {
          return this.accountsListService.rejectAccountCreation(selection[0], comment).pipe(
            map(res => {

              if (res.status.error) {
                return new rejectSelectedApproveAccountFail({ status: res.status });
              } else {
                return new rejectSelectedApproveAccountSuccess({ status: res.status, res: res.data });
              }
            }),
            catchError(err => {
              return of(new rejectSelectedApproveAccountFail({ status: err }));
            })
          );
        }
      })
    );
  @Effect()
  public approveAccountCreation$ = this.actions$
    .pipe(ofType(APPROVE_SELECTED_APPROVE_ACCOUNTS),
      withLatestFrom(this.store.pipe(select(getApproveSelectedIds))))
    .pipe(
      switchMap(([action, selection]) => {
        if (selection.length > 1) {
          return this.accountsListService.approveAccountCreationBulk(selection).pipe(
            map(res => {
              if (res.status.error) {
                return new approveSelectedApproveAccountFail({ status: res.status });
              } else {
                return new approveSelectedApproveAccountSuccess({ status: res.status, res: res.data });
              }
            })
          )
        } else {
          return this.accountsListService.approveAccountCreation(selection[0]).pipe(
            map(res => {
              if (res.status.error) {

                // return new approveSelectedApproveAccountSuccess({status:res.status, id:selection[0]})
                return new approveSelectedApproveAccountFail({ status: res.status });
              } else {
                return new approveSelectedApproveAccountSuccess({ status: res.status, res: res.data });
              }
            }),
            catchError(err => {

              // return of(new approveSelectedApproveAccountSuccess({status:err, id:selection[0]}))
              return of(new approveSelectedApproveAccountFail({ status: err }));
            })
          );
        }
      })
    );

  //#endregion

  //#region API Formatters



  private formatAcc = (acc: IAccountAPIElem): IAccount => {
    return {
      id: acc.id,
      lifeCycleStatus: acc.lifecycle_status ?
        /enable/gi.test(acc.lifecycle_status) ? 'ENABLE' :
          /disable/gi.test(acc.lifecycle_status) ? 'DISABLE' :
            acc.lifecycle_status.toLocaleUpperCase() :
        'NONE',
      pwdRemainingDays: acc.pwd_expiration_days,
      pwdStatus: acc.doesat ? acc.pwd_expiration_days > 0 ? 'ACTIVE' : 'EXPIRED' : 'NO_PASSWORD',
      division: acc.solution ? acc.solution.division ? acc.solution.division.name : null : null,
      last_name:acc.last_name,
      first_name:acc.first_name,
      email:acc.email,
      ai_email:acc.ai_email,
      type: acc.type,
      uid: acc.name,
      pwdLastSetUTC: acc.pwd_last_set_date ? new Date(acc.pwd_last_set_date) : undefined,
      distinguishedName: acc.dn ? acc.dn : '',
      creationDateUTC: acc.creation_date ? new Date(acc.creation_date) : undefined,
      lastLogonDateUTC: acc.last_logon_date ? new Date(acc.last_logon_date) : undefined,
      lastUpdatedDateUTC: acc.last_updated_date ? new Date(acc.last_updated_date) : undefined,
      unixEnabled: acc.unix_enabled,
      scheduledResetPwdDateUTC: acc.scheduled_reset_pwd_date ? new Date(acc.scheduled_reset_pwd_date) : null,
      // locked: Math.random() > 0.5 ? true : false,
      locked: acc.locked === undefined ? false : acc.locked,
      ownerDisplayName: acc.end_user ? acc.end_user.displayname : null,
      endUser: acc.end_user,
      directoryEnvironment: acc.directory ? acc.directory.project_phase : '',
      directoryType: acc.directory ? acc.directory.type : '',
      directoryDomain: acc.directory ? acc.directory.domain : '',
      hp: acc.hp,
      // contextName: acc.solution ? acc.solution.name : null,
      // contextCode: acc.solution ? acc.solution.code : null,
      canReset: acc.doesat,
      compliance_status: acc.compliance_status,
      contextName: `${acc.solution ? acc.solution.code : ''} - ${acc.solution ? acc.solution.name : ''}`,
      contextId: acc.solution.id,
      description: acc.description,
      end_of_lifecycle_date: acc.end_of_lifecycle_date ? new Date(acc.end_of_lifecycle_date) : undefined,
      AccountExpirationDays: acc.end_of_lifecycle_date ? Math.floor((new Date(acc.end_of_lifecycle_date).getTime() - (new Date()).getTime()) / (1000 * 60 * 60 * 24)) : 0,
    };
  }

  private formatAccHistory = (accHist: IAccountHistoryAPIElem[]): IAccountHistory[] => {
    return accHist.map(h => {
      return {
        action: h.type,
        dateUtc: new Date(h.date),
        scheduledDateUtc: h.scheduled_date ? new Date(h.scheduled_date) : null,
        description: h.description,
        messageParams: h.parameters ? h.parameters.reduce((p, c, i) => {
          p[i + 1] = c || '';
          return p;
        }, {}) : null,
        message: h.type,
        owner: h.owner ? h.owner.displayname : ''
      };
    }).sort(a => a.dateUtc.getTime() * -1);
  }

  private formatAccDeputy = (api_data: IDelegateIndentityApiElem): IAccountDeputity => {
    return {
      id: api_data.identity.id,
      displayName: api_data.identity.displayname,
      profile: api_data.profile,
      email: api_data.identity.email,
      login: api_data.identity.login,
      status: api_data.identity.status
    };
  }

  private formatDeputyFromIdentity = (api_data: IIdentityApiElem): IAccountDeputity => {
    return {
      id: api_data.id,
      displayName: api_data.displayname,
      profile: null,
      email: api_data.email,
      login: api_data.login,
      status: api_data.status
    };
  }

  private formatBusinessHours = (hours: IBusinessHoursAPIElem): IBusinessHrsUTC => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    return {
      openHr: parseInt(hours.opens_utc.split(':')[0]),
      openMin: parseInt(hours.opens_utc.split(':')[1]),
      closeHr: parseInt(hours.closes_utc.split(':')[0]),
      closeMin: parseInt(hours.closes_utc.split(':')[1]),
      days: hours.day_of_week.map(str => days.indexOf(str))
    };
  }

  private formatFollowUpActions = <T extends TActionFollowUpApiElem | TScheduledFollowUpApiElem>(followUps: T[], loggedUserId: number): T extends TActionFollowUpApiElem ? TActionFollowUp[] : TScheduledPasswordFollowUp[] => {
    const res = followUps.map(f => {
      const apiElem = f as TActionFollowUpApiElem & TScheduledFollowUpApiElem;
      const calc: TActionFollowUp & TScheduledPasswordFollowUp = {
        id: apiElem.id,
        accountId: apiElem.account ? apiElem.account.id : null,
        accountName: apiElem.account ? apiElem.account.name : null,
        creationDate: apiElem.creation_date ? new Date(apiElem.creation_date) : null,
        scheduledDate: apiElem.scheduled_date ? new Date(apiElem.scheduled_date) : null,
        domain: apiElem.domain,
        requestor: apiElem.requestor ? {
          displayName: apiElem.requestor.displayname,
          id: apiElem.requestor.id
        } : null,
        justification: apiElem.justification || '-',
        status: apiElem.status,
        message: apiElem.parameters ? apiElem.parameters[0] : 'No Comment Available',
        validators: apiElem.validators ? apiElem.validators.map(v => {
          return {
            displayName: v.displayname,
            id: v.id
          };
        }) : [],
        type: apiElem.type ? apiElem.type : (apiElem.hasOwnProperty('scheduled_date') ? 'ACCOUNT_RESET_PASSWORD' : 'ACCOUNT_CREATION'),
        cancellable: this.cancellable(apiElem, loggedUserId)
      };
      return calc as unknown;
    });
    return res as T extends TActionFollowUpApiElem ? TActionFollowUp[] : TScheduledPasswordFollowUp[];
  }

  private cancellable = (followUp: TActionFollowUpApiElem & TScheduledFollowUpApiElem, loggedUserId): boolean => {
    return (
      (followUp.status === 'TO_BE_APPROVED' && followUp.requestor.id === loggedUserId) ||
      followUp.hasOwnProperty('scheduled_date') ||
      followUp.type === 'ACCOUNT_RESET_PASSWORD'
    );
  }

  private formatAcceptAccount = (acc: IApproveAccountAPI): IApproveAccount => {
    return {
      accountName: acc.account_name,
      creationDate: new Date(acc.creation_date),
      deputies: acc.deputies ? acc.deputies.map(dep => {
        return {
          displayName: dep.displayname,
          id: dep.id
        };
      }) : [],
      domain: {
        id: acc.domain && acc.domain.id,
        name: acc.domain && acc.domain.name
      },
      environment: acc.project_phase,
      id: acc.id,
      requestor: {
        displayName: acc.requestor && acc.requestor.displayname,
        id: acc.requestor && acc.requestor.id
      },
      justification: acc.justification || '-',
      solution: {
        code: acc.solution && acc.solution.code,
        id: acc.solution && acc.solution.id,
        name: acc.solution && acc.solution.name
      },
      user: {
        displayName: acc.user && acc.user.displayname,
        id: acc.user && acc.user.id
      }
    };
  }

  private getUnique = (state: IAccount[], property): string[] => {
    return state.reduce((prev, cur) => {
      return prev.indexOf(cur[property]) === -1 ? [...prev, cur[property]] : prev;
    }, []).filter(val => val !== '');
  }

  //#endregion
}
