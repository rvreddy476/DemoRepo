import { AccountsListEffects } from './accounts-list.effect';

export const effects: any[] = [AccountsListEffects];

// export * from './accounts-stats.effect';
