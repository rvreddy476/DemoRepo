import { openApproveAccountModal, openRejectAccountModal, approveSelectedApproveAccounts, requestApproveAccountList } from './../../store/actions/approve-list.actions';
import { IApproveAccount } from './../../../../shared/interfaces/shared/account/approve';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { IApproveListState } from 'src/app/shared/interfaces/shared/account/approve';
import { getApproveAccounts, getApproveSelectedIds, getApproveModal, getSelectAllStatus, SetSelectedAccounts, getApprovedSelectAllStatus } from '../../store';
import { selectApproveAccount } from '../../store/actions/approve-list.actions';
import { pipe } from '@angular/core/src/render3';
import { map, tap, debounceTime, withLatestFrom, filter } from 'rxjs/operators';
import { formatDisplayName } from 'src/app/shared/helper-functions';
import { SelectAllAccounts } from 'src/app/core/accounts/store/actions/accounts-list.actions';

@Component({
  selector: 'app-2f82-account-approve-page',
  templateUrl: './account-approve-page.component.html',
  styleUrls: ['./account-approve-page.component.scss'],
  host: {
    class: 'page-margin-std',
    style: `
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    `
  }
})
export class AccountApprovePageComponent implements OnInit {


  constructor(private store: Store<IApproveListState>) { }

  @ViewChild('grid') private grid;
  @ViewChild('gridSizer') private gridSizer;

  public $accounts: Observable<IApproveAccount[]>;
  public selection$ = this.store.pipe(select(getApproveSelectedIds))
  public selection: number[];
  public disabled: boolean;
  public gridHeight: number;
  public selectAllBtnState$ = this.store.pipe(select(getApprovedSelectAllStatus));

  public modalOpen$ = this.store.pipe(select(getApproveModal)).pipe(map(m => m.open))

  public ngOnInit() {
    this.store.dispatch(new requestApproveAccountList());
    this.$accounts = this.store.pipe(select(getApproveAccounts));
    this.selection$.pipe(
      tap(sel => {
        this.selection = sel;
        this.disabled = sel.length === 0;
      }),
      debounceTime(200),
      tap(() => {
        this.gridHeight = this.gridSizer.nativeElement.clientHeight;
      })
      ).subscribe();

    this.grid.selectionChange.pipe(
     
      withLatestFrom(this.selection$,this.$accounts),
      map(([res, selection,accounts]) => {

        const added = res.selectedRows.map(acc => acc.dataItem.id);
          const removed = res.deselectedRows.map(acc => acc.dataItem.id);
          const newSelection = [...selection, ...added].filter(cur => removed.indexOf(cur) === -1);
          const isAll = accounts.every(acc => newSelection.indexOf(acc.id) !== -1);
         
          console.log(newSelection);
          this.store.dispatch(
            new SetSelectedAccounts({ ids: newSelection, isAll })
          );
       
        if (res.selectedRows.length > 0) {
          this.store.dispatch(new selectApproveAccount([...selection, ...res.selectedRows.map(x => x.dataItem.id)]));
        }
        if (res.deselectedRows.length > 0) {
          const deselectedIds = res.deselectedRows.map(x => x.dataItem.id)
          const filtered = selection.filter(sel => deselectedIds.indexOf(sel) === -1)
          this.store.dispatch(new selectApproveAccount(filtered));
        }
      })
    ).subscribe();
  }

  public onSelectAllChange() {
    this.store.dispatch(new SelectAllAccounts());
  }

  public isRowSelected() {
    return (row) => {
      return this.selection.indexOf(row.dataItem.id) !== -1;
    };
  }

  public accept(e) {
    if (!this.disabled) {
      this.store.dispatch(new openApproveAccountModal());
    }
  }
  public reject(e) {
    if (!this.disabled) {
      this.store.dispatch(new openRejectAccountModal());
    }
  }

  public formatDN(name){
    return formatDisplayName(name)
  }

  public formatDepTooltip(deps){
    return deps.filter((d,i) => i > 0).map( d => formatDisplayName(d.displayName)).join('\n')
  }
}
