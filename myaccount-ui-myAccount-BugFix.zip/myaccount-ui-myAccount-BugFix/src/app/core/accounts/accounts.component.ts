import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { select, Store } from '@ngrx/store';
import { IIdentity } from '../../shared/interfaces/identity/identity';
import { getIdentity } from '../../shared/store/selectors';
import { IBaseState } from '../../shared/interfaces/base-state';
import { Subscription, combineLatest } from 'rxjs';
import { getEditDescriptionModal, getAddRemoveDeputiesModal, getAccountsEnfOfLifeModal, getEnableDisableModal, getAccountsResetModal, SetSelectedAccounts, getSelectedAccounts, getPasswordReceiverModal } from './store';
import { pluck, map } from 'rxjs/operators';
import { selectApproveAccount } from './store/actions/approve-list.actions';

@Component({
  selector: 'app-2f82-accounts',
  templateUrl: './accounts.component.html',
  styles: [`
    :host{
      display: flex;
      flex-direction: column;
      flex-grow: 1;
    }
    .page-margin-std{
      flex-grow: 1;
    }
  `]
})
export class AccountsComponent implements OnInit, OnDestroy {

  constructor(private translate: TranslateService, private store: Store<IBaseState>) { }
  public identity: IIdentity;
  public identity$: Subscription;


  public showEndOflifeModal = this.store.pipe(select(getAccountsEnfOfLifeModal), map(modal => modal.open));
  public showEditAccDescriptionModal = this.store.pipe(select(getEditDescriptionModal), map(modal => modal.open));
  public showDeputiesModal = this.store.pipe(select(getAddRemoveDeputiesModal), map(modal => modal.open));
  public showEnableDisableModal = this.store.pipe(select(getEnableDisableModal), map(modal => modal.open));
  public showResetPassModal = this.store.pipe(select(getAccountsResetModal), map(modal => modal.open));
  public showPasswordReceiverModal = this.store.pipe(select(getPasswordReceiverModal), map(modal => modal.open));
  public passwordReceiverEmail = this.store.pipe(select(getPasswordReceiverModal), map(modal => modal.email));
  // public showSelectionLimitModal = combineLatest(this.store.pipe(select(getShowMaxSelectionWarningModal)), this.store.pipe(select(getShowMaxSelectionWarningModalApprRej))).pipe(
  //   map(([list, apprRej]) => {
  //     return list || apprRej
  //   })
  // );

  public ngOnInit() {

  }

  public ngOnDestroy() {
    if (this.identity$) {
      this.identity$.unsubscribe();
    }
    // Remove selection on leaving accounts module
    this.store.dispatch(new SetSelectedAccounts({ ids: [], isAll: false }))
    this.store.dispatch(new selectApproveAccount([]))
  }

  public getState(outlet) {
    return outlet.activatedRouteData.state;
  }

}
