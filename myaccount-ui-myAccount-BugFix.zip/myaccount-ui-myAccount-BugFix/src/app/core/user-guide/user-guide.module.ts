import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserGuidePageComponent } from './user-guide-page.component';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { UserGuidePageRoutingModule } from './user-guide-page-routing.module';


@NgModule({
  imports: [
    LayoutModule,
    CommonModule,
    UserGuidePageRoutingModule,
  ],
  declarations: [
    UserGuidePageComponent
  ],
  bootstrap: [UserGuidePageComponent]
})
export class UserGuideModule {
  constructor() {

  }
}
