import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-guide-page',
  templateUrl: './user-guide-page.component.html',
  styleUrls: ['./user-guide-page.component.scss']
})
export class UserGuidePageComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
