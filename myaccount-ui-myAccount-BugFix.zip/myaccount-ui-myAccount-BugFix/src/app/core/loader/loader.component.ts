import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription, Observable, observable } from 'rxjs';
import { LoaderService, LoaderState } from '../../shared/interceptors/loader-interceptor';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit {

  public $show: Observable<boolean>;

  public ngOnInit() {
    this.$show = this.loaderService.loaderSubject.pipe(map(s => s.show));

  }


  constructor(private loaderService: LoaderService) {}

}
