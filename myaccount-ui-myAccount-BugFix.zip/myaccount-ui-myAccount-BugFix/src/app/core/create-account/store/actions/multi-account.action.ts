import { Action } from '@ngrx/store';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { API } from 'src/app/shared/interfaces/shared/api';



export const REQUEST_AUTOLOGON_SOLUTIONS = '[Create Account Multi] request AL solutions';
export const REQUEST_AUTOLOGON_SOLUTIONS_SUCCESS = '[Create Account Multi] request AL solutions success';
export const REQUEST_AUTOLOGON_SOLUTIONS_FAIL = '[Create Account Multi] request AL solutions fail';
export const SELECT_AUTOLOGON_SOLUTION = '[Create Account Multi] select AL solution';

export const REQUEST_AUTOLOGON_DEPUTY_BLACKLIST = '[Create Account Multi] deputy blacklist';
export const REQUEST_AUTOLOGON_DEPUTY_BLACKLIST_SUCCESS = '[Create Account Multi] deputy blacklist success';
export const REQUEST_AUTOLOGON_DEPUTY_BLACKLIST_FAILED = '[Create Account Multi] deputy blacklist failure';

export const REQUEST_AUTOLOGON_RULES = '[Create Account Multi] request AL rules';
export const REQUEST_AUTOLOGON_RULES_SUCCESS = '[Create Account Multi] request AL rules success';
export const REQUEST_AUTOLOGON_RULES_FAIL = '[Create Account Multi] request AL rules fail';
export const SELECT_AUTOLOGON_DOMAIN = '[Create Account Multi] select AL domain';

export const REQUEST_AUTOLOGON_COMPUTERS = '[Create Account Multi] request AL computers';
export const REQUEST_AUTOLOGON_COMPUTERS_SUCCESS = '[Create Account Multi] request AL computers success';
export const REQUEST_AUTOLOGON_COMPUTERS_FAIL = '[Create Account Multi] request AL computers fail';
export const SELECT_AUTOLOGON_COMPUTER = '[Create Account Multi] select AL computer';

export const REQUEST_AUTOLOGON_DEPUTIES = '[Create Account Multi] request AL deputies';
export const REQUEST_AUTOLOGON_DEPUTIES_SUCCESS = '[Create Account Multi] request AL deputies success';
export const REQUEST_AUTOLOGON_DEPUTIES_FAIL = '[Create Account Multi] request AL deputies fail';
export const SELECT_AUTOLOGON_DEPUTY = '[Create Account Multi] select AL deputy';

export const SELECT_AUTOLOGON_JUSTIFICATION = '[Create Account Multi] set AL justification text';

export const CREATE_AUTOLOGON_ACCOUNTS = '[Create Account Multi] request AL account creation';
export const CREATE_AUTOLOGON_ACCOUNTS_SUCCESS = '[Create Account Multi] request AL account creation success';
export const CREATE_AUTOLOGON_ACCOUNTS_FAIL = '[Create Account Multi] request AL account creation fail';

export const CLEAR_AUTOLOGON_TABLE = '[Create Account Multi] clear AL account creation table';

export const OPEN_AUTOLOGON_MODAL = '[Create Account Multi] open AL modal';
export const CLOSE_AUTOLOGON_MODAL = '[Create Account Multi] close AL modal';

export const OPEN_AUTOLOGON_JUSTIFICATION_MODAL = '[Create Account Multi] open AL justification modal';
export const CLOSE_AUTOLOGON_JUSTIFICATION_MODAL = '[Create Account Multi] close AL justification modal';

//#region Solutions
export class RequestAutoLogonSolutions implements Action {
  public readonly type = REQUEST_AUTOLOGON_SOLUTIONS;
  constructor(public payload?: string) { }
}
export class RequestAutoLogonSolutionsSuccess implements Action {
  public readonly type = REQUEST_AUTOLOGON_SOLUTIONS_SUCCESS;
  constructor(public payload: CreateAcc.Common.Solution[]) { }
}
export class RequestAutoLogonSolutionsFail implements Action {
  public readonly type = REQUEST_AUTOLOGON_SOLUTIONS_FAIL;
  constructor(public payload: API.Status) { }
}

export class SelectAutoLogonSolution implements Action {
  public readonly type = SELECT_AUTOLOGON_SOLUTION;
  constructor(public payload: CreateAcc.Common.Solution) { }
}

//#endregion


export class RequestAutoLogonDeputyBlacklist implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTY_BLACKLIST;
  constructor(public payload: { index: number; domain: string, context: number }) { } // number => account id;
}
export class RequestAutoLogonDeputyBlacklistSuccess implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTY_BLACKLIST_SUCCESS;
  constructor(public payload: { index: number, deputies: number[] }) { }
}
export class RequestAutoLogonDeputyBlacklistFailed implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTY_BLACKLIST_FAILED;
  constructor(public payload: { index: number, status: API.Status }) { }
}


export class RequestAutoLogonRules implements Action {
  public readonly type = REQUEST_AUTOLOGON_RULES;
  constructor(public payload: CreateAcc.Common.Solution) { }
}
export class RequestAutoLogonRulesSuccess implements Action {
  public readonly type = REQUEST_AUTOLOGON_RULES_SUCCESS;
  constructor(public payload: CreateAcc.Common.Rules) { }
}
export class RequestAutoLogonRulesFail implements Action {
  public readonly type = REQUEST_AUTOLOGON_RULES_FAIL;
  constructor(public payload: API.Status) { }
}
export class SelectAutoLogonDomain implements Action {
  public readonly type = SELECT_AUTOLOGON_DOMAIN;
  constructor(public payload: { domain: CreateAcc.Common.Domain, index: number }) { }
}

//#region Domain



//#endregion


export class RequestAutoLogonComputers implements Action {
  public readonly type = REQUEST_AUTOLOGON_COMPUTERS;
  constructor(public payload: { term: string, index: number }) { }
}
export class RequestAutoLogonComputersSuccess implements Action {
  public readonly type = REQUEST_AUTOLOGON_COMPUTERS_SUCCESS;
  constructor(public payload: { index: number, options: CreateAcc.Common.MachineName[] }) { }
}
export class RequestAutoLogonComputersFail implements Action {
  public readonly type = REQUEST_AUTOLOGON_COMPUTERS_FAIL;
  constructor(public payload: API.Status) { }
}
export class SelectAutoLogonComputer implements Action {
  public readonly type = SELECT_AUTOLOGON_COMPUTER;
  constructor(public payload: { computer: CreateAcc.Common.MachineName, index: number }) { }
}



export class RequestAutoLogonDeputies implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTIES;
  constructor(public payload: { term: string, index: number }) { }
}
export class RequestAutoLogonDeputiesSuccess implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTIES_SUCCESS;
  constructor(public payload: { index: number, options: CreateAcc.Common.Deputy[] }) { }
}
export class RequestAutoLogonDeputiesFail implements Action {
  public readonly type = REQUEST_AUTOLOGON_DEPUTIES_FAIL;
  constructor(public payload: API.Status) { }
}
export class SelectAutoLogonDeputy implements Action {
  public readonly type = SELECT_AUTOLOGON_DEPUTY;
  constructor(public payload: { deputies: CreateAcc.Common.Deputy[], index: number }) { }
}

export class SelectAutoLogonJustification implements Action {
  public readonly type = SELECT_AUTOLOGON_JUSTIFICATION;
  constructor(public payload: { justification: string, index: number }) { }
}


export class CreateAutoLogonAccounts implements Action {
  public readonly type = CREATE_AUTOLOGON_ACCOUNTS;
}
export class CreateAutoLogonAccountsSuccess implements Action {
  public readonly type = CREATE_AUTOLOGON_ACCOUNTS_SUCCESS;
  constructor(public payload: CreateAcc_API.CreationResponse[]) { }
}
export class CreateAutoLogonAccountsFail implements Action {
  public readonly type = CREATE_AUTOLOGON_ACCOUNTS_FAIL;
  constructor(public payload: API.Status) { }
}

export class CloseAutoLogonAccountsModal implements Action {
  public readonly type = CLOSE_AUTOLOGON_MODAL;
}

export class OpenAutoLogonJustificationModal implements Action {
  public readonly type = OPEN_AUTOLOGON_JUSTIFICATION_MODAL;
  constructor(public payload: CreateAcc.Multi.IAutoLogonAcc) { }
}
export class CloseAutoLogonJustificationModal implements Action {
  public readonly type = CLOSE_AUTOLOGON_JUSTIFICATION_MODAL;
}


export class ClearAutoLogonTable implements Action {
  public readonly type = CLEAR_AUTOLOGON_TABLE;
}

export type MultiAccActions =
  RequestAutoLogonSolutions
  | RequestAutoLogonSolutionsSuccess
  | RequestAutoLogonSolutionsFail
  | SelectAutoLogonSolution
  | RequestAutoLogonRules
  | RequestAutoLogonRulesSuccess
  | RequestAutoLogonRulesFail
  | SelectAutoLogonDomain
  | RequestAutoLogonComputers
  | RequestAutoLogonComputersSuccess
  | RequestAutoLogonComputersFail
  | SelectAutoLogonComputer
  | RequestAutoLogonDeputies
  | RequestAutoLogonDeputiesSuccess
  | RequestAutoLogonDeputiesFail
  | SelectAutoLogonDeputy
  | SelectAutoLogonJustification
  | CreateAutoLogonAccounts
  | CreateAutoLogonAccountsSuccess
  | CreateAutoLogonAccountsFail
  | ClearAutoLogonTable
  | RequestAutoLogonDeputyBlacklist
  | RequestAutoLogonDeputyBlacklistSuccess
  | RequestAutoLogonDeputyBlacklistFailed
  | CloseAutoLogonAccountsModal
  | OpenAutoLogonJustificationModal
  | CloseAutoLogonJustificationModal;
