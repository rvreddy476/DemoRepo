import { Action } from '@ngrx/store';
import { IAccountCreationContext, IAccCreationRules, IAccCreationPolicy, TMachineName, ICreateAccount } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { IResStatus } from '../../../../shared/interfaces/shared/api/status';
import { IIdentityAPI } from 'src/app/shared/interfaces/identity/identity';

export const REQUEST_ACC_CREATION_RULES = '[Create Account] request static creation rules';
export const REQUEST_ACC_CREATION_RULES_SUCCESS = '[Create Account] recieve static creation rules success';
export const REQUEST_ACC_CREATION_RULES_FAILED = '[Create Account] recieve static creation rules failure';
export const REQUEST_ACC_CREATION_POLICY = '[Create Account] request static creation policy';
export const REQUEST_ACC_CREATION_POLICY_SUCCESS = '[Create Account] recieve static creation policy success';
export const REQUEST_ACC_CREATION_POLICY_FAILED = '[Create Account] recieve static creation policy failure';
export const REQUEST_DEPUTY_BLACKLIST = '[Create Account] deputy blacklist';
export const REQUEST_DEPUTY_BLACKLIST_SUCCESS = '[Create Account] deputy blacklist success';
export const REQUEST_DEPUTY_BLACKLIST_FAILED = '[Create Account] deputy blacklist failure';
export const SEARCH_CONTEXT_TERM = '[Create Account] enter context search term';
export const SEARCH_OWNER_TERM = '[Create Account] enter owner search term';
export const SEARCH_DEPUTY_TERM = '[Create Account] enter duputy search term';
export const SEARCH_MACHINE_NAME = '[Create Account] search machine name search term';
export const SEARCH_MACHINE_NAME_SUCCESS = '[Create Account] search machine name search term success';
export const SEARCH_MACHINE_NAME_FAILED = '[Create Account] search machine name search term failed';
export const MAKE_SELECTION = '[Create Account] select an option';
export const CLEAR_FORM = '[Create Account] clear form';
export const UPDATE_LABEL_PREVIEW = '[Create Account] update label preview';
export const REFRESH_CREATE_ACCOUNT_OPTIONS = '[Create Account] update options & disabled state for account';
export const DUPLICATE_CREATE_ACCOUNT = '[Create Account] create a copy of this account';
export const DELETE_CREATE_ACCOUNT = '[Create Account] delete this account';
export const CREATE_ACCOUNTS = '[Create Account] request the creation of these accounts';
export const CREATE_ACCOUNTS_FAIL = '[Create Account] creation request failed';
export const CREATE_ACCOUNTS_SUCCESS = '[Create Account] creation request success';
export const CLOSE_CREATE_ACC_MODAL = '[Create Account] close modal';
export const OPEN_JUSTIFICATION_MODAL = '[Create Account] open justification modal';
export const CLOSE_JUSTIFICATION_MODAL = '[Create Account] close justification modal';
export const UNIQUE_ACCOUNT_DIRECTORY = '[Create Account] set unique account directory';

export class RequestAccCreationRules implements Action {
  public readonly type = REQUEST_ACC_CREATION_RULES;
  constructor(public payload: { accCode: string; accIndex: number, contextType: string }) { } // number => account id;
}
export class RequestAccCreationRulesSuccess implements Action {
  public readonly type = REQUEST_ACC_CREATION_RULES_SUCCESS;
  constructor(public payload: { rules: IAccCreationRules, index: number }) { }
}
export class RequestAccCreationRulesFailed implements Action {
  public readonly type = REQUEST_ACC_CREATION_RULES_FAILED;
  constructor(public payload: IResStatus) { }
}
export class RequestAccCreationPolicy implements Action {
  public readonly type = REQUEST_ACC_CREATION_POLICY;
  constructor(public payload: { index: number; domain: string }) { } // number => account id;
}
export class RequestAccCreationPolicySuccess implements Action {
  public readonly type = REQUEST_ACC_CREATION_POLICY_SUCCESS;
  constructor(public payload: { policy: IAccCreationPolicy, index: number }) { }
}
export class RequestAccCreationPolicyFailed implements Action {
  public readonly type = REQUEST_ACC_CREATION_POLICY_FAILED;
  constructor(public payload: { index: number, status: IResStatus }) { }
}

export class RequestDeputyBlacklist implements Action {
  public readonly type = REQUEST_DEPUTY_BLACKLIST;
  constructor(public payload: { index: number; domain: string, context: number }) { } // number => account id;
}
export class RequestDeputyBlacklistSuccess implements Action {
  public readonly type = REQUEST_DEPUTY_BLACKLIST_SUCCESS;
  constructor(public payload: { index: number, deputies: number[] }) { }
}
export class RequestDeputyBlacklistFailed implements Action {
  public readonly type = REQUEST_DEPUTY_BLACKLIST_FAILED;
  constructor(public payload: { index: number, status: IResStatus }) { }
}

export class SearchContextTerm implements Action {
  public readonly type = SEARCH_CONTEXT_TERM;
  constructor(public payload: { term: string; index: number }) { }
}
export class SearchOwnerTerm implements Action {
  public readonly type = SEARCH_OWNER_TERM;
  constructor(public payload: { term: string; index: number }) { }
}
export class SearchMachineName implements Action {
  public readonly type = SEARCH_MACHINE_NAME;
  constructor(public payload: { term: string; index: number }) { }
}
export class SearchMachineNameSuccess implements Action {
  public readonly type = SEARCH_MACHINE_NAME_SUCCESS;
  constructor(public payload: { results: TMachineName[]; index: number }) { }
}
export class SearchMachineNameFailed implements Action {
  public readonly type = SEARCH_MACHINE_NAME_FAILED;
  constructor(public payload: { res: IResStatus; index: number }) { }
}
export class SearchDeputyTerm implements Action {
  public readonly type = SEARCH_DEPUTY_TERM;
  constructor(public payload: { term: string; index: number }) { }
}
export class SelectCreateAccOption implements Action {
  public readonly type = MAKE_SELECTION;
  constructor(public payload: { field: string; value: any; index: number }) { }
}
export class SetUniqueDirectory implements Action {
  public readonly type = UNIQUE_ACCOUNT_DIRECTORY;
  constructor(public payload: { field: string; value: any; index: number }) { }
}
export class ClearCreateAccForm implements Action {
  public readonly type = CLEAR_FORM;
  constructor(public payload: { index?: number[]; optionsFields?: string[]; valueFields?: string[] }) { }
}
export class RefreshCreateAccountOptions implements Action {
  public readonly type = REFRESH_CREATE_ACCOUNT_OPTIONS;
  constructor(public payload: { index: number; field: string; value: any[] }) { }
}

export class UpdateLabelPreview implements Action {
  public readonly type = UPDATE_LABEL_PREVIEW;
  constructor(public payload: { index: number; domainPrefix: string, preview: string, tooLong: boolean, tooShort: boolean, charViolation: boolean }) { }
}

export class DuplicateCreateAccount implements Action {
  public readonly type = DUPLICATE_CREATE_ACCOUNT;
  constructor(public payload: number) { }
}
export class DeleteCreateAccount implements Action {
  public readonly type = DELETE_CREATE_ACCOUNT;
  constructor(public payload: number) { }
}
export class CreateAccounts implements Action {
  public readonly type = CREATE_ACCOUNTS;
}
export class CreateAccountsFail implements Action {
  public readonly type = CREATE_ACCOUNTS_FAIL;
  constructor(public payload: IResStatus) { }
}
export class CreateAccountsSuccess implements Action {
  public readonly type = CREATE_ACCOUNTS_SUCCESS;
  constructor(public payload: IResStatus) { }
}

export class CloseModal implements Action {
  public readonly type = CLOSE_CREATE_ACC_MODAL;
}

export class OpenJustificationModel implements Action {
  public readonly type = OPEN_JUSTIFICATION_MODAL;
  constructor(public payload: number) { }
}

export class CloseJustificationModal implements Action {
  public readonly type = CLOSE_JUSTIFICATION_MODAL;
}

export type AccountsStatsAction =
  | RequestAccCreationRules
  | RequestAccCreationRulesSuccess
  | RequestAccCreationRulesFailed
  | RequestAccCreationPolicy
  | RequestAccCreationPolicySuccess
  | RequestAccCreationPolicyFailed
  | RequestDeputyBlacklist
  | RequestDeputyBlacklistSuccess
  | RequestDeputyBlacklistFailed
  | SearchMachineName
  | SearchMachineNameSuccess
  | SearchMachineNameFailed
  | SearchContextTerm
  | SearchOwnerTerm
  | SearchDeputyTerm
  | ClearCreateAccForm
  | SelectCreateAccOption
  | UpdateLabelPreview
  | RefreshCreateAccountOptions
  | DuplicateCreateAccount
  | DeleteCreateAccount
  | CreateAccounts
  | CreateAccountsFail
  | CreateAccountsSuccess
  | CloseModal
  | OpenJustificationModel
  | CloseJustificationModal
  | SetUniqueDirectory;
