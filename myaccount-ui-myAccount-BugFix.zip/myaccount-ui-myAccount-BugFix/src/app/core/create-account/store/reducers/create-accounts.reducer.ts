import * as fromActions from '../actions/create-account.action';
import { ICreateAccountFormState, ICreateAccount } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { createAccConfig } from '../../create-account.config';


const emptyInitialState: ICreateAccount[] = [
  {
    contextCode: {
      loading: false,
      loadingContent: false,
      value: null,
      options: [],
    },
    rules: null,
    rulesLoaded: false,
    rulesLoading: false,
    policy: null,
    policyLoaded: false,
    policyLoading: false,
    deputyBlacklist: [],
    deputyBlacklistLoaded: false,
    deputyBlacklistLoading: false,
    type: {
      loading: false,
    },
    environment: {
      loading: false,
    },
    uniqueInADandADAM: {
      loading: false,
      value: false
    },
    directory: {
      loading: false,
    },
    domain: {
      loading: false,
    },
    labelPrefix: {
      loading: false,
      value: '',
      valid: true
    },
    labelPreview: {
      loading: false,
    },
    owner: {
      loading: false,
      loadingContent: false,
      options: [],
      value: null,
    },
    machineName: {
      loading: false,
      options: [],
      value: null
    },
    deputies: {
      loading: false,
      options: [],
      value: [],
      loadingContent: false,
    },
    justification: {
      loading: false,
      value: '',
      valid: false
    },
    end_of_lifecycle_date: {
      loading: false,
      value: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
    }
  },
];

const initialState: ICreateAccountFormState = {
  editingAccList: emptyInitialState,
  justificationModal: {
    account: null
  },
  modal: {
    open: false,
    loading: false,
    response: null
  }
};

const cxtMinChar = createAccConfig.contextSearchMinChars;

export function CreateAccountsReducer(state = initialState, action: fromActions.AccountsStatsAction): ICreateAccountFormState {
  const editAcc = (account, field, property, value): ICreateAccount => {
    return { ...account, [field]: { ...account[field], [property]: value } };
  };

  switch (action.type) {
    case fromActions.REQUEST_ACC_CREATION_RULES_SUCCESS:
      const { rules, index: rulesIndex } = action.payload;
      const rulesAccList = [...state.editingAccList];
      rulesAccList[rulesIndex].rules = rules;
      rulesAccList[rulesIndex].rulesLoading = false;
      rulesAccList[rulesIndex].rulesLoaded = true;

      return {
        ...state,
        editingAccList: rulesAccList
      };

    case fromActions.REQUEST_ACC_CREATION_POLICY:
      const { index: policyIndexR } = action.payload;
      const policyAccListR = [...state.editingAccList];
      policyAccListR[policyIndexR].policyLoading = true;
      policyAccListR[policyIndexR].policyLoaded = false;

      return {
        ...state,
        editingAccList: policyAccListR
      };

    case fromActions.REQUEST_ACC_CREATION_POLICY_SUCCESS:
      const { policy, index: policyIndex } = action.payload;
      const policyAccList = [...state.editingAccList];
      policyAccList[policyIndex].policy = policy;
      policyAccList[policyIndex].policyLoading = false;
      policyAccList[policyIndex].policyLoaded = true;

      return {
        ...state,
        editingAccList: policyAccList
      };

    case fromActions.REQUEST_ACC_CREATION_POLICY_FAILED:

      const { index: policyFailIndex } = action.payload;
      const policyFailAccList = [...state.editingAccList];
      policyFailAccList[policyFailIndex].policy = policy;
      policyFailAccList[policyFailIndex].policyLoading = false;
      policyFailAccList[policyFailIndex].policyLoaded = false;

      return {
        ...state,
        editingAccList: policyFailAccList
      };

    case fromActions.REQUEST_DEPUTY_BLACKLIST:
      const depBlacklistAccList = [...state.editingAccList];
      const blackModAcc = depBlacklistAccList[action.payload.index];

      blackModAcc.deputyBlacklistLoading = true;
      blackModAcc.deputyBlacklistLoaded = false;

      return {
        ...state,
        editingAccList: depBlacklistAccList
      };

    case fromActions.REQUEST_DEPUTY_BLACKLIST_SUCCESS:
      const depBlacklistAccListSuccess = [...state.editingAccList];
      let blackModAccSuccess = depBlacklistAccListSuccess[action.payload.index];

      blackModAccSuccess = {
        ...blackModAccSuccess,
        deputyBlacklistLoading: false,
        deputyBlacklistLoaded: true,
        deputyBlacklist: action.payload.deputies
      };

      depBlacklistAccListSuccess[action.payload.index] = blackModAccSuccess;

      return {
        ...state,
        editingAccList: [...depBlacklistAccListSuccess]
      };

    case fromActions.SEARCH_CONTEXT_TERM:
      const searchEditingAccList = [...state.editingAccList];
      const searchCur = searchEditingAccList[action.payload.index].contextCode;

      searchCur.loadingContent = action.payload.term.length >= cxtMinChar;
      searchCur.options = action.payload.term.length < cxtMinChar ? [] : searchCur.options;
      searchCur.message = (action.payload.term.length < cxtMinChar && action.payload.term.length > 0) ? `CREATE_ACCOUNT.WARN.AUTO_SUGGEST_MIN` : null;

      return {
        ...state,
        editingAccList: searchEditingAccList,
      };

    case fromActions.SEARCH_OWNER_TERM:
      const searchOwnerEditingAccList = [...state.editingAccList];
      const searchOwnerCur = searchOwnerEditingAccList[action.payload.index].owner;
      const ownerMinChar = createAccConfig.contextSearchMinChars;

      searchOwnerCur.loadingContent = action.payload.term.length >= ownerMinChar;
      searchOwnerCur.options = action.payload.term.length < cxtMinChar ? [] : searchOwnerCur.options;
      searchOwnerCur.message = action.payload.term.length > 0 && action.payload.term.length < ownerMinChar ? `CREATE_ACCOUNT.WARN.AUTO_SUGGEST_MIN` : null;

      return {
        ...state,
        editingAccList: searchOwnerEditingAccList,
      };

    case fromActions.SEARCH_DEPUTY_TERM:
      const searchDepEditingAccList = [...state.editingAccList];
      const searchDepCur = searchDepEditingAccList[action.payload.index].deputies;
      const depMinChar = createAccConfig.contextSearchMinChars;

      searchDepCur.loadingContent = action.payload.term.length >= depMinChar;
      searchDepCur.options = action.payload.term.length < cxtMinChar ? [] : searchDepCur.options;
      searchDepCur.message = action.payload.term.length > 0 && action.payload.term.length < depMinChar ? `CREATE_ACCOUNT.WARN.AUTO_SUGGEST_MIN` : null;

      return {
        ...state,
        editingAccList: searchDepEditingAccList,
      };

    //#region make Selection

    case fromActions.MAKE_SELECTION:
      const { index: indexSel, field: fielSel, value: valSel } = action.payload;
      const selectList: ICreateAccount[] = [...state.editingAccList];

      // set value
      selectList[indexSel] = editAcc(selectList[indexSel], fielSel, 'value', valSel || null);

      // remove policy and rules if clearing context code
      if (!valSel && fielSel == 'contextCode') {
        selectList[indexSel] = { ...selectList[indexSel], policyLoaded: false, rulesLoaded: false };
      }

      return {
        ...state,
        editingAccList: selectList,
      };

    case fromActions.UNIQUE_ACCOUNT_DIRECTORY:
      const { index: indSel, field: fieldSel, value: valueSel } = action.payload;
      const selectedList: ICreateAccount[] = [...state.editingAccList];

      // set value
      if (valueSel == true)
        selectedList[indSel] = editAcc(selectedList[indSel], 'directory', 'value', 'ACDS-AD')
      else
        selectedList[indSel] = editAcc(selectedList[indSel], 'directory', 'value', null)

      return {
        ...state,
        editingAccList: selectedList,
      };

    //#endregion


    //#region clear form
    case fromActions.CLEAR_FORM:
      const { index: indexClear, optionsFields: optionClear, valueFields: valClear } = action.payload;

      if (indexClear ? indexClear.length === 0 : true) {
        return {
          ...state,
          editingAccList: [{
            ...emptyInitialState[0],
            contextCode: { ...emptyInitialState[0].contextCode, options: [] },
          }],
        };
      }

      const clearedList = state.editingAccList.map((acc, i) => {
        if (indexClear.indexOf(i) === -1) {
          return acc;
        } else {
          if (optionClear) {
            optionClear.forEach((opt) => {
              if (acc[opt]) {
                acc[opt].options = [];
                acc[opt].message = [];
                acc[opt].disabled = true;
              }
            });
          }
          if (valClear) {
            valClear.forEach((val) => {
              if (acc[val]) {
                acc[val].value = null;
                acc[val].message = [];
              }
            });
          }
          return acc;
        }
      });

      return {
        ...state,
        editingAccList: clearedList,
      };

    //#endregion


    case fromActions.REFRESH_CREATE_ACCOUNT_OPTIONS:
      const { field: freshField, index: freshIndex } = action.payload;
      let freshValue = action.payload.value;
      const editingAccListOptions = [...state.editingAccList];

      switch (freshField) {
        case 'contextCode':
          editingAccListOptions[freshIndex][freshField].message = freshValue.length === 0 ? 'CREATE_ACCOUNT.WARN.NO_CONTEXT' : null;
          break;
        case 'owner':
          editingAccListOptions[freshIndex][freshField].message = freshValue.length === 0 ? 'CREATE_ACCOUNT.WARN.NO_OWNER' : null;
          break;
        case 'deputies':
          editingAccListOptions[freshIndex][freshField].message = freshValue.length === 0 ? 'CREATE_ACCOUNT.WARN.NO_DEPUTY' : null;
          break;
        case 'environment':
          const order = ['INT', 'VAL', 'PROD'];
          const ordered = order.filter((type) => freshValue.indexOf(type) !== -1);
          freshValue = ordered;
      }

      editingAccListOptions[freshIndex][freshField].options = freshValue;
      editingAccListOptions[freshIndex][freshField].loadingContent = false;
      editingAccListOptions[freshIndex][freshField].disabled = false;

      return {
        ...state,
        editingAccList: editingAccListOptions,
      };

    case fromActions.CREATE_ACCOUNTS:
      return {
        ...state,
        modal: {
          ...state.modal, loading: true, open: true, response: null
        }
      };

    case fromActions.CREATE_ACCOUNTS_FAIL:
      return {
        ...state,
        modal: {
          ...state.modal, open: true, loading: false, response: action.payload
        }
      };

    case fromActions.CREATE_ACCOUNTS_SUCCESS:
      return {
        ...state,
        modal: {
          ...state.modal, loading: false, open: true, response: action.payload
        }
      };

    case fromActions.CLOSE_CREATE_ACC_MODAL:
      // cannot close while loading
      return {
        ...state,
        modal: {
          ...state.modal, open: state.modal.loading
        }
      };

    case fromActions.OPEN_JUSTIFICATION_MODAL:
      return {
        ...state,
        justificationModal: {
          account: state.editingAccList[0]
        }
      }

    case fromActions.CLOSE_JUSTIFICATION_MODAL:
      return {
        ...state,
        justificationModal: {
          account: null
        }
      }

  }

  return state;
}
