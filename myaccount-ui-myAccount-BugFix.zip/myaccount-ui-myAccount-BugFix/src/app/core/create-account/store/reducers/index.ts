
import { ActionReducerMap } from '@ngrx/store';
import { ICreateAccountFormState } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { CreateAccountsReducer } from './create-accounts.reducer';
import { CreateMultiReducer } from './multi-accounts.reducer';

export interface ICreateAccountState {
  createFormState: ICreateAccountFormState;
  createMultiState: CreateAcc.Multi.State;
}

export const reducers: ActionReducerMap<ICreateAccountState> = {
  createFormState: CreateAccountsReducer,
  createMultiState: CreateMultiReducer
};
