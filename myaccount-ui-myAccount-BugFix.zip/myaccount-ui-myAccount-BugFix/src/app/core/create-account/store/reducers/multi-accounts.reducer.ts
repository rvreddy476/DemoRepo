
import * as fromActions from '../actions/index';

import { createEntityAdapter, Update, EntityAdapter } from '@ngrx/entity';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { AccountsStatsAction } from '../actions';


export const adaptor = createEntityAdapter<CreateAcc.Multi.IAutoLogonAcc>();

let initialState: CreateAcc.Multi.State = adaptor.getInitialState({
	solution: null,
	policy: null,
	rules: null,
	activeIndex: null,
	select_valid: null,
	options: {
		solutions: [],
		computers: {
			index: 0,
			options: null
		},
		deputies: {
			index: 0,
			options: null
		},
	},
	modal: {
		loading: false,
		data: null,
	},
	justificationModal:{
		account:null
	}
});

const setInitialState = (adaptor: EntityAdapter<CreateAcc.Multi.IAutoLogonAcc>, global: CreateAcc.Multi.State = null) => {
	return adaptor.addOne({
		id: 0,
		computer: null,
		select_computerOptions: [],
		deputies: [],
		blacklistedDeputies: [],
		select_deputyOptions: [],
		domain: null,
		justification:'',
		select_valid: null,
		failedReason: null,
		select_label: '',
	}, global || initialState);
};



initialState = setInitialState(adaptor);


export function CreateMultiReducer(state = initialState, action: fromActions.MultiAccActions | fromActions.AccountsStatsAction): CreateAcc.Multi.State {
	switch (action.type) {

		case fromActions.REQUEST_AUTOLOGON_SOLUTIONS:
			return {
				...state,
			};
			break;

		case fromActions.REQUEST_AUTOLOGON_SOLUTIONS_SUCCESS:
			return {
				...state,
				options: {
					...state.options,
					solutions: action.payload
				}
			};
			break;

		case fromActions.SELECT_AUTOLOGON_SOLUTION:
			return {
				...state,
				solution: action.payload,
			};
			break;

		case fromActions.REQUEST_AUTOLOGON_RULES_SUCCESS:
			return {
				...state,
				rules: action.payload
			};
			break;

		case fromActions.SELECT_AUTOLOGON_DOMAIN:

			return adaptor.updateOne({ id: action.payload.index, changes: { domain: action.payload.domain } }, state);
			break;

		case fromActions.REQUEST_AUTOLOGON_COMPUTERS_SUCCESS:
			return {
				...state,
				options: {
					...state.options,
					computers: action.payload
				}
			};
			break;

		case fromActions.SELECT_AUTOLOGON_COMPUTER:
			return adaptor.updateOne({ id: action.payload.index, changes: { computer: action.payload.computer } }, state);
			break;


		case fromActions.REQUEST_AUTOLOGON_DEPUTIES_SUCCESS:
			return {
				...state,
				options: {
					...state.options,
					deputies: action.payload
				}
			};
			break;

		case fromActions.REQUEST_AUTOLOGON_DEPUTY_BLACKLIST_SUCCESS:
			return adaptor.updateOne({ id: action.payload.index, changes: { blacklistedDeputies: action.payload.deputies } }, state);
			break;

		case fromActions.SELECT_AUTOLOGON_DEPUTY:
			return adaptor.updateOne({ id: action.payload.index, changes: { deputies: action.payload.deputies } }, state);
			break;

			case fromActions.SELECT_AUTOLOGON_JUSTIFICATION:
				return adaptor.updateOne({ id: action.payload.index, changes: { justification: action.payload.justification } }, state);
				break;

		case fromActions.DUPLICATE_CREATE_ACCOUNT:
			const duplicate: CreateAcc.Multi.IAutoLogonAcc = {
				id: Math.max(...state.ids as number[]) + 1,
				domain: state.entities[action.payload] ? state.entities[action.payload].domain : null,
				computer: null,
				deputies: [],
				failedReason: null,
				blacklistedDeputies: [],
				justification:'',
				select_computerOptions: [],
				select_deputyOptions: [],
				select_valid: false,
				select_label: null
			};
			const duplicatedElement = adaptor.addOne(duplicate, state);
			// duplicatedElement.ids = [3,2,1,0]
			return duplicatedElement;
			break;
		case fromActions.DELETE_CREATE_ACCOUNT:
			return adaptor.removeOne(action.payload, state);
			break;

		case fromActions.CREATE_AUTOLOGON_ACCOUNTS_SUCCESS:

			// return adaptor.removeMany(removeIds,{
			return {
				...state,
				modal: {
					data: action.payload,
					loading: false
				}
			};

		case fromActions.CLEAR_AUTOLOGON_TABLE:
			adaptor.removeAll(state);
			const clearedTableState = setInitialState(adaptor, {
				...initialState,
				options: {
					...state.options,
					solutions: state.options.solutions
				}});
				return clearedTableState;
			break;

		case fromActions.CLOSE_AUTOLOGON_MODAL:

			// and clear successful accounts from table
			const removeIds = state.modal ? state.modal.data ? state.modal.data.map((res, i) => res.type === 'SUCCESS' ? state.ids[i].toString() : null).filter(id => Boolean(id)) : [] : [];

			const clearedState = {
				...state,
				modal: {
					data: null,
					loading: false
				}
			};
			const zeroRemains = removeIds.length === state.ids.length;
			const newClearedList = adaptor.removeMany(removeIds, clearedState);
			if (zeroRemains) {
				return setInitialState(adaptor, newClearedList);
			} else {
				return newClearedList;
			}
			break;

			case fromActions.OPEN_AUTOLOGON_JUSTIFICATION_MODAL:
				return {
					...state,
					justificationModal:{
						account:action.payload
					}
				}

			case fromActions.CLOSE_JUSTIFICATION_MODAL:
				return {
					...state,
					justificationModal:{
						account:null
					}
				}
	}
	return state;
}
