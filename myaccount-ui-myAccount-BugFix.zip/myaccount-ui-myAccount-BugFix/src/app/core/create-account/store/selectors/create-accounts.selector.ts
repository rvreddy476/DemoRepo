import { ICreateAccount } from './../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { ICreateAccountState } from '../reducers';
import { createAccConfig } from '../../create-account.config';

export const getCreateAccountsList = (state: ICreateAccountState) => state.createFormState.editingAccList;

