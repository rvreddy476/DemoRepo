import { getCreateAccountsList } from './create-accounts.selector';
import { ICreateAccountState } from '../reducers';
import { getCreateAccountFormState, getCreateAccountState, getCreateAccFormValues, getCreateAccExportValues, createAccModal, getCreateAccTypeInput, getCreateAccEnvironmentInput } from '.';

const rules2F82 = {
    contextType: {
        name: 'Application',
        accountTypes: [
            {
                name: 'SHARED',
                environments: [
                    {
                        name: 'DEV',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'INT',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PRE-PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'VAL',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                name: 'TEST',
                environments: [
                    {
                        name: 'DEV',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'INT',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PRE-PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'VAL',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                name: 'AUTOLOGON',
                environments: [
                    {
                        name: 'PROD',
                        directories: [
                            {
                                forceSelected: true,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    }
                                ]
                            },
                            {
                                forceSelected: true,
                                ignore: true,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: true,
                                        ignore: true,
                                        name: 'ACDSLAN'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                name: 'SERVICE',
                environments: [
                    {
                        name: 'DEV',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'INT',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PRE-PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'VAL',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                name: 'TECHNICAL',
                environments: [
                    {
                        name: 'DEV',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'INT',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PRE-PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'PROD',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        name: 'VAL',
                        directories: [
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-AD',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIIDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIVDMZ'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'EU'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'NA'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AS'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'RES'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'AIDMZ'
                                    }
                                ]
                            },
                            {
                                forceSelected: false,
                                ignore: false,
                                type: 'ACDS-ADAM',
                                domains: [
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-I'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ-V'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSLAN'
                                    },
                                    {
                                        forceSelected: false,
                                        ignore: false,
                                        name: 'ACDSDMZ'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    deputyRequired: true,
    solution: {
        id: 3702,
        code: '2F82',
        division: {
            id: 1,
            name: 'Airbus Commercial Aircraft'
        },
        name: 'MyAccount',
        type: 'Application'
    }
};


describe('getCreateAccountsModal Selector', () => {
    const mock = { modal: 'testModal' };
    it(' should return Create account Modal State', () => {
        expect(createAccModal.projector(mock as any as ICreateAccountState)).toBe('testModal');
    });
});

describe('getCreateAccTypeInput Selector', () => {
    it(' should return empty type if rules are not loaded', () => {
        expect(getCreateAccTypeInput.projector([{
            rules: null,
            rulesLoaded: false,
            type: {
                value: ''
            }
        }]))
        .toEqual([{
            options: [],
            value: [],
            environments: null,
            valid: false
        }]);
    });

    it(' should return correct value and options and valid properties', () => {
        const output = getCreateAccTypeInput.projector([{
            rules: rules2F82,
            rulesLoaded: true,
            type: {
                value: 'SERVICE',
            }
        }])[0];
        expect(output.value).toEqual(['SERVICE']);
        expect(output.valid).toBe(true);
        expect(output.options).toEqual([
            'SHARED',
            'TEST',
            'AUTOLOGON',
            'SERVICE',
            'TECHNICAL',
        ]);
    });
});

describe('getCreateAccountsList Selector', () => {
    const mock = { createFormState: { editingAccList: 'testVal' } };
    it(' should return editingAccList', () => {
        expect(getCreateAccountsList(mock as any as ICreateAccountState)).toBe('testVal');
    });
});

describe('getCreateAccountState Selector', () => {
    const mock = { createFormState: 'testVal' };
    it(' should return CreateAccountFormState', () => {
        expect(getCreateAccountState.projector(mock).createFormState).toBe('testVal');
    });
});

describe('getCreateAccountFormState Selector', () => {
    const mock = { createFormState: 'testVal' };
    it(' should return CreateAccountFormState', () => {
        expect(getCreateAccountFormState.projector(mock)).toBe('testVal');
    });
});

describe('getCreateAccFormValues Selector', () => {
    const mockVal = [1, 2, 3];
    const mock = { editingAccList: mockVal };
    it(' should return getCreateAccFormValues', () => {
        expect(getCreateAccFormValues.projector(mock)).toBe(mockVal);
    });
});
