import { ICreateAccountAPI, TAccountType, TAccountDirectory } from './../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as SelectorFunctions from './create-accounts.selector';
import { ICreateAccountState } from '../reducers';
import { ICreateAccountFormState, ICreateAccount } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { createAccConfig } from '../../create-account.config';
import { every } from 'rxjs/operators';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { adaptor } from '../reducers/multi-accounts.reducer';
import { getIdentityID, getIdentity } from 'src/app/shared/store/selectors';
import { DebugRenderer2 } from '@angular/core/src/view/services';
import { environment } from 'src/environments/environment.prod';
import { forEach } from '@angular/router/src/utils/collection';


// high level selectors

export const getCreateAccountState = createFeatureSelector<ICreateAccountState>('createAccountModule');
export const getCreateAccountFormState = createSelector(
  getCreateAccountState,
  (state: ICreateAccountState) => state.createFormState
);
export const getMultiAccountState = createSelector(
  getCreateAccountState,
  (state: ICreateAccountState) => state.createMultiState
);

// low level selectors

export const getCreateAccFormValues = createSelector(
  getCreateAccountFormState,
  (state: ICreateAccountFormState) => state.editingAccList
);



//#region create account modal
export const createAccModal = createSelector(
  getCreateAccountFormState,
  (state: ICreateAccountFormState) => state.modal
);

export const getJustificationModal = createSelector(
  getCreateAccountFormState,
  (state: ICreateAccountFormState) => state.justificationModal
);
//#endregion



//#region Derived Create-Account Data

//#region Form Inputs

/**
 *
 * @param userInput selected options chosen by the user
 * @param options all possible options, includes any forced options
 * @returns Input as it should appear on the form.
 * - combines forced values with selected values
 * - automatically sets value if only one option and marks input as valid
 * - detects if all options are forced, sets all as selected and marks input as valid
 */
const deriveInputValueAndValidate = (input: string, options: { forceSelected?: boolean, name?: string, type?: string }[]) => {
  const userInput = input ? [input] : [];
  // there is only one option
  if (options.length === 1) {
    return {
      value: options.map(opt => opt.name || opt.type),
      valid: true
    };
  }
  // all options are forced
  if (options.every(opt => opt.forceSelected === true)) {
    return {
      value: options.map(opt => opt.name || opt.type),
      valid: true
    };
    // there are unforced options. (maybe all are unforced)
  } else {
    return {
      // join user selection to forced selection
      value: userInput.concat(options.filter(opt => opt.forceSelected).map(filtOpt => filtOpt.name || filtOpt.type)),
      // validate if at least one unforced options is selected
      valid: options.some(opt => (!opt.forceSelected) && (userInput.indexOf(opt.name || opt.type) !== -1))
    };
  }
};

/**
 * returns the options and value if the acc type input
 * value is returned in array form to keep uniformity for inputs which require an array. eg directories & domain
 */
export const getCreateAccTypeInput = createSelector(
  getCreateAccFormValues,
  accounts => {
    return accounts.map(acc => {
      if (!acc.rulesLoaded) {
        return {
          options: [],
          value: [],
          environments: null,
          valid: false
        };
      }
      const types = acc.rules.contextType.accountTypes;
      // user selected value can be overridden here to allow for forced selection
      const value = acc.type.value ? [acc.type.value] : [];
      // if there is a selection value, return the list of corrosponding environments.
      // Output is reduced to a single array to combine multiple "type" matches
      const environments = value.length > 0 ?
        types.filter(type => value.indexOf(type.name) !== -1).map(type => type.environments)
          .reduce((p, c) => {
            return p.concat(c);
          }, [])
        : null;
      return {
        options: types.map(type => type.name),
        value,
        environments,
        valid: value.length > 0
      };
    });
  }
);

export const getCreateAccEnvironmentInput = createSelector(
  getCreateAccFormValues, getCreateAccTypeInput,
  (values, types) => {
    return values.map(
      (acc, accIndex) => {
        if (types[accIndex].value.length === 0) {
          return {
            options: [],
            value: [],
            directories: null,
            valid: false
          };
        }
        try {
          const options = types[accIndex].environments;

          // if there is only one option, select it. otherwise return the user value ||
          const { value, valid } = deriveInputValueAndValidate(acc.environment.value, options);

          const directories = value.length > 0 ?
            types[accIndex].environments.filter(env => value.indexOf(env.name) !== -1).map(env => env.directories)
              .reduce((p, c) => {
                return p.concat(c);
              }, []) : [];
          return {
            options: options.map(opt => opt.name),
            value,
            directories,
            valid
          };
        } catch (err) {
          console.error(err);
          return {
            options: [],
            value: [],
            directories: null,
            valid: false
          };
        }
      }
    );
  }
);
export const getCreateAccDirectoryInput = createSelector(
  getCreateAccFormValues, getCreateAccEnvironmentInput,
  (values, envs) => {
    return values.map(
      (acc, accIndex) => {
        if (envs[accIndex].value.length === 0) {
          return {
            options: [],
            value: [],
            domains: null,
            valid: false
          };
        }
        try {
          const diectories = envs[accIndex].directories;
          const options = diectories.map(env => env.type);

          const { value, valid } = deriveInputValueAndValidate(acc.directory.value, diectories);

          const domains = value.length > 0 ?
            envs[accIndex].directories.filter(dir => value.indexOf(dir.type) !== -1).map(env => env.domains)
              .reduce((p, c) => {
                return p.concat(c);
              }, []) : [];
          return {
            options,
            value,
            domains,
            valid
          };
        } catch (err) {
          console.error(err);
          return {
            options: [],
            value: [],
            domains: null,
            valid: false
          };
        }
      }
    );
  }
);

export const getCreateAccDomainInput = createSelector(
  getCreateAccFormValues, getCreateAccDirectoryInput,
  (values, dirs) => {
    return values.map(
      (acc, accIndex) => {
        if (dirs[accIndex].value.length === 0) {
          return {
            options: [],
            value: [],
            valid: false
          };
        }
        try {
          const diectories = dirs[accIndex].domains.filter(d => !d.forceSelected);
          // dont show forced selections in dropdown
          const options = diectories.map(dir => dir.name);
          const { value, valid } = deriveInputValueAndValidate(acc.domain.value, diectories);
          // include force selected domains
          // .concat(diectories.filter(dir => dir.forceSelected).map(dir => dir.name))

          return {
            options,
            value,
            valid
          };
        } catch (err) {
          console.error(err);
          return {
            options: [],
            value: [],
            valid: false
          };
        }
      }
    );
  }
);
//#endregion

export const getLabelPreviewInfo = createSelector(
  getCreateAccFormValues, getCreateAccEnvironmentInput, getIdentity,
  (state, envInput, identity, id: number = 0) => {
    const acc = state[id];
    const empty = {
      preview: null,
      message: null,
      valid: false
    };
    // if no policy loaded return null
    if (!acc.policy || acc.policyLoading || !acc.policyLoaded || !acc.type.value) {
      return empty;
    }

    let labelValue = '';

    // what to use to create the label preview
    const labelSource: 'text' | 'login' | 'computer' | undefined = acc.policy.label.types[acc.type.value];

    switch (labelSource) {
      case 'computer':
        labelValue = acc.machineName.value ? acc.machineName.value[0] ? acc.machineName.value[0].name.substring(3, acc.machineName.value[0].name.length) : null : null;
        break;
      case 'login':
        labelValue = acc.owner.value ? acc.owner.value[0] ? acc.owner.value[0].login : null : null;
        break;
      case 'text':
        labelValue = acc.labelPrefix.value;
        break;
      default:
        labelValue = ' - - ';
    }
    if (!labelValue) {
      return empty;
    }

    const typeTag = createAccConfig.accountTypeMapping[acc.type.value];
    let contextTag = acc.contextCode.value.code;
    const policyEnvs = acc.policy.environment.values.filter(envP => envP.name.toLocaleUpperCase() === envInput[id].value[0]);
    const envTag = policyEnvs ? policyEnvs[0] ? policyEnvs[0].label : '' : '';
    const accSuffix = acc.owner.value && acc.owner.value.length > 0 ? acc.owner.value[0].firstname.substring(0, 1) + acc.owner.value[0].lastname.substring(0, 2) : '';

    // if length is more than 6 chracters ,consider last 6 characters from aspire code
    if (contextTag.length > 6) {
      contextTag = contextTag.trim().slice(-6);
    }

    var preview = ""
    if (acc.type.value === 'TECHNICAL' && !environment.exemptedSolutionCodeForAccNameSuffix.includes(contextTag.toUpperCase())) {
      preview = `${typeTag}-${contextTag}-${labelValue}-${accSuffix}${envTag}`.toLocaleUpperCase();
    }
    else {
      preview = `${typeTag}-${contextTag}-${labelValue}${envTag}`.toLocaleUpperCase();
    }

    const labelRegex = new RegExp(`^${acc.policy.label.pattern}$`);
    const hasCharError = !labelRegex.test(labelValue);

    const tooLong = preview.length > acc.policy.maxNameLength;
    const tooShort = labelValue.length < 3;

    let message = null;
    if (tooShort) {
      message = 'CREATE_ACCOUNT.WARN.TOO_SHORT';
    } else if (tooLong) {
      message = 'CREATE_ACCOUNT.WARN.TOO_LONG';
    } else if (hasCharError) {
      message = 'CREATE_ACCOUNT.WARN.ILLEGAL_CHARS';
    }

    return {
      preview,
      message,
      valid: !hasCharError && !tooLong && !tooShort
    };
  }
);

//#region visible fields



export const getCreateAccountVisibleFields = createSelector(
  getCreateAccFormValues, getCreateAccDomainInput, getIdentityID,
  (state: ICreateAccount[], domain, userId, id: number = 0) => {
    const acc = state[id];
    if (!acc) {
      return {
        contextCode: false,
        type: false,
        environment: false,
        directory: false,
        domain: false,
        machineName: false,
        labelPrefix: false,
        labelPreview: false,
        owner: false,
        deputies: false,
      };
    }
    const isDomainValid = domain[id].valid;
    const endUser = acc.owner.value && acc.type.value === "TECHNICAL" ? acc.owner.value.length > 0 : 0;
    return {
      contextCode: true,
      type: Boolean(acc.contextCode.value),
      environment: Boolean(acc.type.value),
      directory: Boolean(acc.environment.value),
      domain: Boolean(acc.directory.value),

      machineName: acc.policyLoaded ? isDomainValid && policyFiltersmatching(acc.policy.computer.map(f => {
        const key = Object.keys(f)[0];
        return { accProp: key, accValue: f[key] };
      }), acc) : false,

      labelPrefix: acc.policyLoaded && acc.type.value === "TECHNICAL" ? (isDomainValid && endUser) && policyFiltersmatching(acc.policy.text.map(f => {
        const key = Object.keys(f)[0];
        return { accProp: key, accValue: f[key] };
      }), acc) : acc.policyLoaded ? isDomainValid && policyFiltersmatching(acc.policy.text.map(f => {
        const key = Object.keys(f)[0];
        return { accProp: key, accValue: f[key] };
      }), acc) : false,

      labelPreview: acc.policyLoaded && acc.type.value === "TECHNICAL" ? (isDomainValid && endUser) && policyFiltersmatching(Object.keys(acc.policy.label.types).map(type => {
        return {
          accProp: 'type',
          accValue: type
        };
      }), acc) : acc.policyLoaded ? isDomainValid && policyFiltersmatching(Object.keys(acc.policy.label.types).map(type => {
        return {
          accProp: 'type',
          accValue: type
        };
      }), acc) : false,

      owner: acc.policyLoaded ? isDomainValid && policyFiltersmatching(acc.policy.login.map(f => {
        const key = Object.keys(f)[0];
        return { accProp: key, accValue: f[key] };
      }), acc) : false,

      deputies: acc.rulesLoaded && isDomainValid,

      justification: isDomainValid && acc.policyLoaded

      // justification: isDomainValid ? (acc.policyLoaded && acc.deputyBlacklistLoaded) ? acc.deputyBlacklist.indexOf(parseInt(userId)) === -1 : true : false
    };
  }
);

const policyFiltersmatching = (filters: { accProp: string, accValue: any }[], acc) => {
  return filters.some(f => {
    return acc[f.accProp].value.indexOf(f.accValue) !== -1;
  });
};
//#endregion

//#endregion

//#region export create account data

/**
 * @param ICreateAccount[]
 * @returns ICreateAccountAPI[]
 */
export const getCreateAccExportValues = createSelector(
  getCreateAccFormValues,
  getCreateAccTypeInput,
  getLabelPreviewInfo,
  getCreateAccEnvironmentInput,
  getCreateAccDirectoryInput,
  getCreateAccDomainInput,
  getIdentity,



  (state, type, label, environmentVar, directory, domain, userIdentity): { valid: boolean, value: CreateAcc_API.IPostBody }[] => {

    return state.map((acc, index) => {
      if (!acc.policyLoaded || !acc.rulesLoaded) {
        return {
          valid: false,
          value: null
        };
      }

      if (!domain || !directory) {
        return {
          valid: false,
          value: null
        };
      }

      const exportMethods = {
        contextType: () => {
          return acc.rules.contextType.name;
        },
        deputies: () => {
          if (!acc.deputies.value) {
            return null;
          }
          if (acc.deputies.value.length === 0) {
            return null;
          }
          return acc.deputies.value.map(dep => ({ login: dep.login }));
        },
        description: () => {
          return acc.justification.value || null;
        },
        uniqueInADandADAM: () => {
          if (acc.uniqueInADandADAM.value !== null) {
            return acc.uniqueInADandADAM.value
          }
          return false;
        },
        end_of_lifecycle_date: () => {
          if (acc.end_of_lifecycle_date.value !== null && acc.type.value === 'TECHNICAL') {
            return acc.end_of_lifecycle_date.value
          }
          return null;
        },
        domain: () => {
          return directory[index].domains.filter(dom => {
            return (domain[index].value.indexOf(dom.name) !== -1) && !dom.ignore;
          }).map(fdom => fdom.name)[0];
        },
        directory: () => {
          // take all possible directories
          return environmentVar[index].directories.filter(dir => {
            // check the directory is in the derived selection and not ignored
            return (directory[index].value.indexOf(dir.type) !== -1) && (!dir.ignore);
          }).map(fd => {
            return {
              domain: exportMethods.domain(),
              project_phase: environmentVar[index].value[0],
              type: fd.type
            };
          })[0];
        },
        endUser: () => {
          if (!acc.owner.value) {
            return null;
          }
          return acc.owner.value.map(eu => {
            return {
              login: eu.login,
            };
          })[0];

        },
        label: () => {
          switch (acc.policy.label.types[exportMethods.type()]) {
            case 'text':
              const contextTag = acc.contextCode.value.code;
              if (acc.type.value === 'TECHNICAL' && !environment.exemptedSolutionCodeForAccNameSuffix.includes(contextTag.toUpperCase())) {
                let accountEnduserSuffix = acc.owner.value && acc.owner.value.length > 0 ? acc.owner.value[0].firstname.substring(0, 1) + acc.owner.value[0].lastname.substring(0, 2) : '';
                return label.valid ? acc.labelPrefix.value + "-" + accountEnduserSuffix : null;
              }
              else {
                return label.valid ? acc.labelPrefix.value : null;
              }
              break;
            case 'login':
              return acc.owner.value ? acc.owner.value[0] ? acc.owner.value[0].login : null : null;
              break;
            case 'computer':
              return acc.machineName.value ? acc.machineName.value[0] ? acc.machineName.value[0].name : null : null;
              break;
            default:
              console.error(`${exportMethods.type()} is not a valid policy label type key`);
          }
        },
        solution: () => {
          const { code } = acc.contextCode.value;
          return { code };
        },
        type: () => {
          return type[index].value[0];
        },
        justification: () => {
          return acc.justification.value || null;
        }
      };

      const requiredFields = {
        solution: true,
        context_type: true,
        type: true,
        description: true,
        environment: true,
        directory: true,
        domain: true,
        machineName: policyFiltersmatching(acc.policy.computer.map(f => {
          const key = Object.keys(f)[0];
          return { accProp: key, accValue: f[key] };
        }), acc),
        label: true,
        end_user: policyFiltersmatching(acc.policy.login.map(f => {
          const key = Object.keys(f)[0];
          return { accProp: key, accValue: f[key] };
        }), acc),
        deputies: acc.rules.deputyRequired,
        end_of_lifecycle_date: acc.type.value === 'TECHNICAL',
        justification: acc.deputyBlacklist.indexOf(parseInt(userIdentity.id)) === -1
      };

      const populatedFields: CreateAcc_API.IPostBody = {
        context_type: exportMethods.contextType(),
        deputies: exportMethods.deputies(),
        description: exportMethods.description(),
        end_user: exportMethods.endUser(),
        label: exportMethods.label(),
        solution: exportMethods.solution(),
        type: exportMethods.type(),
        directory: exportMethods.directory(),
        unique_in_ad_and_adam: exportMethods.uniqueInADandADAM(),
        end_of_lifecycle_date: exportMethods.end_of_lifecycle_date() ? exportMethods.end_of_lifecycle_date().toISOString() : null,
        justification: exportMethods.justification()
      };

      const validAcc = (
        (Boolean(populatedFields.deputies) || !requiredFields.deputies) &&
        (Boolean(populatedFields.end_user) || !requiredFields.end_user) &&
        (Boolean(populatedFields.label) || !requiredFields.label) &&
        Boolean(populatedFields.directory) &&
        Boolean(populatedFields.directory.domain) &&
        (Boolean(populatedFields.justification) || !requiredFields.justification) &&
        (Boolean(populatedFields.end_of_lifecycle_date) || !requiredFields.end_of_lifecycle_date) &&
        Boolean(populatedFields)
      );

      return { valid: validAcc, value: populatedFields };
    });
  }
);

export const isMultiCreateAccFormComplete = createSelector(
  getCreateAccExportValues,
  (exportState): boolean => {
    return exportState.every(acc => acc.valid);
  }
);

export const isSingleCreateAccFormComplete = createSelector(
  getCreateAccExportValues,
  (exportState): boolean => {
    return exportState[0].valid;
  }
);

export const isCreateAccFormSending = createSelector(
  getCreateAccountFormState,
  (state: ICreateAccountFormState): boolean => state.modal.loading
);

//#endregion


//#region MultiAccount

export const getMultiAccListEntities = createSelector(
  getMultiAccountState, getIdentity,
  (state, identity) => adaptor.map(entity => {

    const justificationRequired = entity.blacklistedDeputies.indexOf(parseInt(identity.id)) === -1

    const select_valid = (Boolean(entity.computer) && Boolean(entity.domain) && (!justificationRequired || Boolean(entity.justification.length > 0)));
    const select_deputyOptions = state.options.deputies.index === entity.id ? state.options.deputies.options : [];
    const select_computerOptions = state.options.computers.index === entity.id ? state.options.computers.options : [];
    const select_label = (state.solution && entity.computer) ? `AL-${state.solution.code}-${entity.computer.name.slice(3, entity.computer.name.length)}` : '';
    return {
      ...entity,
      select_deputyOptions,
      select_computerOptions,
      select_label,
      select_valid
    };
  }, state).entities
);

export const getMultiJustificationModal = createSelector(
  getMultiAccountState,
  (state) => state.justificationModal
);

export const getMultiAccListIds = createSelector(
  getMultiAccountState,
  (state) => state.ids
);

export const getMultiAccSolution = createSelector(
  getMultiAccountState,
  (state) => state.solution
);

export const getMultiAccPolicy = createSelector(
  getMultiAccountState,
  (state) => state.policy
);

export const getMultiAccRules = createSelector(
  getMultiAccountState,
  (state) => state.rules
);

export const getMultiAccDomainOptions = createSelector(
  getMultiAccountState,
  (state) => {
    if (!state.rules) {
      return [];
    }
    const firstAlAcc = state.rules.contextType.accountTypes.filter(at => at.name === 'AUTOLOGON')[0];
    if (!firstAlAcc) {
      console.error('no AUTOLOGON account types found in solution rules');
      return [];
    }
    const firstAlProd = firstAlAcc.environments.filter(env => env.name === 'PROD')[0];
    if (!firstAlProd) {
      console.error('no Production environments found in solution rules');
      return [];
    }
    const ADDomainType = firstAlProd.directories.filter(dir => dir.type === 'ACDS-AD')[0];
    if (!ADDomainType) {
      console.error('no AD domain directory found in solution rules');
      return [];
    }
    return ADDomainType.domains.filter(dom => dom.name);
  }
);

export const getMultiSolutionOptions = createSelector(
  getMultiAccountState,
  (state) => state.options.solutions
);
export const getMultiComputerOptions = createSelector(
  getMultiAccountState,
  (state) => state.options.computers
);
export const getMultiDeputyOptions = createSelector(
  getMultiAccountState,
  (state) => state.options.deputies
);

export const getMultiValidStatus = createSelector(
  getMultiAccListEntities,
  (state) => {
    return Object.keys(state).every(key => state[key].select_valid);
  }
);

export const getMultiAccountModal = createSelector(
  getMultiAccountState, (state) => {
    return state.modal;
  }
);

export const getMultiExportValues = createSelector(
  getMultiAccountState,
  (state): CreateAcc_API.IPostBody[] => {
    return Object.keys(state.entities).map(key => {
      const obj = state.entities[key];
      return {
        context_type: state.solution ? state.solution.type : null,
        deputies: obj.deputies.map(dep => {
          return {
            login: dep.login
          };
        }),
        description: obj.justification,
        directory: {
          domain: obj.domain ? obj.domain.name : null,
          project_phase: 'PROD',
          type: 'ACDS-AD' as TAccountDirectory
        },
        end_of_lifecycle_date: 'NA',
        unique_in_ad_and_adam: false,
        end_user: null,
        label: obj.computer ? obj.computer.name : null,
        solution: {
          code: state.solution ? state.solution.code : null,
        },
        type: 'AUTOLOGON' as TAccountType,
        justification: obj.justification,
      };
    });
  }
);
//#endregion
