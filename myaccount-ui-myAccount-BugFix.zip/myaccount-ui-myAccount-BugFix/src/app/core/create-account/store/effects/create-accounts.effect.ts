import { IAccCreationRulesApiElem, IAccCreationPolicyApiElem } from './../../../../shared/interfaces/admin/create-account/create-account-rules-api';
import { IResStatus } from './../../../../shared/interfaces/shared/api/status';
import { REQUEST_ACC_CREATION_POLICY, RequestAccCreationPolicy, RequestAccCreationPolicySuccess, RequestAccCreationPolicyFailed, SEARCH_MACHINE_NAME, SearchMachineName, RequestDeputyBlacklist, REQUEST_DEPUTY_BLACKLIST, RequestDeputyBlacklistSuccess } from './../actions/create-account.action';
import { RECEIVE_API_ERROR } from './../../../../shared/store/actions/base.actions';
import { Injectable } from '@angular/core';
import { Effect, Actions, ofType } from '@ngrx/effects';
import { switchMap, map, filter, withLatestFrom, mergeMap, tap, catchError } from 'rxjs/operators';
import {
  MAKE_SELECTION,
  RefreshCreateAccountOptions,
  SEARCH_CONTEXT_TERM,
  REQUEST_ACC_CREATION_RULES,
  RequestAccCreationRulesFailed,
  RequestAccCreationRulesSuccess,
  SelectCreateAccOption,
  SearchContextTerm,
  RequestAccCreationRules,
  SEARCH_OWNER_TERM,
  SearchOwnerTerm,
  SEARCH_DEPUTY_TERM,
  SearchDeputyTerm,
  CREATE_ACCOUNTS,
  CreateAccountsFail,
  CreateAccountsSuccess,
  CREATE_ACCOUNTS_FAIL,
  CREATE_ACCOUNTS_SUCCESS,
  UpdateLabelPreview,
  ClearCreateAccForm,
} from '../actions';
import { Store, select } from '@ngrx/store';
import { ICreateAccountState } from '../reducers';

import { CreateAccountService } from '../../create-accounts.service';
import { createAccConfig } from '../../create-account.config';
import { IAccCreationRulesAPI, IAccCreationPolicyAPI } from '../../../../shared/interfaces/admin/create-account/create-account-rules-api';
import { getCreateAccFormValues, getCreateAccExportValues, getCreateAccountFormState, getCreateAccountVisibleFields, getCreateAccDomainInput } from '../selectors';
import { NoAction } from '../../../accounts/store';
import { NotificationService } from '@progress/kendo-angular-notification';
import { combineLatest, of } from 'rxjs';
import { getIdentity } from 'src/app/shared/store/selectors';
import { IAccCreationRules, IAccCreationPolicy, TAccountType, TAccountEnvironment, TAccountDirectory, TAccountDomains } from 'src/app/shared/interfaces/admin/create-account/create-accounts-state';

@Injectable()
export class AccountsStatsEffects {
  constructor(
    private actions$: Actions,
    private store: Store<ICreateAccountState>,
    private createService: CreateAccountService,
    private notification: NotificationService
  ) { }


  //#region request Creation Rules

  @Effect()
  public requestCreationRules$ = this.actions$.pipe(ofType(REQUEST_ACC_CREATION_RULES)).pipe(
    switchMap((action: any) => {
      return this.createService.getRules(action.payload.accCode, action.payload.contextType).pipe(
        mergeMap(rules => {
          const ret = [];
          if (rules.status.error) {
            ret.push(new RequestAccCreationRulesFailed(rules.status));
          } else {

            ret.push(new RequestAccCreationRulesSuccess({ rules: this.formatCreateRules(rules.data), index: action.payload.accIndex }));
          }
          return ret;
        })
      );
    })
  );
  //#endregion

  //#region Request Policy
  @Effect()
  public requestPolicy$ = this.actions$
    .pipe(
      ofType(REQUEST_ACC_CREATION_POLICY),
    )
    .pipe(
      switchMap((action: RequestAccCreationPolicy) => {
        return this.createService.getDomainID(action.payload.domain).pipe(
          map(list => list.data[0].id),
          switchMap(id => {
            return this.createService.getPolicy(id).pipe(
              map(policy => {
                if (policy.status.error) {
                  return new RequestAccCreationPolicyFailed({ index: action.payload.index, status: policy.status });
                } else {
                  return new RequestAccCreationPolicySuccess({ policy: this.formatPolicy(policy.data), index: action.payload.index });
                }
              }),
              catchError(e => {
                return [new RequestAccCreationPolicyFailed({ index: action.payload.index, status: e })];
              })
            );
          }),
          catchError(e => {
            // Failed to get domain ID of selected id
            return [new RequestAccCreationPolicyFailed({ index: action.payload.index, status: e })];
          })
        );
      })
    );
  //#endregion

  //#region API Search Context
  @Effect()
  public searchContext$ = this.actions$
    .pipe(
      ofType(SEARCH_CONTEXT_TERM),
      filter((action: SearchContextTerm) => action.payload.term.length >= createAccConfig.contextSearchMinChars)
    )
    .pipe(
      switchMap((action: SearchContextTerm) => {
        return this.createService.getContextSearchList(action.payload.term).pipe(
          map((res) => {
            return new RefreshCreateAccountOptions({
              index: action.payload.index,
              field: 'contextCode',
              value: res.data,
            });
          }),
        );
      })
    );

  //#endregion

  //#region API Search Owner
  @Effect()
  public searchOwner$ = this.actions$
    .pipe(
      ofType(SEARCH_OWNER_TERM),
      filter((action: SearchOwnerTerm) => action.payload.term.length >= createAccConfig.contextSearchMinChars)
    )
    .pipe(
      switchMap((action: SearchOwnerTerm) => {
        return this.createService.getOwnerSearchList(action.payload.term).pipe(
          map((res) => {
            return new RefreshCreateAccountOptions({
              index: action.payload.index,
              field: 'owner',
              value: res.data,
            });
          }),
        );
      })
    );
  //#endregion

  //#region API Search Deputy Blacklist
  @Effect()
  public requestDeputyBlacklist$ = this.actions$
    .pipe(
      ofType(REQUEST_DEPUTY_BLACKLIST),
      switchMap((action: { payload: { index: number; domain: string, context: number } }) => {
        return this.createService.getDeputityBlacklistList(action.payload.context, action.payload.domain).pipe(
          map(res => {
            if (res.status.error === false) {
              const deputies = res.data ? res.data.identities_delegate ? res.data.identities_delegate.map(D => D.identity.id) : [] : [];
              return new RequestDeputyBlacklistSuccess({ index: action.payload.index, deputies });
            }
          })
        );
      })
    );
  //#endregion

  //#region API Search Deputies
  @Effect()
  public searchDeputies$ = this.actions$
    .pipe(
      ofType(SEARCH_DEPUTY_TERM),
      filter((action: SearchDeputyTerm) => action.payload.term.length >= createAccConfig.contextSearchMinChars)
    )
    .pipe(
      switchMap((action) => {
        return this.createService.getDeputitySearchList(action.payload.term).pipe(
          map((res) => {

            return new RefreshCreateAccountOptions({
              index: action.payload.index,
              field: 'deputies',
              value: res.data,
            });
          }),
        );
      })
    );
  //#endregion

  //#region API Search Machine Name
  @Effect()
  public searchMachineName$ = this.actions$
    .pipe(
      ofType(SEARCH_MACHINE_NAME)
    )
    .pipe(
      switchMap(action => {
        const a = action as SearchMachineName;
        return this.createService.getMachineNameSearchList(a.payload.term).pipe(
          map((res) => {
            return new RefreshCreateAccountOptions({
              index: a.payload.index,
              field: 'machineName',
              value: res.data.map(api => {
                return {
                  id: api.id,
                  name: api.name,
                  hasAccount: api.has_account
                };
              }),
            });
          }),
        );
      })
    );
  //#endregion

  //#region Select Context Code
  @Effect()
  public selectContext$ = this.actions$
    .pipe(
      ofType(MAKE_SELECTION),
      filter((action: SelectCreateAccOption) => action.payload.field === 'contextCode')
    )
    .pipe(
      mergeMap((action: SelectCreateAccOption) => {
        const res = [];
        if (action.payload.value) {
          res.push(new RequestAccCreationRules({ accCode: action.payload.value.code, contextType: action.payload.value.type, accIndex: action.payload.index }));
        }
        const clearFields = ['type', 'environment', 'uniqueInADandADAM', 'directory', 'domain', 'labelPrefix', 'owner', 'deputies', 'machineName'];
        res.push(
          new ClearCreateAccForm({
            index: [action.payload.index],
            valueFields: clearFields,
            optionsFields: clearFields,
          })
        );
        return res;
      })
    );

  /**
   * if only one domain option exists it is automatically considered selected,
   * in this case rules request action is manually dispached by this effect
   */
  @Effect()
  public AutoselectContext$ = this.actions$
    .pipe(
      ofType(MAKE_SELECTION),
      withLatestFrom(this.store.select(getCreateAccDomainInput), this.store.select(getCreateAccFormValues)),
      filter(([action, domainInput, form]) => (domainInput[0].valid) && (form[0].domain.value === null) && !(form[0].policyLoaded || form[0].policyLoading))
    )
    .pipe(
      map(([action, domainInput, form]) => {
        return new RequestAccCreationPolicy({ index: (action as SelectCreateAccOption).payload.index, domain: domainInput[0].value[0] })
      })
    );
  //#endregion

  //#region Select Context DOMAIN
  @Effect()
  public selectDomain$ = this.actions$
    .pipe(
      ofType(MAKE_SELECTION),
      filter((action: SelectCreateAccOption) => action.payload.field === 'domain'),
      withLatestFrom(this.store.pipe(select(getCreateAccountFormState)))
    )
    .pipe(
      mergeMap(([action, form]) => {
        return [
          new RequestAccCreationPolicy({ index: action.payload.index, domain: action.payload.value }),
          new RequestDeputyBlacklist({ index: action.payload.index, domain: action.payload.value, context: form.editingAccList[action.payload.index].contextCode.value.id })
        ];
      })
    );
  //#endregion

  //#region selection Butttons effects

  @Effect()
  public clearInputOnPastSelectionChange$ = this.actions$
    .pipe(
      ofType(MAKE_SELECTION),
      filter((action: SelectCreateAccOption) => {
        const field = action.payload.field;
        const pass = (field === 'type' || field === 'environment' || field === 'directory' || field === 'domain' || field === 'uniqueInADandADAM') && action.payload.value !== null;
        return pass;
      }),
      withLatestFrom(this.store.pipe(select(getCreateAccFormValues)))
    )
    .pipe(
      mergeMap(([action, formVal]) => {
        const res = [];
        const { field, index } = action.payload;
        switch (field) {
          case 'type':
            res.push(
              new ClearCreateAccForm({
                index: [index],
                valueFields: ['environment', 'uniqueInADandADAM', 'directory', 'domain', 'owner', 'deputies', 'machineName']
              })
            );
            break;
          case 'environment':
            if (formVal[index].type.value === 'AUTOLOGON') { // TEMP OVERRIDE
              break;
            }
            res.push(
              new ClearCreateAccForm({
                index: [action.payload.index],
                valueFields: ['uniqueInADandADAM', 'directory', 'domain', 'owner', 'deputies', 'machineName']
              })
            );
            break;
          case 'directory':
            res.push(
              new ClearCreateAccForm({
                index: [action.payload.index],
                valueFields: ['domain', 'owner', 'deputies', 'machineName']
              })
            );
            break;
          case 'uniqueInADandADAM':
            res.push(
              new ClearCreateAccForm({
                index: [action.payload.index],
                valueFields: ['domain', 'owner', 'deputies', 'machineName']
              })
            );
            break;
          case 'domain':
            break;
        }
        return res;
      })
    );

  //#endregion

  //#region create accounts
  @Effect()
  public createAccounts$ = this.actions$
    .pipe(
      ofType(CREATE_ACCOUNTS),
      withLatestFrom(this.store.pipe(select(getCreateAccExportValues)))
    )
    .pipe(
      switchMap(([action, accounts]) => {
        return this.createService.createAccount(accounts[0].value).pipe(
          map((res) => {

            if (res.status ? res.status.type === 'SUCCESS' : false) {
              return new CreateAccountsSuccess(res.status);
            } else {
              return new CreateAccountsFail(res.status);
            }
          }),
          catchError((error) => {
            if (error.body) {
              return of(new CreateAccountsFail(error.body.status));
            }
            return of(new CreateAccountsFail(error));
          })
        );
      })
    );

  @Effect()
  public createAccountsSuccess$ = this.actions$
    .pipe(
      ofType(CREATE_ACCOUNTS_SUCCESS),
      map(() => {
        return new ClearCreateAccForm({});
      })
    );

  //#endregion

  //#region FORMATTERS

  private formatCreateRules = (api: IAccCreationRulesApiElem): IAccCreationRules => {
    return {
      contextType: {
        name: api.context_type.name,
        accountTypes: api.context_type.account_types.map(at => {
          return {
            name: at.name as TAccountType,
            environments: at.project_phases.map(env => {
              return {
                name: env.name as TAccountEnvironment,
                directories: env.directories.map(dir => {
                  return {
                    forceSelected: dir.force_selected,
                    ignore: dir.ignore,
                    type: dir.type as TAccountDirectory,
                    domains: dir.domains.map(dom => {
                      return {
                        forceSelected: dom.force_selected,
                        ignore: dom.ignore,
                        name: dom.name as TAccountDomains
                      };
                    })
                  };
                })
              };
            })
          };
        })
      },
      deputyRequired: api.deputy_required,
      solution: api.solution
    };
  }
  private formatPolicy = (apiData: IAccCreationPolicyApiElem): IAccCreationPolicy => {
    const policy: IAccCreationPolicy = {
      ...apiData,
      accountType: apiData.account_type,
      contextCode: apiData.context_code,
      endUser: apiData.end_user || [],
      login: apiData.login || [],
      text: apiData.text || [],
      computer: apiData.computer || [],
      maxDescriptionLength: apiData.max_description_length,
      maxNameLength: apiData.max_name_length,
      environment: { ...apiData.project_phase },
    };

    // TEMP change TA label content ****

    policy.label.types.TECHNICAL = 'text';
    policy.text.push({ type: 'TECHNICAL' });
    policy.login.push({ type: 'TECHNICAL' });


    return policy;
  }

  //#endregion
}
