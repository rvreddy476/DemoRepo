import { Injectable } from '@angular/core';
import { Effect, ofType, Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { ICreateAccountState } from '../reducers';
import { CreateAccountService } from '../../create-accounts.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { switchMap, map, withLatestFrom, tap, mergeMap } from 'rxjs/operators';
import { REQUEST_AUTOLOGON_SOLUTIONS, RequestAutoLogonSolutionsSuccess, RequestAutoLogonSolutionsFail, SELECT_AUTOLOGON_SOLUTION, RequestAutoLogonRules, REQUEST_AUTOLOGON_RULES, RequestAutoLogonRulesSuccess, REQUEST_AUTOLOGON_COMPUTERS, RequestAutoLogonComputersFail, RequestAutoLogonComputersSuccess, REQUEST_AUTOLOGON_DEPUTIES, RequestAutoLogonDeputiesFail, RequestAutoLogonDeputiesSuccess, CREATE_AUTOLOGON_ACCOUNTS, CreateAutoLogonAccountsSuccess, SELECT_AUTOLOGON_DOMAIN, RequestAutoLogonDeputyBlacklist, REQUEST_AUTOLOGON_DEPUTY_BLACKLIST, RequestAutoLogonDeputyBlacklistFailed, RequestAutoLogonDeputyBlacklistSuccess } from '../actions';
import { API } from 'src/app/shared/interfaces/shared/api';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { TAccountType, TAccountEnvironment, TAccountDirectory, TAccountDomains } from 'src/app/shared/interfaces/admin/create-account/create-accounts-state';
import { getMultiExportValues, getMultiAccSolution } from '../selectors';

@Injectable()
export class CreateMultiAccountEffects {
  constructor(
    private actions$: Actions,
    private store: Store<ICreateAccountState>,
    private createService: CreateAccountService,
    private notification: NotificationService
  ) { }


  //#region Solution

  @Effect()
  public requestAutoLogonSolutions = this.actions$.pipe(ofType(REQUEST_AUTOLOGON_SOLUTIONS)).pipe(
    switchMap((action: any) => {
      return this.createService.getContextSearchList(action.payload, true);
    }),
    map(solutions => {
      if (solutions.status.error !== false) {
        return new RequestAutoLogonSolutionsFail(solutions.status);
      } else {
        const formattedSolutions = solutions.data.map(sol => formatSolution(sol));
        return new RequestAutoLogonSolutionsSuccess(formattedSolutions);
      }
    })
  );

  //#endregion

  //#region Rules

  @Effect()
  public triggerRulesRequest = this.actions$.pipe(ofType(SELECT_AUTOLOGON_SOLUTION)).pipe(
    map((action: { payload: CreateAcc.Common.Solution }) => {
      return new RequestAutoLogonRules(action.payload);
    })
  );

  @Effect()
  public requestAutoLogonRules = this.actions$.pipe(ofType(REQUEST_AUTOLOGON_RULES)).pipe(
    switchMap((action: { payload: CreateAcc.Common.Solution }) => {
      return this.createService.getRules(action.payload.code, action.payload.type);
    }),
    map(rules => {
      if (rules.status.error !== false) {
        return new RequestAutoLogonSolutionsFail(rules.status);
      } else {
        const formattedRules = formatCreateRules(rules.data);
        return new RequestAutoLogonRulesSuccess(formattedRules);
      }
    })
  );

  //#endregion


  //#region Computers

  @Effect()
  public loadRules = this.actions$.pipe(
    ofType(REQUEST_AUTOLOGON_COMPUTERS),
    switchMap((action: { payload: { term: string, index: number } }) => this.createService.getMachineNameSearchList(action.payload.term).pipe(
      map((computers: API.Response<CreateAcc_API.Get.MachineName[]>) => {
        if (computers.status.error !== false) {
          return new RequestAutoLogonComputersFail(computers.status);
        } else {
          const formattedMachineNames = computers.data.map(machine => formatMachineName(machine));
          return new RequestAutoLogonComputersSuccess({ options: formattedMachineNames, index: action.payload.index });
        }
      })
    ))
  );

  //#endregion

  //#region deputies

  @Effect()
  public triggerRequestDeputyBlacklist$ = this.actions$
    .pipe(
      ofType(SELECT_AUTOLOGON_DOMAIN),
      map(a => a as { payload: { domain: CreateAcc.Common.Domain, index: number } }),
      withLatestFrom(this.store.pipe(select(getMultiAccSolution)))
    )
    .pipe(
      mergeMap(([action, solution]) => {
        return [
          // new RequestAccCreationPolicy({ index: action.payload.index, domain: action.payload.value }),
          new RequestAutoLogonDeputyBlacklist({ index: action.payload.index, domain: action.payload.domain.name, context: solution.id })
        ];
      })
    );
  //#endregion

  @Effect()
  public requestAutoLogonDeputyBlacklist = this.actions$.pipe(
    ofType(REQUEST_AUTOLOGON_DEPUTY_BLACKLIST)).pipe(
      map(a => a as { payload: { index: number, domain: string, context: number } }),
      switchMap((action) => {
        return this.createService.getDeputityBlacklistList(action.payload.context, action.payload.domain).pipe(
          map(blacklist => {
            if (blacklist.status.error !== false) {
              return new RequestAutoLogonDeputyBlacklistFailed({ index: action.payload.index, status: blacklist.status });
            } else {
              const deputyIds = blacklist.data.identities_delegate.map(dep => dep.identity.id);
              return new RequestAutoLogonDeputyBlacklistSuccess({ deputies: deputyIds, index: action.payload.index });
            }
          })
        );
      }),
    );


  @Effect()
  public requestAutoLogonDeputies = this.actions$.pipe(ofType(REQUEST_AUTOLOGON_DEPUTIES)).pipe(
    switchMap((action: { payload: { term: string, index: number } }) => {
      return this.createService.getDeputitySearchList(action.payload.term).pipe(
        map(deputies => {
          if (deputies.status.error !== false) {
            return new RequestAutoLogonDeputiesFail(deputies.status);
          } else {
            const formattedDeputies = deputies.data.map(dep => formatDeputy(dep));
            return new RequestAutoLogonDeputiesSuccess({ options: formattedDeputies, index: action.payload.index });
          }
        })
      );
    }),
  );

  //#endregion

  //#region create accounts

  @Effect()
  public createAutoLogonAccounts = this.actions$.pipe(
    ofType(CREATE_AUTOLOGON_ACCOUNTS),
    withLatestFrom(this.store.pipe(select(getMultiExportValues))),
    switchMap(([action, exp]) => {
      return this.createService.createBulkAccounts(exp).pipe(
        map(res => {
          return new CreateAutoLogonAccountsSuccess(res.data);
        })
      );
    }),
  );

  //#endregion


}

const formatSolution = (api: CreateAcc_API.Get.Solution): CreateAcc.Common.Solution => {
  return {
    code: api.code,
    name: api.name,
    id: api.id,
    type: api.type
  };
};

const formatCreateRules = (api: CreateAcc_API.Get.Rules): CreateAcc.Common.Rules => {
  return {
    contextType: {
      name: api.context_type.name,
      accountTypes: api.context_type.account_types.map(at => {
        return {
          name: at.name as TAccountType,
          environments: at.project_phases.map(env => {
            return {
              name: env.name as TAccountEnvironment,
              directories: env.directories.map(dir => {
                return {
                  forceSelected: dir.force_selected,
                  ignore: dir.ignore,
                  type: dir.type as TAccountDirectory,
                  domains: dir.domains.map(dom => {
                    return {
                      forceSelected: dom.force_selected,
                      ignore: dom.ignore,
                      name: dom.name as TAccountDomains
                    };
                  })
                };
              })
            };
          })
        };
      })
    },
    deputyRequired: api.deputy_required,
    solution: api.solution
  };
};

const formatMachineName = (api: CreateAcc_API.Get.MachineName): CreateAcc.Common.MachineName => {
  return {
    hasAccount: api.has_account,
    id: api.id,
    name: api.name
  };
};

const formatDeputy = (api: CreateAcc_API.Get.Identity): CreateAcc.Common.Deputy => {
  return {
    login: api.login,
    id: api.id,
    displayName: api.displayname
  };
};
