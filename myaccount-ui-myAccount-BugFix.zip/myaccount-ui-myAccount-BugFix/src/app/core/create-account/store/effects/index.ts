import { AccountsStatsEffects } from './create-accounts.effect';
import { CreateMultiAccountEffects } from './multi-account.effects';

export const effects: any[] = [AccountsStatsEffects, CreateMultiAccountEffects];

export * from './create-accounts.effect';
export * from './multi-account.effects';
