import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { select, Store } from '@ngrx/store';
import { IIdentity } from '../../shared/interfaces/identity/identity';
import { getIdentity } from '../../shared/store/selectors';
import { IBaseState } from '../../shared/interfaces/base-state';
import { Subscription, combineLatest } from 'rxjs';
import { ClearCreateAccForm, ClearAutoLogonTable } from './store/actions';
import { getMultiJustificationModal, getJustificationModal } from './store/selectors';
import { single, map } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-create-account',
  templateUrl: './create-account.component.html',
  styles: [
    `:host{
        flex-grow:1;
        display:flex;
    }`
  ]
})
export class CreateAccountComponent implements OnInit, OnDestroy {
  public identity: IIdentity;
  public identity$: Subscription;

  constructor(private translate: TranslateService, private store: Store<IBaseState>) {}

  public $justificationModalSingle = this.store.pipe(select(getJustificationModal))
  public $justificationModalMulti = this.store.pipe(select(getMultiJustificationModal))

  public $justification = combineLatest(this.$justificationModalSingle,this.$justificationModalMulti).pipe(
    map(([single,multi]) => {
      if(multi.account){
        const multiAcc = {
          id: multi.account.id,
          value: multi.account.justification
        }
        return multiAcc
      }else if(single.account){
        const singAcc = {
          id:null,
          value: single.account.justification ? single.account.justification.value : ''
        }
        return singAcc
      }else{
        return null
      }
    })
  )

  public ngOnInit() {}

  public ngOnDestroy() {
    if (this.identity$) {
      this.identity$.unsubscribe();
    }
    this.store.dispatch(new ClearCreateAccForm({}))
    this.store.dispatch(new ClearAutoLogonTable());
  }

  public getState(outlet) {
    return outlet.activatedRouteData.state;
  }
}
