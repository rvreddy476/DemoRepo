import { CreateAccountComponent } from './create-account.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateAccountSingleComponent } from './components/create-account-single/create-account-single.component';
import { CreateAccountMultiComponent } from './components/create-account-multi/create-account-multi.component';
import { CreateAccountRoutingModule } from './create-account-routing.module';
import { CreateAccountBaseComponent } from './components/create-account-base/create-account-base.component';
import { KendoModule } from '../../modules/kendo.module';
import { SharedModule } from '../../modules/shared.module';
import { StoreModule } from '@ngrx/store';
import { reducers } from './store';
import { EffectsModule } from '@ngrx/effects';
import { effects } from './store/effects';

import { CreateAccountService } from './create-accounts.service';
import { CreateAccountResponseModalComponent } from './components/create-account-response-modal/create-account-response-modal.component';
import { SharedTranslateModule } from 'src/app/modules/shared-translate.module';
import { CreateMultiAccountResponseModalComponent } from './components/create-multi-account-response-modal/create-multi-account-response-modal.component';
import { CreateAccountJustificationModalComponent } from './components/create-account-justification-modal/create-account-justification-modal.component';

@NgModule({
  providers: [CreateAccountService],
  imports: [
    // CommonModule,
    CreateAccountRoutingModule,
    // KendoModule,
    SharedModule,
    StoreModule.forFeature('createAccountModule', reducers),
    EffectsModule.forFeature(effects),
    SharedTranslateModule
  ],
  declarations: [
    CreateAccountComponent,
    CreateAccountBaseComponent,
    CreateAccountSingleComponent,
    CreateAccountMultiComponent,
    CreateAccountResponseModalComponent,
    CreateMultiAccountResponseModalComponent,
    CreateAccountJustificationModalComponent,
  ],
})
export class CreateAccountModule {}
