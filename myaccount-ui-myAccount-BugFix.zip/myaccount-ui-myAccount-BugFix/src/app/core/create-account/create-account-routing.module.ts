import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountBaseComponent } from './components/create-account-base/create-account-base.component';
import { CreateAccountComponent } from './create-account.component';
import { AccessAutoLogin } from 'src/app/shared/route-guards/access-autologon-mgmt';

export const CREATE_ROUTES: Routes = [
  {
    path: '',
    component: CreateAccountComponent,
    children: [
      {
        path: 'one',
        component: CreateAccountBaseComponent,
      },
      {
        path: 'multi',
        component: CreateAccountBaseComponent,
        canActivate: [AccessAutoLogin]
      },
      {
        path: '**',
        redirectTo: 'one',
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(CREATE_ROUTES)
  ],
  providers: [
    AccessAutoLogin
  ],
  exports: [RouterModule],
})
export class CreateAccountRoutingModule {}
