import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ICreateAccount, IAccountField, ICreateAccountActiveFields, TMachineName } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { AccountDivisionEnum } from '../../../../shared/enums';
import { Observable, Subscription } from 'rxjs';
import { pluck, distinctUntilChanged, map, tap } from 'rxjs/operators';
import { ICreateAccountState } from '../../store';
import { Store, select } from '@ngrx/store';
import { getLabelPreviewInfo, getCreateAccountVisibleFields, getCreateAccFormValues, getCreateAccTypeInput, getCreateAccEnvironmentInput, getCreateAccDirectoryInput, getCreateAccDomainInput, getCreateAccExportValues } from '../../store/selectors';
import { ClearCreateAccForm, OpenJustificationModel } from '../../store/actions';
import { IIdentity } from 'src/app/shared/interfaces/identity/identity';

@Component({
  selector: 'app-2f82-create-account-single',
  templateUrl: './create-account-single.component.html',
  styleUrls: ['./create-account-single.component.scss'],
})
export class CreateAccountSingleComponent implements OnInit {
  constructor(private store: Store<ICreateAccountState>) { }

  public contextCode: number;
  private deps: number[];
  private owner: number;

  public $accountData: Observable<ICreateAccount>;

  public $typeInput;
  public $environmentInput;
  public $directoryInput;
  public $domainInput;

  @Output() public makeSelection = new EventEmitter();
  @Output() public searchContext = new EventEmitter();
  @Output() public searchOwner = new EventEmitter();
  @Output() public searchMachineName = new EventEmitter();
  @Output() public searchDeputies = new EventEmitter();
  @Output() public toggleSelection = new EventEmitter();

  public $labelInfo: Observable<{ preview: string, message: string }>;
  public $activeFields: Observable<ICreateAccountActiveFields>;

  public labels = {
    division: {
      [AccountDivisionEnum.Commercial_Aircraft]: 'Commercial Aircraft',
      [AccountDivisionEnum.Defence_and_Space]: 'Defence and Space',
      [AccountDivisionEnum.Helicopters]: 'Helecopters',
    },
  };

  private subs: Subscription[] = [];
  public accountData: ICreateAccount;

  public ngOnInit() {
    this.$labelInfo = this.store.pipe(select(getLabelPreviewInfo));
    this.$activeFields = this.store.pipe(select(getCreateAccountVisibleFields));
    this.$accountData = this.store.pipe(select(getCreateAccFormValues), map(acc => acc[0])).pipe(
      tap(acc => {
        this.contextCode = acc.contextCode ? acc.contextCode.value ? acc.contextCode.value.id : null : null;
        this.deps = acc.deputyBlacklist;
        this.owner = acc.owner.value ? acc.owner.value[0] ? parseInt(acc.owner.value[0].id) : null : null;

      })
    );

    // derived Data
    this.$typeInput = this.store.pipe(select(getCreateAccTypeInput), map(acc => acc[0]));
    this.$environmentInput = this.store.pipe(select(getCreateAccEnvironmentInput), map(acc => acc[0]));
    this.$directoryInput = this.store.pipe(select(getCreateAccDirectoryInput), map(acc => acc[0]));
    this.$domainInput = this.store.pipe(select(getCreateAccDomainInput), map(acc => acc[0]));

  }

  public range = {
    start: new Date(),
    end: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
  };

  public disabledDates = (date: Date): boolean => {
    return date < this.range.start || date > this.range.end;
  }

  public machineDisabled(machine: { dataItem: TMachineName }) {
    return machine.dataItem.hasAccount;
  }

  public pluck(obs: Observable<any>, prop: string | string[]) {
    if (Array.isArray(prop)) {
      return obs.pipe(
        pluck(...prop),
        distinctUntilChanged()
      );
    } else {
      return obs.pipe(
        pluck(prop),
        distinctUntilChanged()
      );
    }
  }

  public disabledDeputy = (backlist: number[]) => (dep) => {
    return (backlist ? backlist.indexOf(dep.dataItem.id) !== -1 : false) || this.owner === dep.dataItem.id;
  }

  public disabledEndUser = (deps) => (owner) => {
    return (deps ? deps.map(d => d.id).indexOf(owner.dataItem.id) !== -1 : false);
  }

  public clearForm() {
    this.store.dispatch(new ClearCreateAccForm({}));
  }

  public selectDropdown(value, field) {
    this.makeSelection.emit({ value, field, index: 0 });
  }

  public toggleSelect(value, field) {
    this.makeSelection.emit({ value, field, index: 0 });
    this.toggleSelection.emit({ value, field, index: 0 });
  }
  public selectButton($event, value, field) {
    $event.preventDefault();
    this.makeSelection.emit({ value, field, index: 0 });
  }
  public searchContextHandler(term) {
    this.searchContext.emit({ term, index: 0 });
  }
  public selectContextHandler(value) {
    this.makeSelection.emit({ value: value[0], field: 'contextCode', index: 0 });
  }

  public searchOwnerHandler(term) {
    this.searchOwner.emit({ term, index: 0 });
  }
  public selectOwnerHandler(value) {
    this.makeSelection.emit({ value, field: 'owner', index: 0 });
  }

  public searchDeputiesHandler(term) {
    this.searchDeputies.emit({ term, index: 0 });
  }
  public selectDeputiesHandler(value) {
    this.makeSelection.emit({ value, field: 'deputies', index: 0 });
  }

  public searchMachineNameHandler(term) {
    this.searchMachineName.emit({ term, index: 0 });
  }
  public selectMachineNameHandler(value) {
    this.makeSelection.emit({ value, field: 'machineName', index: 0 });
  }

  public selectLabel(event) {
    this.makeSelection.emit({ value: event.target.value, field: 'labelPrefix', index: 0 });
  }

  public openJustificationModel() {
    this.store.dispatch(new OpenJustificationModel(0))
  }
  public onEOLdateChange(value) {
    this.makeSelection.emit({ value, field: 'end_of_lifecycle_date', index: 0 });
  }


}
