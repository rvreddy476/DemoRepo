import { Component, Input, ViewChild, ElementRef, AfterContentInit, AfterViewInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { CloseAutoLogonJustificationModal, CloseJustificationModal, SelectCreateAccOption, SelectAutoLogonJustification } from '../../store/actions';
import { ICreateAccount } from 'src/app/shared/interfaces/admin/create-account/create-accounts-state';

@Component({
  selector: 'app-create-account-justification-modal',
  templateUrl: './create-account-justification-modal.component.html',
  styleUrls: ['./create-account-justification-modal.component.scss']
})
export class CreateAccountJustificationModalComponent implements AfterViewInit{
  @ViewChild('justificationTag') private justificationElem: ElementRef;

/**
 * the id of the account to edit.
 * null value for single account
 */
  @Input() public justification:{id:number,value:string}

  ngAfterViewInit(){
    this.justificationElem ? this.justificationElem.nativeElement.focus() : null
  }

  constructor(private store:Store<any>) {
  }

  public closeModal(){
    this.store.dispatch(new CloseAutoLogonJustificationModal())
    this.store.dispatch(new CloseJustificationModal())
  }

  public saveJustification() {
    const justification = this.justificationElem.nativeElement.value;
    if(this.justification.id === null){
      this.store.dispatch(new SelectCreateAccOption({field:'justification', value:justification, index:0}));
    }else{
      this.store.dispatch(new SelectAutoLogonJustification({justification, index:this.justification.id}));
    }
    this.closeModal()
  }

}
