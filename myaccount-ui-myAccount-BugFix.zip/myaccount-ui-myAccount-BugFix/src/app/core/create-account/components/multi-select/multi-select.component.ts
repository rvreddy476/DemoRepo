import { Input, Component, ViewChild, Output, EventEmitter, OnInit, ViewEncapsulation, OnDestroy, OnChanges, AfterContentInit, ContentChild, QueryList, ElementRef, HostListener, AfterViewInit } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-2f82-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MultiSelectComponent implements OnChanges, AfterViewInit, OnDestroy {
  @ViewChild('multiselect') public multiselect: any;

  @ContentChild('OptionTemplate') public optionTemplate: QueryList<ElementRef>;
  @ContentChild('TagTemplate') public tagTemplate: QueryList<ElementRef>;
  @ContentChild('SummaryTagTemplate') public summaryTagTemplate: QueryList<ElementRef>;

  //#region inputs

  @Input()
  public data: any[];
  @Input()
  public value: any;
  @Input()
  public loading: boolean;
  @Input()
  public disabled = false;

  @Input()
  public textField = 'text';
  @Input()
  public valueField = 'value';
  @Input()
  public maxSelection = 1;
  @Input()
  public placeholder = '';
  @Input()
  public tableMode = false; // compress component to render in a table cell


  @Input()
  private showSelectedInList = false;

  @Output()
  public valueChange = new EventEmitter();
  @Output()
  public filterChange = new EventEmitter();

  private subs: Subscription[];
  public focused = false;
  public hideInput = false;
  public popupSettings = {
    animate: true,
    appendTo: 'root',
  };

  public _data = [];
  public _value = [];

  @Input() public itemDisabled: Function = () => false;

  public ngOnChanges(e) {
    if(Object.keys(e)[0] !== 'itemDisabled'){
      this.updateState();
    }
  }

  private updateState() {
    this._data = this.data || [];
    this._value = Array.isArray(this.value) ? this.value : this.value ? [this.value] : [];

    if (this.showSelectedInList) {
      this._data = [...this._value, ...this._data.filter(d => !this.value.some(v => v[this.valueField] === d[this.valueField]))];
    }

    this.hideInput = this.maxSelection <= this._value.length;

    const canOpen = !this.multiselect.isOpen && this._data.length > 0 && this.focused;

    const canClose = this.multiselect.isOpen && (this._data.length === 0 || !this.focused);

    if (canOpen || canClose) {
      this.multiselect.toggle();
    }
  }

  public onClose(e) {
    e.preventDefault();
  }

  public onOpen(e) {
    e.preventDefault();
  }

  public onRemoveTag(e) { }

  public onValueChange(e) {
    this.valueChange.emit(e);
  }

  public onFilterChange(e) {
    this.filterChange.emit(e);
  }

  public ngAfterViewInit() {
    const focus = this.multiselect.onFocus as EventEmitter<any>;
    const blur = this.multiselect.onBlur as EventEmitter<any>;

    this.subs = [
      focus.subscribe(e => {
        this.focused = true;
        this.updateState();
      }),
      blur.subscribe(e => {
        this.focused = false;
        this.updateState();
      })
    ];
  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }
}
