import { Component, Input, Output, EventEmitter, ViewChild, ViewChildren, AfterViewChecked, ViewEncapsulation, OnInit, OnDestroy } from '@angular/core';
import { ICreateAccount } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { combineLatest, of, Subject, BehaviorSubject, Subscription } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { getMultiAccSolution, getMultiSolutionOptions, getMultiComputerOptions, getMultiDeputyOptions, getMultiAccDomainOptions, getMultiAccListEntities, getMultiAccListIds, getMultiValidStatus } from '../../store/selectors';
import { DuplicateCreateAccount, DeleteCreateAccount, RequestAutoLogonSolutions, RequestAutoLogonSolutionsSuccess, SelectAutoLogonSolution, SelectAutoLogonDomain, RequestAutoLogonComputers, RequestAutoLogonComputersSuccess, SelectAutoLogonComputer, RequestAutoLogonDeputies, RequestAutoLogonDeputiesSuccess, SelectAutoLogonDeputy, CreateAutoLogonAccounts, ClearAutoLogonTable, OpenJustificationModel, OpenAutoLogonJustificationModal } from '../../store/actions';
import { MAX_ACCOUNT_SELECTION_LENGTH } from 'src/app/config/parameters';
import { formatDisplayName } from 'src/app/shared/helper-functions';

@Component({
  selector: 'app-2f82-create-account-multi',
  templateUrl: './create-account-multi.component.html',
  styleUrls: ['./create-account-multi.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CreateAccountMultiComponent implements AfterViewChecked, OnInit, OnDestroy {

  constructor(private store: Store<CreateAcc.Multi.State>) { }
  @ViewChild('gridSizer') private gridSizer;
  @ViewChildren('labels') private labels;

  private targetFocusRow: number = null; // if not null, will try to focus on this lable on re-render event.

  public entities$ = this.store.pipe(select(getMultiAccListEntities));
  public ids$ = this.store.pipe(select(getMultiAccListIds));

  public solutionOptions$ = this.store.pipe(select(getMultiSolutionOptions));
  public domainOptions$ = this.store.pipe(select(getMultiAccDomainOptions));

  public allValid$ = this.store.pipe(select(getMultiValidStatus));

  public validateClearFormModalOpen = false;
  private solution$ = new BehaviorSubject(null);
  private requestedSolution = null;

  private subs: Subscription[] = [];

  public gridHeight: number;

  public reachedLimit = false

  public list$ = combineLatest(this.ids$, this.entities$).pipe(
    tap(([ids, entitys]) => {
      this.resetHeight();
      this.reachedLimit = ids.length >= MAX_ACCOUNT_SELECTION_LENGTH
    }),
    map(([ids, entitys]) => {
      return [...ids].map(id => entitys[id]);
    }
    )
  );
  private resetHeight() {
    this.gridHeight = this.gridSizer.nativeElement.clientHeight;
  }

  public ngOnInit() {
    this.store.dispatch(new RequestAutoLogonSolutions(''));
    this.resetHeight();

    this.subs = [
      this.store.pipe(
        select(getMultiAccSolution),
        tap(sol => {
          this.solution$.next(sol);
        })
      ).subscribe()
    ];

  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }

  public validateClearForm(a: boolean) {
    this.validateClearFormModalOpen = false;

    if (a) {
      this.store.dispatch(new ClearAutoLogonTable());
      this.store.dispatch(new SelectAutoLogonSolution(this.requestedSolution));
    } else {
      this.solution$.next({...this.solution$.value});
    }
  }

  public ngAfterViewChecked() {
    if (this.targetFocusRow === null) {
      return;
    }
    if (this.labels.length >= this.targetFocusRow) {
      this.focusLabelOnRow(this.targetFocusRow);
      this.targetFocusRow = null;
    }
  }

  public delete(row) {
    this.store.dispatch(new DeleteCreateAccount(row));
  }

  public KeypressHandler(event, field, index) {
    const shiftEnter = event.code === 'Enter' && !event.shiftKey;
    if (shiftEnter) {
      this.targetFocusRow = index + 1;
      // this.duplicateIndex.emit(index);
    }
  }

  public focusLabelOnRow(row) {
    const index = Math.min(this.labels.length - 1, row);
    const label = this.labels._results[index].nativeElement;
    label.focus();
  }

  public selectContextHandler(value) {

    if (this.solution$.value === null) {
      this.store.dispatch(new SelectAutoLogonSolution(value));
    } else {
      this.requestedSolution = value;
      this.validateClearFormModalOpen = true;
    }
  }

  public selectDomainHandler(value, index) {
    this.store.dispatch(new SelectAutoLogonDomain({ domain: value, index: index }));
  }

  public searchComputerHandler(term, index) {
    if (term.length == 0) {
      this.store.dispatch(new RequestAutoLogonComputersSuccess({ index, options: [] }));
    } else {
      this.store.dispatch(new RequestAutoLogonComputers({ term, index }));
    }

  }

  public selectComputerHandler(computer, index) {
    this.store.dispatch(new SelectAutoLogonComputer({ computer: computer[0], index }));
  }

   public searchDeputiesHandler(term, index) {
    if (term.length == 0) {
      this.store.dispatch(new RequestAutoLogonDeputiesSuccess({ index, options: [] }));
    } else {
      this.store.dispatch(new RequestAutoLogonDeputies({ term, index }));
    }
  }

  public selectDeputiesHandler(deputies, index) {
    this.store.dispatch(new SelectAutoLogonDeputy({ deputies, index }));
  }

  public duplicate(row) {
    this.store.dispatch(new DuplicateCreateAccount(row));
    // this.duplicateIndex.emit(row);
  }

  public machineDisabled = (list: CreateAcc.Multi.IAutoLogonAcc[]) => (machine: {dataItem: CreateAcc.Common.MachineName}) => {
    const machineInList = list.some(m => m.computer ? m.computer.id === machine.dataItem.id : false);
    return machine.dataItem.hasAccount || machineInList;
  }

  public deputyDisabled = (list: number[]) => (deputy: {dataItem: CreateAcc.Common.Deputy}) => {
    return list.indexOf(deputy.dataItem.id) !== -1;
  }

  public submit(e) {
    this.store.dispatch(new CreateAutoLogonAccounts());
  }

  public formatDN(name){
    return formatDisplayName(name)
  }

  public openJustificationModal(acc){
    this.store.dispatch(new OpenAutoLogonJustificationModal(acc))
  }
}
