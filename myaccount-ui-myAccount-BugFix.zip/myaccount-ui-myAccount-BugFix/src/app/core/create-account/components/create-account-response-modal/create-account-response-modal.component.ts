import { CloseModal } from './../../store/actions/create-account.action';
import { Subscription } from 'rxjs';
import { createAccModal } from './../../store/selectors/index';
import { ICreateAccountFormState } from './../../../../shared/interfaces/admin/create-account/create-accounts-state';
import { Store, select } from '@ngrx/store';
import { Component, OnInit, Input, OnDestroy, EventEmitter } from '@angular/core';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { Router } from '@angular/router';

@Component({
  selector: 'app-2f82-create-account-response-modal',
  templateUrl: './create-account-response-modal.component.html',
  styleUrls: ['./create-account-response-modal.component.scss']
})
export class CreateAccountResponseModalComponent implements OnInit, OnDestroy {

  constructor(private store: Store<ICreateAccountFormState>, private router: Router) {
      this.close = new EventEmitter();
  }

  public open = false;
  public title = '';
  public message = '';
  public largeIcon = null;

  public loading = true;
  public finished = false;

  public close: EventEmitter<any>;

  private subs: Subscription[] = [];

  public ngOnInit() {
    this.subs = [
      this.store.pipe(select(createAccModal)).subscribe(modal => {
        const failed = modal.response ? !(/^SUCCESS/.test(modal.response.type)) : false;
        const warning = modal.response ? /^WARNING/.test(modal.response.type) : false;
        this.finished = Boolean(modal.response)
        this.open = modal.open;
        this.title = modal.loading ? 'CREATE_ACCOUNT.RESPONSE.LOADING' : failed ? 'CREATE_ACCOUNT.RESPONSE.FAILED' : 'CREATE_ACCOUNT.RESPONSE.SUCCESS';
        this.message = modal.loading ? '' : failed ? modal.response ? modal.response.message : 'CREATE_ACCOUNT.RESPONSE.FAILED' :  modal.response ? modal.response.message : 'CREATE_ACCOUNT.RESPONSE.SUCCESS';
        this.largeIcon = modal.loading ?  'Loading' : failed ? warning ? 'Warning' : 'Failed' : 'Success';
      })
    ];
  }

  public closeModal() {
    this.store.dispatch(new CloseModal());
  }

  public goHome() {
    this.store.dispatch(new CloseModal());
    this.router.navigateByUrl('/');
  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }

}
