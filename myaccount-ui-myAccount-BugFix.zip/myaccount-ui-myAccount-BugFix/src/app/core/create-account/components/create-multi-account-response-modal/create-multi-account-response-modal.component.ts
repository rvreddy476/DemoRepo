import { Component, OnInit } from '@angular/core';
import { CreateAcc } from 'src/app/shared/interfaces/create-account/state.namespace';
import { Store, select } from '@ngrx/store';
import { getMultiAccountModal, getMultiAccListEntities } from '../../store/selectors';
import { map, withLatestFrom } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { CloseAutoLogonAccountsModal } from '../../store/actions';

@Component({
  selector: 'app-create-multi-account-response-modal',
  templateUrl: './create-multi-account-response-modal.component.html',
  styleUrls: ['./create-multi-account-response-modal.component.scss']
})
export class CreateMultiAccountResponseModalComponent implements OnInit {

  constructor(private store: Store<CreateAcc.Multi.State>) { }

  public modal$;
  public state$: Observable<{
    title: string;
    largeIcon: string;
    message: string;
    failed: string[];
    success: string[];
  }>;

  public closeModal() {
    this.store.dispatch(new CloseAutoLogonAccountsModal());
  }

  public ngOnInit() {
    this.modal$ = this.store.pipe(select(getMultiAccountModal));
    this.state$ = this.modal$.pipe(
      withLatestFrom(this.store.pipe(select(getMultiAccListEntities))),
      map(([m, list]) => {
        if (m.loading) {
          return {
            title: 'Creating Accounts',
            largeIcon: 'Loading',
            message: null,
            messageParams: null,
            failed: null,
            success: null
          };
        }
        if (m.data ? m.data.length > 0 : false) {

          const [success, failed] = m.data.reduce((p, c, i) => {
            if (c.type === 'SUCCESS') {
              p[0].push(list[i] ? list[i].select_label : i);
            } else {
              p[1].push(list[i] ? list[i].select_label : i);
            }
            return p;
          }, [[], []]);

          const message = `${failed.length > 0 ? 'CREATE_MULTI_ACCOUNT.RESPONSE.WARNING_MESSAGE' : 'CREATE_MULTI_ACCOUNT.RESPONSE.SUCCESS_MESSAGE'}`;
          const messageParams = {success: success.length, failed: failed.length};

            if (failed.length === 0) {
            return {
              title: `CREATE_MULTI_ACCOUNT.RESPONSE.SUCCESS`,
              largeIcon: 'Success',
              message,
              messageParams,
              failed,
              success
            };
          } else {
            return {
              title: `CREATE_MULTI_ACCOUNT.RESPONSE.WARNING`,
              largeIcon: 'Warning',
              message,
              messageParams,
              failed,
              success
            };
          }
        }
      })
    );
  }

}
