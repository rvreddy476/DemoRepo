import { Input, Component, ViewChild, Output, EventEmitter, ViewEncapsulation, ContentChild, OnInit, ElementRef, QueryList, OnDestroy } from '@angular/core';
import { Observable, BehaviorSubject, Subscription, combineLatest } from 'rxjs';
import { debounceTime, map, tap, withLatestFrom, skipWhile } from 'rxjs/operators';

@Component({
  selector: 'app-2f82-multi-select-async',
  templateUrl: './multi-select-async.component.html',
  styleUrls: ['./multi-select-async.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MultiSelectAsyncComponent implements OnInit, OnDestroy {
  @ViewChild('multiselect') public multiselect: any;

  @ContentChild('OptionTemplate') public optionTemplate: QueryList<ElementRef>;
  @ContentChild('TagTemplate') public tagTemplate: QueryList<ElementRef>;
  @ContentChild('SummaryTagTemplate') public summaryTagTemplate: QueryList<ElementRef>;

  //#region inputs

  @Input()
  public $data: Observable<any[]>;
  @Input()
  public $value: Observable<any>;
  @Input()
  public $loading: Observable<boolean>;


  @Input()
  public maxSelection = 1;
  @Input()
  public placeholder = '';
  @Input()
  public valueField: string;
  @Input()
  public textField: string;
  @Input()
  public summaryTag = false;

  @Output()
  public valueChange = new EventEmitter();
  @Output()
  public filterChange = new EventEmitter();

  public valueList: any[];
  public options$: Observable<any[]>;
  public popupSettings = {
    animate: true,
    appendTo: 'root',
    width: 250,
  };
  private subs: Subscription[];
  public hideInput: boolean;
  private isOpen = false;
  public templateNativeElem: any;

  @Input() public itemDisabled: Function = () => false;

  public ngOnInit() {
    this.options$ = combineLatest(this.$data, this.$value).pipe(
      map(([opt, val]) => {
          val = val ? Array.isArray(val) ? val : [val] : [];
          opt = opt ? Array.isArray(opt) ? opt : [opt] : [];
        return [opt, val];
      }),
      map(([opt, val]) => {
        this.valueList = val;
        this.hideInput = val.length >= this.maxSelection && !this.summaryTagTemplate;

        if (this.summaryTagTemplate) {

          // Remove Duplicates
          const remDupl = opt.filter((optArr) => !val.some((val) => val.id === optArr.id));
          if (val.length >= this.maxSelection) {
            return val;
          } else {
            return [...val, ...remDupl];
          }
        } else {
          return opt;
        }
      }),
      debounceTime(20),
      tap((e) => {
        const canOpen = !this.multiselect.isOpen && this.multiselect.isFocused && e.length > 0;
        const canClose = this.multiselect.isOpen && (!this.multiselect.isFocused || e.length === 0);

        if (canOpen || canClose) {
          this.multiselect.toggle();
        }
      })
    );

    this.subs = [
      this.multiselect.filterChange
        .pipe(
          debounceTime(350),
          tap((f) => this.filterChange.emit(f))
        )
        .subscribe(),

      // Close Options List Immediately after selection if single selection type
      this.multiselect.valueChange
        .pipe(
          tap((value: any[]) => {
            this.valueChange.emit(value);
          })
        )
        .subscribe(),

      this.multiselect.onFocus
        .pipe(
          withLatestFrom(this.options$),
          tap((e) => {
            if (e[1].length > 0) {
              this.multiselect.toggle();
            }
          })
        )
        .subscribe(),

      this.multiselect.onBlur
        .pipe(
          tap(() => {
            if (this.multiselect.isOpen) {
              this.multiselect.toggle();
            }
          })
        )
        .subscribe(),

      this.multiselect.open.pipe(tap((e: Event) => e.preventDefault())).subscribe(),

      this.multiselect.close.pipe(tap((e: Event) => e.preventDefault())).subscribe(),

    ];
  }

  public ngOnDestroy() {
    this.subs.forEach((sub) => {
      sub.unsubscribe();
    });
  }

  public onRemoveTag(e) {}

  public tagMapper(tags: any[]): any[] {
    if (tags.length > 1) {
      return [tags];
    } else {
      return tags;
    }
  }

  public tagRepeater(tags: any[]) {
    return tags;
  }
}
