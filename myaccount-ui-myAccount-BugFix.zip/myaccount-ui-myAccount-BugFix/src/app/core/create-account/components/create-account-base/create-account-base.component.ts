import { OnInit, Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { ICreateAccountState } from '../../store';

import { ICreateAccount } from '../../../../shared/interfaces/admin/create-account/create-accounts-state';
import {
  SelectCreateAccOption,
  DuplicateCreateAccount,
  DeleteCreateAccount,
  SearchContextTerm,
  SearchOwnerTerm,
  SearchDeputyTerm,
  CreateAccounts,
  SearchMachineName,
  SetUniqueDirectory,
} from '../../store/actions';
import { getCreateAccFormValues, isMultiCreateAccFormComplete, isCreateAccFormSending, isSingleCreateAccFormComplete, getMultiAccountModal } from '../../store/selectors';
import { hasAutologonMgmtRole } from 'src/app/shared/store/selectors';

@Component({
  selector: 'app-2f82-create-account-base',
  templateUrl: './create-account-base.component.html',
  styleUrls: ['./create-account-base.component.scss'],
})
export class CreateAccountBaseComponent implements OnInit, OnDestroy {
  constructor(private router: ActivatedRoute, private store: Store<ICreateAccountState>) { }
  public createMode: Observable<'one' | 'multi'>;
  public formMulti: Observable<ICreateAccount[]>;
  public formSingle: Observable<ICreateAccount>;
  public singleSendable: Observable<boolean>;
  public multiSendable: Observable<boolean>;
  public sending: Observable<boolean>;

  public multiAccResponseOpen$: Observable<boolean>;

  public canManageAutoLogon$: Observable<boolean>;

  public subscriptions: Subscription[];

  public ngOnInit() {
    this.createMode = this.router.url.pipe(map((res) => res[0].path)) as Observable<'one' | 'multi'>;
    this.formMulti = this.store.pipe(select(getCreateAccFormValues));
    this.formSingle = this.store.pipe(select(getCreateAccFormValues)).pipe(map((res) => res[0]));
    this.multiSendable = this.store.pipe(select(isMultiCreateAccFormComplete));
    this.singleSendable = this.store.pipe(select(isSingleCreateAccFormComplete));
    this.sending = this.store.pipe(select(isCreateAccFormSending));
    this.canManageAutoLogon$ = this.store.pipe(select(hasAutologonMgmtRole));
    this.multiAccResponseOpen$ = this.store.pipe(select(getMultiAccountModal), map(m => Boolean(m.data) || m.loading));
  }

  public ngOnDestroy() { }

  public searchContext({ term, index }) {
    this.store.dispatch(new SearchContextTerm({ term, index }));
  }
  public makeSelection(obj) {
    this.store.dispatch(new SelectCreateAccOption(obj));
  }
  public toggleSelection(obj) {
    this.store.dispatch(new SetUniqueDirectory(obj))
  }

  public searchOwner({ term, index }) {
    this.store.dispatch(new SearchOwnerTerm({ term, index }));
  }
  public searchDeputies({ term, index }) {
    this.store.dispatch(new SearchDeputyTerm({ term, index }));
  }
  public searchMachineName({ term, index }) {
    this.store.dispatch(new SearchMachineName({ term, index }));
  }

  public duplicateIndex(index) {
    this.store.dispatch(new DuplicateCreateAccount(index));
  }
  public deleteIndex(index) {
    this.store.dispatch(new DeleteCreateAccount(index));
  }
  public submit(event) {
    this.store.dispatch(new CreateAccounts());
  }
  public cancel(event) { }
}
