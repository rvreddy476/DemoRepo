import { IIdentity } from './../../shared/interfaces/identity/identity';
import { IAccDomainAPI } from './../../shared/interfaces/admin/create-account/create-account-rules-api';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from, of } from 'rxjs';
import { Endpoints } from '../../shared/endpoints';
import { IAccCreationRulesAPI, IAccCreationPolicyAPI } from '../../shared/interfaces/admin/create-account/create-account-rules-api';
import { IAccCreationIdentiesListAPI } from '../../shared/interfaces/admin/create-account/create-account-identies-api';
import { IDelegateAPI } from 'src/app/shared/interfaces/shared/common/identity';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { API } from 'src/app/shared/interfaces/shared/api';


@Injectable()
export class CreateAccountService {
  constructor(private http: HttpClient) { }

  public getRules(accCode, type): Observable<IAccCreationRulesAPI> {
    return this.http.get<IAccCreationRulesAPI>(Endpoints.CREATE_ACCOUNT_RULES(accCode, type));
    // return this.http.get<IAccCreationStaticRulesAPI>(`./assets/mock_data/create_account/staticRules.json`).pipe(delay(500));
  }
  public getPolicy(domainID): Observable<IAccCreationPolicyAPI> {
    return this.http.get<IAccCreationPolicyAPI>(Endpoints.CREATE_ACCOUNT_DOMAIN_POLICY(domainID), {
      params: {autologon_only: 'true'}
    });
  }

  public getDomainID(domainName): Observable<IAccDomainAPI> {
    return this.http.get<IAccDomainAPI>(Endpoints.CREATE_ACCOUNT_DOMAINS(domainName));
  }

  public getContextSearchList(term: string, autologonOnly: boolean = false): Observable<API.Response<CreateAcc_API.Get.Solution[]>> {
    return this.http.get<API.Response<CreateAcc_API.Get.Solution[]>>(Endpoints.CREATE_ACCOUNT_CONTEXT_SEARCH(term, autologonOnly));
  }
  public getMachineNameSearchList(term: string): Observable<API.Response<CreateAcc_API.Get.MachineName[]>> {
    return this.http.get<API.Response<CreateAcc_API.Get.MachineName[]>>(Endpoints.CREATE_ACCOUNT_MACHINE_NAMES(term));
  }

  public getOwnerSearchList(term: string): Observable<IAccCreationIdentiesListAPI> {
    return this.http.get<IAccCreationIdentiesListAPI>(Endpoints.CREATE_ACCOUNT_IDENTIES_SEARCH(term, 'validated', 'employee'));
  }
  public getDeputitySearchList(term: string): Observable<API.Response<CreateAcc_API.Get.Identity[]>> {
    return this.http.get<API.Response<CreateAcc_API.Get.Identity[]>>(Endpoints.CREATE_ACCOUNT_IDENTIES_SEARCH(term, 'validated'));
  }

  public getDeputityBlacklistList(context: number, domain: string): Observable<API.Response<CreateAcc_API.Get.Delegate>> {
    return this.http.get<API.Response<CreateAcc_API.Get.Delegate>>(Endpoints.CREATE_ACCOUNT_DEPUTY_BLACKLIST(context, domain));
  }

  public getIdentity(id: number): Observable<IIdentity> {
    return this.http.get<IIdentity>(Endpoints.CREATE_ACCOUNT_IDENTITY(id));
  }

  public createAccount(account: CreateAcc_API.IPostBody): Observable<API.Response<CreateAcc_API.CreationResponse[]>> {
    const url = Endpoints.CREATE_ACCOUNT();
    return this.http.post<API.Response<CreateAcc_API.CreationResponse[]>>(url, account);
  }

  public createBulkAccounts(accounts: CreateAcc_API.IPostBody[]): Observable<API.Response<CreateAcc_API.CreationResponse[]>> {
    const url = Endpoints.CREATE_BULK_ACCOUNTS();
    return this.http.post<API.Response<CreateAcc_API.CreationResponse[]>>(url, accounts);
  }
}
