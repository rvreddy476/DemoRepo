export const createAccConfig = {
  contextSearchMinChars: 2,
  accountTypeMapping: {
    SERVICE: 'SA',
    TECHNICAL: 'TA',
    SHARED: 'SH',
    LOGON: 'LA',
    AUTOLOGON: 'AL',
    TRAINING: 'TR',
    TEST: 'TS',
    LEGACY: 'LE',
  },
};
