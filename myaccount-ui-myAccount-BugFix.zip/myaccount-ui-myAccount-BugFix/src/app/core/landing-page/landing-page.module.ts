import { NgModule } from '@angular/core';
import { UserRoutingModule } from './landing-page-routing.module';
import { SharedModule } from '../../modules/shared.module';

import { LandingPageComponent } from './landing-page.component';
import { UserStatsTilesComponent } from './components/user-stats-tiles/user-stats-tiles.component';
import { SharedTranslateModule } from 'src/app/modules/shared-translate.module';



@NgModule({
  imports: [
    SharedModule,
    SharedTranslateModule,
    UserRoutingModule
  ],
  declarations: [LandingPageComponent, UserStatsTilesComponent],
})
export class LandingPageModule {}
