import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';

import { ActivatedRoute, Router } from '@angular/router';
import { IAccountsStats } from '../../../../shared/interfaces/user/user-accounts-stats';
import { AccountDivisionEnum } from '../../../../shared/enums';
import { TileTypeEnum } from '../../../../shared/enums/tile-type.enum';
import { map, tap, distinctUntilChanged, pairwise, filter } from 'rxjs/operators';
import { getGlobalDelegationMode, getAccountsStatsLoaded, getAccountsStatsLoading, getAccountsStats } from 'src/app/shared/store/selectors';
import { TAccountDelegationType } from 'src/app/shared/interfaces/shared/account/account';
import { LoadAccountsStats } from 'src/app/shared/store';
import { IBaseState } from 'src/app/shared/interfaces/base-state';

@Component({
  selector: 'app-2f82-user-stats-tiles',
  templateUrl: './user-stats-tiles.component.html',
  styleUrls: ['./user-stats-tiles.component.scss'],
})
export class UserStatsTilesComponent implements OnInit, OnDestroy {
  public data$: Observable<IAccountsStats>;
  public loaded$: Observable<boolean>;
  public loading$: Observable<boolean>;

  public accDivisions = AccountDivisionEnum;
  public tileType = TileTypeEnum;

  public accountsStats: IAccountsStats;
  public accSum$: Observable<number>;
  public delegation$: Observable<TAccountDelegationType>;

  public summaryTitle$: Observable<string>;

  public lineChart;
  public pcEnabled;
  public pcDisabled;

  public tileTypes = TileTypeEnum;

  private subs: Subscription[];

  constructor(private store: Store<IBaseState>, public router: Router,private activatedRoute : ActivatedRoute) { }

  public ngOnInit() {
    console.log(2,{store:this.store, LoadAccountsStats});
    console.log(this.activatedRoute.component['name']);
    this.store.dispatch(new LoadAccountsStats);
    this.loaded$ = this.store.pipe(select(getAccountsStatsLoaded));
    this.loading$ = this.store.pipe(select(getAccountsStatsLoading));
    this.data$ = this.store.pipe(select(getAccountsStats)).pipe(distinctUntilChanged());
    this.accSum$ = this.data$.pipe(map(d => d.ads + d.ah + d.ca));
    this.delegation$ = this.store.pipe(select(getGlobalDelegationMode));

    this.summaryTitle$ = this.delegation$.pipe(
      map(del => {
        switch (del) {
          case 'ALL':
            return 'DELEGATION_PANEL.ALL_ACCOUNTS';
          case 'DIRECT':
            return 'DELEGATION_PANEL.MY_ACCOUNTS';
          case 'DISABLED':
            return 'DELEGATION_PANEL.ALL_ACCOUNTS';
          case 'INDIRECT':
            return 'DELEGATION_PANEL.MY_INHERITED_ACCOUNTS';
        }
      }),
    );

    this.subs = [
      this.delegation$.pipe(
        pairwise(),
        filter(([p, c]) => {
          return Boolean(p);
        }),
        tap(() => {
          console.log(3,{store:this.store, LoadAccountsStats})
          this.store.dispatch(new LoadAccountsStats);
        }),
      ).subscribe()
    ];

  }

  public ngOnDestroy() {
    this.subs.forEach(sub => {
      sub.unsubscribe();
    });
  }

  public navigateViaTile(tile) {
    this.router.navigate(['./accounts', { tile }]);
  }


  
}
