
// import { RouterTestingModule } from '@angular/router/testing';
// import { TranslateModule } from '@ngx-translate/core';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { NoopAnimationsModule } from '@angular/platform-browser/animations';
// import { provideMockStore, MockStore } from '@ngrx/store/testing';
// import { Chart } from 'chart.js';
// import { defaultTestStore } from '../../../../shared/mock-data';

// import { UserStatsTilesComponent } from './user-stats-tiles.component'
// import { TileComponent } from '../../../../shared/components/tile-components/tile/tile.component'
// import { AppState } from '../../../../shared/store';
// import { Store } from '@ngrx/store';
// import { TooltipModule } from '@progress/kendo-angular-tooltip';
// import { DelegationSelectionPanelComponent } from 'src/app/shared/components/delegation-selection-panel/delegation-selection-panel.component';
// import { IAccountsStatsState } from 'src/app/shared/interfaces/user/user-accounts-stats-state';



// describe('UserStatsTilesComponent', () => {
//   let makeStatsState = (init: AppState, statsState: Partial<IAccountsStatsState>) => {
//     return {}
//   }
//   const mockData = {
//     data: {
//       noStats: {
//         id: "",
//         ads: 0,
//         ah: 0,
//         ca: 0,
//         disabled: 0,
//         expired: 0,
//         pending: 0,
//         change_pwd_scheduled: 0,
//         to_approve: 0,
//         to_reset: 0
//       },
//       fullStats: {
//         id: "",
//         ads: 55,
//         ah: 55,
//         ca: 55,
//         disabled: 55,
//         expired: 55,
//         pending: 55,
//         change_pwd_scheduled: 55,
//         to_approve: 55,
//         to_reset: 55
//       }
//     }
//   }
//   let component: UserStatsTilesComponent;
//   let fixture: ComponentFixture<UserStatsTilesComponent>;
//   let elem: HTMLElement
//   let store: MockStore<AppState>

//   window.matchMedia = jest.fn().mockImplementation(query => {
//     return {
//       matches: false,
//       media: query,
//       onchange: null,
//       addListener: jest.fn(),
//       removeListener: jest.fn(),
//     };
//   });

//   const initialState: AppState = defaultTestStore

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [TranslateModule.forRoot(), RouterTestingModule, TooltipModule],
//       providers: [
//         provideMockStore({ initialState }),
//       ],
//       declarations: [UserStatsTilesComponent, TileComponent, DelegationSelectionPanelComponent]
//     }).compileComponents().then(() => {
//       fixture = TestBed.createComponent(UserStatsTilesComponent);
//       component = fixture.componentInstance;
//       elem = fixture.nativeElement;
//       fixture.detectChanges();
//       store = TestBed.get(Store)
//     });
//   }));
//   it('displays all 9 tiles when stats are 0', async () => {
//     store.setState(makeStatsState(initialState, { data: mockData.data.noStats }))
//     const tiles = elem.querySelectorAll('app-2f82-tile .tile-value')
//     expect(tiles.length).toBe(9);
//   });
//   it('maps the correct value to the correct tile', () => {
//     const specificMock = {
//       id: "",
//       ads: 3,
//       ah: 7,
//       ca: 9,
//       disabled: 13,
//       expired: 17,
//       pending: 27,
//       change_pwd_scheduled: 31,
//       to_approve: 57,
//       to_reset: 67
//     }
//     store.setState(makeStatsState(initialState, { data: specificMock, loading:false, loaded:true}))
//     fixture.detectChanges();

//     expect(elem.querySelector('.to-reset .tile-value').textContent).toBe(specificMock.to_reset.toString())
//     expect(elem.querySelector('.to-approve .tile-value').textContent).toBe(specificMock.to_approve.toString())
//     expect(elem.querySelector('.action-follow-up-acc .tile-value').textContent).toBe(specificMock.pending.toString())
//     expect(elem.querySelector('.expired-acc .tile-value').textContent).toBe(specificMock.expired.toString())
//     expect(elem.querySelector('.disabled-acc .tile-value').textContent).toBe(specificMock.disabled.toString())
//     expect(elem.querySelector('.pwd_scheduled .tile-value').textContent).toBe(specificMock.change_pwd_scheduled.toString())
//   });
// });
