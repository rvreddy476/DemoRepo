import { Component} from '@angular/core';
@Component({
  selector: 'app-2f82-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
})
export class LandingPageComponent {
  constructor() {}
}
