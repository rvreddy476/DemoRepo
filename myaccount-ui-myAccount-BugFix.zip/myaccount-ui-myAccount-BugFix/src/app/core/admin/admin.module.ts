import { NgModule } from '@angular/core';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { SharedModule } from 'src/app/modules/shared.module';
import { SharedTranslateModule } from 'src/app/modules/shared-translate.module';
import { AdminStatsTilesComponent } from './components/admin-stats-tiles/admin-stats-tiles.component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { reducers } from './store/reducers';
import { effects } from './store/effects';
import { AdminAccountsListComponent } from './components/admin-accounts-list/admin-accounts-list.component';
import { AdminAccountsSearchPanelComponent } from './components/accounts-search-panel/accounts-search-panel.component';
import { AdminAccountsDetailSearchComponent } from './components/accounts-search-panel/accounts-detail-search/accounts-detail-search.component';
// import { AccountsFilterPillsComponent } from '../accounts/list/accounts-search-panel/accounts-filter-pills/accounts-filter-pills.component';
// import { AccountsGlobalSearchComponent } from '../accounts/list/accounts-search-panel/accounts-global-search/accounts-global-search.component';
// import { FormDateRangeDropdownComponent } from '../accounts/list/accounts-search-panel/filters/form-date-range-dropdown';
// import { FormFilterMultiDropdownComponent } from '../accounts/list/accounts-search-panel/filters/form-filter-multi-dropdown';
// import { FormPasswordExpDropdown } from '../accounts/list/accounts-search-panel/filters/form-password-exp-dropdown';
import { AdminAccountsFilterPillsComponent } from './components/accounts-search-panel/accounts-filter-pills/accounts-filter-pills.component';
import { AdminAccountsGlobalSearchComponent } from './components/accounts-search-panel/accounts-global-search/accounts-global-search.component';
import { AdminFormDateRangeDropdownComponent } from './components/accounts-search-panel/filters/form-date-range-dropdown';
import { AdminFormFilterMultiDropdownComponent } from './components/accounts-search-panel/filters/form-filter-multi-dropdown';
import { AdminFormPasswordExpDropdown } from './components/accounts-search-panel/filters/form-password-exp-dropdown';
import { AdminVirtualScrollListComponent } from './components/virtual-scroll-list/virtual-scroll-list.component';

import { AdminAddRemoveDeputiesModalComponent } from './components/modal/add-remove-deputies-modal/add-remove-deputies-modal.component';

import { AdminFollowUpBaseComponent } from './components/admin-follow-up-base/admin-follow-up-base.component';
import { AdminActionFollowUpComponent } from './components/admin-action-follow-up/admin-action-follow-up.component';
import { AdminEnableDisableModalComponent } from './components/modal/enable-disable-modal/enable-disable-modal.component';
import { AdminResetPasswordModalComponent } from './components/modal/reset-password-modal/reset-password-modal.component';
import { AdminAssignOrphanModalComponent } from './components/modal/assign-orphan-modal/assign-orphan-modal.component'
import { AdminAccountsActionbarComponent } from './components/accounts-actionbar/accounts-actionbar.component';
import { AdminAccountActionIconBarComponent } from './components/account-action-icon-bar/account-action-icon-bar.component';
import { CSVExporter } from 'src/app/shared/services/csv-exporter';

import { AdminFollowUpModalComponent } from './components/admin-follow-up-modal/admin-follow-up-modal.component';
import { AdminOrphanAccountsComponent } from './components/admin-orphan-accounts/admin-orphan-accounts.component';
import { OrphanSelectionPanelComponent } from './components/admin-orphan-accounts/orphan-selection-panel/orphan-selection-panel.component';
import { AdminViewClearSelectionComponent } from './components/admin-view-clear-selection/admin-view-clear-selection.component';
import { AdminOrphanListComponent } from './components/admin-orphan-accounts/admin-orphan-list/admin-orphan-list.component';
import { AdminOrphanAccountDetailSearchComponent } from './components/admin-orphan-accounts/admin-orphan-account-detail-search/admin-orphan-account-detail-search.component';
import { RouterModule } from '@angular/router';
import { IconModule } from 'src/app/modules/icon.module';
import { AccountDetailPageComponent } from './detail/account-detail-page/account-detail-page.component';
import { AccountDetailInfoComponent } from './detail/account-detail-info/account-detail-info.component';
import { AccountDetailHistoryComponent } from './detail/account-detail-history/account-detail-history.component';
import { AccountDetailDelegationComponent } from './detail/account-detail-delegation/account-detail-delegation.component';
import { EditDescriptionModalComponent } from './components/modal/edit-description-modal/edit-description-modal.component';
import { EndOfLifeModalComponent } from './components/modal/end-of-life-modal/end-of-life-modal.component';



@NgModule({

  declarations: [AdminComponent,
    AdminStatsTilesComponent,
    AdminAccountsListComponent,

    AdminActionFollowUpComponent, 
    AdminFollowUpModalComponent,

    AdminFollowUpBaseComponent,
    AdminAssignOrphanModalComponent,
    AdminAccountsSearchPanelComponent,
    AdminAccountsDetailSearchComponent,
    AdminAccountsFilterPillsComponent,
    AdminAccountsGlobalSearchComponent,
    AdminFormDateRangeDropdownComponent,
    AdminFormFilterMultiDropdownComponent,
    AdminFormPasswordExpDropdown,
    AdminAddRemoveDeputiesModalComponent,
    AdminVirtualScrollListComponent,
    AdminEnableDisableModalComponent,
    AdminResetPasswordModalComponent,
    AdminAccountsActionbarComponent,
    AdminAccountActionIconBarComponent,
    AdminOrphanAccountsComponent,
    OrphanSelectionPanelComponent,
    AdminViewClearSelectionComponent,
    AdminOrphanListComponent,
    AdminOrphanAccountDetailSearchComponent,
    AccountDetailPageComponent,
    AccountDetailInfoComponent,
    AccountDetailHistoryComponent,
    AccountDetailDelegationComponent,
    EditDescriptionModalComponent,
    EndOfLifeModalComponent],
  providers: [
    CSVExporter
  ],
  imports: [
    RouterModule ,
    SharedModule,
    SharedTranslateModule,
    IconModule,
    AdminRoutingModule,
    StoreModule.forFeature('adminModule', reducers),
    EffectsModule.forFeature(effects)
  ]
})
export class AdminModule { }
