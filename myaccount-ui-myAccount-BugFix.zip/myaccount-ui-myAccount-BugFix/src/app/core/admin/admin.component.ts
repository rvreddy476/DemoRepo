import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { getEditDescriptionModal, getAdminAccountsResetModal,getAccountsEnfOfLifeModal, getAdminEnableDisableModal } from './store/selectors';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-2f82-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  constructor(private store: Store<IAccountsListState>) { }
  public showEditAccDescriptionModal = this.store.pipe(select(getEditDescriptionModal), map(modal => modal.open));
  public showEnableDisableModal = this.store.pipe(select(getAdminEnableDisableModal)).pipe(map(acc => acc.open));
  public showEndOflifeModal = this.store.pipe(select(getAccountsEnfOfLifeModal), map(modal => modal.open));
  public showResetModal = this.store.pipe(select(getAdminAccountsResetModal)).pipe(map(acc => acc.open));
  ngOnInit() {
    console.log('admin called');
  }

}
