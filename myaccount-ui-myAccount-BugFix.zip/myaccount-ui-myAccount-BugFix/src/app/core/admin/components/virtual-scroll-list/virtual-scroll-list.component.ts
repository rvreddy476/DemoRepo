
//#region imports
import { Component, OnInit, OnDestroy, ViewChild, ViewEncapsulation, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { State, SortDescriptor, CompositeFilterDescriptor, orderBy } from '@progress/kendo-data-query';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { map, delay, distinctUntilChanged, tap, withLatestFrom, filter, switchMap } from 'rxjs/operators';
import { IAccountGridData, IEnabledColunms, IAccountsListState, IAccount } from '../../../../shared/interfaces/shared/account/account';
import { TranslateService } from '@ngx-translate/core';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { getAccounts, getAccountsListState, getGridDataResult, getSelectAllStatus, getGridFilters, getGridSort, getSelectedAccounts, getAccountsEnabledColumns, getAccountsVisibleColumns, getAccountsGridState, getAccountsListLoading, getVisibleAccounts, getAccountsUniqueDirectoryType, getSortedFilteredAccountList, getAccountsUniqueDirectoryEnvironment, getAccountsUniqueDivision, getAccountsUniqueLifeCycleStatus, getAccountsUniqueType, getAdvancedFilterPanelOpen } from '../../store';
import { LoadAdminAccountsList, ResetDetailFilter, SelectAllAccounts, SetAccountsShowUidList, LoadAccountsList, SetAccountsFilter, SetSelectedAccounts, SetViewOnlySelectedAccounts, SetAccountsFilterByTile, AddBenchmark, SetAccountsSort, SetAccountsPage } from '../../store/actions/accounts-list.actions';

//#endregion

@Component({
  selector: 'app-2f82-admin-virtual-scroll-list',
  templateUrl: './virtual-scroll-list.component.html',
  styleUrls: ['./virtual-scroll-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AdminVirtualScrollListComponent implements OnInit {

  @ViewChild('grid') private grid;

  loading: boolean;
  public gridHeight = 0;
  public columnConfig;
  public sortMultiple = false;
  public allowUnsort = true;
  public testMode = false;

  private colunmVisibilityPriority = [
    'uid',
    'directoryDomain',
    'lifeCycleStatus',
    'pwdStatus',
    'pwdRemainingDays',
    'contextName',
    'type',
    'directoryEnvironment',
    'division',
  ];

  public query: any;

  public colMedia: any; // Derived from Screen Resolution and "enabled colunms"
  public selectedAccounts: number[] = [];

  public subscriptions: Subscription[] = [];

  public benchmarksViewRenderTimestamp: Date;
  public benchmarks$: Observable<string>;
  public data$: Observable<IAccountGridData>;
  public uniqueDirectoryType$: Observable<any[]>;
  public uniqueDirectoryEnvironment$: Observable<any[]>;
  public uniqueDivision$: Observable<any[]>;
  public uniqueLifeCycleStatus$: Observable<any[]>;
  public uniqueType$: Observable<any[]>;

  public isLoading$: Observable<boolean>;
  // public sort: SortDescriptor[] = [];
  public filter: CompositeFilterDescriptor = { filters: [], logic: 'and' };
  public filterable = true;

  private detailRowID: string;
  private visibleColumns: string[];
  private enabledColumns: IEnabledColunms;
  public gridState: State;
  private stateChange = new BehaviorSubject<any>(this.gridState);
  public selectAllBtnState$ = this.store.pipe(select(getSelectAllStatus));

  constructor(private store: Store<IAdminAccountListState>,
    private active: ActivatedRoute,
    private router: Router,
    private translate: TranslateService) {
    this.getColumnConfig();
    this.query = this.stateChange.pipe(
      tap(state => {
        this.gridState = state;
        this.loading = true;
      }),
      switchMap(state => this.store.select(getGridDataResult)),
      tap((res) => {
        this.loading = false;
      })
    );
  }

  ngOnInit(): void {
    this.subscriptions.push(

      this.store.pipe(select(getGlobalDelegationMode)).pipe(
        filter(d => {
          return Boolean(d);
        }),
        withLatestFrom(this.active.params),
        tap(([delegation, params]) => {
          console.log(params);
          this.loadAccounts(params);
        })
      ).subscribe(),

      this.store.pipe(select(getGridFilters)).subscribe((filter) => {
        this.grid.filterService.changes.next(filter);
        this.filter = filter;
      }),

      this.translate.onLangChange.subscribe(() => {
        this.getColumnConfig();
        // trigger a change in state to trigger a page update to show new languages
        // this.store.dispatch(new SetAccountsSort(this.sort));
      }),

      this.store.pipe(select(getGridSort)).subscribe((sort) => {
        this.sort = sort;
      }),

      this.store.pipe(select(getSelectedAccounts)).subscribe((selected) => {
        this.selectedAccounts = selected;
      }),
      this.store.pipe(select(getAccountsEnabledColumns)).subscribe((cols) => {
        this.enabledColumns = cols;
      }),
      this.store.pipe(select(getAccountsVisibleColumns)).subscribe((visible) => {
        this.visibleColumns = visible;
        this.calculateColMedia();
      }),
      this.store.pipe(select(getAccountsGridState)).subscribe((gridState) => {
        this.gridState = gridState;
      }),

      this.grid.selectionChange.pipe(
        // dont act on locked or hp accounts selection
        filter((e: any) => {
          return [...e.selectedRows, ...e.deselectedRows].every(row => (!row.dataItem.hp && !row.dataItem.locked));
        }),
        filter((e: any) => {
          const wasSelectAllBtn = (e.ctrlKey && e.shiftKey);
          // prevent default behaviour when clicking on the "select all" button
          return !wasSelectAllBtn;
        }),
        withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getSortedFilteredAccountList))),
        map(([change, selected, filtered]) => {
          const added = change.selectedRows.filter(row => !row.dataItem.locked).map(acc => acc.dataItem.id);
          const removed = change.deselectedRows.map(acc => acc.dataItem.id);
          const newSelection = [...selected, ...added].filter(cur => removed.indexOf(cur) === -1);
          const isAll = filtered.filter(acc => !acc.locked).every(acc => newSelection.indexOf(acc.id) !== -1);
          console.log(newSelection);
          this.store.dispatch(
            new SetSelectedAccounts({ ids: newSelection, isAll })
          );
        })
      ).subscribe()
    );

    this.isLoading$ = this.store.pipe(select(getAccountsListLoading));
    this.query = this.store.pipe(select(getVisibleAccounts));
    this.uniqueDirectoryType$ = this.store.pipe(select(getAccountsUniqueDirectoryType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDirectoryEnvironment$ = this.store
      .pipe(select(getAccountsUniqueDirectoryEnvironment))
      .pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueDivision$ = this.store.pipe(select(getAccountsUniqueDivision)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueLifeCycleStatus$ = this.store.pipe(select(getAccountsUniqueLifeCycleStatus)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));
    this.uniqueType$ = this.store.pipe(select(getAccountsUniqueType)).pipe(map((names) => names.map((n) => ({ value: n, name: n }))));

    this.store.pipe(select(getAdvancedFilterPanelOpen)).pipe(delay(200)).subscribe(() => {
      this.resetGridHeight();
    });

    this.resetGridHeight();
  }

  ngOnDestroy() {
    this.store.dispatch(new ResetDetailFilter());
  }

  public sort: SortDescriptor[] = [{
    field: 'directoryDomain',
    dir: 'asc'
  }, {
    field: 'lifeCycleStatus',
    dir: 'asc'
  }, {
    field: 'pwdStatus',
    dir: 'asc'
  }, {
    field: 'pwdRemainingDays',
    dir: 'asc'
  }, {
    field: 'contextName',
    dir: 'asc'
  }, {
    field: 'type',
    dir: 'asc'
  }, {
    field: 'directoryEnvironment',
    dir: 'asc'
  }];

  public sortChangeHandler(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.store.dispatch(new SetAccountsSort(sort));
  }
  public pageChangeHandler(state: State): void {
    this.store.dispatch(new SetAccountsPage(state));
    this.closeCurrentDetail();
  }

  public onSelectAllChange() {
    this.store.dispatch(new SelectAllAccounts());
  }

  public isRowSelected(selected) {
    return (row) => {
      return selected.indexOf(row.dataItem.id) !== -1;
    };
  }

  public rowClass(e) {
    let res = 'row';
    if (e.dataItem.locked) {
      res += ' locked';
    }
    if (e.dataItem.hp) {
      res += ' hp';
    }
    return res;
  }

  public pageChange(state: any): void {
    this.stateChange.next(state);
  }

  public shouldShowColunm(field) {
    if (field === 'id') {
      return false;
    }
    return this.enabledColumns[field];
  }

  public derivePasswordStatus(acc: IAccount) {
    if (acc.pwdStatus === 'NO_PASSWORD') {
      return {
        text: `-`,
        value: null
      };
    }
    if (acc.pwdStatus === 'EXPIRED') {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRED_SINCE`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    } else {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN`,
        value: { d: Math.abs(acc.pwdRemainingDays) }
      };
    }
  }

  public hasDetail(input) {
    return true;
  }
  public detailLoadedForAcc(acc) {
    for (const key in acc) {
      if (acc.hasOwnProperty(key)) {
        if (acc[key] === undefined) {
          return false;
        }
      }
    }
    return true;
  }

  private closeCurrentDetail() {
    if (this.detailRowID !== null) {
      this.grid.collapseRow(this.detailRowID);
    }
  }

  private calculateColMedia() {
    let accum = 82;
    this.colMedia = this.colunmVisibilityPriority.reduce((prev, cur) => {
      accum += this.enabledColumns[cur] ? this.columnConfig[cur].width : 0;
      prev[cur] = `(min-width: ${accum}px)`;
      return prev;
    }, {});
  }

  private resetGridHeight() {   
    const footerHieght = 30;
    if(this.grid.wrapper.nativeElement.parentElement.offsetParent!=null)
    {     
      const height =this.grid.wrapper.nativeElement.parentElement.offsetParent.clientHeight;
      this.gridHeight = height - (footerHieght*2)-this.grid.wrapper.nativeElement.parentElement.offsetTop;
    }
    else{
    const height = this.grid.wrapper.nativeElement.parentElement.clientHeight;
    this.gridHeight = height - footerHieght
    }
  
  }

  private loadAccounts(urlParams: Params) {
    if (urlParams.term) {
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new LoadAccountsList());
      this.store.dispatch(new SetAccountsFilter({
        filters: [
          {
            field: 'uid',
            operator: 'contains',
            value: urlParams.term,
            ignoreCase: true,
          },
        ],
        logic: 'and'
      }));
    } else if (urlParams.viewonly) {
      const viewList: number[] = JSON.parse(urlParams.viewonly).split(',').map(id => parseInt(id));
      this.store.dispatch(new LoadAccountsList());
      this.store.dispatch(new SetSelectedAccounts({ ids: viewList, isAll: true }));
      this.store.dispatch(new SetViewOnlySelectedAccounts(true));
    } else if (urlParams.tile) {
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new SetAccountsFilterByTile(urlParams.tile));
      this.store.dispatch(new LoadAccountsList());
    } else {
      this.store.dispatch(new SetAccountsShowUidList([]));
      this.store.dispatch(new AddBenchmark({ event: 'Request Accounts List', time: new Date() }));
      this.store.dispatch(new LoadAccountsList());
    }
  }

  public navigate(id) {
    this.router.navigate([`admin/${id}`]);
  }

  private getColumnConfig = () => {
    this.columnConfig = {
      id: {
        title: 'ID',
        field: 'id',
        width: 0,
      },
      uid: {
        title: 'ACCOUNT_LIST.ROW_NAME.UID',
        field: 'uid',
        width: 200,
      },
      lifeCycleStatus: {
        title: 'ACCOUNT_LIST.ROW_NAME.ACC_STATUS',
        field: 'lifeCycleStatus',
        width: 150,
      },
      pwdStatus: {
        title: 'ACCOUNT_LIST.ROW_NAME.PASS_STATUS',
        field: 'pwdStatus',
        width: 150,
      },
      pwdRemainingDays: {
        title: 'ACCOUNT_LIST.ROW_NAME.PASS_LIFETIME',
        field: 'pwdRemainingDays',
        width: 180,
      },
      contextName: {
        title: 'ACCOUNT_LIST.ROW_NAME.SOLUTION',
        field: 'contextName',
        width: 120,
      },
      type: {
        title: 'ACCOUNT_LIST.ROW_NAME.TYPE',
        field: 'type',
        width: 140,
      },
      directoryEnvironment: {
        title: 'ACCOUNT_LIST.ROW_NAME.ENVIRONMENT',
        field: 'directoryEnvironment',
        width: 130,
      },
      directoryDomain: {
        title: 'ACCOUNT_LIST.ROW_NAME.DOMAIN',
        field: 'directoryDomain',
        width: 120,
      },
      division: {
        title: 'ACCOUNT_LIST.ROW_NAME.DIVISION',
        field: 'division',
        width: 230,
      },
      locked: {
        title: '',
        field: 'locked',
        width: 70,
      },
    };
  }

}
