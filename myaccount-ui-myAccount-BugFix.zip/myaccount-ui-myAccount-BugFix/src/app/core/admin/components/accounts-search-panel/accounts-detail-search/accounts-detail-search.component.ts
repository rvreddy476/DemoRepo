import { Component, OnInit, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAdminState, getSolutions, getDelegation_Members, getAccounts, getUniqueData, getFilters, getAccountNames} from '../../../store';
import { switchMap, tap, delay, map } from 'rxjs/operators';
import { from, of, Subscription } from 'rxjs';
import { LoadAdminSolutions, LoadAdminDelegationMember, SET_FILTER_VALUES, SetFilterValues, LoadAdminAccountsList, DetailFilterToggle, ResetDetailFilter, LoadAdminAccountsListSuccess, LoadAdminAccountName } from '../../../store/actions/accounts-list.actions';

@Component({
  selector: 'app-2f82-admin-accounts-detail-search',
  templateUrl: './accounts-detail-search.component.html',
  styleUrls: ['./accounts-detail-search.component.scss']
})
export class AdminAccountsDetailSearchComponent implements OnInit {

  @Input() detailFilterToggle: boolean;

  resetValue: string = '';
  filters: any = {
    delegation_identity: '',
    account_name: '',
    solution_code: '',
    environment: '',
    account_lifetime: '',
    password_status: '',
    password_lifetime: '',
    domain: '',
  }

  subs: Subscription[] = [];

  public accountsData$ = this.store.select(getAccounts);
  private accountCount: number;
  public filters$ = this.store.select(getFilters);

  public Solutions$ = this.store.select(getSolutions);
  public Delegation_Members$ = this.store.select(getDelegation_Members);
 
  public AccountNames$ = this.store.select(getAccountNames);
  public domainList$ = this.store.select(getUniqueData).pipe(map(data => data.directoryDomain))
  public lifeCycleStatus$ = this.store.select(getUniqueData).pipe(map(data => data.lifeCycleStatus))
  public pwdStatus$ = this.store.select(getUniqueData).pipe(map(data => data.pwdStatus))
  public environment$ = this.store.select(getUniqueData).pipe(map(data => data.directoryEnvironment))

  constructor(private store: Store<IAdminState>) {

  }

  ngOnInit(): void {
    this.store.dispatch(new LoadAdminSolutions({ term: '' }));
    this.subs.push(this.filters$.subscribe(filter => {
      this.filters.delegation_identity = filter.delegation_identity === null ? '' : filter.delegation_identity[0];
      this.filters.account_name = filter.account_name === null ? '' : filter.account_name[0];
      this.filters.solution_code = filter.solution_code === null ? '' : filter.solution_code[0];
      this.filters.environment = filter.environment === null ? '' : filter.environment[0];
      this.filters.account_lifetime = filter.account_lifetime === null ? '' : filter.account_lifetime[0];
      this.filters.password_status = filter.password_status === null ? '' : filter.password_status[0];
      this.filters.password_lifetime = filter.password_lifetime === null ? '' : filter.password_lifetime[0];
      this.filters.domain = filter.domain === null ? '' : filter.domain[0];
    })
    );
    
    //this.subs.push(this.accountsData$.subscribe(a => this.accountCount = a.length));    
  
  }
  ngOnDestroy() {
    this.filters = null;
    if (this.subs !== null) {
      this.subs.forEach(a => a.unsubscribe());
    }
  }

  SolutionFilter(value) {
    this.store.dispatch(new LoadAdminSolutions({ term: value }))
    this.makeSelection('solution_code', value)
  }

  DelegationFilter(value) {
   
    this.store.dispatch(new LoadAdminDelegationMember({ term: value }));
    this.makeSelection('delegation_identity', value)
  }

  AccountNameFilter(value: string) {
    
    this.store.dispatch(new LoadAdminAccountName({ term: value }));
    this.makeSelection('account_name', value)

  }

  makeSelection(field: string, value: string) {
    this.store.dispatch(new SetFilterValues({ field, value }))
  }

  applyFilter() {
    if (this.CheckIfFilterNotEmpty()) {
      this.store.dispatch(new LoadAdminAccountsList())
      this.CloseDetailFilter();
      this.subs.push(this.accountsData$.subscribe(a => this.accountCount = a.length));
           
    }
  }

  private CheckIfFilterNotEmpty() {
    return (this.filters.solution_code !== "" || this.filters.delegation_identity !== "" || this.filters.account_name !== "")
  }

  CloseDetailFilter() {
    if (this.CheckIfFilterNotEmpty() && this.accountCount > 0) {
      this.store.dispatch(new DetailFilterToggle(false));
    }
  }

  ResetFilter() {
    this.store.dispatch(new ResetDetailFilter());
    this.resetValue = '';
  }
  SelectedValueFilterUpdate(value){
    this.makeSelection('solution_code', value.substring(0,4));
  }
  SelectedDelegationMemberFilterUpdate(value){    
    this.makeSelection('delegation_identity', value.split(' ')[0]);
  }

}
