import { Component, ElementRef, OnInit } from '@angular/core';
import { Store ,select} from '@ngrx/store';
import { IAdminState } from '../../store';
import {Observable,Subscription} from 'rxjs'
import { ModifyOrphanAccountsFilter, LoadAdminOrphanAccounts, LoadAdminOrphanFilteredAccounts } from '../../store/actions/admin-orphanaccounts-list.actions'
import { IAdminOrphanAccountState } from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state'
import { getOrphanAccNameFilterValue} from '../../store/index'



@Component({
  selector: 'app-2f82-admin-accounts-search-panel',
  templateUrl: './accounts-search-panel.component.html',
  styleUrls: ['./accounts-search-panel.component.scss'],
})
export class AdminAccountsSearchPanelComponent implements OnInit {

  constructor(private store: Store<IAdminOrphanAccountState>, private _eref: ElementRef) {
    this.nameFilterValue$ = this.store.pipe(select(getOrphanAccNameFilterValue));
  }


  public nameFilterValue$: Observable<any>;
  public globalMessage = 'this is a drill';

  private subs: Subscription[] = [];

  // public filters: CompositeFilterDescriptor;
  // public pills: tabContent[];

  // public $detailPanelOpen = this.store.pipe(select(getAdvancedFilterPanelOpen));


  public ngOnInit() {
    // this.subs.push(
    //   this.store.pipe(select(getGridFilters)).pipe(
    //     tap(filters => {
    //       this.filters = filters;
    //       this.pills = filters ? this.getFilterNames(filters) : [];
    //     }),
    //   ).subscribe()
    // );

  }

  // public onClick(event) {
  //   // detect clicks ouside of search panel (to close on blur)
  //   if (!this._eref.nativeElement.contains(event.target)) {
  //     // ignore open/close button
  //     if (event.target.parentNode ? event.target.parentNode.classList ? !event.target.parentNode.classList.contains('adv-search-btn') : false : false) {
  //       this.store.dispatch(new OpenCloseAdvancedSearch('close'));
  //     }
  //   }
  // }

  // public openPanel() {
  //   this.store.dispatch(new OpenCloseAdvancedSearch('open'));
  // }
  // public closePanel() {
  //   this.store.dispatch(new OpenCloseAdvancedSearch('close'));
  // }
  // public removePill(e) {
  //   this.store.dispatch(new ModifyAccountsFilter({ field: e, filter: null }));
  // }

  // public clearPills() {
  //   this.store.dispatch(new SetAccountsFilter({
  //     logic: 'and',
  //     filters: []
  //   }));
  // }

  public UIDinput(v) {
    this.store.dispatch(new ModifyOrphanAccountsFilter({
      field: 'account_name',
      value:v
    } ));
    this.store.dispatch(new LoadAdminOrphanFilteredAccounts());
  }


  // public getFilterNames(filterDescriptor): tabContent[] {
  //   return filterDescriptor.filters
  //     .map(f => f.field ? f.field : f.filters[0] ? f.filters[0].field ? f.filters[0].field : null : null)
  //     .filter(f => Boolean(f))
  //     .map(value => {
  //       return {
  //         text: this.tabConfig[value].title,
  //         value
  //       };
  //     });
  // }


}
