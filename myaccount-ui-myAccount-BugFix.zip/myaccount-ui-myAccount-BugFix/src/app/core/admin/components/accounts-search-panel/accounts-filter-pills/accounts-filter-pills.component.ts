import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-2f82-admin-accounts-filter-pills',
  templateUrl: './accounts-filter-pills.component.html',
  styleUrls: ['./accounts-filter-pills.component.scss']
})
export class AdminAccountsFilterPillsComponent {

  constructor() {
    this.deletePill = new EventEmitter();
    this.deleteAll = new EventEmitter();
  }

  @Output()
  public deletePill: EventEmitter<any>;

  @Output()
  public deleteAll: EventEmitter<any>;

  @Input()
  public pills: { text: string, value: string | number }[];

  public deleteTag(e) {
    this.deletePill.emit(e.value);
  }

}
