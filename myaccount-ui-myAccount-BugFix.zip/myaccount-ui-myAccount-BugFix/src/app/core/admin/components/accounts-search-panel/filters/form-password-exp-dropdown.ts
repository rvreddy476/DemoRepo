import { IAdminState, /*getAccountsGridState, getFilterPwdRemainingDays*/ } from './../../../store';
import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';


@Component({
	selector: 'app-2f82-admin-form-pwd-dropdown',
	template: `
    <app-2f82-admin-form-filter-multi-dropdown class="adv-input" [filter]="filter" [filterable]="false"
        [data]="options" filterField="pwdRemainingDays"
        (applyFilter)="selectionHandler($event)"
        [selectedValue]="pwdRemainingDaysFilterValue">
    </app-2f82-admin-form-filter-multi-dropdown>
  `,
	styles: [
		`
    `,
	],
})
export class AdminFormPasswordExpDropdown implements OnInit, OnDestroy {
	constructor(private store: Store<IAdminState>) {
		this.applyFilter = new EventEmitter();
	}

	//#region variables

	@Input()
	public filter: CompositeFilterDescriptor;

	@Input()
	public data: any[];
	@Input()
	public textField = 'name';
	@Input()
	public valueField = 'value';
	@Input()
	public filterField: string;
	@Input()
	public filterable = true;
	@Input()
	public selectedValue;

	@Output()
	public applyFilter: EventEmitter<any>;

	public subscriptions: Subscription[] = [];
	public buttonLabel = 'None';
	public pwdRemainingDaysFilterValue = [];


	public nestFilter: CompositeFilterDescriptor = null;

	public options = [{
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_SINCE_50_PLUS',
		value: '< -50',
		filterIdentifier: {
			operator: 'lt',
			value: -50,
		}
	}, {
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_SINCE_50_LESS',
		value: '>= -50',
		filterIdentifier: {
			operator: 'gt',
			value: -50,
		}
	}, {
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_SINCE_7_LESS',
		value: '> -7',
		filterIdentifier: {
			operator: 'gte',
			value: -7,
		}
	}, {
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_IN_7_LESS',
		value: '< 7',
		filterIdentifier: {
			operator: 'lte',
			value: 7,
		}
	}, {
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_IN_50_LESS',
		value: '<= 50',
		filterIdentifier: {
			operator: 'gte',
			value: 8,
		}
	}, {
		name: 'ACCOUNT_LIST.ROW_FILTER_OPTION.PASS_LIFETIME.EXP_IN_50_PLUS',
		value: '> 50',
		filterIdentifier: {
			operator: 'gt',
			value: 50,
		}
	}];

	//#endregion

	//#region init

	public ngOnInit() {
		this.subscriptions.push(
			// this.store.select(getFilterPwdRemainingDays).subscribe((x) => {
			// 	if (!x) {
			// 		return;
			// 	}
			// 	if (Array.isArray(x)) {

			// 		this.pwdRemainingDaysFilterValue = this.createSelectionFromFilter(x);


			// 	}

			// })


		);
	}

	public ngOnDestroy() {
		this.subscriptions.forEach((sub) => sub.unsubscribe());
	}

	//#endregion

	//#region calender actions

	public selectionHandler(event) {
		event = JSON.parse(event);


		if (!event.filters) {
			this.applyFilter.emit(JSON.stringify({
				logic: 'and',
				filters: []
			}));
			return;
		}


		// only keep final filter
		const filter = event.filters.length > 0 ? event.filters[event.filters.length - 1] : null;

		if (!filter) {
			this.applyFilter.emit(null);
			return;
		}


		const selectedFilter = this.createFilterFromSelection(filter.value);
		this.applyFilter.emit(JSON.stringify(selectedFilter));
	}


	//#endregion

	//#region helper function
	private createFilterFromSelection(selection): CompositeFilterDescriptor {

		switch (selection) {
			case '< -50':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'lt',
							value: -50,
						},
					],
				};
			case '>= -50':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'gt',
							value: -50,
						},
						{
							field: this.filterField,
							operator: 'lte',
							value: -8,
						},
					],
				};
			case '> -7':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'gte',
							value: -7,
						},
						{
							field: this.filterField,
							operator: 'lte',
							value: 0,
						},
					],
				};
			case '< 7':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'gte',
							value: 1,
						},
						{
							field: this.filterField,
							operator: 'lte',
							value: 7,
						},
					],
				};
			case '<= 50':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'gte',
							value: 8,
						},
						{
							field: this.filterField,
							operator: 'lte',
							value: 50,
						},
					],
				};
			case '> 50':
				return {
					logic: 'and',
					filters: [
						{
							field: this.filterField,
							operator: 'neq',
							value: null,
						},
						{
							field: this.filterField,
							operator: 'gt',
							value: 50,
						},
					],
				};
		}

	}
	private createSelectionFromFilter(filter: (CompositeFilterDescriptor | FilterDescriptor)[]): string[] {

		return this.options.filter(opt => {
			const id = opt.filterIdentifier;


			return filter.some(filter => {
				const match = ((id.operator === (filter as FilterDescriptor).operator) && (id.value === (filter as FilterDescriptor).value));

				return match;
			});


		}).map(val => val.value);
	}
	//#endregion
}
