import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-2f82-admin-accounts-global-search',
  templateUrl: './accounts-global-search.component.html',
  styleUrls: ['./accounts-global-search.component.scss']
})
export class AdminAccountsGlobalSearchComponent {

  @Output()
  public clickBtn: EventEmitter<any>;

  @Output()
  public onInput: EventEmitter<any>;

  @Input()
  public showButton = false;

  @Input()
  public showSearchIcon = false;

  @Input()
    public value = '';

  @Input()
  public placeholder = '';

  @Input()
  public message = 'No Accounts Found';

  constructor() {
    this.clickBtn = new EventEmitter();
    this.onInput = new EventEmitter();
  }

  public advPanelOpen = false;

}
