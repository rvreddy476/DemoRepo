import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { IAccount } from '../../../../shared/interfaces/shared/account/account';
import { Observable } from 'rxjs';
// import { getSelectedAccounts } from '../../store';
import { map, filter } from 'rxjs/operators';
import { DetailFilterToggle } from '../../store/actions/accounts-list.actions';
import { getFilterToggle, getAppliedFilterNumber, getAdminAccountsResetModal, getAdminEnableDisableModal, getAdminAddRemoveDeputiesModal } from '../../store';

@Component({
  selector: 'app-2f82-admin-accounts-list',
  templateUrl: './admin-accounts-list.component.html',
  styleUrls: ['./admin-accounts-list.component.scss'],
})
export class AdminAccountsListComponent implements OnInit {
  constructor(private store: Store<IAccount[]>) { }

  // public selected = this.store.select(getSelectedAccounts);

  // public selectedCount = this.selected.pipe(map((res) => res.length));

  // public hasSelected = this.selected.pipe(map((res) => res.length > 0));

  public viewState$ = this.store.pipe(select(getFilterToggle));
  public FilterData = this.store.pipe(select(getAppliedFilterNumber));
  public showResetModal = this.store.pipe(select(getAdminAccountsResetModal)).pipe(map(acc => acc.open));
  public showEnableDisableModal = this.store.pipe(select(getAdminEnableDisableModal)).pipe(map(acc => acc.open));
  public showDeputiesModal = this.store.pipe(select(getAdminAddRemoveDeputiesModal)).pipe(map(acc => acc.open));
  filterToggle: boolean;
  filterCount: number;

  public userAccList$: Observable<IAccount[]>;

  public ngOnInit() {
    // this.userAccList$ = this.store.pipe(select(getUserAccList));
    this.OpenDetailFilter();
    this.viewState$=this.store.pipe(select(getFilterToggle));
    this.viewState$.subscribe(a => this.filterToggle = a);
    this.FilterData.subscribe(a => { this.filterCount = a;/*  console.log(a); */ });
  }

  OpenDetailFilter() {
    this.store.dispatch(new DetailFilterToggle(true));
  }
  
}
