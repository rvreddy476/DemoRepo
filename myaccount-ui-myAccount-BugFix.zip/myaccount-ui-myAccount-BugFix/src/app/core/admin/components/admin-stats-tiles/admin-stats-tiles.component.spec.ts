import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StoreModule, Store } from '@ngrx/store';
import { AdminStatsTilesComponent } from './admin-stats-tiles.component'
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { AdminBarChartComponent } from './../../../../shared/components/tile-components/admin-bar-chart/admin-bar-chart.component';
import { reducers, AppState } from 'src/app/shared/store';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminReducer } from './../../store/reducers/admin-reducer';
import { AccountsSearchComponent } from 'src/app/shared/components/accounts-search/accounts-search.component';
import { ProfilesBgIconComponent } from 'src/app/shared/icons/profiles-bg-icon/profiles-bg-icon.component';
import { IconModule } from 'src/app/modules/icon.module';
import { SearchbarComponent } from 'src/app/shared/components/searchbar/searchbar.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { BaseReducer } from 'src/app/shared/store/reducers/base.reducer';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { defaultTestStore } from 'src/app/shared/mock-data';


describe('AdminStatsTilesComponent', () => {
  let component: AdminStatsTilesComponent;
  let fixture: ComponentFixture<AdminStatsTilesComponent>;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AdminStatsTilesComponent,
        AdminBarChartComponent,
        AccountsSearchComponent,
        SearchbarComponent
      ],
      imports: [
        TranslateModule.forRoot(),
        KendoModule,
        // StoreModule.forRoot({id:BaseReducer}),
        // StoreModule.forFeature('adminModule',{adminStats:AdminReducer}),
        // StoreModule.forFeature('base',{base:BaseReducer}),
        IconModule,
        RouterTestingModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule
      ],
      providers: [
        provideMockStore({ initialState })
      ]
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(AdminStatsTilesComponent);
        component = fixture.componentInstance;
        component.disabled = true;
        fixture.detectChanges();
        store = TestBed.get(Store);
      });;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminStatsTilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
