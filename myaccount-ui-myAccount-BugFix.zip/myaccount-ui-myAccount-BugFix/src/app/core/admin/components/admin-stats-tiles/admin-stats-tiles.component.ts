import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { map, tap, distinctUntilChanged, pairwise, filter } from 'rxjs/operators';
import { Chart } from 'chart.js';
import 'rxjs/add/observable/of';
import { Router, ActivatedRoute } from '@angular/router';
import { IAccountsStats } from 'src/app/shared/interfaces/user/user-accounts-stats';
import { AccountDivisionEnum } from 'src/app/shared/enums';
import { TileTypeEnum } from 'src/app/shared/enums/tile-type.enum';
import { TAccountDelegationType } from 'src/app/shared/interfaces/shared/account/account';
import { IBaseState } from 'src/app/shared/interfaces/base-state';
import { LoadAccountsStats } from 'src/app/shared/store';
import { getAccountsStatsLoaded, getAccountsStatsLoading, getAccountsStats, getGlobalDelegationMode } from 'src/app/shared/store/selectors';
import { IAccountsState } from 'src/app/core/accounts/store';
import { LoadAdminStats } from '../../store/actions/admin-actions';
import { getAdminAccountStats } from '../../store/selectors';
import { ISuperAdminAccountsStatsState } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-state';
import { ISuperAdminAccountsStats } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats';

@Component({
  selector: 'app-2f82-admin-stats-tiles',
  templateUrl: './admin-stats-tiles.component.html',
  styleUrls: ['./admin-stats-tiles.component.scss']
})
export class AdminStatsTilesComponent implements OnInit {

  public data$: Observable<ISuperAdminAccountsStatsState> = this.store.pipe(select(getAdminAccountStats)).pipe(distinctUntilChanged());
  public disabled$: Observable<number>;
  public pending$: Observable<number>;
  public orphan$: Observable<number>;
  public total$: Observable<number>;
  public loading$: Observable<boolean>;
  public loaded$: Observable<boolean>;
  public accountsData$: Observable<any[]>;
  public lineChart;
  public pcEnabled;
  public pcDisabled;
  public tileTypes = TileTypeEnum;
  public title = "All Accounts"

  public data: ISuperAdminAccountsStats;
  public loaded = false;
  public loading = true;
  public dateItems: Array<DateFilter>;
  public disabled = false;
  public accounts: Array<any> = []

  public chartId = '';
  private enabledAcc: number;
  private disabledAcc: number;
  private initialised = false;

  public pending: number;
  public orphan: number;
  public total: number;
  public lastUpdatedDate: string;


  private subs: Subscription[];

  public selectedItem: DateFilter;

  constructor(private store: Store<IBaseState>, public router: Router, private activatedRoute: ActivatedRoute) {
    this.chartId = new Date().getTime().toString() + Math.random();
  }




  public ngAfterViewInit() {
    this.initialised = true;
    this.InitChart();
  }

  public valueChange(value: any): void {
    this.selectedItem = value;
    this.loadStats();
  }

  public loadStats() {
    this.loaded = false;
    this.loading = true;
    this.store.dispatch(new LoadAdminStats({ numberOfDays: this.selectedItem.value }));
    this.store.pipe(select(getAdminAccountStats)).pipe(distinctUntilChanged()).subscribe(x => {

      if (x.loaded && !x.loading) {
        this.total = x.data.total_accounts;
        this.disabledAcc = x.data.disabled;
        this.accounts = x.data.account_stats;
        this.enabledAcc = this.total - this.disabledAcc;
        this.loaded = x.loaded;
        this.loading = x.loading;
        this.orphan = x.data.orphan;
        this.pending = x.data.pending;
        this.accountsData$ = Observable.of<any[]>(this.accounts);
        this.lastUpdatedDate = new Date(x.data.last_updated_date).toUTCString();
        //this.lastUpdatedDate=x.data.last_updated_date;
        this.InitChart();
      }
    });

  }
  public ngOnInit() {
    //console.log(this.activatedRoute.component['name']);
    this.InitDropdown();
    this.loadStats();
  }

  public ngOnDestroy() {
  }

  public navigateViaTile(tile) {
    this.router.navigate(['./accounts', { tile }]);
  }
  public InitChart() {

    // don't init chart during unit-tests as no canvas is available
    // Netscape is navigator appName during jest unit tests
    if (/jsdom/.test(window.navigator.userAgent)) {
      return;
    }

    if (!this.initialised) {
      return;
    }

    const accSum = this.enabledAcc + this.disabledAcc;
    const greyMode = accSum === 0;
    this.pcEnabled = greyMode ? 0 : Math.round((this.enabledAcc / accSum) * 100);
    this.pcDisabled = greyMode ? 1 : Math.round((this.disabledAcc / accSum) * 100);
    this.lineChart = new Chart(this.chartId, {
      type: 'doughnut',
      data: {
        datasets: [
          {
            borderWidth: [0, 0],
            backgroundColor: greyMode ? ['#c8c9d2', '#c8c9d2'] : ['#83ba10', '#266180'],
            data: [this.enabledAcc, this.disabledAcc],
          },
        ],

        labels: [`Enabled`, `Disabled`],
      },
      options: {
        animation: {
          duration: (!this.loading && this.loaded) ? 500 : 0
        },
        maintainAspectRatio: false,
        cutoutPercentage: 90,
        rotation: -0.775 * Math.PI,
        events: ['click'],
        legend: {
          display: false,
        },
        tooltips: {
          mode: 'nearest',
        },
        layout: {
          padding: {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
          },
        },
      },
    });
  }

  public InitDropdown() {
    this.dateItems = new Array<DateFilter>();
    this.dateItems.push(new DateFilter("Past 24 Hours", 1));
    this.dateItems.push(new DateFilter("Past 7 Days", 7));
    this.dateItems.push(new DateFilter("Past 30 Days", 30));
    this.dateItems.push(new DateFilter("All", -1));
    this.selectedItem = this.dateItems[0];
  }


  tileClick(action: string) {
    if (action === 'create_one') {

      this.router.navigate(['/create/one']);
    }
    else if (action === "manage_accounts") {
      this.router.navigate(['accounts'], { relativeTo: this.activatedRoute });
    }
    else if (action === "followup") {
      this.router.navigate(['follow-up'], { relativeTo: this.activatedRoute });
    }
    else if (action === "orphans"){
      this.router.navigate(['orphans'], {relativeTo : this.activatedRoute});
    }
  }
}

export class DateFilter {
  public key: string;
  public value: number;

  public constructor(key, value) {
    this.key = key;
    this.value = value;
  }
}