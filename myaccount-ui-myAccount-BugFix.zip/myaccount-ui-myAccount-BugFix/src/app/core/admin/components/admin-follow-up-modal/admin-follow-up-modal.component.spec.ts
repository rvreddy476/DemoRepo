import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminFollowUpModalComponent } from './admin-follow-up-modal.component';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { IconModule } from 'src/app/modules/icon.module';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';

describe('AdminFollowUpModalComponent', () => {
  let component: AdminFollowUpModalComponent;
  let fixture: ComponentFixture<AdminFollowUpModalComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule],
      declarations: [AdminFollowUpModalComponent, BaseModalComponent],
      providers: [
        provideMockStore({ initialState })
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(AdminFollowUpModalComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
