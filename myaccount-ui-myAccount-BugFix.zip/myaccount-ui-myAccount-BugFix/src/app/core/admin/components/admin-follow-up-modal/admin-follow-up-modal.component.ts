import { closeAdminFollowUpModal, cancelAdminPendingRequest } from '../../store/actions/admin-followup-list.actions';
import { IFollowUpState, TActionFollowUp } from './../../../../shared/interfaces/shared/account/follow-up';
import { Component, OnInit, EventEmitter } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {  getAdminFollowUpModal } from '../../store/selectors/index';

@Component({
  selector: 'app-admin-2f82-follow-up-modal',
  templateUrl: './admin-follow-up-modal.component.html',
  styleUrls: ['./admin-follow-up-modal.component.scss']
})
export class AdminFollowUpModalComponent implements OnInit {

  constructor(private store: Store<IFollowUpState>) {
    this.close = new EventEmitter();
  }

  public close: EventEmitter<any>;

  public open = false;
  public title = 'Delete Request';
  public message = '';
  public messageParams = null;
  public largeIcon = null;
  public titleIcon = 'Delete';
  public action: TActionFollowUp = null;

  public loading = false;
  public finished = false;

  public rejectMessage = '';

  public ngOnInit() {
    
    this.store.pipe(select(getAdminFollowUpModal)).subscribe(x => {
      if (!x.open) {
        this.open = false;
        return;
      }
      this.open = x.open;
      this.action = x.action;
      this.loading = x.loading;
      // request response has been recieved
      if (x.res) {
        const hasError = x.res.error !== false;
        this.message = x.res.type === 'SUCCESS' ? 'FOLLOW_UP.CANCEL_MODAL.RESPONSE.SUCCESS_MESSAGE' : '';
        this.finished = !!x.res;
        this.largeIcon = hasError ? 'Failed' : 'Success';
        this.titleIcon = null;
        this.title = `FOLLOW_UP.CANCEL_MODAL.RESPONSE.${hasError ? 'FAILED' : 'SUCCESS'}`;
      } else if (!x.res && x.loading) {
        // waiting for response
        this.message = null;
        this.largeIcon = 'Loading';
        this.title = 'FOLLOW_UP.CANCEL_MODAL.RESPONSE.LOADING';
        this.titleIcon = null;
        this.finished = false;
      } else {
        // ask user to take action or not
        switch (x.action.type) {
        
          case 'ACCOUNT_CREATION':
            this.message = 'FOLLOW_UP.CANCEL_MODAL.CANCEL_RESET_PASS_MESSAGE';
            break;
        }
        this.messageParams = { ac: (x.action.domain.name ? x.action.domain.name + '\\' : '') + x.action.accountName };
        this.largeIcon = null;
        this.title = 'FOLLOW_UP.CANCEL_MODAL.TITLE';
        this.titleIcon = 'Delete';
        this.finished = false;
      }
    });
  }

  public closeModal() {
    this.store.dispatch(new closeAdminFollowUpModal());
    this.rejectMessage = '';
  }

  public reject() {   
        this.store.dispatch(new cancelAdminPendingRequest(this.action.id));
  }

}
