import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminActionFollowUpComponent } from './admin-action-follow-up.component';
import { AppState } from './../../../../shared/store/reducers/index';
import { defaultTestStore } from './../../../../shared/mock-data';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store, select } from '@ngrx/store';
import { IconModule } from 'src/app/modules/icon.module';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { AdminFollowUpBaseComponent } from '../admin-follow-up-base/admin-follow-up-base.component';
import { AdminFollowUpModalComponent } from '../admin-follow-up-modal/admin-follow-up-modal.component';
import { DelegationSelectionPanelComponent } from 'src/app/shared/components/delegation-selection-panel/delegation-selection-panel.component';
import { PageTitleComponent } from 'src/app/shared/components/page-title/page-title.component';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';

describe('AdminActionFollowUpComponent', () => {
  let component: AdminActionFollowUpComponent;
  let fixture: ComponentFixture<AdminActionFollowUpComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule, IconModule],
      declarations: [
        AdminActionFollowUpComponent, 
        AdminFollowUpModalComponent,
        BaseModalComponent,
        AdminFollowUpBaseComponent,
        DelegationSelectionPanelComponent,
        PageTitleComponent,
        DateDisplayComponent
      ],
      providers: [
        provideMockStore({ initialState })
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(AdminActionFollowUpComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
