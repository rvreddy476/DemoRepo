import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
 import {  getAdminFollowUpActions } from '../../store';
 //import { requestActionFollowUp, openFollowUpModal } from '../../store/actions/follow-up-list.actions';
import { tap, filter } from 'rxjs/operators';
import { TActionFollowUp, IFollowUpState } from '../../../../shared/interfaces/shared/account/follow-up';
import { getGlobalDelegationMode } from 'src/app/shared/store/selectors';
import { requestAdminActionFollowUp, openAdminFollowUpModal } from '../../store/actions/admin-followup-list.actions';


@Component({
  selector: 'app-2f82-admin-action-follow-up',
  templateUrl: './admin-action-follow-up.component.html',
  styleUrls: ['./admin-action-follow-up.component.scss'],
})
export class AdminActionFollowUpComponent implements OnInit, OnDestroy {

  constructor(private store: Store<IFollowUpState>) { }

  public $actions: Observable<TActionFollowUp[]>;

  public cols = {
    accountName: true,
    domain: true,
    requestor: true,
    validator: true,
    type: true,
    creationDate: true,
    scheduledDate: false,
    status: true,
    justification:true,
    cancellable: true
  };


  public ngOnInit() {
    this.store.dispatch(new requestAdminActionFollowUp);
    this.$actions = this.store.pipe(
      select(getAdminFollowUpActions)
    );
  }

  public ngOnDestroy() {
   
  }

  public isRowSelected() {
    return () => false;
  }
  public rowClass(row) {
    return { followuprow: true };
  }

  public cancelAction = action => {
    
     this.store.dispatch(new openAdminFollowUpModal(action));
  }

  public showDetail = elem => {
    elem.srcElement.closest('.detail-wrapper').classList.toggle('detail-open');
  }
}
