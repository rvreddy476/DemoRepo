import { Component, OnInit } from '@angular/core';
import { Observable, of } from 'rxjs'
import { Store, select } from '@ngrx/store'
import { IAdminOrphanAccountState, TOrhpanMode } from '../../../../../shared/interfaces/super-admin/admin-orphanlist-state'
import { map } from 'rxjs/operators';
import { getOrphanAccountsMode } from '../../../store/index'
import { SetOrphanAccountMode } from '../../../store/actions/admin-orphanaccounts-list.actions'

@Component({
  selector: 'app-2f82-orphan-selection-panel',
  templateUrl: './orphan-selection-panel.component.html',
  styleUrls: ['./orphan-selection-panel.component.scss']
})
export class OrphanSelectionPanelComponent implements OnInit {
  public class$: Observable<{
    enduser: string[],
    solution: string[],
    all: string[],
  }> = of({
    enduser: [],
    solution: [],
    all: [],
  });
  constructor(private store: Store<IAdminOrphanAccountState>) { }

  public ngOnInit() {
    this.class$ = this.store.pipe(select(getOrphanAccountsMode)).pipe(
      map((del) => {
        return {
          enduser: del === 'NOENDUSER' ? ['active'] : [],
          solution: del === 'NOSOLUTION' ? ['active'] : [],
          enduser_solution:del === 'NOSOLENDUSER'? ['active'] : [],
          all: del === 'ALL' ? ['active'] : [],
        };
      })
    );
  }
  public selectOrphanMode = (orphanMode: TOrhpanMode) => {
    
    this.store.dispatch(new SetOrphanAccountMode(orphanMode));
  };
}
