import { IAdminOrphanAccountState } from '../../../../../shared/interfaces/super-admin/admin-orphanlist-state'
import { Store, select } from '@ngrx/store';
import { SortDescriptor, State } from '@progress/kendo-data-query';
import {
    getOrphanVisibleAccounts,
    getOrphanAccountsGridState,
    getOrphanSelectAllStatus,
    getOrphanGridSort,
    getOrphanSelectedAccounts,
    getOrphanAccountsStateLoading,
    getOrphanGridFilters,
    getOrphanSortedFilteredAccountList
} from '../../../store/index'
import { LoadAdminOrphanAccounts } from '../../../store/actions/admin-orphanaccounts-list.actions'
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataBindingDirective } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { IOrphanAccount } from '../../../../../shared/interfaces/super-admin/admin-orphanlist-state'
import { map, withLatestFrom, filter } from 'rxjs/operators';
import { OrphanSetSelectedAccounts, OrphanSetViewOnlySelectedAccounts,OrphanSelectAllAccounts, SetOrphanAccountsSort, SetOrphanAccountsPage, SetOrphanAccountsFilter } from '../../../store/actions/admin-orphanaccounts-list.actions'
import { Observable, BehaviorSubject, Subscription,combineLatest } from 'rxjs';
import { SetViewOnlySelectedAccounts } from '../../../store/actions/accounts-list.actions';

@Component({
    selector: 'app-2f82-admin-orphan-list',
    templateUrl: './admin-orphan-list.component.html',
    styleUrls: ['./admin-orphan-list.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class AdminOrphanListComponent implements OnInit {
    @ViewChild(DataBindingDirective) dataBinding: DataBindingDirective;
    @ViewChild('grid') private grid;

    public gridHeight = 0;
    public data$: any;
    public gridState: State;
    private stateChange = new BehaviorSubject<any>(this.gridState);
    public selectAllBtnState$ = this.store.pipe(select(getOrphanSelectAllStatus));
    public sortMultiple = false;
    public allowUnsort = true;
    public gridData: any[];
    public gridView: any[];
    public subscriptions: Subscription[] = [];
    public isLoading$: Observable<boolean>;
    public selectedAccounts: number[] = [];
    public mySelection: string[] = [];
    public loading: boolean = false;
    public columnConfig;

    public sort: SortDescriptor[] = [{
        field: 'domain',
        dir: 'asc'
    }, {
        field: 'account_name',
        dir: 'asc'
    }, {
        field: 'password_status',
        dir: 'asc'
    }, {
        field: 'password_lifetime',
        dir: 'asc'
    }, {
        field: 'solution',
        dir: 'asc'
    }, {
        field: 'account_type',
        dir: 'asc'
    }, {
        field: 'directory_type',
        dir: 'asc'
    }];



    public constructor(private store: Store<IAdminOrphanAccountState>) {
        this.getColumnConfig();
    }

    public filter: CompositeFilterDescriptor = { filters: [], logic: 'and' };

    public rowClass(e) {
        let res = 'row';
        if (e.dataItem.locked) {
            res += ' locked';
          }
          if (e.dataItem.hp) {
            res += ' hp';
          }
        return res;
    }

    


    public ngOnInit(): void {
        //this.store.dispatch(new LoadAdminOrphanAccounts());
        //this.store.dispatch(new SetViewOnlySelectedAccounts(true));
       
        this.isLoading$ = this.store.pipe(select(getOrphanAccountsStateLoading));
        this.subscriptions.push(
        this.store.pipe(select(getOrphanGridFilters)).subscribe((filter) => {
            this.grid.filterService.changes.next(filter);
            this.filter = filter;
        }),
        this.store.pipe(select(getOrphanGridSort)).subscribe((sort) => {
            this.sort = sort;
        }),
        this.store.pipe(select(getOrphanVisibleAccounts)).subscribe(x => {
            
            if (x.loaded) {
                this.loading = false;
                this.gridView = x.list;
            }
        }),

        //this.data$= this.store.pipe(select(getOrphanVisibleAccounts));
        this.store.pipe(select(getOrphanSelectedAccounts)).subscribe((selected) => {
            this.selectedAccounts = selected;
        }),

        this.store.pipe(select(getOrphanAccountsGridState)).subscribe((gridState) => {
            this.gridState = gridState;
           
        }));


        this.grid.selectionChange.pipe(
           // dont act on locked or hp accounts selection
        filter((e: any) => {
            return [...e.selectedRows, ...e.deselectedRows].every(row => (!row.dataItem.hp && !row.dataItem.locked));
          }),
            filter((e: any) => {
                const wasSelectAllBtn = (e.ctrlKey && e.shiftKey);
                // prevent default behaviour when clicking on the "select all" button
                return !wasSelectAllBtn;
            }),
            withLatestFrom(this.store.pipe(select(getOrphanSelectedAccounts)), this.store.pipe(select(getOrphanSortedFilteredAccountList))),
            map(([change, selected, filtered]) => {
                let result = filtered.filter(o1 => selected.some(o2 => o1.id === o2.id));
               if(result.length ==0 )
               {
                selected=[];
               }
                else{

                }
                  const added = change.selectedRows.filter(row => !row.dataItem.locked).map(acc => acc.dataItem.id);
                const removed = change.deselectedRows.map(acc => acc.dataItem.id);
                const newSelection = [...selected, ...added].filter(cur => removed.indexOf(cur) === -1);
                const isAll = filtered.filter(acc => !acc.locked).every(acc => newSelection.indexOf(acc.id) !== -1);
                console.log(newSelection);
                
                this.store.dispatch(
                    new OrphanSetSelectedAccounts({ ids: newSelection, isAll })
                );
               
                
            })
        ).subscribe();
    }

    public ngOnDestroy(){
        this.subscriptions.forEach((sub) => {
            sub.unsubscribe();
          });
    }

    public pageChange(state: any): void {
        this.stateChange.next(state);
    }
    public getSortDirection(field) {
        const filter = this.sort ? this.sort.filter(s => s.field === field)[0] : null;
        return filter ? filter.dir : null;
    }

    public sortChangeHandler(sort: SortDescriptor[]): void {
        this.sort = sort;
        this.store.dispatch(new SetOrphanAccountsSort(sort));
    }
    public pageChangeHandler(state: State): void {
        this.store.dispatch(new SetOrphanAccountsPage(state));

    }

    public isRowSelected(selected) {
        return (row) => {
            return selected.indexOf(row.dataItem.id) !== -1;
        };
    }
    public derivePasswordStatus(acc: IOrphanAccount) {

        if (acc.pwdStatus === 'NO_PASSWORD') {
            return {
                text: `-`,
                value: null
            };
        }
        if (acc.pwdStatus === 'EXPIRED') {
            return {
                text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRED_SINCE`,
                value: { d: Math.abs(acc.pwd_expiration_days) }
            };
        } else {
            return {
                text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN`,
                value: { d: Math.abs(acc.pwd_expiration_days) }
            };
        }
    }

    public onSelectAllChange() {
        this.store.dispatch(new OrphanSelectAllAccounts());
    }

    private getColumnConfig = () => {
        this.columnConfig = {
          id: {
            title: 'ID',
            field: 'id',
            width: 0,
          },
          uid: {
            title: 'ACCOUNT_LIST.ROW_NAME.UID',
            field: 'name',
            width: 150,
          },
          pwdStatus: {
            title: 'ACCOUNT_LIST.ROW_NAME.PASS_STATUS',
            field: 'pwdStatus',
            width: 100,
          },
          pwdRemainingDays: {
            title: 'ACCOUNT_LIST.ROW_NAME.PASS_LIFETIME',
            field: 'lifetime',
            width: 130,
          },
          contextName: {
            title: 'ACCOUNT_LIST.ROW_NAME.SOLUTION',
            field: 'solution',
            width: 100,
          },
          type: {
            title: 'ACCOUNT_LIST.ROW_NAME.TYPE',
            field: 'type',
            width: 80,
          },
          directoryEnvironment: {
            title: 'ACCOUNT_LIST.ROW_NAME.ENVIRONMENT',
            field: 'environment',
            width: 80,
          },
          directoryDomain: {
            title: 'ACCOUNT_LIST.ROW_NAME.DOMAIN',
            field: 'domain',
            width: 80,
          },
          division: {
            title: 'ACCOUNT_LIST.ROW_NAME.DIVISION',
            field: 'division',
            width: 230,
          },
          locked: {
            title: '',
            field: 'locked',
            width: 70,
          },
        };
      }
}