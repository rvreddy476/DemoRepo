import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppState } from 'src/app/shared/store/reducers/index';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { AdminOrphanAccountDetailSearchComponent } from './admin-orphan-account-detail-search.component';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { IconModule } from 'src/app/modules/icon.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

describe('AdminOrphanAccountDetailSearchComponent', () => {
  let component: AdminOrphanAccountDetailSearchComponent;
  let fixture: ComponentFixture<AdminOrphanAccountDetailSearchComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule,IconModule,
        ReactiveFormsModule,
        FormsModule
      ],
      declarations: [ AdminOrphanAccountDetailSearchComponent ],
      providers: [
        provideMockStore({ initialState })
      ]
    })
    .compileComponents().then(()=> {
      fixture = TestBed.createComponent(AdminOrphanAccountDetailSearchComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOrphanAccountDetailSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
