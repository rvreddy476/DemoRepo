import { Component, OnInit, ViewEncapsulation, ViewChild, Input, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import {
  getOrphanFilterToggle,
  getOrphanAppliedFilterNumber,
  getOrphanAccountAssignModal,
  getOrphanAccountsStateLoading,
  getOrphanSelectedAccounts
} from '../../store';
import { OrphanDetailFilterToggle, OpenAssignOrphanModal } from '../../store/actions/admin-orphanaccounts-list.actions'
import { TActionFollowUp } from '../../../../shared/interfaces/shared/account/follow-up';
import { IAdminOrphanAccountState } from '../../../../shared/interfaces/super-admin/admin-orphanlist-state'
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-admin-orphan-accounts',
  templateUrl: './admin-orphan-accounts.component.html',
  styleUrls: ['./admin-orphan-accounts.component.scss']
})
export class AdminOrphanAccountsComponent implements OnInit {

  public constructor(private store: Store<IAdminOrphanAccountState>,private translate: TranslateService) {

  }

  showAssignModal: boolean = false;
  public isLoading$:any;
  public showAssignOrphanModal = this.store.pipe(select(getOrphanAccountAssignModal)).subscribe(p => {
    this.showAssignModal = p.open;
  });
  // this.store.pipe(select(getOrphanAccountAssignModal), map(modal => modal.open));
  

  public $actions: Observable<TActionFollowUp[]>;

  public cols = {
    accountName: true,
    domain: true,
    requestor: true,
    validator: true,
    type: true,
    creationDate: true,
    scheduledDate: false,
    status: true,
    justification: true,
    cancellable: true
  };


  public openAssignOrphanModal(): void {

    this.store.dispatch(new OpenAssignOrphanModal())
  }


  public ngOnDestroy() {

  }

  public isRowSelected() {
    return () => false;
  }
  public rowClass(row) {
    return { followuprow: true };
  }



  public cancelAction = action => {
    ;
    //this.store.dispatch(new openAdminFollowUpModal(action));
  }

  public showDetail = elem => {
    //elem.srcElement.closest('.detail-wrapper').classList.toggle('detail-open');
  }



  // public selected = this.store.select(getSelectedAccounts);

  // public selectedCount = this.selected.pipe(map((res) => res.length));

  // public hasSelected = this.selected.pipe(map((res) => res.length > 0));
 
  public viewState$ = this.store.pipe(select(getOrphanFilterToggle));
  public FilterData = this.store.pipe(select(getOrphanAppliedFilterNumber));
  filterToggle: boolean;
  filterCount: number;
  public selection:Observable<number[]>;

  public ngOnInit() {
    
    // this.userAccList$ = this.store.pipe(select(getUserAccList));
    this.OpenDetailFilter();
    this.viewState$ = this.store.pipe(select(getOrphanFilterToggle));
    this.isLoading$ = this.store.pipe(select(getOrphanAccountsStateLoading));
    this.viewState$.subscribe(a => this.filterToggle = a);   
    this.FilterData.subscribe(a => { this.filterCount = a;/*  console.log(a); */ });
    this.selection = this.store.pipe(select(getOrphanSelectedAccounts));
    
  }
 
  OpenDetailFilter() {
    this.store.dispatch(new OrphanDetailFilterToggle(true));
  }

}
