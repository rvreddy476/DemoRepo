import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppState } from 'src/app/shared/store/reducers/index';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { IconModule } from 'src/app/modules/icon.module';
import { AdminOrphanAccountsComponent } from './admin-orphan-accounts.component';
import { AdminAccountsSearchPanelComponent } from '../accounts-search-panel/accounts-search-panel.component';
import { AdminOrphanAccountDetailSearchComponent } from './admin-orphan-account-detail-search/admin-orphan-account-detail-search.component';
import { OrphanSelectionPanelComponent } from './orphan-selection-panel/orphan-selection-panel.component';
import { AdminViewClearSelectionComponent } from '../admin-view-clear-selection/admin-view-clear-selection.component';
import { AdminOrphanListComponent } from './admin-orphan-list/admin-orphan-list.component';
import { AdminAssignOrphanModalComponent } from '../modal/assign-orphan-modal/assign-orphan-modal.component';
import { AdminAccountsGlobalSearchComponent } from '../accounts-search-panel/accounts-global-search/accounts-global-search.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';

describe('AdminOrphanAccountsComponent', () => {
  let component: AdminOrphanAccountsComponent;
  let fixture: ComponentFixture<AdminOrphanAccountsComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule,IconModule, ReactiveFormsModule,
        FormsModule],
      declarations: [ AdminOrphanAccountsComponent,AdminAccountsSearchPanelComponent, 
        AdminOrphanAccountDetailSearchComponent, OrphanSelectionPanelComponent, 
        AdminViewClearSelectionComponent, AdminOrphanListComponent, 
        AdminAssignOrphanModalComponent, AdminAccountsGlobalSearchComponent,
        BaseModalComponent
       ],
      providers: [
        provideMockStore({ initialState })
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(AdminOrphanAccountsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOrphanAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
