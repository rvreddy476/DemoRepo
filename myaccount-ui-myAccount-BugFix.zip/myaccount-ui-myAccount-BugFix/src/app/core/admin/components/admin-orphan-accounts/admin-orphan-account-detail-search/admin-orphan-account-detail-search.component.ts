import { Component, OnInit, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import {
  IAdminState,
  getOrphanAccounts,
  getOrphanUniqueData,
  getOrphanFilters,
  getSolutionSearchData,
  getOrphanAccountsApiState,
  getOrphanVisibleAccounts
} from '../../../store/index';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import {
  LoadAdminOrphanAccounts,
  OrphanDetailFilterToggle,
  OrphanResetDetailFilter,
  SetOrphanFilterValues,
  LoadOrphanSolutionWithTerm,
  LoadAdminOrphanFilteredAccounts
} from '../../../store/actions/admin-orphanaccounts-list.actions'

@Component({
  selector: 'app-admin-orphan-account-detail-search',
  templateUrl: './admin-orphan-account-detail-search.component.html',
  styleUrls: ['./admin-orphan-account-detail-search.component.scss']
})
export class AdminOrphanAccountDetailSearchComponent implements OnInit {

  @Input() detailFilterToggle: boolean;

  resetValue: string = '';
  filters: any = {
    account_name: '',
    solution_code: '',
    environment: '',
    account_lifetime: '',
    password_status: '',
    password_lifetime: '',
    domain: '',
    account_type: '',
    account_uid:''
  }

  accountTypes:String[]=['TECHNICAL','SERVICE']

  subs: Subscription[] = [];

  public accountsData$ = this.store.select(getOrphanAccountsApiState);
  public accountsData;
  public accountNumber;
  public Solutions$ = this.store.select(getSolutionSearchData).pipe(map(data => data));
  public domainList$ = this.store.select(getOrphanUniqueData).pipe(map(data => data.directoryDomain))
  public pwdStatus$ = this.store.select(getOrphanUniqueData).pipe(map(data => data.pwdStatus))
  public environment$ = this.store.select(getOrphanUniqueData).pipe(map(data => data.directoryEnvironment))
  public accountType$ = this.store.select(getOrphanUniqueData).pipe(map(data => data.type))
  public filter$ = this.store.pipe(select(getOrphanFilters));
  constructor(private store: Store<IAdminState>) {
  }

  ngOnInit(): void {    
    this.store.pipe(select(getOrphanAccountsApiState)).subscribe((data) => {
      this.accountsData=data;
  });
    this.subs.push(this.filter$.subscribe(filter => {
      
      this.filters.account_name = filter.account_name === null ? '' : filter.account_name[0];
      this.filters.solution_code = filter.solution_code === null ? '' : filter.solution_code[0];
      this.filters.environment = filter.environment === null ? '' : filter.environment[0];
      this.filters.password_status = filter.password_status === null ? '' : filter.password_status[0];
      this.filters.password_lifetime = filter.password_lifetime === null ? '' : filter.password_lifetime[0];
      this.filters.domain = filter.domain_name === null ? '' : filter.domain_name[0];
      this.filters.account_type = filter.account_type === null ? '' : filter.account_type[0];
      this.filters.account_uid = filter.account_uid === null ? '' : filter.account_uid[0];
    }));  
   
    this.ResetFilter();
  }
  ngOnDestroy() {
    this.filters = null;
    if (this.subs !== null) {
      this.subs.forEach(a => a.unsubscribe());
    }
  }

  SolutionFilter(value) {
    this.store.dispatch(new LoadOrphanSolutionWithTerm(value));
    this.makeSelection('solution_code', value)
  }

  makeSelection(field: string, value: string) {
    this.store.dispatch(new SetOrphanFilterValues({ field, value }))
  }

  isInCorrectUIDFilter(){
    return this.filters.account_uid.length<5 && this.filters.account_uid.length>0
   }

 

  applyFilter() {
    if(this.IsPrimaryFilterApplied()){
      this.CloseDetailFilter();
      this.store.dispatch(new LoadAdminOrphanAccounts())
      this.subs.push(this.accountsData$.subscribe(a => this.accountNumber = a.length));
      //this.store.dispatch(new LoadAdminOrphanFilteredAccounts())
    }
  }

  private IsPrimaryFilterApplied() {
    if(this.filters.account_uid.length>0 && this.filters.account_uid.length<5)
 return false;
    return !(this.filters.account_uid === "" && this.filters.account_type === "")
  }

  CloseDetailFilter() {  
    if (this.IsPrimaryFilterApplied() && this.accountNumber > 0) {
    this.store.dispatch(new OrphanDetailFilterToggle(false));
    }
  }

  ResetFilter() {
    this.store.dispatch(new OrphanResetDetailFilter());
    this.resetValue = '';
    this.filters.account_uid='';
    //this.CloseDetailFilter();
  }
}