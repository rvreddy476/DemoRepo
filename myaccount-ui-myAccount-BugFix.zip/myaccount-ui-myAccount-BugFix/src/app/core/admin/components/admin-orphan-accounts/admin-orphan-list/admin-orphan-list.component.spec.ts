import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppState } from 'src/app/shared/store/reducers/index';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { AdminOrphanListComponent } from './admin-orphan-list.component';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { SortOrderIconComponent } from 'src/app/shared/icons/sort-order-icon/sort-order-icon.component';
import { IconModule } from 'src/app/modules/icon.module';

describe('AdminOrphanListComponent', () => {
  let component: AdminOrphanListComponent;
  let fixture: ComponentFixture<AdminOrphanListComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), RouterTestingModule, KendoModule,IconModule],
      declarations: [ AdminOrphanListComponent],
      providers: [
        provideMockStore({ initialState })
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(AdminOrphanListComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOrphanListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
