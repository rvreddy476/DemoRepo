import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';
import {map, tap, delay} from 'rxjs/operators';
import { TScheduledPasswordFollowUp, TActionFollowUp } from '../../../../shared/interfaces/shared/account/follow-up';
import { formatDisplayName } from 'src/app/shared/helper-functions';

@Component({
  selector: 'app-2f82-admin-follow-up-base',
  templateUrl: './admin-follow-up-base.component.html',
  styleUrls: ['./admin-follow-up-base.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: {
    style: `
      display: flex;
      flex-direction: column;
      flex-grow: 1;
    `
  }
})
export class AdminFollowUpBaseComponent implements OnInit {

  constructor() {
    this.cancelAction = new EventEmitter();
  }
  @ViewChild('gridSizer') private gridSizer;

  @Input() public $actions: Observable< TActionFollowUp[]>;
  public gridHeight: number;

  @Input()
  public showDelegate = false;

  @Input() public hideCols: string[] = [];

  @Input()
  public title = 'Follow Up';

  @Input() public colunms = {
    accountName: false,
    domain: false,
    requestor: false,
    validator: false,
    type: false,
    creationDate: false,
    scheduledDate: false,
    status: false,
    justification: false,
    cancellable: false
  };

  @Output() public cancelAction: EventEmitter<any>;



  private resetHeight() {
    this.gridHeight = this.gridSizer.nativeElement.clientHeight;
  }

  public ngOnInit() {
    this.$actions.pipe(
      delay(100),
      tap((x) => {
        this.resetHeight();
      })
    ).subscribe();
    this.resetHeight();
  }

  public isRowSelected() {
    return () => false;
  }
  public rowClass(row) {
    return { followuprow: true };
  }

  public cancel = <T extends  TActionFollowUp>(action: T) => {
      this.cancelAction.emit(action as TActionFollowUp );
  }

  public showDetail = elem => {
    elem.srcElement.closest('.detail-wrapper').classList.toggle('detail-open');
  }

  public formatDN(name){
    return formatDisplayName(name)
  }

  public formatDepTooltip(deps){
    return deps.filter((d,i) => i > 0).map( d => formatDisplayName(d.displayName)).join('\n')
  }
}


