describe('Admin Action Follow Up Base Component', () => {
    it('temp test', () => {
      expect(1).toBeTruthy();
    });
});
  