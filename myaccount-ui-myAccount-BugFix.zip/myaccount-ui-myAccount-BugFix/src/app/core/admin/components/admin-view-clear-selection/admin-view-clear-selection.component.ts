import { Component, OnInit } from '@angular/core';
import { of, Observable } from 'rxjs'
import { Store, select } from '@ngrx/store'
import { getOrphanSelectedAccounts, getOrphanAccountsViewState } from '../../store/index'
import { OrphanSetViewOnlySelectedAccounts, OrphanSetSelectedAccounts } from '../../store/actions/admin-orphanaccounts-list.actions'
import { IAdminOrphanAccountState } from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state'
import { pluck } from 'rxjs/operators';
@Component({
  selector: 'app-2f82-admin-view-clear-selection',
  templateUrl: './admin-view-clear-selection.component.html',
  styleUrls: ['./admin-view-clear-selection.component.scss']
})
export class AdminViewClearSelectionComponent implements OnInit {

  constructor(private store: Store<IAdminOrphanAccountState>) { }

  public selection: Observable<number[]>;
  public viewSelected: Observable<boolean>;

  public ngOnInit() {
    this.selection = this.store.pipe(select(getOrphanSelectedAccounts));
    this.viewSelected = this.store.pipe(select(getOrphanAccountsViewState), pluck('showOnlySelected'));
  }

  public clearSelection() {
    this.store.dispatch(new OrphanSetSelectedAccounts({ ids: [], isAll: false }));
    this.store.dispatch(new OrphanSetViewOnlySelectedAccounts(false));
  }

  public setViewOnlySelected(e: boolean) {
    this.store.dispatch(new OrphanSetViewOnlySelectedAccounts(e));
  }
}
