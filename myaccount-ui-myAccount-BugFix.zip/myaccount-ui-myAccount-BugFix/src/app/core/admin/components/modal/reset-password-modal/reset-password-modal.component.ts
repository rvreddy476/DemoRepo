import { Component, ViewEncapsulation, OnInit, EventEmitter } from '@angular/core';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { IAccount, IBusinessHrsUTC } from 'src/app/shared/interfaces/shared/account/account';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { getAdminAccountsResetModal, getAdminSelectedAccountsList, getAdminBusinessHours } from '../../../store';
import { distinctUntilChanged, map, withLatestFrom } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import moment = require('moment');
import { CloseResetPassModal, ResetPassword, LoadBusinessHours } from '../../../store/actions/accounts-list.actions';
import { dateToString } from 'src/app/shared/helper-functions';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-admin-2f82-reset-password-modal',
  templateUrl: './reset-password-modal.component.html',
  styleUrls: ['./reset-password-modal.component.scss'],
  encapsulation: ViewEncapsulation.None,

})
export class AdminResetPasswordModalComponent implements OnInit {

  constructor(private store: Store<IAdminAccountListState>, private route: Router, private translateService: TranslateService) {
    this.close = new EventEmitter();
  }

  /**
   * Date range for enabled and selectable calander dates
   */
  public range = {
    start: new Date(),
    end: new Date(new Date().getTime() + (1000 * 60 * 60 * 24 * 180)),
  };

  /**
   * for absolute limits on the calandar view
   * prevents missing days in a month,
   * insted they will appear as disabled
   */
  public softRange = {
    start: new Date(new Date(this.range.start.getTime()).setDate(1)),
    end: new Date(new Date(this.range.end.setMonth(this.range.end.getMonth() + 1)).setDate(0))
  };

  public prescheduledResetHour: number;

  public availableTimes: Date[] = [];

  public account: IAccount;

  public modal: Observable<{
    open: boolean,
    loading: boolean,
    response: IResStatus
  }>;
  public title: Observable<string>;
  public message: Observable<string>;
  public largeIcon = null;

  public inputMode: Observable<boolean>;
  public failed: Observable<boolean>;

  public scheduleDate: Date = null;
  public excludedChars = '';

  public scheduledDateValid = false;
  public resetNowActive: boolean;

  private businessHours: IBusinessHrsUTC

  public close: EventEmitter<any>;

  public resetMode$ = new BehaviorSubject<'reset-now' | 'schedule-reset'>(null);
  private showConfirm$ = new BehaviorSubject(false);
  private showSelected$ = new BehaviorSubject(false);
  private showStatus$ = new BehaviorSubject(false);
  private requestedDate$: BehaviorSubject<Date> = new BehaviorSubject(null);

  private modal$ = this.store.pipe(select(getAdminAccountsResetModal));
  private selected$ = this.store.pipe(select(getAdminSelectedAccountsList));
  private businessHours$ = this.store.pipe(select(getAdminBusinessHours));

  private viewState$ = combineLatest(this.resetMode$, this.showSelected$, this.showConfirm$, this.showStatus$);

  public modalState$ = combineLatest(this.modal$, this.selected$, this.businessHours$, this.requestedDate$, this.viewState$).pipe(
    distinctUntilChanged(),
    map(([modal, accs, hrs, requestedDate, [requestedMode, viewSelected, viewConfirm, viewStatus]]) => {
      //Needs to to tested for Business Hours 9 -5
      // if(requestedDate==null)
      // { 
      //   requestedDate=  new Date();
      // }

      //#region INIT
      const bulk = accs.length > 1;
      const screen: 'input' | 'view-selection' | 'confirm' | 'success' | 'status' = null;

      const res = {
        screen,
        mode: requestedMode,
        title: '',
        message: '',
        messageParams: {
          acc: (!bulk && accs[0]) ? `${accs[0].directoryDomain}\\${accs[0].uid}` : null,
          accs: accs.length,
          date: null,
          time: environment.prescheduledResetHour
        },
        scheduledDate: null,
        availableTimes: [],
        scheduledDateValid: false,
        resetNowActive: false,
        responseList: [],
        largeIcon: '',
      };

      // SET DEFAULTS

      // should set scheduled mode by default?
      if (!requestedMode && (accs.every(acc => acc.scheduledResetPwdDateUTC !== null))) {
        this.resetMode$.next('schedule-reset');
        return res;
      }




      // TEMP OVERRIDES
      // if(hrs){
      //   hrs.days = [1,3,4,5]
      //   hrs.openHr = 3
      //   hrs.closeHr = 12
      // acc.type = 'SERVICE'
      // }

      //#endregion

      //#region LOADING SCREEN
      if (!hrs || modal.loading || accs.length === 0) {
        res.title = 'GLOBAL.LOADING';
        res.largeIcon = 'Loading';
        return res;
      }
      //#endregion

      //#region STATUS SCREEN
      if (viewStatus) {
        res.title = res.mode === 'reset-now' ? 'RESET_PASSWORD.MODAL.VIEW_SELECTION.INSTANT.TITLE' : 'RESET_PASSWORD.MODAL.VIEW_SELECTION.SCHEDULED.TITLE';
        res.screen = 'status';
        res.responseList = modal.responseList ? modal.responseList.map((res, i) => {
          return {
            outcome: res.type === 'SUCCESS' ? 'SUCCESS' : 'FAILED',
            acc: `${accs[i].directoryDomain}\\${accs[i].uid}`,
            message: this.translateService.instant(`RESET_PASSWORD.API_MESSAGE_TYPE.${res.type}`),
          };
        }) : [];
        return res;
      }
      //#endregion

      //#region SUCCESS
      if (modal.response ? modal.response.type === 'SUCCESS' : false) {
        res.screen = 'success';
        if (bulk) {
          res.message = res.mode === 'reset-now' ? 'RESET_PASSWORD.MODAL.SUCCESS.INSTANT.BULK.MESSAGE' : 'RESET_PASSWORD.MODAL.SUCCESS.SCHEDULED.BULK.MESSAGE';
        } else {
          res.message = res.mode === 'reset-now' ? 'RESET_PASSWORD.MODAL.SUCCESS.INSTANT.MESSAGE' : 'RESET_PASSWORD.MODAL.SUCCESS.SCHEDULED.MESSAGE';
        }
        res.title = 'RESET_PASSWORD.MODAL.SUCCESS_TITLE';
        res.largeIcon = 'Success';
        return res;
      }
      //#endregion

      //#region INPUT SCREEN
      if (!modal.response && !viewSelected && !viewConfirm) {

        // List of currently selected account types
        const uniqueAccTypes = new Set(accs.map(acc => acc.type));



        // If at least one service account is selected, use the business hours
        hrs = uniqueAccTypes.has('SERVICE') ? hrs : null;
        //test comment
        if (uniqueAccTypes.has('SERVICE')) {
          //close hr and open hr should be modified is the business hours is in place 9-5
          // if (moment([parseInt(moment().format('YYYY')), parseInt(moment().format('MM')), parseInt(moment().format('DD'))]).isDST()) {
          ///If daylight savings exist - Update the open and close UTC timings
          if (this.findDSTExist()) {
            if (moment(requestedDate).isDST()) {
              hrs.closeHr = 24;//15 GMT +2
              hrs.openHr = 0;//7 GMT +2
            }
            else {
              hrs.closeHr = 24;//16 GMT +1 Values coming from database set_setup_data table key-opening_hours
              hrs.openHr = 0;//8 GMT +1  Values coming from database setup table key-opening_hours
            }
          }
          else {
            ///Countries who doesnot have daylight savings
            // if (moment(requestedDate).tz('Europe/Amsterdam').isDST()) {
            //   hrs.closeHr = 24;//15 GMT +2
            //   hrs.openHr = 0;//7 GMT +2
            // }
            // else {
            hrs.closeHr = 24;//16 GMT +1
            hrs.openHr = 0;//8 GMT +1
            //}
          }
        }

        this.businessHours = hrs

        res.screen = 'input';
        res.title = 'RESET_PASSWORD.MODAL.TITLE';
        res.message = 'RESET_PASSWORD.MODAL.DESCRIPTION';
        res.resetNowActive = this.canResetNow(hrs);

        // RESET NOW MODE ------------------------------
        if (res.mode === 'reset-now') {
          res.scheduledDateValid = this.canResetNow(hrs);
        }

        // SCHEDULE RESET MODE -------------------------
        if (res.mode === 'schedule-reset') {

          // set default request date
          if (!requestedDate) {
            // use current request
            if (accs.length === 1 ? !!accs[0].scheduledResetPwdDateUTC : false) {
              this.requestedDate$.next(accs[0].scheduledResetPwdDateUTC);
            } else {
              this.requestedDate$.next(this.getNextAvailableSlots(hrs)[0])
            }
            return res
          }

          // schedule-reset, get next available date
          const nextSlots = this.getAllSlotsForDay(requestedDate, hrs);
          res.availableTimes = nextSlots.map(t => t.getTime());

          // is requestedDate in the list of availbale time slots?
          if (nextSlots.map(t => t.getTime()).indexOf(requestedDate.getTime()) !== -1) {
            res.scheduledDate = requestedDate;
          } else {
            res.scheduledDate = nextSlots[0];
          }
          res.scheduledDateValid = true;


        }
        return res;
      }
      //#endregion

      //#region VIEW SELECTION SCREEN
      if (viewSelected) {
        res.title = requestedMode === 'reset-now' ? 'RESET_PASSWORD.MODAL.VIEW_SELECTION.INSTANT.TITLE' : 'RESET_PASSWORD.MODAL.VIEW_SELECTION.SCHEDULED.TITLE';
        res.screen = 'view-selection';

        return res;
      }

      //#endregion

      //#region CONFIRM SCREEN
      if (viewConfirm) {

        if (bulk) {
          res.title = requestedMode === 'reset-now' ? 'RESET_PASSWORD.MODAL.CONFIRM.INSTANT.TITLE' : 'RESET_PASSWORD.MODAL.CONFIRM.SCHEDULED.TITLE';
          res.message = requestedMode === 'reset-now' ? 'RESET_PASSWORD.MODAL.CONFIRM.INSTANT.BULK.MESSAGE' : 'RESET_PASSWORD.MODAL.CONFIRM.SCHEDULED.BULK.MESSAGE';
        } else {
          res.title = requestedMode === 'reset-now' ? 'RESET_PASSWORD.MODAL.CONFIRM.INSTANT.TITLE' : 'RESET_PASSWORD.MODAL.CONFIRM.SCHEDULED.TITLE';
          res.message = requestedMode === 'reset-now' ? 'RESET_PASSWORD.MODAL.CONFIRM.INSTANT.MESSAGE' : 'RESET_PASSWORD.MODAL.CONFIRM.SCHEDULED.MESSAGE';
        }
        res.screen = 'confirm';

        res.messageParams.date = (requestedMode === 'schedule-reset' && requestedDate) ? `${dateToString(requestedDate)}` : null;

        return res;
      }

      //#endregion




    })
  );

  public ngOnInit() {
    this.prescheduledResetHour = environment.prescheduledResetHour;

    this.store.dispatch(new LoadBusinessHours());

    //#region modal lifecycle

    this.modal = this.store.pipe(select(getAdminAccountsResetModal));
    this.inputMode = this.modal.pipe(map(m => !m.response && !m.loading));
    this.failed = this.modal.pipe(map(m => m.response ? m.response.error : false));

    this.title = this.modal.pipe(
      withLatestFrom(this.failed, this.inputMode),
      map(([m, f, i]) => {
        return i ? 'RESET_PASSWORD.MODAL.TITLE' : m.loading ? 'RESET_PASSWORD.RESPONSE.LOADING' : f ? 'RESET_PASSWORD.RESPONSE.FAILED' : 'RESET_PASSWORD.RESPONSE.SUCCESS';
      }));
    this.message = this.modal.pipe(
      withLatestFrom(this.failed, this.inputMode),
      map(([m, f, i]) => {
        return i ? `RESET_PASSWORD.MODAL.DESCRIPTION` : m.loading ? '' : m.response.message ? m.response.message : f ? 'RESET_PASSWORD.RESPONSE.FAILED' : 'RESET_PASSWORD.RESPONSE.SUCCESS_MESSAGE';
      }));
    this.largeIcon = this.modal.pipe(
      withLatestFrom(this.failed, this.inputMode),
      map(([m, f, i]) => {
        return i ? null : m.loading ? 'Loading' : f ? 'Failed' : 'Success';
      }));

    //#endregion

    //#region reset input

  }

  private findDSTExist(): boolean {
    var year = new Date().getFullYear();
    if (year < 1000)
      year += 1900;

    var firstSwitch = 0;
    var secondSwitch = 0;
    var lastOffset = 99;

    // Loop through every month of the current year
    for (let i = 0; i < 12; i++) {
      // Fetch the timezone value for the month
      var newDate = new Date(Date.UTC(year, i, 0, 0, 0, 0, 0));
      var tz = -1 * newDate.getTimezoneOffset() / 60;

      // Capture when a timzezone change occurs
      if (tz > lastOffset)
        firstSwitch = i - 1;
      else if (tz < lastOffset)
        secondSwitch = i - 1;

      lastOffset = tz;
    }
    // Go figure out date/time occurrences a minute before
    // a DST adjustment occurs
    // var secondDstDate = this.FindDstSwitchDate(year, secondSwitch);
    // var firstDstDate = this.FindDstSwitchDate(year, firstSwitch);
    if (secondSwitch > 0 && firstSwitch > 0)
      return true;
    else
      return false;

  }


  //#region helper functions
  private isSameDay(date: Date, compareTo: Date = new Date()): boolean {
    return date.getFullYear() === compareTo.getFullYear() && date.getMonth() === compareTo.getMonth() && date.getDate() === compareTo.getDate();
  }


  /**
   * triggered when the user changes reset panel
   * between "reset-now" and "schedule-reset"
   */
  public changeResetMode(mode) {
    this.resetMode$.next(mode);
  }

  public disabledCalanderDates = (date: Date) => {
    let hrs = this.businessHours
    if (this.getAllSlotsForDay(date, hrs).length === 0) {
      return true;
    }
    const outOfRange = (
      (date.getDate() > this.range.end.getDate() && date.getMonth() === this.range.end.getMonth()) ||
      (date.getDate() < this.range.start.getDate() && date.getMonth() === this.range.start.getMonth()) ||
      ((date.getFullYear() === this.range.start.getFullYear()) ? (date.getMonth() < this.range.start.getMonth() ? true : false) : false) ||
      ((date.getFullYear() === this.range.end.getFullYear()) ? (date.getMonth() > this.range.end.getMonth() ? true : false) : false)
    );
    return outOfRange;
  }

  private isValidTime = (date, hrs: IBusinessHrsUTC, offset: number = null) => {

    const resetOffset = offset ? offset * 60 * 1000 : 0;

    // check date is in the future by 5 mins
    if (date.getTime() < new Date().getTime() + resetOffset) {
      return false;
    }

    // if no business hours must be valid
    if (!hrs) {
      return true;
    }
    // check if day is out of bounds
    if (hrs ? hrs.days.indexOf(date.getDay()) === -1 : false) {
      return false;
    }

    // check time of day within business hours
    const UTChr = date.getUTCHours();
    const UTCmin = date.getUTCMinutes();

    const tooEarly = (UTChr < hrs.openHr);
    const tooLate = (UTChr > hrs.closeHr || (UTChr === hrs.closeHr && UTCmin > hrs.closeMin));

    // console.log(`valid time check: ${(date as Date).toString()} UTChr:${UTChr} openHr:${hrs.openHr} valid:${!tooEarly && !tooLate}`)

    return !tooEarly && !tooLate;

  }

  public getNextAvailableSlots(hrs: IBusinessHrsUTC): Date[] {
    // start with today
    const checkingDay = new Date();

    for (let d = 0; d < 7; d++) {
      const slots = this.getAllSlotsForDay(checkingDay, hrs);
      if (slots.length > 0) {
        return slots;
      }

      checkingDay.setDate(checkingDay.getDate() + 1);
    }
    console.error('No "next available reset date" found in the next 7 days');
  }

  private getAllSlotsForDay(localDate: Date, hrs: IBusinessHrsUTC): Date[] {
    const firstSlot = new Date(localDate.getTime());

    // start at 0:00
    firstSlot.setHours(0, 0, 0, 0);

    const slots: Date[] = [];

    let addingDate = new Date(firstSlot.getTime());


    // loop 30min inc for full day, 0:00 till 23:30
    // Next slot will be aviable only  (this.prescheduledResetHour*60)+30 mins  from now

    for (let i = 0; i < 48; i++) {
      if (this.isValidTime(addingDate, hrs, (this.prescheduledResetHour * 60) + 30)) {
        slots.push(addingDate);
      }
      addingDate = new Date(addingDate.getTime());
      addingDate.setMinutes(addingDate.getMinutes() + 30);
    }

    return slots;
  }

  private canResetNow(hrs: IBusinessHrsUTC) {
    if (!hrs) {
      return true;
    }
    return this.isValidTime(new Date(), hrs);
  }

  public timeAsInt(time: Date): number {
    return time ? time.getTime ? time.getTime() : null : null;
  }

  public dateFromTime(time: number): Date {
    return new Date(time);
  }



  //#endregion


  //#endregion


  //#region event handlers

  public onScheduleDateChange(e) {

    this.requestedDate$.next(e);


    // this.availableTimes = this.getAllSlotsForDay(e)
    // this.scheduleDate = new Date(this.availableTimes[0])

  }

  public onScheduleTimeChange(time) {

    this.requestedDate$.next(new Date(time));
  }

  //#endregion

  public closeModal() {
    this.store.dispatch(new CloseResetPassModal());
  }

  public validate(open) {
    this.showConfirm$.next(open);
  }
  public showSelection(open) {
    this.showSelected$.next(open);
  }
  public showStats(open) {

    this.showStatus$.next(open);
  }

  public submit() {
    this.store.dispatch(new ResetPassword({
      schedule: this.resetMode$.value === 'schedule-reset' ? this.requestedDate$.value : null,
      type: this.resetMode$.value === 'schedule-reset' ? 'SCHEDULE' : 'NOW',
      pre_scheduledhour: this.prescheduledResetHour,
      excludedChars: ''
    }));
  }

}
