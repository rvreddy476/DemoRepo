import { Component, OnInit } from '@angular/core';
import { Observable, BehaviorSubject, combineLatest } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { IAccount, IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { getSelectedAccounts, getSelectedAccountsList, getEndofLifeModal,getSelectedAccountType } from '../../../store';
import { CloseEndOfLifeModal,SetSelectedAccounts,EnableAccountsWithEndOfLife } from '../../../store/actions/accounts-list.actions';
import { API } from 'src/app/shared/interfaces/shared/api';

@Component({
  selector: 'app-admin-2f82-end-of-life-modal',
  templateUrl: './end-of-life-modal.component.html',
  styleUrls: ['./end-of-life-modal.component.scss']
})
export class EndOfLifeModalComponent implements OnInit {
  showStats$ = new BehaviorSubject<boolean>(false);
  public lifeCycleDateMode$ = new BehaviorSubject<'extend-one-year' | 'extend-with-custom-date'>(null);
  ngOnInit(): void {
    this.selectedIds$.subscribe((ids) => this.selectedIds = ids);
  }
  private selectedIds$ = this.store.pipe(select(getSelectedAccounts));
  private $selected = this.store.pipe(select(getSelectedAccountsList));
  private $selectedTechnicalAccounts = this.store.pipe(select(getSelectedAccountsList), map(account => account.filter(acc => acc.type === 'TECHNICAL')));
  private $modal = this.store.pipe(select(getEndofLifeModal));
  private $selectedAccountType = this.store.pipe(select(getSelectedAccountType));
  private viewSelection$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private viewTaSelection$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private previousSelection: IAccount[] = [];


  constructor(private store: Store<IAccountsListState>) {
  }

  public selectedIds = [];
  public disabled$ = new BehaviorSubject<boolean>(true);

  public range = {
    start: new Date(),
    end: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
  };
  public disabledDates = (date: Date): boolean => {
    return date < this.range.start || date > this.range.end;
  }

  public selectedDate = this.range.end;

  public trigger = null;

  public modalState$ = combineLatest(this.$modal, this.$selected, this.viewSelection$, this.viewTaSelection$, this.$selectedAccountType, this.showStats$).pipe(
    map(([modal, selected, viewSelection, viewTaSelection, selectedAccountType, showStats]) => {

      // Dont overrite Selected list if it is empty. (becuase deselection occurs after successful request)
      if (selected.length > 0) { this.previousSelection = selected; }
      selected = this.previousSelection;

      let screen: 'view-selection' | 'view-ta-selection' | 'enable-confirm' | 'enable-success' | 'enable-success-status' | 'kebab-confirm' | 'kebab-success' | 'kebab-success-status' | 'mixed-selection' | 'show-status' = null;
      let title = '';
      let largeIcon = null;
      const titleIcon = null;
      const loading = false;
      let messageParams = {};
      let message = null;
      let status: API.BulkElemRes[] = [];
      this.trigger = modal.trigger;

      messageParams = {

        acc: selected[0] ? `${selected[0].directoryDomain}\\${selected[0].uid}` : 0,
        accs: selected.length.toString(),
      };

      if (!modal.response) {
        // there is no response
        if (!modal.loading) {
          title = modal.trigger === 'Enable' ? 'Set Expiry date for Technical Accounts' : modal.trigger === 'Notification' ? 'Accounts about to expire' : 'Set Expiry date for the selected account';
          screen = 'enable-confirm';


        } else {
          // LOADING page
          title = 'GLOBAL.LOADING';
          largeIcon = 'Loading';
        }
      } else {
        if (showStats) {
          title = 'Status';
          screen = 'show-status';
          status = modal.responseList;
        }

        else if (modal.response.error !== false) {
          console.log(modal.responseList);
          // request FAILED page
          title = modal.trigger === 'Enable' ? 'ENABLE_ACC.MODAL.FAILED_TITLE' : 'ENABLE_ACC.MODAL.FAILED_TITLE';
          largeIcon = 'Failed';
        } else {
          console.log(modal.responseList);
          // Request Success Page
          const singleMulti = selected.length > 1 ? 'MULTI' : 'SINGLE';
          title = modal.trigger === 'Enable' ? `ENABLE_ACC.MODAL.SUCCESS.TITLE` : `END_OF_LIFE.MODAL.SUCCESS.TITLE`;
          message = '';
          // modal.trigger === 'Enable' ? `ENABLE_ACC.MODAL.SUCCESS.MESSAGE.${singleMulti}` : `END_OF_LIFE.MODAL.SUCCESS.MESSAGE.${singleMulti}`;
          screen = modal.trigger === 'Enable' ? 'enable-success' : 'enable-success';
          largeIcon = 'Success';
        }
      }

      return {
        screen,
        title,
        largeIcon,
        loading,
        titleIcon,
        message,
        messageParams,
        status
      };
    })
  );
  public showSelection(open = true) {
    this.viewSelection$.next(open);
  }
  public showTaSelection(open = true) {
    this.viewTaSelection$.next(open);
  }
  public closeModal() {
    this.store.dispatch(new CloseEndOfLifeModal());
  }
  public enableAccs() {
    console.log(this.selectedDate);
    this.store.dispatch(new SetSelectedAccounts({ ids: this.selectedIds, isAll: false }));
    this.store.dispatch(new EnableAccountsWithEndOfLife({ end_of_lifecycle_date: this.selectedDate, trigger: this.trigger }));
  }
  public checkboxEvent(Id: any) {
    this.selectedIds.findIndex(id => id === Id) == -1 ? this.selectedIds.push(Id) : this.selectedIds.splice(this.selectedIds.findIndex(id => id === Id), 1);
    this.enableSubmitButton();
  }

  public changeLifeCycleDateMode(mode) {
    this.lifeCycleDateMode$.next(mode);
    this.enableSubmitButton();
  }
  
  public enableSubmitButton() {
    this.disabled$.next(false)
    if (this.selectedIds.length < 1 || this.lifeCycleDateMode$.value === null) {
      this.disabled$.next(true);
    }
  }
  public showStats() {
    this.showStats$.next(true);
  }
}
