import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomKenduModule } from 'src/app/modules/custom-kendu-elements/custom-kendu.module';
import { TranslateModule } from '@ngx-translate/core';
import { EndOfLifeModalComponent } from './end-of-life-modal.component';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { AppState } from 'src/app/shared/store';
import { Store } from '@ngrx/store';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { KendoModule } from 'src/app/modules/kendo.module';
import { IconModule } from 'src/app/modules/icon.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

describe('EndOfLifeModalComponent', () => {
  let component: EndOfLifeModalComponent;
  let fixture: ComponentFixture<EndOfLifeModalComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndOfLifeModalComponent,BaseModalComponent ],
      imports:[CustomKenduModule, TranslateModule.forRoot(), 
        KendoModule,IconModule,NoopAnimationsModule],
      providers: [
        provideMockStore({ initialState })
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(EndOfLifeModalComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      store = TestBed.get(Store);
  });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EndOfLifeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
