import { Component, ViewEncapsulation, OnInit, EventEmitter, ViewChild } from '@angular/core';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { Store, select } from '@ngrx/store';
import { Router } from '@angular/router';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { BehaviorSubject, combineLatest } from 'rxjs';
import { getOrphanAccountAssignModal, getOrphanSelectedAccounts, getSolutions, getDelegation_Members, getOrphanAccounts } from '../../../store';
import { map } from 'rxjs/operators';
import { LoadAdminSolutions, LoadAdminDelegationMember } from '../../../store/actions/accounts-list.actions';
import { TranslateService } from '@ngx-translate/core';
import { IAdminOrphanAccountState } from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';
import { API } from 'src/app/shared/interfaces/shared/api';
import { CloseAssignOrphanModal, AssignOrphanAccount, OrphanSetSelectedAccounts } from '../../../store/actions/admin-orphanaccounts-list.actions';
import { SuperAdminAccountStatsService } from 'src/app/shared/services/superadmin/superadmin-account-stats.service';
import { getIdentity } from 'src/app/shared/store/selectors';

@Component({
  selector: 'app-2f82-assign-orphan-modal',
  templateUrl: './assign-orphan-modal.component.html',
  styleUrls: ['./assign-orphan-modal.component.scss'],
  encapsulation: ViewEncapsulation.None,

})
export class AdminAssignOrphanModalComponent implements OnInit {

  constructor(private store: Store<IAdminOrphanAccountState>, private route: Router, private translateService: TranslateService, private superAdminAccountStatsService: SuperAdminAccountStatsService) {
    this.close = new EventEmitter();
  }


  public selectedIds = [];
  public disabled$ = new BehaviorSubject<boolean>(true);

  @ViewChild('Modal') private modalElement: BaseModalComponent;


  public close: EventEmitter<any>;
  private $selected = this.store.pipe(select(getOrphanSelectedAccounts));

  private previousSelection: IAccount[] = [];
  private showStats$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private showConfirm$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private showEnduser$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private viewSelection$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public Solutions$ = this.store.select(getSolutions);
  public Enduser$ = this.store.select(getDelegation_Members);
  private searchTerm$: BehaviorSubject<string> = new BehaviorSubject('');
  public source: Array<string> = ['Albania', 'Andorra', 'Armenia', 'Austria', 'Azerbaijan'];
  public title = 'ADD_REMOVE_DEPUTY.MODAL.TITLE';
  public message = 'ADD_REMOVE_DEPUTY.MODAL.DESCRIPTION';
  public messageParams = null;
  public selectedSolution: string;
  public selectedEnduser: string;
  public enduserReadonly$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public solutionReadonly$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public selectedAccountType: string;
  public domain = "";
  public largeIcon = null;
  public titleIcon = null;
  public hasError = false;
  public hasWarning = false;
  public contextType: string = "";
  public solutionData: Array<string>;
  public allAccounts$ = this.store.pipe(select(getOrphanAccounts));
  private $modal = this.store.pipe(select(getOrphanAccountAssignModal));
  public modalState$ = combineLatest(this.$modal, this.$selected, this.allAccounts$, this.viewSelection$, this.showStats$).pipe(
    map(([modal, selected, allAccounts, viewSelection, showStats]) => {
      
      this.selectedIds = [];
      let screen: 'Load-selection' | 'view-selection' | 'assign-success' | 'restrict-screen' | 'show-status' = null;
        let title = '';
        let largeIcon = null;
        const titleIcon = null;
        const loading = false;
        let messageParams = {};
        let message = null;
        let status: API.BulkElemRes[] = [];
        messageParams = {
        };
        screen = 'Load-selection';
        title = 'ASSIGN_ORPHAN_MODAL.TITLE'
        message = ""
       
      for (var acc in selected) {
        if(selected.length ==1)
        {

        this.selectedIds.findIndex(id => id === selected[0]) == -1 ? this.selectedIds.push(selected[0]) : this.selectedIds.splice(this.selectedIds.findIndex(id => id === selected[0]), 1);
        // this.selectedIds.push(selected[parseInt(acc)]);
        var temp = allAccounts.filter(p => p.id === selected[0]);
        if (this.selectedSolution == undefined) {
          this.selectedSolution = temp.map(p => p.solution_code)[0];
          if (this.selectedSolution != "") {
            this.solutionReadonly$.next(true);
          }
          this.selectedAccountType = temp.map(p => p.type)[0];
        }

        if (this.selectedEnduser == undefined && this.selectedAccountType.toUpperCase() == 'TECHNICAL'.toUpperCase()) {
          this.showEnduser$.next(true);
          this.selectedEnduser = allAccounts.map(p => p.enduser_displayname)[0];
          if (this.selectedEnduser != "") {
            this.enduserReadonly$.next(true);
          }

          else {
            //this.selectedEnduser=null;
          }

          this.domain = allAccounts.map(p => p.domain)[0];
        }
        console.log(modal)
        
        if (!modal.response) {
          if (!modal.loading) {
            messageParams = {
            };
            screen = 'Load-selection';
            title = 'ASSIGN_ORPHAN_MODAL.TITLE';
            message = ""
            console.log(modal)
          } else {
            console.log(modal)
          }
        } else {
          if (showStats) {
            title = 'Status';
            screen = 'show-status';

            status = modal.responseList;
          }

          else if (modal.response.error !== false) {
            // request FAILED page
            title = 'ASSIGN_ORPHAN_MODAL.MODAL.FAILED.TITLE';
            largeIcon = 'Failed';
            message = modal.response.message;
          } else {
            // Request Success Page
            console.log(modal)
            title = 'ASSIGN_ORPHAN_MODAL.MODAL.SUCCESS.TITLE';
            message = 'ASSIGN_ORPHAN_MODAL.MODAL.SUCCESS.MESSAGE';
            screen = 'assign-success'
            largeIcon = 'Success';
          }
        }
      }
      else{
        title = 'ASSIGN_ORPHAN_MODAL.MODAL.REJECT.TITLE';
        message = 'ASSIGN_ORPHAN_MODAL.MODAL.REJECT.MESSAGE';
        screen = 'restrict-screen'
        largeIcon = 'Failed';
       
      }

        return {
          screen,
          title,
          largeIcon,
          loading,
          titleIcon,
          message,
          messageParams,
          status
        };
      }
    }));

   public isValidForm()
   {
     var isSolutionValid=true;
     var isEnduserValid=true
     
     if(!this.solutionReadonly$.value)
     {
      this.store.pipe(select(getSolutions)).subscribe(solution=>
        isSolutionValid=solution.filter(x=>x===this.selectedSolution).length==1?true:false)
     }
     if(!this.enduserReadonly$.value)
     {
      // this.store.pipe(select(getI)).subscribe(identity=>
      //   isFormValid=identity.id===this.selectedEnduser?true:false)
      isEnduserValid=this.selectedEnduser?true:false;
     }
      return isSolutionValid && isEnduserValid;
   } 

  public valueChangeEndUser(value: any): void {
    this.selectedEnduser = value;
  }
  public valueChangeSolution(value: any): void {
    this.selectedSolution = value;
  }
  public filterenduserChange(filter: any): void {
    this.store.dispatch(new LoadAdminDelegationMember({ term: filter }));
  }

  public filterChange(filter: any): void {
    this.store.dispatch(new LoadAdminSolutions({ term: filter }));
  }

  public showStats() {
    this.showStats$.next(true);
  }

  public ngOnInit() {
    this.store.dispatch(new LoadAdminSolutions({ term: '' }));

  }

  public closeModal() {
    this.store.dispatch(new CloseAssignOrphanModal())
  }

  SolutionFilter(value) {
    this.store.dispatch(new LoadAdminSolutions({ term: value }))

  }

  public enableSubmitButton() {
    this.disabled$.next(false)
    if (this.selectedIds.length < 1) {
      this.disabled$.next(true);
    }
  }

  public AssignOrphan() {
    this.superAdminAccountStatsService.getSolutions(this.selectedSolution).subscribe(res => {
      
      this.contextType = res.data[0].type
      this.store.dispatch(new OrphanSetSelectedAccounts({ ids: this.selectedIds, isAll: false }));
      this.store.dispatch(new AssignOrphanAccount({ solution_code: this.solutionReadonly$.value?null: this.selectedSolution, context_type: this.contextType, end_user:this.enduserReadonly$.value?null: this.selectedEnduser }))
    });
    console.log(this.selectedIds);
  }

}
