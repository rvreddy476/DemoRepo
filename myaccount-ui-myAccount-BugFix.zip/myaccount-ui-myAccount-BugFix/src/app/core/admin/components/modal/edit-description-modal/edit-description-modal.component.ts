import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { Observable, of, fromEvent, combineLatest } from 'rxjs';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { IAccount, IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { getAdminAccountDetail, getEditDescriptionModal } from '../../../store';
import { map } from 'rxjs/operators';
import { EditAccountDescription, CloseEditDescriptionModal } from '../../../store/actions/accounts-list.actions';

@Component({
  selector: 'app-edit-description-modal',
  templateUrl: './edit-description-modal.component.html',
  styleUrls: ['./edit-description-modal.component.scss']
})
export class EditDescriptionModalComponent implements OnInit, AfterViewInit {
  @ViewChild('description') private descriptionElem: ElementRef;

  public editDescModal$: Observable<{
    open: boolean;
    response: IResStatus;
    loading: boolean;
}>;
  public account$: Observable<IAccount>;

  public descInput$;
  public saveBtnActive$ = of(false);
  public localModal$ = of({title: 'ACCOUNT_DETAIL.EDIT_DESCRIPTION.MODAL.TITLE', icon: null, inputMode: true});


  constructor(private store: Store<IAccountsListState>) {
    this.editDescModal$ = this.store.pipe(select(getEditDescriptionModal));
    this.account$ = this.store.pipe(select(getAdminAccountDetail));
    this.localModal$ = this.editDescModal$.pipe(
      map(modal => {
          if (modal.loading) {
            return {
              title: 'DASHBOARD.LOADING',
              icon: 'Loading',
              inputMode: false
            };
          }
          if (modal.response ? modal.response.error === false : false) {
            return {
              title: 'ACCOUNT_DETAIL.EDIT_DESCRIPTION.MODAL.SUCCESS_TITLE',
              icon: 'Success',
              inputMode: false
            };
          }
          if (modal.response ? modal.response.error === true : false) {
            return {
              title: 'ACCOUNT_DETAIL.EDIT_DESCRIPTION.MODAL.FAILED_TITLE',
              icon: 'Failed',
              inputMode: false
            };
          }
          return {
            title: 'ACCOUNT_DETAIL.EDIT_DESCRIPTION.MODAL.TITLE',
            icon: null,
            inputMode: true
          };
      })
    );
  }

  public ngAfterViewInit() {
    this.descInput$ = fromEvent(this.descriptionElem.nativeElement, 'input');
    this.saveBtnActive$ = combineLatest(this.descInput$, this.account$).pipe(
      map(([inputElem, accState]) => {
        return (inputElem as any).target.value !== accState.description;
      })
    );
  }



  public saveDesc() {
    const description = this.descriptionElem.nativeElement.value;
    this.store.dispatch(new EditAccountDescription(description));
  }

  public closeModal() {
    this.store.dispatch(new CloseEditDescriptionModal());
  }

  public ngOnInit() {
  }

}

