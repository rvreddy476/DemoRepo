import { AdminEffects } from './admin-effects';
import { AdminListEffects } from './admin-list-effects';
import { AdminFollowupListEffects } from './admin-followup-list-effects';
import {AdminOrphanAccountsEffects} from './admin-orphanaccounts-list.effects';


export const effects: any[] = [AdminEffects, AdminListEffects,AdminFollowupListEffects,AdminOrphanAccountsEffects];