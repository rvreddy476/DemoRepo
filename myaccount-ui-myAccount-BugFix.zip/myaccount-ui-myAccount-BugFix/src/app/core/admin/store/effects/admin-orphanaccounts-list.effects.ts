import { Actions, Effect, ofType } from '@ngrx/effects';
import { Injectable } from '@angular/core';
import { SuperAdminAccountStatsService } from 'src/app/shared/services/superadmin/superadmin-account-stats.service';
import { ISuperAdminAccountsStatsState } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-state';
import { Store, select } from '@ngrx/store';
import { of } from 'rxjs';
import { switchMap, map, filter, withLatestFrom, catchError, pluck, distinctUntilChanged } from 'rxjs/operators';
import { LoadAdminOrphanAccounts, LoadAdminOrphanAccountsSuccess, LoadAdminOrphanAccountsFail, LOAD_ADMIN_ORPHAN_ACCOUNTS, SetOrphanUniqueData, AssignOrphanAccount, ASSIGN_ORPHAN_ACCOUNT, AssignOrphanAccountSuccess, AssignOrphanAccountFail, ORPHAN_SET_SELECT_ALL, OrphanSelectAllAccounts, OrphanSetSelectedAccounts, OrphanModifyPrimaryFilterFlag, LoadAdminOrphanFilteredAccounts } from '../actions/admin-orphanaccounts-list.actions';
import { IAdminOrphanAccountsListAPI } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-api';
import { IOrphanAccount, IorphanAccountAPIElem } from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state';
import { environment } from 'src/environments/environment';
import { orderBy } from '@progress/kendo-data-query';
import { getOrphanSelectedAccounts, getOrphanSortedFilteredAccountList, getOrphanSelectAllStatus, getOrphanVisibleAccounts, getOrphanFilters, getOrphanPrimaryFilterModifyState } from '../selectors';

@Injectable()
export class AdminOrphanAccountsEffects {
  constructor(
    private actions$: Actions,
    private adminService: SuperAdminAccountStatsService,
    private store: Store<ISuperAdminAccountsStatsState>
  ) { }

  @Effect()
  public assignOrphanAccount$ = this.actions$
    .pipe(ofType(ASSIGN_ORPHAN_ACCOUNT),
      withLatestFrom(this.store.pipe(select(getOrphanSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        
        const solution_code = (action as any).payload.solution_code;
        const context_type = (action as any).payload.context_type;
        // const domain = (action as any).payload.domain;
        const end_user = (action as any).payload.end_user;
        return this.adminService.assignOrphanAccounts(accounts, solution_code, context_type, end_user).pipe(
          map(res => {
            return new AssignOrphanAccountSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new AssignOrphanAccountFail());
          })
        );
      })
    );

  @Effect()
  public selectAllOrphanAccountsTrigger$ = this.actions$
    .pipe(
      ofType(ORPHAN_SET_SELECT_ALL),
      withLatestFrom(
        this.store.pipe(select(getOrphanSortedFilteredAccountList)),
        this.store.pipe(select(getOrphanVisibleAccounts)),
        this.store.pipe(select(getOrphanSelectAllStatus)),
      )
    )
    .pipe(
      map(([action, state, selected, selectAllStatus]) => {
        switch (selectAllStatus) {
          case 'checked':
            return new OrphanSetSelectedAccounts({ ids: [], isAll: false });
          case 'unchecked':
          case 'indeterminate':
            return new OrphanSetSelectedAccounts({ ids: state.filter(acc => (!acc.locked && !acc.hp)).map(acc => acc.id), isAll: true });
        }
      })
    );

  @Effect()
  public loadAllOrphanAccountsStats$ = this.actions$
    .pipe(ofType(LOAD_ADMIN_ORPHAN_ACCOUNTS),
      withLatestFrom(this.store.pipe(select(getOrphanFilters)),this.store.pipe(select(getOrphanPrimaryFilterModifyState)))).pipe(
        switchMap(([action, filters,flag]) => {
          try {
            
            const uid = filters.account_uid ? filters.account_uid[0] : null
            const type = filters.account_type ? filters.account_type[0] : null
            
            if ((uid || type) && flag) {
              return this.adminService.getAdminOrphanAccounts(uid,type).pipe(
                map((res:IAdminOrphanAccountsListAPI) => {

                  if (!res.status.error) {
                    const processed: IOrphanAccount[] = orderBy(res.data.map((acc) => this.formatAcc(acc)), [{ field: 'domain_name', dir: 'asc' }]);
                    this.store.dispatch(new SetOrphanUniqueData(processed));
                    this.store.dispatch(new OrphanModifyPrimaryFilterFlag(false));
                    return new LoadAdminOrphanAccountsSuccess({ status: res.status, data: processed });
                  } else {
                    return new LoadAdminOrphanAccountsFail(res.status);
                  }
                })
              );
            }
            else {
              this.store.dispatch(new LoadAdminOrphanFilteredAccounts());
              return of(new LoadAdminOrphanAccountsSuccess(null));
            }

          } catch (error) {

            return of(new LoadAdminOrphanAccountsFail(error));
          }
        })
      );

  private formatAcc = (acc: IorphanAccountAPIElem): IOrphanAccount => {
    return {
      id: acc.id,
      pwd_expiration_days: acc.pwd_expiration_days,
      pwdStatus: acc.doesat ? acc.pwd_expiration_days > 0 ? 'ACTIVE' : 'EXPIRED' : 'NO_PASSWORD',
      division: acc.solution ? acc.solution.division ? acc.solution.division.name : null : null,
      type: acc.type,
      name: acc.name,
      enduser_displayname: acc.end_user ? acc.end_user.displayname : '',
      enduser_id: acc.end_user ? acc.end_user.id : 0,
      environment: acc.directory ? acc.directory.project_phase : '',
      directory: acc.directory ? acc.directory.type : '',
      domain: acc.directory ? acc.directory.domain : '',
      solution_code: acc.solution ? acc.solution.code : '',
      solution_id: acc.solution ? acc.solution.id : 0,
      doesat: acc.doesat,
      solution_name: acc.solution ? acc.solution.name : '',
      hp: acc.hp,
      locked: acc.locked
    };
  }
}