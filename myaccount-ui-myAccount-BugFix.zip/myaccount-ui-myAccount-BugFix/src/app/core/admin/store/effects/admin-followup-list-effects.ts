
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { SuperAdminAccountStatsService } from 'src/app/shared/services/superadmin/superadmin-account-stats.service';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { Store, select } from '@ngrx/store';
import { LOAD_ADMIN_ACCOUNTS_LIST, SetUniueData, LoadAdminAccountsListSuccess, LoadAdminAccountsListFail } from '../actions/accounts-list.actions';
import { getFilters } from '../selectors';
import { withLatestFrom, switchMap, mergeMap, catchError, filter, map } from 'rxjs/operators';
import { IAccountAPI, IAccountAPIElem } from 'src/app/shared/interfaces/shared/account/accountAPI';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { orderBy, process } from '@progress/kendo-data-query';
import { of } from 'rxjs';
import { IAdminFollowUpState } from 'src/app/shared/interfaces/super-admin/admin- followuplist-state';
import { ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST, requestAdminActionFollowUpFail, requestAdminActionFollowUpSuccess, CANCEL_ADMIN_PENDING_REQUEST, cancelAdminPendingRequestFailed, cancelAdminPendingRequestSuccess } from '../actions/admin-followup-list.actions';
import { getIdentityID } from 'src/app/shared/store/selectors';
import { TActionFollowUp } from 'src/app/shared/interfaces/shared/account/follow-up';
import { IActionFollowUpAPI, TActionFollowUpApiElem } from 'src/app/shared/interfaces/shared/account/follow-upAPI';
import { AccountsService } from 'src/app/shared/services/accounts.service';

@Injectable()
export class AdminFollowupListEffects {
  constructor(
    private actions$: Actions,
    private accountsListService: AccountsService,
    private adminService: SuperAdminAccountStatsService,
    private store: Store<IAdminFollowUpState>
  ) { }

  
@Effect()
  public loadAdminFollowUpActions$ = this.actions$.pipe(
    ofType(ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST),
    withLatestFrom(this.store.pipe(select(getIdentityID)))
  )
    .pipe(
      switchMap(([action, requestorId]) => {
        return this.accountsListService.getAdminActionFollowUp(requestorId).pipe(
          map((response: IActionFollowUpAPI) => {
          
            if (response.status.error) {
              return new requestAdminActionFollowUpFail(response.status);
            } else {
              // const processed = defaultTestStore.accountsModule.followUpList.actions
              const processed: TActionFollowUp[] = this.formatFollowUpActions(response.data, parseInt(requestorId));
              return new requestAdminActionFollowUpSuccess({ status: response.status, data: processed });
            }
          }),
          catchError((error) => {
            return of(new requestAdminActionFollowUpFail(error));
          })
        );
      })
    );

    private formatFollowUpActions = <T extends TActionFollowUpApiElem >(followUps: T[], loggedUserId: number): T extends TActionFollowUpApiElem ? TActionFollowUp[] : any[] => {
        const res = followUps.map(f => {
          const apiElem = f as TActionFollowUpApiElem ;
          const calc: TActionFollowUp = {
            id: apiElem.id,
            accountId: apiElem.account ? apiElem.account.id : null,
            accountName: apiElem.account ? apiElem.account.name : null,
            creationDate: apiElem.creation_date ? new Date(apiElem.creation_date) : null,
           // scheduledDate:  null,
            domain: apiElem.domain,
            requestor: apiElem.requestor ? {
              displayName: apiElem.requestor.displayname,
              id: apiElem.requestor.id
            } : null,
            justification: apiElem.justification || '-',
            status: apiElem.status,
            message: apiElem.parameters ? apiElem.parameters[0] : 'No Comment Available',
            validators: apiElem.validators ? apiElem.validators.map(v => {
              return {
                displayName: v.displayname,
                id: v.id
              };
            }) : [],
            type: apiElem.type ? apiElem.type : (apiElem.hasOwnProperty('scheduled_date') ? 'ACCOUNT_RESET_PASSWORD' : 'ACCOUNT_CREATION'),
            cancellable: this.cancellable(apiElem, loggedUserId)
          };
          return calc as unknown;
        });
        return res as T extends  TActionFollowUpApiElem ? TActionFollowUp[] : any[];
      }

      private cancellable = (followUp: TActionFollowUpApiElem , loggedUserId): boolean => {
        return (
          (followUp.status === 'TO_BE_APPROVED' && followUp.requestor.id === loggedUserId)
          
        );
      }
      @Effect()
  public cancelFollowUpAction$ = this.actions$.pipe(
    ofType(CANCEL_ADMIN_PENDING_REQUEST),
  )
    .pipe(
      switchMap((action) => {
        return this.accountsListService.cancelActionFollowUp((action as any).payload).pipe(
          map((response) => {

            if (response.status.error) {
              return new cancelAdminPendingRequestFailed(response.status);
            } else {
              return new cancelAdminPendingRequestSuccess((action as any).payload);
            }
          }),
          catchError(error => {
            return of(new cancelAdminPendingRequestFailed(error.error.status || 'an error has occured'));
          })
        );
      })
    );
    }