import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { SuperAdminAccountStatsService } from 'src/app/shared/services/superadmin/superadmin-account-stats.service';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { Store, select } from '@ngrx/store';
import {
  LOAD_ADMIN_ACCOUNTS_LIST, SetUniueData, LoadAdminAccountsListSuccess, LoadAdminAccountsListFail,
  REMOVE_ACCOUNT_DEPUTIES, RemoveAccountDeputiesSuccess, SEARCH_ACCOUNT_DEPUTITY,ENABLE_ACCOUNT_END_OF_LIFE,
  searchAccountDeputityForModalSuccess, ADD_ACCOUNT_DEPUTIES, AddAccountDeputiesSuccess,EnableAccountsWithEndOfLifeSuccess,
  ENABLE_ACCOUNT, EnableAccountSuccess, EnableAccountFail, DISABLE_ACCOUNT, DisableAccountSuccess,EnableAccountsWithEndOfLifeFailure,
  DisableAccountFail, RESET_PASSWORD, ResetPasswordSuccess, LOAD_BUSINESS_HOURS, LoadBusinessHoursFail,
  LoadBusinessHoursSuccess, LOAD_ADMIN_ACCOUNT_NAME, LoadAdminAccountName, LoadAdminAccountNameSuccess, RESET_PASSWORD_SUCCESS, ADD_ACCOUNT_DEPUTIES_SUCCESS, ENABLE_ACCOUNT_SUCCESS, DISABLE_ACCOUNT_SUCCESS, LoadAdminAccountsList, SetSelectedAccounts, SET_SELECT_ALL, LOAD_ACCOUNT_DETAIL, LoadAccountDetailFail, LoadAccountDetailSuccess, EDIT_ACCOUNT_DESCRIPTION, EditAccountDescriptionSuccess, EditAccountDescriptionFail, EDIT_ACCOUNT_DESCRIPTION_SUCCESS, LoadAccountDetail
} from '../actions/accounts-list.actions';
import { TActionFollowUpApiElem, TScheduledFollowUpApiElem } from './../../../../shared/interfaces/shared/account/follow-upAPI';
import { TActionFollowUp, TScheduledPasswordFollowUp, followUpStatus, followActionType } from './../../../../shared/interfaces/shared/account/follow-up';
import {ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST,requestAdminScheduledFollowUp,requestAdminScheduledFollowUpSuccess,requestAdminScheduledFollowUpFail} from '../actions/admin-followup-list.actions';
import { getFilters, getAdminAddRemoveDeputiesModal, getAdminSelectedAccountsList, getAdminSelectedAccounts,getAdminAccountDetail, getSortedFilteredAccountList, getVisibleAccounts, getSelectAllStatus, getSelectedAccounts, getAccountsDetail } from '../selectors';
import { withLatestFrom, switchMap, mergeMap, catchError, filter, map, concatMap } from 'rxjs/operators';
import { IAccountAPI, IAccountAPIElem, IBusinessHoursAPIElem, IAccountHistoryAPIElem } from 'src/app/shared/interfaces/shared/account/accountAPI';
import { IAccount, IAccountDeputity, IBusinessHrsUTC, IAccountHistory } from 'src/app/shared/interfaces/shared/account/account';
import { IScheduledFollowUpAPI } from './../../../../shared/interfaces/shared/account/follow-upAPI';
import { orderBy, process } from '@progress/kendo-data-query';
import { of } from 'rxjs';
import { getIdentityID, getIdentity } from '../../../../shared/store/selectors';
import { createAccConfig } from 'src/app/core/create-account/create-account.config';
import { IIdentityApiElem, IDelegateIndentityApiElem } from 'src/app/shared/interfaces/shared/common/identity';
import { AccountsService } from 'src/app/shared/services/accounts.service';

@Injectable()
export class AdminListEffects {
  constructor(
    private actions$: Actions,
    private accountsListService: AccountsService,
    private adminService: SuperAdminAccountStatsService,
    private store: Store<IAdminAccountListState>
  ) { }
  // @Effect()
  // public loadAccountsList$ = this.actions$.pipe(
  //   ofType(LOAD_ADMIN_ACCOUNTS_LIST),
  //   withLatestFrom(this.store.pipe(select(getFilters)))
  // )
  //   .pipe(
  //     switchMap(([action, filters]) => {
  //       const uid = filters.account_name ? filters.account_name : ''
  //       const identity = filters.delegation_identity ? filters.delegation_identity : ''
  //       const solution = filters.solution_code ? filters.solution_code : ''
  //       if (uid || identity || solution) {
  //         return this.adminService.getAdminAccountsList({ uid, identity, solution }).pipe(
  //           mergeMap((response: IAccountAPI) => {
  //             const processed: IAccount[] = orderBy(response.data.map((acc) => this.formatAcc(acc)), [{ field: 'uid', dir: 'asc' }]);
  //             const filtered = this.filterAdminAccountList(processed, filters);
  //             console.log("admin-filtered-account-list");
  //             console.log(filtered);
  //             return [new SetUniueData(filtered), new LoadAdminAccountsListSuccess(filtered)];
  //           }),
  //           catchError((error) => {
  //             console.error(error);
  //             return of(new LoadAdminAccountsListFail(error));
  //           })
  //         );
  //       }
  //       else {
  //         return of(new LoadAdminAccountsListSuccess(null));
  //       }
  //     })
  //   );

  @Effect()
  public loadAccountsList$ = this.actions$.pipe(
    ofType(LOAD_ADMIN_ACCOUNTS_LIST),
    withLatestFrom(this.store.pipe(select(getFilters)))
  )
    .pipe(
      switchMap(([action, filters]) => {
        const uid = filters.account_name ? filters.account_name : ''
        const identity = filters.delegation_identity ? filters.delegation_identity : ''
        const solution = filters.solution_code ? filters.solution_code : ''
        if (uid || identity || solution) {
          return this.adminService.getAdminAccountsList({ uid, identity, solution }).pipe(
            mergeMap((response: IAccountAPI) => {
              const processed: IAccount[] = orderBy(response.data.map((acc) => this.formatAcc(acc)), [{ field: 'uid', dir: 'asc' }]);
              // const filtered = this.filterAdminAccountList(processed, filters);
              // console.log("admin-filtered-account-list");
              // console.log(filtered);
              return [new SetUniueData(processed), new LoadAdminAccountsListSuccess(processed)];
            }),
            catchError((error) => {
              console.error(error);
              return of(new LoadAdminAccountsListFail(error));
            })
          );
        }
        else {
          return of(new LoadAdminAccountsListSuccess(null));
        }
      })
    );

  @Effect()
  public searchAccountName$ = this.actions$
    .pipe(
      ofType(LOAD_ADMIN_ACCOUNT_NAME),
      filter((action: LoadAdminAccountName) => action.payload.term.length >= 4)
    )
    .pipe(
      switchMap((action: LoadAdminAccountName) => {
        return this.adminService.getAccountName(action.payload.term).pipe(
          map((res) => {
            const processed: IAccount[] = orderBy(res.data.map((acc) => this.formatAcc(acc)), [{ field: 'uid', dir: 'asc' }]);
            return new LoadAdminAccountNameSuccess(processed);
          }),
        );
      })
    );

  private filterAdminAccountList = (accounts: IAccount[], filters: any) => {
    let filteredAccounts = accounts;
    if (filters.delegation_identity) {
      filteredAccounts = accounts;
    }
    if (filters.account_name) {
      filteredAccounts = filteredAccounts.filter(x => x.uid.toLowerCase() === filters.account_name[0].toLowerCase())
    }
    if (filters.solution_code) {
      filteredAccounts = filteredAccounts.filter(x => x.contextCode.toLowerCase() === filters.solution_code[0].toLowerCase())
    }
    if (filters.environment) {
      filteredAccounts = filteredAccounts.filter(x => x.directoryEnvironment.toLowerCase() === filters.environment[0].toLowerCase())
    }
    if (filters.password_status) {
      filteredAccounts = filteredAccounts.filter(x => x.pwdStatus.toLowerCase() === filters.password_status[0].toLowerCase())
    }
    if (filters.domain) {
      filteredAccounts = filteredAccounts.filter(x => x.directoryDomain.toLowerCase() === filters.domain[0].toLowerCase())
    }

    return filteredAccounts;
  }
  private formatAcc = (acc: IAccountAPIElem): IAccount => {
    return {
      id: acc.id,
      compliance_status:{
        password_age:acc.compliance_status.password_age,
        account_inactivity:acc.compliance_status.account_inactivity,
        account_owners:acc.compliance_status.account_owners,
        enduser_identity:acc.compliance_status.enduser_identity,
        referenced_identity:acc.compliance_status.referenced_identity,
      },
      lifeCycleStatus: acc.lifecycle_status ?
        /enable/gi.test(acc.lifecycle_status) ? 'ENABLE' :
          /disable/gi.test(acc.lifecycle_status) ? 'DISABLE' :
            acc.lifecycle_status.toLocaleUpperCase() :
        'NONE',
      pwdRemainingDays: acc.pwd_expiration_days,
      pwdStatus: acc.doesat ? acc.pwd_expiration_days > 0 ? 'ACTIVE' : 'EXPIRED' : 'NO_PASSWORD',
      division: acc.solution ? acc.solution.division ? acc.solution.division.name : null : null,
      type: acc.type,
      last_name:acc.last_name,
      first_name:acc.first_name,
      email:acc.email,
      ai_email:acc.ai_email,
      uniqueKey:acc.unique_key,
      uid: acc.name,
      pwdLastSetUTC: acc.pwd_last_set_date ? new Date(acc.pwd_last_set_date) : undefined,
      distinguishedName: acc.dn ? acc.dn : '',
      creationDateUTC: acc.creation_date ? new Date(acc.creation_date) : undefined,
      lastLogonDateUTC: acc.last_logon_date ? new Date(acc.last_logon_date) : undefined,
      lastUpdatedDateUTC: acc.last_updated_date ? new Date(acc.last_updated_date) : undefined,
      unixEnabled: acc.unix_enabled,
      scheduledResetPwdDateUTC: acc.scheduled_reset_pwd_date ? new Date(acc.scheduled_reset_pwd_date) : null,
      // locked: Math.random() > 0.5 ? true : false,
      locked: acc.locked === undefined ? false : acc.locked,
      ownerDisplayName: acc.end_user ? acc.end_user.displayname : null,
      endUser: acc.end_user,
      directoryEnvironment: acc.directory ? acc.directory.project_phase : '',
      directoryType: acc.directory ? acc.directory.type : '',
      directoryDomain: acc.directory ? acc.directory.domain : '',
      hp: acc.hp,
      // contextName: acc.solution ? acc.solution.name : null,
      contextCode: acc.solution ? acc.solution.code : null,
      canReset: acc.doesat,
      contextName: `${acc.solution ? acc.solution.code : ''} - ${acc.solution ? acc.solution.name : ''}`,
      contextId: acc.solution.id,
      description: acc.description,
      end_of_lifecycle_date: acc.end_of_lifecycle_date ? new Date(acc.end_of_lifecycle_date) : undefined,
      AccountExpirationDays: acc.end_of_lifecycle_date ? Math.floor((new Date(acc.end_of_lifecycle_date).getTime() - (new Date()).getTime()) / (1000 * 60 * 60 * 24)) : 0,
    };
  }
  private getUnique = (state: IAccount[], property): string[] => {
    return state.reduce((prev, cur) => {
      return prev.indexOf(cur[property]) === -1 ? [...prev, cur[property]] : prev;
    }, []).filter(val => val !== '');
  }
  @Effect()
  public removeDeputies$ = this.actions$
    .pipe(
      ofType(REMOVE_ACCOUNT_DEPUTIES),
      withLatestFrom(this.store.pipe(select(getAdminAddRemoveDeputiesModal)), this.store.pipe(select(getAdminSelectedAccountsList)))
    )
    .pipe(
      switchMap(([action, modal, selectedAcc]) => {
        return this.adminService.removeDeputy(selectedAcc.map(acc => acc.id), modal.currentDeputies.map(dep => dep.login)).pipe(
          map((res) => {
            if (res.status.error) {
            } else {
              return new RemoveAccountDeputiesSuccess({ accIds: null, data: res.data, res: res.status });
            }
          }),
        );
      })
    );

  // @Effect()
  // public checkUserInSelectedDelegation$ = this.actions$
  //   .pipe(
  //     ofType(SET_SELECTED_ACCOUNTS),
  //     withLatestFrom(
  //       this.store.pipe(select(getSelectedAccountsList)),
  //       this.store.pipe(select(getIdentity)),
  //     )
  //   )
  //   .pipe(
  //     switchMap(([action, selectedAcc, id]) => {
  //       if (selectedAcc.length === 1) {
  //         return this.adminService.getAccountDeputies(selectedAcc[0].id).pipe(
  //           map((deps) => {
  //             const allDeputies: IAccountDeputity[] = deps.data.identities_delegate.map(dep => this.formatAccDeputy(dep));
  //             return new SetCanEditDeputiesOfAllSelected(allDeputies.some(dep => (dep.id === parseInt(id.id)) && dep.profile !== 'ACCOUNT_DEPUTY'));
  //           }
  //           ));
  //       }
  //       return of(new SetCanEditDeputiesOfAllSelected(false));
  //     }
  //     )
  //   );
  @Effect()
  public searchDeputies$ = this.actions$
    .pipe(
      ofType(SEARCH_ACCOUNT_DEPUTITY),
      filter((action: any) => action.payload.length >= createAccConfig.contextSearchMinChars),
    )
    .pipe(
      switchMap((action) => {
        return this.adminService.searchDeputies(action.payload).pipe(
          map((res) => {
            return new searchAccountDeputityForModalSuccess(res.data.map(d => this.formatDeputyFromIdentity(d)));
          }),
        );
      })
    );

  @Effect()
  public addDeputies$ = this.actions$
    .pipe(
      ofType(ADD_ACCOUNT_DEPUTIES),
      withLatestFrom(this.store.pipe(select(getAdminAddRemoveDeputiesModal)), this.store.pipe(select(getAdminSelectedAccountsList)))
    )
    .pipe(
      switchMap(([action, modal, selectedAcc]) => {
        return this.adminService.addDeputy(selectedAcc.map(acc => acc.id), modal.currentDeputies.map(dep => dep.login)).pipe(
          map((res) => {
            if (res.status.error) {
            } else {
              return new AddAccountDeputiesSuccess({ accIds: null, data: res.data, res: res.status });
            }
          }),
        );
      })
    );
  @Effect()
  public enableAccounts$ = this.actions$
    .pipe(ofType(ENABLE_ACCOUNT),
      withLatestFrom(this.store.pipe(select(getAdminSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        return this.adminService.editBulkLifecycleStatus(accounts, 'enabled').pipe(
          map(res => {
            return new EnableAccountSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new EnableAccountFail());
          })
        );
      })
    );

    @Effect()
    public loadAccountDetail$ = this.actions$.pipe(ofType(LOAD_ACCOUNT_DETAIL)).pipe(
      concatMap((action: { payload: number }) => {
        return this.accountsListService.getAccountDetail(action.payload,false).pipe(
          concatMap(detail => {
            // return this.accountsListService.getAccountHistory(detail.data.id).pipe(
            //   concatMap(hist => {
                return this.accountsListService.getAccountDomainId(detail.data.directory.domain).pipe(
                  concatMap(domain => {
                    return this.accountsListService.getAccountPolicy(domain.data[0].id).pipe(
                      map(policy => {
                        // return this.accountsListService.getAccountDeputies(detail.data.id).pipe(
                        //   map((deps) => {
                            if (policy.status.error) {
                              return new LoadAccountDetailFail(action.payload);
                            } else {
                              //const allDeputies: IAccountDeputity[] = deps.data.identities_delegate.map(dep => this.formatAccDeputy(dep));
                              //const history = this.formatAccHistory(hist.data);
                              // const deputies = allDeputies.filter(dep => dep.profile === 'ACCOUNT_DEPUTY');
                              // const indirectDeputies = allDeputies.filter(dep => dep.profile !== 'ACCOUNT_DEPUTY');
                              const combined: IAccount = { ...this.formatAcc(detail.data), max_description_length: policy.data.max_description_length ,compliance_status:detail.data.compliance_status};
                              return new LoadAccountDetailSuccess({ id: action.payload, data: combined });
                            }
                          })
                        );
                    //   })
                    // );
                //   })
                // );
              })
            );
          })
        );
      })
    );

    @Effect()
    public enableAccountsWithEndOfLife$ = this.actions$
      .pipe(ofType(ENABLE_ACCOUNT_END_OF_LIFE),
        withLatestFrom(this.store.pipe(select(getSelectedAccounts))))
      .pipe(
        switchMap(([action, accounts]) => {
          const end_of_lifecycle_date = (action as any).payload.end_of_lifecycle_date;
          const trigger = (action as any).payload.trigger;
          return this.accountsListService.editBulkLifecycleStatus(accounts, trigger == "Enable" ? 'enabled' : 'updated', end_of_lifecycle_date).pipe(
            map(res => {
              return new EnableAccountsWithEndOfLifeSuccess({ stats: res.data, res: res.status });
            }),
            catchError(err => {
              return of(new EnableAccountsWithEndOfLifeFailure());
            })
          );
        })
      );

  @Effect()
  public disableAccounts$ = this.actions$
    .pipe(ofType(DISABLE_ACCOUNT),
      withLatestFrom(this.store.pipe(select(getAdminSelectedAccounts))))
    .pipe(
      switchMap(([action, accounts]) => {
        return this.adminService.editBulkLifecycleStatus(accounts, 'disabled').pipe(
          map(res => {
            return new DisableAccountSuccess({ stats: res.data, res: res.status });
          }),
          catchError(err => {
            return of(new DisableAccountFail());
          })
        );
      })
    );
  @Effect()
  public resetAccounts$ = this.actions$
    .pipe(ofType(RESET_PASSWORD),
      map(a => a as { payload: { schedule: Date, excludedChars: string, type: 'CANCEL' | 'NOW' | 'SCHEDULE', pre_scheduledhour: number } }),
      withLatestFrom(this.store.pipe(select(getAdminSelectedAccounts))))
    .pipe(
      switchMap(([action, selection]) => {
        return this.adminService.resetBulkPassword(selection, action.payload.schedule, action.payload.type, action.payload.pre_scheduledhour).pipe(
          mergeMap(res => {

            return [new ResetPasswordSuccess({ status: res.data, res: res.status })];
          }),
        );
      })
    );
  @Effect()
  public requestBusinessHours$ = this.actions$
    .pipe(ofType(LOAD_BUSINESS_HOURS),
      switchMap(action => {
        return this.adminService.getBusinessHours().pipe(
          map(hrs => {
            if (hrs.status.error !== false) {
              return new LoadBusinessHoursFail();
            } else {
              return new LoadBusinessHoursSuccess(this.formatBusinessHours(hrs.data.opening_hours));
            }
          })
        );
      })
    );

    @Effect()
    public loadFollowUpScheduled$ = this.actions$.pipe(
      ofType(ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST),
      withLatestFrom(this.store.pipe(select(getIdentityID)))
    )
      .pipe(
        switchMap(([action, requestorId]) => {
          return this.accountsListService.getScheduledFollowUp(requestorId).pipe(
            map((response: IScheduledFollowUpAPI) => {
              if (response.status.error) {
                return new requestAdminScheduledFollowUpFail(response.status);
              } else {
                const processed: TScheduledPasswordFollowUp[] = this.formatFollowUpActions(response.data, parseInt(requestorId));
                return new requestAdminScheduledFollowUpSuccess({ status: response.status, data: processed });
              }
            }),
            catchError((error) => {
              return of(new requestAdminScheduledFollowUpFail(error));
            })
          );
        })
      );
  

  @Effect()
  public reloadAccountsAfterAction$ = this.actions$.pipe(
    ofType(RESET_PASSWORD_SUCCESS, ADD_ACCOUNT_DEPUTIES_SUCCESS, ENABLE_ACCOUNT_SUCCESS, DISABLE_ACCOUNT_SUCCESS),
    withLatestFrom(this.store.pipe(select(getAdminAccountDetail)))
    )
    .pipe(
      switchMap(([action, detail]) => {
        const actions: any[] = [new LoadAdminAccountsList()];
        if (!detail) {
          return actions;
        }
        if (detail) {
          actions.push(new LoadAccountDetail(detail.id));
        }
        if (detail.scheduledResetPwdDateUTC) {
          actions.push(new requestAdminScheduledFollowUp());
        }
        return actions;
      })
    );

  @Effect()
  public selectAllAccountsTrigger$ = this.actions$
    .pipe(
      ofType(SET_SELECT_ALL),
      withLatestFrom(
        this.store.pipe(select(getSortedFilteredAccountList)),
        this.store.pipe(select(getVisibleAccounts)),
        this.store.pipe(select(getSelectAllStatus)),
      )
    )
    .pipe(
      map(([action, state, selected, selectAllStatus]) => {
        
        switch (selectAllStatus) {

          case 'checked':
            return new SetSelectedAccounts({ ids: [], isAll: false });
          case 'unchecked':
          case 'indeterminate':
            return new SetSelectedAccounts({ ids: state.filter(acc => (!acc.locked && !acc.hp)).map(acc => acc.id), isAll: true });
        }
      })
    );

    @Effect()
    public editAccountDescription$ = this.actions$
      .pipe(ofType(EDIT_ACCOUNT_DESCRIPTION),
        withLatestFrom(this.store.pipe(select(getSelectedAccounts)), this.store.pipe(select(getAccountsDetail))))
      .pipe(
        switchMap(([action, selection, detail]) => {
          const acc = detail[selection[0]];
          const description = (action as any).payload;
          return this.accountsListService.editDescription(acc, description).pipe(
            mergeMap(res => {
              return [new EditAccountDescriptionSuccess({ id: acc.id, res: res.status })];
            }),
            catchError(err => {
              return [new EditAccountDescriptionFail({ id: acc.id, res: err })];
            })
          );
        })
      );
  
    @Effect()
    public afterEditDetail = this.actions$
      .pipe(
        ofType(EDIT_ACCOUNT_DESCRIPTION_SUCCESS),
        map(action => {
          return new LoadAccountDetail((action as any).payload.id);
        })
      );


  private formatDeputyFromIdentity = (api_data: IIdentityApiElem): IAccountDeputity => {
    return {
      id: api_data.id,
      displayName: api_data.displayname,
      profile: null,
      email: api_data.email,
      login: api_data.login,
      status:api_data.status
    };
  }
  private formatBusinessHours = (hours: IBusinessHoursAPIElem): IBusinessHrsUTC => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    return {
      openHr: parseInt(hours.opens_utc.split(':')[0]),
      openMin: parseInt(hours.opens_utc.split(':')[1]),
      closeHr: parseInt(hours.closes_utc.split(':')[0]),
      closeMin: parseInt(hours.closes_utc.split(':')[1]),
      days: hours.day_of_week.map(str => days.indexOf(str))
    };
  }
  private formatAccHistory = (accHist: IAccountHistoryAPIElem[]): IAccountHistory[] => {
    return accHist.map(h => {
      return {
        action: h.type,
        dateUtc: new Date(h.date),
        scheduledDateUtc: h.scheduled_date ? new Date(h.scheduled_date) : null,
        description: h.description,
        messageParams: h.parameters ? h.parameters.reduce((p, c, i) => {
          p[i + 1] = c || '';
          return p;
        }, {}) : null,
        message: h.type,
        owner: h.owner ? h.owner.displayname : ''
      };
    }).sort(a => a.dateUtc.getTime() * -1);
  }
  private formatFollowUpActions = <T extends TActionFollowUpApiElem | TScheduledFollowUpApiElem>(followUps: T[], loggedUserId: number): T extends TActionFollowUpApiElem ? TActionFollowUp[] : TScheduledPasswordFollowUp[] => {
    const res = followUps.map(f => {
      const apiElem = f as TActionFollowUpApiElem & TScheduledFollowUpApiElem;
      const calc: TActionFollowUp & TScheduledPasswordFollowUp = {
        id: apiElem.id,
        accountId: apiElem.account ? apiElem.account.id : null,
        accountName: apiElem.account ? apiElem.account.name : null,
        creationDate: apiElem.creation_date ? new Date(apiElem.creation_date) : null,
        scheduledDate: apiElem.scheduled_date ? new Date(apiElem.scheduled_date) : null,
        domain: apiElem.domain,
        requestor: apiElem.requestor ? {
          displayName: apiElem.requestor.displayname,
          id: apiElem.requestor.id
        } : null,
        justification: apiElem.justification || '-',
        status: apiElem.status,
        message: apiElem.parameters ? apiElem.parameters[0] : 'No Comment Available',
        validators: apiElem.validators ? apiElem.validators.map(v => {
          return {
            displayName: v.displayname,
            id: v.id
          };
        }) : [],
        type: apiElem.type ? apiElem.type : (apiElem.hasOwnProperty('scheduled_date') ? 'ACCOUNT_RESET_PASSWORD' : 'ACCOUNT_CREATION'),
        cancellable: this.cancellable(apiElem, loggedUserId)
      };
      return calc as unknown;
    });
    return res as T extends TActionFollowUpApiElem ? TActionFollowUp[] : TScheduledPasswordFollowUp[];
  }
  private cancellable = (followUp: TActionFollowUpApiElem & TScheduledFollowUpApiElem, loggedUserId): boolean => {
    return (
      (followUp.status === 'TO_BE_APPROVED' && followUp.requestor.id === loggedUserId) ||
      followUp.hasOwnProperty('scheduled_date') ||
      followUp.type === 'ACCOUNT_RESET_PASSWORD'
    );
  }

  private formatAccDeputy = (api_data: IDelegateIndentityApiElem): IAccountDeputity => {
    return {
      id: api_data.identity.id,
      displayName: api_data.identity.displayname,
      profile: api_data.profile,
      email: api_data.identity.email,
      login: api_data.identity.login,
      status:api_data.identity.status
    };
  }
}