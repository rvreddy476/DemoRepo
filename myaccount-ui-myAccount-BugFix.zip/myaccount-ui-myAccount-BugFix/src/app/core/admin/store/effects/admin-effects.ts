import { Actions, Effect, ofType } from '@ngrx/effects';
import { Injectable } from '@angular/core';
import { SuperAdminAccountStatsService } from 'src/app/shared/services/superadmin/superadmin-account-stats.service';
import { ISuperAdminAccountsStatsState } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-state';
import { Store } from '@ngrx/store';

import { switchMap, map, filter } from 'rxjs/operators';
import { createAccConfig } from 'src/app/core/create-account/create-account.config';
import { LOAD_ADMIN_ACCOUNTS_STATS, LoadAdminStatsSuccess, LoadAdminStatsFailed, LoadAdminStats } from '../actions/admin-actions';
import { LOAD_ACCOUNTS_LIST } from 'src/app/core/accounts/store';
import { LoadAdminAccountsList, LoadAdminAccountsListSuccess, LoadAdminAccountName, LoadAdminAccountNameSuccess } from '../actions/accounts-list.actions';
import { IAccountAPIElem } from 'src/app/shared/interfaces/shared/account/accountAPI';
import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { LOAD_ADMIN_DELEGATION_MEMBERS, LoadAdminDelegationMember, LoadAdminDelegationMemberSuccess, LOAD_ADMIN_SOLUTIONS, LoadAdminSolutions, LoadAdminSolutionsSuccess } from '../actions/accounts-list.actions';

@Injectable()
export class AdminEffects {
    constructor(
        private actions$: Actions,
        private adminService: SuperAdminAccountStatsService,
        private store: Store<ISuperAdminAccountsStatsState>
    ) { }
    @Effect()
    public loadAllAdminAccountsStats$ = this.actions$
        .pipe(ofType(LOAD_ADMIN_ACCOUNTS_STATS),
            switchMap((action: LoadAdminStats) => {
                try {
                    return this.adminService.getSuperAdminAccStats(action.payload.numberOfDays).pipe(
                        map(res => {
                            if (!res.status.error) {
                                return new LoadAdminStatsSuccess(res.data);
                            } else {
                                return new LoadAdminStatsFailed(res.status.message);
                            }
                        })
                    );
                } catch (error) {

                }

            })
        );

    @Effect()
    public searchOwner$ = this.actions$
        .pipe(
            ofType(LOAD_ADMIN_DELEGATION_MEMBERS),
            filter((action: LoadAdminDelegationMember) => action.payload.term.length >= createAccConfig.contextSearchMinChars)
        )
        .pipe(
            switchMap((action: LoadAdminDelegationMember) => {
                return this.adminService.getOwnerSearchList(action.payload.term).pipe(
                    map((res) => {
                        return new LoadAdminDelegationMemberSuccess(res.data);
                    }),
                );
            })
        );

    


    @Effect()
    public searchContext$ = this.actions$
        .pipe(
            ofType(LOAD_ADMIN_SOLUTIONS),
            filter((action: LoadAdminSolutions) => action.payload.term.length >= createAccConfig.contextSearchMinChars)
        )
        .pipe(
            switchMap((action: LoadAdminSolutions) => {
                return this.adminService.getSolutions(action.payload.term).pipe(
                    map((res) => {
                        console.log("admin-account-filter-solution-effect")
                        console.log(res);
                        return new LoadAdminSolutionsSuccess(res.data);
                    }),
                );
            })
        );
}