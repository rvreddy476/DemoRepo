
import { ISuperAdminAccountsStatsState } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-state';
import * as adminActions from '../actions/admin-actions';


export const initialState: ISuperAdminAccountsStatsState = {
    loading: false,
    loaded: false,
    error: false,
    data: {
        disabled: 0,
        orphan: 0,
        pending: 0,
        total_accounts: 0,
        last_updated_date: '',
        account_stats: []
    }
}

export function AdminReducer(state = initialState, action: adminActions.AdminActions): ISuperAdminAccountsStatsState {

    switch (action.type) {

        case adminActions.LOAD_ADMIN_ACCOUNTS_STATS: {
            return {
                ...state,
                loading: true
            };
        }
        case adminActions.LOAD_ADMIN_ACCOUNTS_STATS_SUCESS: {
            return {
                ...state,
                loading: false,
                loaded: true,
                data: action.payload
            };
        }
        case adminActions.LOAD_ADMIN_ACCOUNTS_STATS_FAILED: {
            return {
                ...state,
                loading: false,
                loaded: true,
                error: true,
            };
        }
        default: {
            return {
                ...state,
                loading: true,
                loaded: false,
                error: true,
            };
        }
    }
}