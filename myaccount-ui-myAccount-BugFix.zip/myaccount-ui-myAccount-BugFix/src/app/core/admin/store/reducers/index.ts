import { ISuperAdminAccountsStatsState } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-state';
import { ActionReducerMap } from '@ngrx/store';
import { AdminReducer } from './admin-reducer';
import { IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { AdminAccountListReducer } from './admin-account-list.reducer';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { IAdminFollowUpState } from 'src/app/shared/interfaces/super-admin/admin- followuplist-state';
import { AdminFollowUpReducer } from './admin-followup-list.reducer';
import {IAdminOrphanAccountState} from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state'
import {AdminOrphanAccountReducer} from './admin-orphanaccounts-list.reducer'

export interface IAdminState {
    accountsList: IAdminAccountListState;
    adminStats: ISuperAdminAccountsStatsState;
    followUpList: IAdminFollowUpState;
    orphanAccountsList:IAdminOrphanAccountState;

}

export const reducers: ActionReducerMap<IAdminState> = {
    adminStats: AdminReducer,
    accountsList: AdminAccountListReducer,
    followUpList: AdminFollowUpReducer,
    orphanAccountsList:AdminOrphanAccountReducer
};