
import {  TActionFollowUp } from './../../../../shared/interfaces/shared/account/follow-up';
import * as fromActions from '../actions/admin-followup-list.actions';
import { IAdminFollowUpState } from 'src/app/shared/interfaces/super-admin/admin- followuplist-state';
import { DebugRenderer2 } from '@angular/core/src/view/services';


export const initialState: IAdminFollowUpState = { 
    actions: [],
    selected: [],
    modal: {
        action: null,
        open: false,
        loading: false,
        res: null
    }
};

export function AdminFollowUpReducer(state = initialState, action: fromActions.AdminAcceptListAction): IAdminFollowUpState {
    switch (action.type) {

        case fromActions.ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST: {       
            return {
                ...state
            };
        }
        case fromActions.ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS: {
            return {
                ...state,
                actions: action.payload.data as TActionFollowUp[]
            };
        }

        case fromActions.ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_FAIL: {
            return {
                ...state
            };
        }


        case fromActions.SELECT_FOLLOW_UP: {
            return {
                ...state,
                selected: [action.payload[0]]
            };
        }
        case fromActions.DESELECT_FOLLOW_UP: {
            return {
                ...state,
                selected: state.selected.filter(x => action.payload.indexOf(x) === -1)
            };
        }

        case fromActions.ADMIN_OPEN_FOLLOW_UP_MODAL: {
            return {
                ...state,
                modal: {
                    action: action.payload,
                    loading: false,
                    res: null,
                    open: true
                }
            };
        }
        case fromActions.ADMIN_CLOSE_FOLLOW_UP_MODAL: {
            return {
                ...state,
                modal: {
                    action: null,
                    loading: false,
                    res: null,
                    open: state.modal.loading
                }
            };
        }

        case fromActions.CANCEL_ADMIN_PENDING_REQUEST: {
            return {
                ...state,
                modal: {
                    ...state.modal,
                    loading: true,
                    res: null,
                }
            };
        }
        case fromActions.CANCEL_ADMIN_PENDING_REQUEST_SUCCESS: {
            ;
            return {
                ...state,
                modal: {
                    ...state.modal,
                    loading: false,
                    res: {
                        code: null,
                        type: null,
                        error: false,
                        message: 'Cancellation in Progress',
                    },
                }
            };
        }
   
        case fromActions.CANCEL_ADMIN_PENDING_REQUEST_FAILED: {
            return {
                ...state,
                modal: {
                    ...state.modal,
                    loading: false,
                    res: action.payload,
                }
            };
        }
    }

    return state;
}
