import { IAdminOrphanAccountState ,IOrphanAccount,TOrhpanMode} from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state';
import * as adminActions from '../actions/admin-orphanaccounts-list.actions';
import {CompositeFilterDescriptor,FilterDescriptor, isCompositeFilterDescriptor} from '@progress/kendo-data-query'
import { MAX_ACCOUNT_SELECTION_LENGTH } from 'src/app/config/parameters';
import { filterAdminAccountList, filterAdminOrphanAccountList } from './filters';
import { convertToR3QueryMetadata } from '@angular/core/src/render3/jit/directive';

export const initialState: IAdminOrphanAccountState = {
    loading: false,
    loaded: false,
    error: false,
    data:new Array<IOrphanAccount>(),
    orphanAccountMode:'ALL',
    selectedAccounts: [],
    showOnlySelected:false,
    searchTerm:'',
    selectedAccountsDetails: {},
    isPrimaryFilterModified:false,
    viewState:{
        visibleColumns: [],
        showOnlySelected: false,
        detailRowID: '',
        showOnlyUID: [],
        gridState: {
            skip: 0,
            take: 50,
        },
        filterByTile: null,
        detail_filter_toggle:true,
        apidata:[]
    },
    filters: {
        account_name: null,
        solution_code: null,
        environment: null,
        password_status: null,
        password_lifetime: null,
        domain_name: null,
        account_type:null,
        account_uid:null
    },
    assignOrphanModal: {
      open: false,
      loading: true,
      response: null,
      responseList: []
  },
    unique: {
      lifeCycleStatus: [],
      directoryEnvironment: [],
      directoryType: [],
      pwdStatus: [],
      directoryDomain: [],
      type: [],
      division: [],
      solutions:[]
  }
}

export function AdminOrphanAccountReducer(state = initialState, action: adminActions.AdminOrphanAccountsListAction): IAdminOrphanAccountState {
  const getUnique = (filtered: IOrphanAccount[], property): string[] => {
    return filtered.reduce((prev, cur) => {
        return prev.indexOf(cur[property]) === -1 ? [...prev, cur[property]] : prev;
    }, []).filter(val => val !== '');
}

    switch (action.type) {
      
 
      case adminActions.LOAD_ADMIN_SOLUTION_SEARCHTERM:{
        return{
          ...state,
          searchTerm:action.payload
        }
      }

      case adminActions.OPEN_ASSIGN_ORPHAN_MODAL:
      {
        return{
          ...state,
          assignOrphanModal:{
            ...state.assignOrphanModal,
            open:true,
            responseList:[],
            response:null

          }
        }
      }
      case adminActions.ASSIGN_ORPHAN_ACCOUNT_FAILURE:
      {
        return{
          ...state,
          assignOrphanModal:{
            ...state.assignOrphanModal,
            open:true,
            responseList:[]

          }
        }
      }

     

      case adminActions.CLOSE_ASSIGN_ORPHAN_MODAL:
      {
        return{
          ...state,
          assignOrphanModal:{
            ...state.assignOrphanModal,
            open:false,
            loading:false
          }
        }
      }
      case adminActions.ASSIGN_ORPHAN_ACCOUNT_SUCCESS:{
        return{
          ...state,
          assignOrphanModal:{
            ...state.assignOrphanModal,
            open:true,
            loading:false,
            responseList:action.payload.stats,
            response:action.payload.res
          }
        }
      }

      case adminActions.SET_ORPHAN_ACCOUNTS_PAGE_STATE: {
        return {
          ...state,
          viewState: {
            ...state.viewState,
            gridState: {
              ...state.viewState.gridState,
              skip: action.payload.skip,
              take: action.payload.take,
            },
          },
        };
      }
  
        case adminActions.LOAD_ADMIN_ORPHAN_ACCOUNTS: {
            return {
                ...state,
                loading: true
            };
        }
        
        case adminActions.LOAD_ADMIN_ORPHAN_ACCOUNTS_SUCCESS: {
          if (action.payload != null) {
            const apiData=filterAdminOrphanAccountList(action.payload.data as IOrphanAccount[],state.filters);
            return {
              ...state,
              viewState:{
                ...state.viewState,
                apidata:apiData
              },
              selectedAccounts:[],
              loading: false,
              loaded: true,
              data:apiData
          };
          }
          else{
            return {
              ...state,
              selectedAccounts:[],
              loading:false
            }
          }
        }
        case adminActions.LOAD_ADMIN_ORPHAN_ACCOUNTS_FILTERED: {
            return {
              ...state,
              loading: false,
              loaded: true,
              data:filterAdminOrphanAccountList(state.viewState.apidata as IOrphanAccount[],state.filters)
          };
        }
        case adminActions.LOAD_ADMIN_ORPHAN_ACCOUNTS_FAILED: {
            return {
                ...state,
                loading: false,
                loaded: true,
                error: true,
            };
        }
        case adminActions.SET_ADMIN_ORPHAN_MODE:{
            return{
                ...state,
                orphanAccountMode:action.payload
            }
        }
        case adminActions.SET_ORPHAN_ACCOUNTS_FILTER_STATE: {
            return {
              ...state,
              viewState: {
                ...state.viewState,
                gridState: {
                  ...state.viewState.gridState,
                  filter: action.payload,
                  skip: 0,
                },
              },
            };
          }
          case adminActions.MODIFY_ORPHAN_ACCOUNTS_FILTER_STATE: {
            // const f = action.payload.filter;
            // const fd = f as FilterDescriptor;
            // const cfd = f as CompositeFilterDescriptor;
      
            // let newFilter: CompositeFilterDescriptor;
            // let modified = false;
      
            // // create if no filter exists
            // if (!state.viewState.gridState.filter) {
            //   const hasAValue = (f as any).value !== ''
            //   newFilter = f ? {
            //     logic: 'and',
            //     filters: hasAValue ? [f] : []
            //   } : null;
            // } else {
            //   newFilter = {
            //     logic: 'and',
            //     filters: state.viewState.gridState.filter.filters.map(statefilterElem => {
            //       const compElem = statefilterElem as CompositeFilterDescriptor;
            //       const filterElem = statefilterElem as FilterDescriptor;
      
            //       if (compElem.filters) {
            //         if (compElem.filters.every((cfe: FilterDescriptor) => {
            //           return cfe.field === action.payload.field;
            //         })) {
            //           modified = true;
            //           return cfd;
            //         } else {
            //           return statefilterElem;
            //         }
            //       } else if (filterElem.field) {
            //         if (filterElem.field === action.payload.field) {
            //           modified = true;
            //           return f;
            //         } else {
            //           return statefilterElem;
            //         }
            //       }
            //     }).filter(f => {
            //       return (f !== null) && (f.hasOwnProperty('value') ? (f as any).value !== '' : true);
            //     })
            //   };
            //   const hasAValue = (f as any).value !== ''
            //   if (!modified && f !== null && hasAValue) {
            //     newFilter.filters = [...newFilter.filters, f];
            //   }
            // }
            // 
            // const filterValues = newFilter.filters.map(f => isCompositeFilterDescriptor(f) ? f.filters :[f] ).reduce((p,n) => p.concat(n), []);
            return {
              ...state,
              filters:{
               ...state.filters,
               account_name:action.payload.value
              },
              viewState: {
                ...state.viewState,
                
                gridState: {
                  ...state.viewState.gridState,
                  filter: null,
                  skip: 0,
                },
              },
            };
          }
          case adminActions.ORPHAN_DETAIL_FILTER_TOGGLE: {
            return {
                ...state,
                viewState: {
                    ...state.viewState,
                    detail_filter_toggle:action.payload
                }
            }
        }
        case adminActions.ORPHAN_MODIFY_PRIMARY_FILTER_FLAG:{
          return {
            ...state,
            isPrimaryFilterModified:action.payload
          }
        }
        case adminActions.ORPHAN_RESET_DETAIL_FILTER: {
            return {
                ...state,
                data:state.viewState.apidata,
                filters: {
                    account_name: null,
                    solution_code:null,
                    environment: null,
                    password_status: null,
                    password_lifetime: null,
                    domain_name: null,
                    account_type:null,
                    account_uid:null
                }
            }
        }
        case adminActions.ORPHAN_SET_SELECTED_ACCOUNTS: {
          // should assign loaded account to detail account?
          const isLoaded = action.payload.ids.length === 1 ? Boolean(state.selectedAccountsDetails[action.payload.ids[0]]) : false;
          let selectedAccounts = []
          let showMaxLengthWarning = false
          // TEMP
          if (action.payload.ids.length > MAX_ACCOUNT_SELECTION_LENGTH) {
            showMaxLengthWarning = true
            let include = []
            let tryAd = []
            action.payload.ids.forEach(acc => {
              if (state.selectedAccounts.indexOf(acc) !== -1) {
                include.push(acc)
              } else {
                tryAd.push(acc)
              }
            })
    
    
            selectedAccounts = [...include, ...tryAd].splice(0, MAX_ACCOUNT_SELECTION_LENGTH)
          }
          else {
            selectedAccounts = action.payload.ids
          }
    
          return {
            ...state,
            selectedAccounts
          };
        }
    
        case adminActions.ORPHAN_SET_VIEW_ONLY_SELECTED: {
          return {
            ...state,
            viewState: {
              ...state.viewState,
              showOnlySelected: action.payload,
              gridState: {
                ...state.viewState.gridState,
                skip: 0
              }
            }
          };
        }
        case adminActions.SET_ORPHAN_FILTER_VALUES:
            {
              const isPrimaryFilterModified=action.payload.field==='account_uid' || action.payload.field==='account_type'?true:false;
                return {
                    ...state,
                    isPrimaryFilterModified:isPrimaryFilterModified,
                    filters: {
                        ...state.filters,
                        [action.payload.field]: [action.payload.value][0] !== "" ? [action.payload.value] : null
                    }
                }
            }
        case adminActions.ORPHAN_SET_UNIQUE_DATA: {
        const unique = {
              lifeCycleStatus: getUnique(action.payload, 'lifeCycleStatus'),
              division: getUnique(action.payload, 'division'),
              type: getUnique(action.payload, 'type'),
              pwdStatus: getUnique(action.payload, 'pwdStatus'),
              directoryEnvironment: getUnique(action.payload, 'environment'),
              directoryType: getUnique(action.payload, 'directory'),
              directoryDomain: getUnique(action.payload, 'domain'),
              solutions:getUnique(action.payload,'solution_code').filter(x=>x !== null && x!== undefined && x!==''),
          };
          return {
              ...state,
              unique: unique
          }
      }

        case adminActions.SET_ORPHAN_ACCOUNTS_SORT_STATE: {
          return {
            ...state,
            viewState: {
              ...state.viewState,
              gridState: {
                ...state.viewState.gridState,
                sort: action.payload,
              },
            },
          };
        }

        

        default : {
            return {
                ...state,
                loading:false,
                loaded: false,
                error: true,
            };
        }
    }
}