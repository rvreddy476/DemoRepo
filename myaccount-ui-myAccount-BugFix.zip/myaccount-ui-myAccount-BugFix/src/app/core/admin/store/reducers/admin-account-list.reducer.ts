import { IAccountsListState, IAccount } from '../../../../shared/interfaces/shared/account/account';
import * as adminListActions from '../actions/accounts-list.actions';
import { SortDescriptor, CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { createAccConfig } from 'src/app/core/create-account/create-account.config';
import { createEntityAdapter } from '@ngrx/entity';
import { MAX_ACCOUNT_SELECTION_LENGTH } from 'src/app/config/parameters';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { filterAdminAccountList } from './filters';

export const accountsListAdaptor = createEntityAdapter<IAccount>();

export const initialState: IAdminAccountListState = {
    accounts: [],
    detailAccount: null,
    filters: {
        delegation_identity: null,
        account_name: null,
        solution_code: null,
        environment: null,
        account_lifetime: null,
        password_status: null,
        password_lifetime: null,
        domain: null
    },
    view_state: {
        detail_filter_toggle: true,
        visibleColumns: [],
        showOnlySelected: false,
        detailRowID: '',
        showOnlyUID: [],
        gridState: {
            skip: 0,
            take: 50,
        },
        filterByTile: null,
    },
    unique: {
        lifeCycleStatus: [],
        directoryEnvironment: [],
        directoryType: [],
        pwdStatus: [],
        directoryDomain: [],
        type: [],
        division: [],
    },
    solutions: [],
    delegation_members: [],
    account_names: [],
    loading: false,
    selectedAccounts: [],
    selectedAccountsDetails: {},
    editDescriptionModal: {
        open: false,
        response: null,
        loading: false
      },
    enabledColumns: {
        ['uid']: true, // Account Name
        ['lifeCycleStatus']: true, // Account status
        ['pwdStatus']: true, // Password Lifetime
        ['pwdRemainingDays']: true, // Password Lifetime
        ['contextName']: true, // Context
        ['type']: true, // Account Type
        ['directoryEnvironment']: true, // Environment
        ['directoryDomain']: true, // Directory
        ['division']: true, // Division
    },
    addRemoveDeputyModal: {
        open: false,
        mode: null,
        loading: false,
        response: null,
        responseList: [],
        previousDeputies: [],
        permissionToEditSelection: false,
        blacklist: [],
        currentDeputies: [],
        deputyOptions: [],
        loadingSearch: false,
    },


    resetPassModal: {
        open: false,
        loading: false,
        response: null,
        responseList: []
    },
    businessHrsUTC: null,
    enableDisableAccModal: {
        open: false,
        mode: null,
        loading: false,
        response: null,
        responseList: [],
    },
    endOfLifeModal:{
        open: false,
        trigger: 'Enable',
        loading: false,
        response: null,
        responseList: []
    }
};

export function AdminAccountListReducer(state = initialState, action: adminListActions.AccountsListAction): IAdminAccountListState {

    const defaultSort: SortDescriptor[] = [];

    const getUnique = (filtered: IAccount[], property): string[] => {
        return filtered.reduce((prev, cur) => {
            return prev.indexOf(cur[property]) === -1 ? [...prev, cur[property]] : prev;
        }, []).filter(val => val !== '');
    }

    switch (action.type) {

        //#region acounts list
        case adminListActions.LOAD_ADMIN_ACCOUNTS_LIST: {
            return {
                ...state,
                loading: true,

            };
        }
        case adminListActions.LOAD_ADMIN_ACCOUNTS_LIST_FAIL: {
            return {
                ...state,
                loading: false,
            };
        }
        case adminListActions.LOAD_ADMIN_ACCOUNTS_LIST_SUCCESS: {
            if (action.payload != null) {
                return {
                    ...state,
                    // loaded: true,
                    loading: false,
                    accounts: filterAdminAccountList(action.payload, state.filters),
                    selectedAccounts: []
                };
            }
            else {
                return {
                    ...state,
                    // loaded: true,
                    loading: false,
                };
            }

        }

        case adminListActions.SET_SELECTED_ACCOUNTS: {
            // should assign loaded account to detail account?
            const isLoaded = action.payload.ids.length === 1 ? Boolean(state.selectedAccountsDetails[action.payload.ids[0]]) : false;
            let selectedAccounts = []
            let showMaxLengthWarning = false
            // TEMP
            if (action.payload.ids.length > MAX_ACCOUNT_SELECTION_LENGTH) {
                showMaxLengthWarning = true
                let include = []
                let tryAd = []
                action.payload.ids.forEach(acc => {
                    if (state.selectedAccounts.indexOf(acc) !== -1) {
                        include.push(acc)
                    } else {
                        tryAd.push(acc)
                    }
                })


                selectedAccounts = [...include, ...tryAd].splice(0, MAX_ACCOUNT_SELECTION_LENGTH)
            }
            else {
                selectedAccounts = action.payload.ids
            }

            return {
                ...state,
                selectedAccounts,
                //showMaxLengthWarning,
                //detailAccount: isLoaded ? state.selectedAccountsDetails[action.payload.ids[0]] : null
            };
        }

        case adminListActions.LOAD_ACCOUNT_DETAIL_SUCCESS: {

            return {
              ...state,
              detailAccount: action.payload.data,
              selectedAccountsDetails: { ...state.selectedAccountsDetails, [action.payload.data.id]: action.payload.data },
              selectedAccounts: action.payload.data.locked ? state.selectedAccounts.filter(acc => acc !== action.payload.data.id) : state.selectedAccounts
            };
          }
        case adminListActions.LOAD_ADMIN_SOLUTIONS_SUCCESS:
            {
                return {
                    ...state,
                    solutions: action.payload
                }
            }
        case adminListActions.LOAD_ADMIN_DELEGATION_MEMBERS_SUCCESS:
            {
                console.log(action.payload);
                return {
                    ...state,
                    delegation_members: action.payload
                }
            }
        case adminListActions.LOAD_ADMIN_ACCOUNT_NAME_SUCCESS:
            {
                console.log(action.payload);
                return {
                    ...state,
                    account_names: action.payload.map(a => a.uid)
                }
            }

        case adminListActions.SET_FILTER_VALUES:
            {
                return {
                    ...state,
                    filters: {
                        ...state.filters,
                        [action.payload.field]: [action.payload.value][0] !== "" ? [action.payload.value] : null
                    }
                }
            }
        case adminListActions.SET_UNIQUE_DATA: {
            const unique = {
                lifeCycleStatus: getUnique(action.payload, 'lifeCycleStatus'),
                division: getUnique(action.payload, 'division'),
                type: getUnique(action.payload, 'type'),
                pwdStatus: getUnique(action.payload, 'pwdStatus'),
                directoryEnvironment: getUnique(action.payload, 'directoryEnvironment'),
                directoryType: getUnique(action.payload, 'directoryType'),
                directoryDomain: getUnique(action.payload, 'directoryDomain')
            };
            return {
                ...state,
                unique: unique
            }
        }
        case adminListActions.DETAIL_FILTER_TOGGLE: {
            return {
                ...state,
                view_state: {
                    ...state.view_state,
                    detail_filter_toggle: action.payload,

                }
            }
        }
        case adminListActions.RESET_DETAIL_FILTER: {
            return {
                ...state,
                accounts: [],
                filters: {
                    delegation_identity: null,
                    account_name: null,
                    solution_code: null,
                    environment: null,
                    account_lifetime: null,
                    password_status: null,
                    password_lifetime: null,
                    domain: null
                }
            }
        }

 //#region edit account description
 case adminListActions.OPEN_EDIT_DESCRIPTION_MODAL: {
    return {
      ...state,
      editDescriptionModal: {
        ...state.editDescriptionModal,
        open: true,
        response: null
      }
    };
  }

  case adminListActions.CLOSE_EDIT_DESCRIPTION_MODAL: {
    return {
      ...state,
      editDescriptionModal: {
        ...state.editDescriptionModal,
        open: false,
        response: null
      }
    };
  }

  case adminListActions.EDIT_ACCOUNT_DESCRIPTION: {
    return {
      ...state,
      editDescriptionModal: {
        ...state.editDescriptionModal,
        loading: true
      }
    };
  }

  case adminListActions.EDIT_ACCOUNT_DESCRIPTION_SUCCESS: {
    return {
      ...state,
      editDescriptionModal: {
        ...state.editDescriptionModal,
        loading: false,
        response: action.payload.res
      }
    };
  }
  case adminListActions.EDIT_ACCOUNT_DESCRIPTION_FAIL: {
    return {
      ...state,
      editDescriptionModal: {
        ...state.editDescriptionModal,
        loading: false,
        response: action.payload.res
      }
    };
  }

  //#endregion
//region end of life
case adminListActions.OPEN_END_OF_LIFE_MODAL: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        open: true,
        trigger: action.payload
      }
    };
  }
  case adminListActions.CLOSE_END_OF_LIFE_MODAL: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        open: false,
        trigger: null,
        loading: false,
        response: null,
        responseList: [],

      }
    };
  }
  case adminListActions.OPEN_TASA_MODAL: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        open: true,
        trigger: "Enable",
        loading: false,
        response: null,
        responseList: [],
      }
    };
  }
  case adminListActions.CLOSE_TASA_MODAL: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        open: false,
        trigger: null,
        loading: false,
        response: null,
        responseList: [],
      }
    };
  }
  case adminListActions.ENABLE_ACCOUNT_END_OF_LIFE:
  case adminListActions.UPDATE_ACCOUNT_END_OF_LIFE: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        loading: true,
        response: null,
        responseList: []
      }
    };
  }
  case adminListActions.ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS:
  case adminListActions.UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        loading: false,
        response: action.payload.res,
        responseList: action.payload.stats
      }
    };
  }
  case adminListActions.ENABLE_ACCOUNT_END_OF_LIFE_FAILURE:
  case adminListActions.UPDATE_ACCOUNT_END_OF_LIFE_FAILURE: {
    return {
      ...state,
      endOfLifeModal: {
        ...state.endOfLifeModal,
        loading: false,
        responseList: []
      }
    };
  }
  // end region
        // ###region deputy

        case adminListActions.OPEN_ADD_REMOVE_DEPUTY_MODAL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    mode: action.payload,
                    open: true,
                }
            };
        }

        case adminListActions.CLOSE_ADD_REMOVE_DEPUTY_MODAL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    currentDeputies: [],
                    deputyOptions: [],
                    blacklist: [],
                    open: state.addRemoveDeputyModal.loading,
                    response: null,
                    loadingSearch: false,
                    loading: false
                }
            };
        }


        case adminListActions.SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    permissionToEditSelection: action.payload
                }
            };
        }

        case adminListActions.LOAD_DEPUTY_BLACKLIST_SUCCESS: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    blacklist: action.payload
                }
            };
        }

        case adminListActions.LOAD_DEPUTY_BLACKLIST_FAIL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal
                }
            };
        }

        case adminListActions.SEARCH_ACCOUNT_DEPUTITY: {
            const shouldClearOption = action.payload.length <= createAccConfig.contextSearchMinChars;
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    loadingSearch: true,
                    deputyOptions: shouldClearOption ? [] : state.addRemoveDeputyModal.deputyOptions
                }
            };
        }

        case adminListActions.SEARCH_ACCOUNT_DEPUTITY_SUCCESS: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    deputyOptions: action.payload,
                    loadingSearch: false
                }
            };
        }

        case adminListActions.SEARCH_ACCOUNT_DEPUTITY_FAIL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    deputyOptions: [],
                    loadingSearch: false
                }
            };
        }

        case adminListActions.SET_SELECTED_DEPUTIES_MODAL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    currentDeputies: action.payload,
                }
            };
        }

        case adminListActions.REMOVE_ACCOUNT_DEPUTIES:
        case adminListActions.ADD_ACCOUNT_DEPUTIES: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    loading: true
                }
            };
        }
        case adminListActions.REMOVE_ACCOUNT_DEPUTIES_SUCCESS:
        case adminListActions.ADD_ACCOUNT_DEPUTIES_SUCCESS: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    loading: false,
                    response: action.payload.res,
                    responseList: action.payload.data
                }
            };
        }
        case adminListActions.REMOVE_ACCOUNT_DEPUTIES_FAIL:
        case adminListActions.ADD_ACCOUNT_DEPUTIES_FAIL: {
            return {
                ...state,
                addRemoveDeputyModal: {
                    ...state.addRemoveDeputyModal,
                    response: action.payload.res,
                    loadingSearch: false,
                    loading: false,
                }
            };
        }
        case adminListActions.OPEN_ENABLE_DISABLE_MODAL: {
            return {
                ...state,
                enableDisableAccModal: {
                    ...state.enableDisableAccModal,
                    open: true,
                    mode: action.payload
                }
            };
        }
        case adminListActions.CLOSE_ENABLE_DISABLE_MODAL: {
            return {
                ...state,
                enableDisableAccModal: {
                    ...state.enableDisableAccModal,
                    open: false,
                    response: null,
                    responseList: [],
                    mode: null
                }
            };
        }
        case adminListActions.DISABLE_ACCOUNT:
        case adminListActions.ENABLE_ACCOUNT: {
            return {
                ...state,
                enableDisableAccModal: {
                    ...state.enableDisableAccModal,
                    loading: true,
                    response: null,
                    responseList: []
                }
            };
        }
        case adminListActions.DISABLE_ACCOUNT_SUCCESS:
        case adminListActions.ENABLE_ACCOUNT_SUCCESS: {
            return {
                ...state,
                enableDisableAccModal: {
                    ...state.enableDisableAccModal,
                    loading: false,
                    response: action.payload.res,
                    responseList: action.payload.stats
                }
            };
        }
        case adminListActions.DISABLE_ACCOUNT_FAIL:
        case adminListActions.ENABLE_ACCOUNT_FAIL: {
            return {
                ...state,
                enableDisableAccModal: {
                    ...state.enableDisableAccModal,
                    loading: false,
                    responseList: []
                }
            };
        }

        case adminListActions.OPEN_RESET_PASS_MODAL: {
            return {
                ...state,
                resetPassModal: {
                    ...state.resetPassModal,
                    open: true,
                }
            };
        }


        case adminListActions.RESET_PASSWORD: {
            return {
                ...state,
                resetPassModal: {
                    response: null,
                    loading: true,
                    open: true,
                    responseList: null
                }
            };
        }

        case adminListActions.RESET_PASSWORD_SUCCESS: {
            return {
                ...state,
                resetPassModal: {
                    response: action.payload.res,
                    responseList: action.payload.status,
                    loading: false,
                    open: true,
                }
            };
        }

        case adminListActions.RESET_PASSWORD_FAIL: {
            return {
                ...state,
                resetPassModal: {
                    response: action.payload.res,
                    loading: false,
                    open: true,
                    responseList: null
                }
            };
        }

        case adminListActions.LOAD_BUSINESS_HOURS_SUCCESS: {
            return {
                ...state,
                businessHrsUTC: action.payload
            };
        }

        case adminListActions.CLOSE_RESET_PASS_MODAL: {
            return {
                ...state,
                resetPassModal: {
                    response: null,
                    loading: false,
                    open: state.resetPassModal.loading, // prevent close if loading
                    responseList: null
                }
            };
        }



    }
    return state;
    //#endregion
}
