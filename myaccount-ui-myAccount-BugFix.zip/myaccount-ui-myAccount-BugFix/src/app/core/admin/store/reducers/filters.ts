import { IAccount } from 'src/app/shared/interfaces/shared/account/account';
import { IOrphanAccount } from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state';

export const filterAdminAccountList = (accounts: IAccount[], filters: any) => {
    let filteredAccounts = accounts;
    if (filters.delegation_identity) {
      filteredAccounts = accounts;
    }
    if (filters.account_name) {
      filteredAccounts = filteredAccounts.filter(x => x.uid.toLowerCase() === filters.account_name[0].toLowerCase())
    }
    if (filters.solution_code) {
      filteredAccounts = filteredAccounts.filter(x => x.contextCode.toLowerCase() === filters.solution_code[0].toLowerCase())
    }
    if (filters.environment) {
      filteredAccounts = filteredAccounts.filter(x => x.directoryEnvironment.toLowerCase() === filters.environment[0].toLowerCase())
    }
    if (filters.password_status) {
      filteredAccounts = filteredAccounts.filter(x => x.pwdStatus.toLowerCase() === filters.password_status[0].toLowerCase())
    }
    if (filters.domain) {
      filteredAccounts = filteredAccounts.filter(x => x.directoryDomain.toLowerCase() === filters.domain[0].toLowerCase())
    }

    return filteredAccounts;
  }


  export const filterAdminOrphanAccountList = (accounts: IOrphanAccount[], filters: any) => {
    let filteredAccounts = accounts;
    if (filters.account_name) {
      filteredAccounts = filteredAccounts.filter(x => x.name.toLowerCase().includes(filters.account_name.toLowerCase()))
    }
    if (filters.solution_code) {
      filteredAccounts = filteredAccounts.filter(x =>x.solution_code!==null && x.solution_code!==undefined && x.solution_code!==''&&  x.solution_code.toLowerCase() === filters.solution_code[0].toLowerCase() )
    }
    if (filters.password_status) {
      filteredAccounts = filteredAccounts.filter(x => x.pwdStatus.toLowerCase()=== filters.password_status[0].toLowerCase())
    }
    
    if (filters.environment) {
      filteredAccounts = filteredAccounts.filter(x => x.environment.toLowerCase() === filters.environment[0].toLowerCase())
    }
    if (filters.account_type) {
      filteredAccounts = filteredAccounts.filter(x => x.type.toLowerCase() === filters.account_type[0].toLowerCase())
    }
    if (filters.domain_name) {
      filteredAccounts = filteredAccounts.filter(x => x.domain.toLowerCase() === filters.domain_name[0].toLowerCase())
    }
    // if (filters.account_uid) {
    //   filteredAccounts = filteredAccounts.filter(x => x.name.toLowerCase() === filters.account_uid[0].toLowerCase())
    // }

    return filteredAccounts;
  }