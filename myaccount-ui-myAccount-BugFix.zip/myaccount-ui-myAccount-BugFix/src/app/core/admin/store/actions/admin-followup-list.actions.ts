import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { Action } from '@ngrx/store';
import { TActionFollowUp,TScheduledPasswordFollowUp } from 'src/app/shared/interfaces/shared/account/follow-up';

export const ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST = '[admin-follow-up-list] get follow-up actions';
export const ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS = '[admin-follow-up-list] get follow-up actions successful';
export const ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_FAIL = '[admin-follow-up-list] get follow-up actions failed';

export const ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST = '[admin-follow-up-list] get follow-up resets scheduled';
export const ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST_SUCCESS = '[admin-follow-up-list] get follow-up resets scheduled successful';
export const ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST_FAIL = '[admin-follow-up-list] get follow-up resets scheduled failed';

export const SELECT_FOLLOW_UP = '[admin-follow-up-list] select account pending approvial';
export const DESELECT_FOLLOW_UP = '[admin-follow-up-list] deselect account pending approvial';

export const ADMIN_OPEN_FOLLOW_UP_MODAL = '[admin-follow-up-list] Open Cancel Request Modal';
export const ADMIN_CLOSE_FOLLOW_UP_MODAL = '[admin-follow-up-list] Close Cancel Request Modal';

export const CANCEL_ADMIN_PENDING_REQUEST = '[admin-follow-up-list] Cancel Pending Requst';
export const CANCEL_ADMIN_PENDING_REQUEST_SUCCESS = '[admin-follow-up-list] Cancel Pending Requst successful';
export const CANCEL_ADMIN_PENDING_REQUEST_FAILED = '[admin-follow-up-list] Cancel Pending Requst failed';

export class requestAdminActionFollowUp implements Action {
    public readonly type = ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST;
}
export class requestAdminActionFollowUpSuccess implements Action {
    public readonly type = ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_SUCCESS;
    constructor(public payload: { status: IResStatus, data: TActionFollowUp[] }) { }
}
export class requestAdminActionFollowUpFail implements Action {
    public readonly type = ADMIN_REQUEST_ACTION_FOLLOW_UP_LIST_FAIL;
    constructor(public payload: IResStatus) { }
}
export class requestAdminScheduledFollowUp implements Action {
    public readonly type = ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST;
}
export class requestAdminScheduledFollowUpSuccess implements Action {
    public readonly type = ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST_SUCCESS;
    constructor(public payload: {status: IResStatus, data: TScheduledPasswordFollowUp[]}) {}
}
export class requestAdminScheduledFollowUpFail implements Action {
    public readonly type = ADMIN_REQUEST_SCHEDULED_FOLLOW_UP_LIST_FAIL;
    constructor(public payload: IResStatus) {}
}
export class selectAdminFollowUpAction implements Action {
    public readonly type = SELECT_FOLLOW_UP;
    constructor(public payload: number[]) { }
}
export class deselectAdminFollowUpAction implements Action {
    public readonly type = DESELECT_FOLLOW_UP;
    constructor(public payload: number[]) { }
}
export class openAdminFollowUpModal implements Action {
    public readonly type = ADMIN_OPEN_FOLLOW_UP_MODAL;
    constructor(public payload:  TActionFollowUp) { }
}
export class closeAdminFollowUpModal implements Action {
    public readonly type = ADMIN_CLOSE_FOLLOW_UP_MODAL;
}

export class cancelAdminPendingRequest implements Action {
    public readonly type = CANCEL_ADMIN_PENDING_REQUEST;
    constructor(public payload: number) { }
}

export class cancelAdminPendingRequestSuccess implements Action {
    public readonly type = CANCEL_ADMIN_PENDING_REQUEST_SUCCESS;
    constructor(public payload: { id: number }) { }
}

export class cancelAdminPendingRequestFailed implements Action {
    public readonly type = CANCEL_ADMIN_PENDING_REQUEST_FAILED;
    constructor(public payload: IResStatus) { }
}



export type AdminAcceptListAction =
    | requestAdminActionFollowUp
    | requestAdminActionFollowUpSuccess
    | requestAdminActionFollowUpFail
    | selectAdminFollowUpAction
    | deselectAdminFollowUpAction
    | openAdminFollowUpModal
    | closeAdminFollowUpModal
    | cancelAdminPendingRequest
    | cancelAdminPendingRequestSuccess
    | cancelAdminPendingRequestFailed
    | requestAdminScheduledFollowUp
    | requestAdminScheduledFollowUpSuccess
    | requestAdminScheduledFollowUpFail;