import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { Action } from '@ngrx/store';
import { IOrphanAccount,TOrhpanMode } from '../../../../shared/interfaces/super-admin/admin-orphanlist-state';
import { State, CompositeFilterDescriptor, SortDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { API } from 'src/app/shared/interfaces/shared/api';

export const LOAD_ADMIN_ORPHAN_ACCOUNTS = '[ADMIN ORHPANACCOUNTS LIST] get all orphan accounts'
export const LOAD_ADMIN_ORPHAN_ACCOUNTS_SUCCESS = '[ADMIN ORHPANACCOUNTS LIST] get all orphan accounts success'
export const LOAD_ADMIN_ORPHAN_ACCOUNTS_FAILED = '[ADMIN ORHPANACCOUNTS LIST] get all orphan accounts failed'
export const LOAD_ADMIN_ORPHAN_ACCOUNTS_FILTERED="[[ADMIN ORHPANACCOUNTS LIST] get all filtered  orphan accounts]";

export const SET_ADMIN_ORPHAN_MODE='[ADMIN ORPHANACCOUNTS MODE] set orphan mode'

export const SET_ORPHAN_ACCOUNTS_FILTER_STATE='[ADMIN ORPHAN FILTERS] set orphan filters'
export const MODIFY_ORPHAN_ACCOUNTS_FILTER_STATE='[ADMIN ORPHAN FILTERS] modify orphan filters'

export const ORPHAN_DETAIL_FILTER_TOGGLE = '[ADMIN ORPHAN] detail filter toggle'
export const ORPHAN_RESET_DETAIL_FILTER = '[ADMIN ORPHAN] reset detail filter'

export const ORPHAN_SET_SELECT_ALL='[ADMIN ORPHAN] set select all'
export const ORPHAN_SET_VIEW_ONLY_SELECTED='[ADMIN ORPHAN] set view only selected'
export const ORPHAN_SET_SELECTED_ACCOUNTS='[ADMIN ORPHAN] set selected accounts'
export const OPEN_ASSIGN_ORPHAN_MODAL = '[Account] Open Assign orphan Modal';
export const CLOSE_ASSIGN_ORPHAN_MODAL = '[Account] Close Assign orphan Modal';

export const ASSIGN_ORPHAN_ACCOUNT = '[Orphan Account] Assign orphan account';
export const ASSIGN_ORPHAN_ACCOUNT_SUCCESS = '[Orphan Account] Assign orphan account success';
export const ASSIGN_ORPHAN_ACCOUNT_FAILURE ='[Orphan Account] Assign orphan account failure';

export const SET_ORPHAN_ACCOUNTS_SORT_STATE = '[ADMIN ORPHAN] Set Accounts Sort';
export const SET_ORPHAN_ACCOUNTS_LIST = '[ADMIN ORPHAN] Set Accounts List';
export const SET_ORPHAN_ACCOUNTS_PAGE_STATE = '[ADMIN ORPHAN] Set Accounts Page';
export const ORPHAN_SET_UNIQUE_DATA='[ADMIN ORPHAN] set orphan unique data'

export const SET_ORPHAN_FILTER_VALUES='[ADMIN ORPHAN] set orphan filter values'

export const ORPHAN_MODIFY_PRIMARY_FILTER_FLAG='[ADMIN ORPHAN] modify primary filter flag'

export const LOAD_ADMIN_SOLUTION_SEARCHTERM='[ADMIN ORPHAN] load admin solution search term'

export class LoadAdminOrphanAccounts implements Action {
    public readonly type = LOAD_ADMIN_ORPHAN_ACCOUNTS;
    constructor(){}
}
export class LoadAdminOrphanFilteredAccounts implements Action{
  public readonly type=LOAD_ADMIN_ORPHAN_ACCOUNTS_FILTERED;
  constructor(){}
}

export class LoadAdminOrphanAccountsSuccess implements Action {
    public readonly type = LOAD_ADMIN_ORPHAN_ACCOUNTS_SUCCESS;
    constructor(public payload: { status: IResStatus, data: IOrphanAccount[] }) { }
}
export class LoadAdminOrphanAccountsFail implements Action {
    public readonly type = LOAD_ADMIN_ORPHAN_ACCOUNTS_FAILED;
    constructor(public payload: IResStatus) { }
}

export class AssignOrphanAccount implements Action {
  public readonly type = ASSIGN_ORPHAN_ACCOUNT;
  constructor(public payload: { solution_code: string,context_type:string, end_user:string}) { }
}

export class AssignOrphanAccountSuccess implements Action {
  public readonly type = ASSIGN_ORPHAN_ACCOUNT_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}

export class AssignOrphanAccountFail implements Action {
  public readonly type = ASSIGN_ORPHAN_ACCOUNT_FAILURE;
}

export class SetOrphanAccountMode implements Action{
    public readonly type = SET_ADMIN_ORPHAN_MODE;
    constructor(public payload: TOrhpanMode) { }
}

export class SetOrphanAccountsFilter implements Action {
    public readonly type = SET_ORPHAN_ACCOUNTS_FILTER_STATE;
    constructor(public payload: CompositeFilterDescriptor) { }
}
  
export class ModifyOrphanAccountsFilter implements Action {
    public readonly type = MODIFY_ORPHAN_ACCOUNTS_FILTER_STATE;
    constructor(public payload: { field: string, value:string}) { }
}

export class OrphanDetailFilterToggle implements Action {
    public readonly type = ORPHAN_DETAIL_FILTER_TOGGLE;
    constructor(public payload: boolean) { }
  }

  export class OrphanModifyPrimaryFilterFlag implements Action {
    public readonly type = ORPHAN_MODIFY_PRIMARY_FILTER_FLAG;
    constructor(public payload: boolean) { }
  }
  export class OrphanResetDetailFilter implements Action {
    public readonly type = ORPHAN_RESET_DETAIL_FILTER;
  }

  export class OrphanSelectAllAccounts implements Action {
    public readonly type = ORPHAN_SET_SELECT_ALL;
  }
  export class LoadOrphanSolutionWithTerm implements Action {
    public readonly type = LOAD_ADMIN_SOLUTION_SEARCHTERM;
    constructor(public payload:string){}
  }
  
  export class OrphanSetViewOnlySelectedAccounts implements Action {
    public readonly type = ORPHAN_SET_VIEW_ONLY_SELECTED;
    constructor(public payload: boolean) { }
  }
  
  export class OrphanSetSelectedAccounts implements Action {
    public readonly type = ORPHAN_SET_SELECTED_ACCOUNTS;
    constructor(public payload: { ids: number[], isAll: boolean }) { }
  }
  export class SetOrphanAccountsSort implements Action {
    public readonly type = SET_ORPHAN_ACCOUNTS_SORT_STATE;
    constructor(public payload: SortDescriptor[]) { }
  }
  export class SetOrphanAccountsList implements Action {
    public readonly type = SET_ORPHAN_ACCOUNTS_LIST;
    constructor(public payload: IOrphanAccount[]) { }
  }
  
  export class SetOrphanAccountsPage implements Action {
    public readonly type = SET_ORPHAN_ACCOUNTS_PAGE_STATE;
    constructor(public payload: State) { }
  }

  export class SetOrphanUniqueData implements Action {
    public readonly type = ORPHAN_SET_UNIQUE_DATA;
    constructor(public payload: any) { }
  }
  export class SetOrphanFilterValues implements Action {
    public readonly type = SET_ORPHAN_FILTER_VALUES;
    constructor(public payload: { field: string, value: string }) { }
  }

  export class OpenAssignOrphanModal implements Action {
    public readonly type = OPEN_ASSIGN_ORPHAN_MODAL;
  }
  
  export class CloseAssignOrphanModal implements Action {
    public readonly type = CLOSE_ASSIGN_ORPHAN_MODAL;
  }

export type AdminOrphanAccountsListAction =
    | LoadAdminOrphanAccounts
    | LoadAdminOrphanAccountsSuccess
    | LoadAdminOrphanAccountsFail
    | SetOrphanAccountMode
    | SetOrphanAccountsFilter
    | ModifyOrphanAccountsFilter
    | OrphanDetailFilterToggle
    | OrphanResetDetailFilter
    | OrphanSelectAllAccounts
    | OrphanSetSelectedAccounts
    | OrphanSetViewOnlySelectedAccounts
    | OpenAssignOrphanModal
    | CloseAssignOrphanModal
    | SetOrphanAccountsList
    | SetOrphanAccountsPage
    | SetOrphanAccountsSort
    | SetOrphanUniqueData
    | SetOrphanFilterValues
    | LoadOrphanSolutionWithTerm
    | AssignOrphanAccount
    | AssignOrphanAccountFail
    | AssignOrphanAccountSuccess
    | LoadAdminOrphanFilteredAccounts
    | OrphanModifyPrimaryFilterFlag
