import { IAccountDeputity, IBusinessHrsUTC } from './../../../../shared/interfaces/shared/account/account';
import { Action } from '@ngrx/store';
import { State, CompositeFilterDescriptor, SortDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { IAccount, IUniqueGridData, IAvailableActions } from '../../../../shared/interfaces/shared/account/account';
import { IResStatus } from 'src/app/shared/interfaces/shared/api/status';
import { IBulkAddDeputyApiElem } from 'src/app/shared/interfaces/shared/common/identity';
import { AccList_API } from 'src/app/shared/interfaces/account-list/api.namespace';
import { API } from 'src/app/shared/interfaces/shared/api';
import { IAccountAPIElem } from 'src/app/shared/interfaces/shared/account/accountAPI';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { IIdentity } from 'src/app/shared/interfaces/identity/identity';

export const LOAD_ADMIN_ACCOUNTS_LIST = '[ADMIN] Load admin Accounts';
export const LOAD_ADMIN_ACCOUNTS_LIST_FAIL = '[ADMIN] Load admin Accounts Fail';
export const LOAD_ADMIN_ACCOUNTS_LIST_SUCCESS = '[ADMIN] Load admin Accounts Success';
export const LOAD_ADMIN_SOLUTIONS = '[ADMIN] get all solutions'
export const LOAD_ADMIN_SOLUTIONS_SUCCESS = '[ADMIN] get all solutions success'
export const LOAD_ADMIN_SOLUTIONS_FAILED = '[ADMIN] get all solutions failed'
export const LOAD_ADMIN_DELEGATION_MEMBERS = '[ADMIN] get all delegation members'
export const LOAD_ADMIN_DELEGATION_MEMBERS_SUCCESS = '[ADMIN] get all delegation members success'
export const LOAD_ADMIN_DELEGATION_MEMBERS_FAILED = '[ADMIN] get all delegation members failed'
export const LOAD_ADMIN_ACCOUNT_NAME = '[ADMIN] get all account names'
export const LOAD_ADMIN_ACCOUNT_NAME_SUCCESS = '[ADMIN] get all account names success'
export const LOAD_ACCOUNTS_LIST = '[Account] Load Accounts';
export const LOAD_ACCOUNTS_LIST_FAIL = '[Account] Load Accounts Fail';
export const LOAD_ACCOUNTS_LIST_SUCCESS = '[Account] Load Accounts Success';

export const SET_SELECT_ALL = '[Account] Toggle All Accounts Selected';
export const SET_FILTER_VALUES = '[ADMIN] set the filter values'
export const SET_UNIQUE_DATA = '[ADMIN] set unique data'
export const SET_ACCOUNTS_SHOW_UID_LIST = '[Account] Set accounts to show by ID';
export const SET_ACCOUNTS_FILTER_STATE = '[Account] Set Accounts Filter';
export const SET_SELECTED_ACCOUNTS = '[Account] Set Selected Accounts';
export const SET_VIEW_ONLY_SELECTED = '[Account] Set view only selected accounts';
export const SET_ACCOUNTS_FILTER_BY_TILE = '[Account] Set Accounts Tile Filter';
export const SET_ACCOUNTS_SORT_STATE = '[Account] Set Accounts Sort';
export const SET_ACCOUNTS_LIST = '[Account] Set Accounts List';
export const SET_ACCOUNTS_PAGE_STATE = '[Account] Set Accounts Page';

export const LOAD_ACCOUNT_DETAIL = '[Account] Load Account Detail';
export const LOAD_ACCOUNT_DETAIL_FAIL = '[Account] Load Account Detail Fail';
export const LOAD_ACCOUNT_DETAIL_SUCCESS = '[Account] Load Account Detail Success';

export const DETAIL_FILTER_TOGGLE = '[ADMIN] detail filter toggle'
export const RESET_DETAIL_FILTER = '[ADMIN] reset detail filter'
export const ADD_BENCHMARK = 'Add Benchmark';
//=====================================START - ADD/REMOVE DEPUTY============================================
export const SEARCH_ACCOUNT_DEPUTITY = '[ADMIN] Search Deputies for modal';
export const SEARCH_ACCOUNT_DEPUTITY_SUCCESS = '[ADMIN] Search Deputies for modal Sucess';
export const SEARCH_ACCOUNT_DEPUTITY_FAIL = '[ADMIN] Search Deputies for modal Failed';
export const SET_SELECTED_DEPUTIES_MODAL = '[ADMIN] set selected deputies in modal';
export const SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED = '[ADMIN] set can edit deputies of all selected accounts';
export const LOAD_DEPUTY_BLACKLIST = '[ADMIN] Load Deputy Blacklist for popup(s)';
export const LOAD_DEPUTY_BLACKLIST_SUCCESS = '[ADMIN] Load Deputy Blacklist Success';
export const LOAD_DEPUTY_BLACKLIST_FAIL = '[ADMIN] Load Deputy Blacklist on Failed';
export const OPEN_ADD_REMOVE_DEPUTY_MODAL = '[ADMIN] Open Add Remove Deputy Modal';
export const CLOSE_ADD_REMOVE_DEPUTY_MODAL = '[ADMIN] Close Add Remove Deputy Modal';
export const ADD_ACCOUNT_DEPUTIES = '[ADMIN] add account deputies';
export const ADD_ACCOUNT_DEPUTIES_SUCCESS = '[ADMIN] add account deputies Success';
export const ADD_ACCOUNT_DEPUTIES_FAIL = '[ADMIN] add account deputies on Failed';
export const REMOVE_ACCOUNT_DEPUTIES = '[ADMIN] remove account deputies';
export const REMOVE_ACCOUNT_DEPUTIES_SUCCESS = '[ADMIN] remove account deputies Success';
export const REMOVE_ACCOUNT_DEPUTIES_FAIL = '[ADMIN] remove account deputies on Failed';
//=======================================END - ADD/REMOVE DEPUTY==============================================
export const OPEN_ENABLE_DISABLE_MODAL = '[ADMIN] open enable disable modal'
export const CLOSE_RESET_PASS_MODAL = '[ADMIN] close reset password modal'
export const OPEN_RESET_PASS_MODAL = '[ADMIN] open reset password modal'
export const DISABLE_ACCOUNT_FAIL = '[ADMIN] disable account failed'
export const DISABLE_ACCOUNT_SUCCESS = '[ADMIN] disable account success'
export const DISABLE_ACCOUNT = '[ADMIN] disable account'
export const ENABLE_ACCOUNT_FAIL = '[ADMIN] enable account failed'
export const ENABLE_ACCOUNT_SUCCESS = '[ADMIN] enable account success'
export const ENABLE_ACCOUNT = '[ADMIN] enable account'
export const RESET_PASSWORD_FAIL = '[ADMIN] reset password fail'
export const RESET_PASSWORD_SUCCESS = '[ADMIN] reset password success'
export const RESET_PASSWORD = '[ADMIN] reset password'
export const CLOSE_ENABLE_DISABLE_MODAL = '[ADMIN] cloase enable disable modal'
export const OPEN_END_OF_LIFE_MODAL = '[Account] Open end of life modal';
export const CLOSE_END_OF_LIFE_MODAL = '[Account] close end of life modal';
export const ENABLE_ACCOUNT_END_OF_LIFE = '[Account] enable and update the EOL date';
export const ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS = '[Account] enable and update the EOL date - success';
export const ENABLE_ACCOUNT_END_OF_LIFE_FAILURE = '[Account] enable and update the EOL date - failure';
export const UPDATE_ACCOUNT_END_OF_LIFE = '[Account] update the EOL date';
export const UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS = '[Account] update the EOL date - success';
export const UPDATE_ACCOUNT_END_OF_LIFE_FAILURE = '[Account] update the EOL date - failure';
export const OPEN_TASA_MODAL = '[Account] open tasa modal';
export const CLOSE_TASA_MODAL = '[Account] close tasa modal';
export const LOAD_BUSINESS_HOURS = '[Account] Load business hours UTC';
export const LOAD_BUSINESS_HOURS_SUCCESS = '[Account] Load business hours UTC Success';
export const LOAD_BUSINESS_HOURS_FAIL = '[Account] Load business hours UTC Failed';
//=======================================Start - Edit Description Model==============================================
export const OPEN_EDIT_DESCRIPTION_MODAL = '[Account] Open Edit description Modal';
export const CLOSE_EDIT_DESCRIPTION_MODAL = '[Account] Close Edit description Modal';
export const EDIT_ACCOUNT_DESCRIPTION = '[Account] edit account description';
export const EDIT_ACCOUNT_DESCRIPTION_SUCCESS = '[Account] edit account description Success';
export const EDIT_ACCOUNT_DESCRIPTION_FAIL = '[Account] edit account description on Failed';
//=======================================End - Edit Description Model==============================================

export class LoadAdminAccountsList implements Action {
  public readonly type = LOAD_ADMIN_ACCOUNTS_LIST;
}

export class LoadAdminAccountsListFail implements Action {
  public readonly type = LOAD_ADMIN_ACCOUNTS_LIST_FAIL;
  constructor(public payload: any) { }
}

export class LoadAccountDetail implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL;
  constructor(public payload: number) { }
}
export class LoadAccountDetailSuccess implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL_SUCCESS;
  constructor(public payload: { id: number, data: IAccount }) { }
}
export class LoadAccountDetailFail implements Action {
  public readonly type = LOAD_ACCOUNT_DETAIL_FAIL;
  constructor(public payload: number) { }
}

export class LoadAdminAccountsListSuccess implements Action {
  public readonly type = LOAD_ADMIN_ACCOUNTS_LIST_SUCCESS;
  constructor(public payload: IAccount[]) { }
}

export class LoadAdminSolutions implements Action {
  public readonly type = LOAD_ADMIN_SOLUTIONS;
  constructor(public payload: { term: string }) { }
}
export class LoadAdminSolutionsSuccess implements Action {
  public readonly type = LOAD_ADMIN_SOLUTIONS_SUCCESS;
  constructor(public payload: CreateAcc_API.Get.Solution[]) { }
}
export class LoadAdminSolutionsFailed implements Action {
  public readonly type = LOAD_ADMIN_SOLUTIONS_FAILED;
  constructor(public payload: any) { }
}
export class LoadAdminDelegationMember implements Action {
  public readonly type = LOAD_ADMIN_DELEGATION_MEMBERS;
  constructor(public payload: { term: string }) { }
}
export class LoadAdminDelegationMemberSuccess implements Action {
  public readonly type = LOAD_ADMIN_DELEGATION_MEMBERS_SUCCESS;
  constructor(public payload: IIdentity[]) { }
}
export class LoadAdminDelegationMemberFailed implements Action {
  public readonly type = LOAD_ADMIN_DELEGATION_MEMBERS_FAILED;
  constructor(public payload: any) { }
}
export class LoadAdminAccountName implements Action {
  public readonly type = LOAD_ADMIN_ACCOUNT_NAME;
  constructor(public payload: { term: string }) { }
}
export class LoadAdminAccountNameSuccess implements Action {
  public readonly type = LOAD_ADMIN_ACCOUNT_NAME_SUCCESS;
  constructor(public payload: IAccount[]) { }
}
export class SetFilterValues implements Action {
  public readonly type = SET_FILTER_VALUES;
  constructor(public payload: { field: string, value: string }) { }
}
export class SetUniueData implements Action {
  public readonly type = SET_UNIQUE_DATA;
  constructor(public payload: any) { }
}

export class DetailFilterToggle implements Action {
  public readonly type = DETAIL_FILTER_TOGGLE;
  constructor(public payload: boolean) { }
}
export class ResetDetailFilter implements Action {
  public readonly type = RESET_DETAIL_FILTER;
}

export class SelectAllAccounts implements Action {
  public readonly type = SET_SELECT_ALL;
}

export class SetAccountsShowUidList implements Action {
  public readonly type = SET_ACCOUNTS_SHOW_UID_LIST;
  constructor(public payload: string[]) { }
}

export class LoadAccountsList implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST;
}

export class LoadAccountsListFail implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST_FAIL;
  constructor(public payload: any) { }
}

export class LoadAccountsListSuccess implements Action {
  public readonly type = LOAD_ACCOUNTS_LIST_SUCCESS;
  constructor(public payload: IAccount[]) { }
}

export class SetAccountsFilter implements Action {
  public readonly type = SET_ACCOUNTS_FILTER_STATE;
  constructor(public payload: CompositeFilterDescriptor) { }
}

export class SetSelectedAccounts implements Action {
  public readonly type = SET_SELECTED_ACCOUNTS;
  constructor(public payload: { ids: number[], isAll: boolean }) { }
}

export class SetViewOnlySelectedAccounts implements Action {
  public readonly type = SET_VIEW_ONLY_SELECTED;
  constructor(public payload: boolean) { }
}

export class SetAccountsFilterByTile implements Action {
  public readonly type = SET_ACCOUNTS_FILTER_BY_TILE;
  constructor(public payload: string) { }
}

export class AddBenchmark implements Action {
  public readonly type = ADD_BENCHMARK;
  constructor(public payload: { event: string; time: Date }) { }
}

export class SetAccountsSort implements Action {
  public readonly type = SET_ACCOUNTS_SORT_STATE;
  constructor(public payload: SortDescriptor[]) { }
}
export class SetAccountsList implements Action {
  public readonly type = SET_ACCOUNTS_LIST;
  constructor(public payload: IAccount[]) { }
}

export class SetAccountsPage implements Action {
  public readonly type = SET_ACCOUNTS_PAGE_STATE;
  constructor(public payload: State) { }
}
//=====================================START - ADD/REMOVE DEPUTY============================================
export class searchAccountDeputityForModal implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY;
  constructor(public payload: string) { }
}
export class searchAccountDeputityForModalSuccess implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY_SUCCESS;
  constructor(public payload: IAccountDeputity[]) { }
}
export class searchAccountDeputityForModalFail implements Action {
  public readonly type = SEARCH_ACCOUNT_DEPUTITY_FAIL;
  constructor(public payload: IResStatus) { }
}
export class LoadDeputyBlacklist implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST;
  constructor(public payload: { contextId: number, domain: string }) { }
}
export class LoadDeputyBlacklistSuccess implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST_SUCCESS;
  constructor(public payload: number[]) { }
}
export class LoadDeputyBlacklistFail implements Action {
  public readonly type = LOAD_DEPUTY_BLACKLIST_FAIL;
  constructor(public payload: IResStatus) { }
}
export class OpenAddRemoveDeputyModal implements Action {
  public readonly type = OPEN_ADD_REMOVE_DEPUTY_MODAL;
  constructor(public payload: 'Add' | 'Remove') { }
}
export class CloseAddRemoveDeputyModal implements Action {
  public readonly type = CLOSE_ADD_REMOVE_DEPUTY_MODAL;
}
export class SetCanEditDeputiesOfAllSelected implements Action {
  public readonly type = SET_CAN_EDIT_DEPUTIES_OF_ALL_SELECTED;
  constructor(public payload: boolean) { }
}
export class AddAccountDeputies implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES;
}
export class AddAccountDeputiesSuccess implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES_SUCCESS;
  constructor(public payload: { accIds: number[], data: IBulkAddDeputyApiElem[], res: IResStatus }) { }
}
export class AddAccountDeputiesFail implements Action {
  public readonly type = ADD_ACCOUNT_DEPUTIES_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}

export class RemoveAccountDeputies implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES;
}
export class RemoveAccountDeputiesSuccess implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES_SUCCESS;
  constructor(public payload: { accIds: number[], data: IBulkAddDeputyApiElem[], res: IResStatus }) { }
}
export class RemoveAccountDeputiesFail implements Action {
  public readonly type = REMOVE_ACCOUNT_DEPUTIES_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class setSelectedDeputitiesModal implements Action {
  public readonly type = SET_SELECTED_DEPUTIES_MODAL;
  constructor(public payload: IAccountDeputity[]) { }
}
//=======================================END - ADD/REMOVE DEPUTY==============================================

//=======================================Start - Account Actions==============================================
export class ResetPassword implements Action {
  public readonly type = RESET_PASSWORD;
  constructor(public payload: { schedule: Date, excludedChars: string, type: 'CANCEL' | 'NOW' | 'SCHEDULE', pre_scheduledhour: number }) { }
}
export class ResetPasswordSuccess implements Action {
  public readonly type = RESET_PASSWORD_SUCCESS;
  constructor(public payload: { status: API.BulkElemRes[], res: IResStatus }) { }
}
export class ResetPasswordFail implements Action {
  public readonly type = RESET_PASSWORD_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}

export class EnableAccounts implements Action {
  public readonly type = ENABLE_ACCOUNT;
}
export class EnableAccountSuccess implements Action {
  public readonly type = ENABLE_ACCOUNT_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class EnableAccountFail implements Action {
  public readonly type = ENABLE_ACCOUNT_FAIL;
}

export class DisableAccounts implements Action {
  public readonly type = DISABLE_ACCOUNT;
}
export class DisableAccountSuccess implements Action {
  public readonly type = DISABLE_ACCOUNT_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class DisableAccountFail implements Action {
  public readonly type = DISABLE_ACCOUNT_FAIL;
}

export class OpenResetPassModal implements Action {
  public readonly type = OPEN_RESET_PASS_MODAL;
}

export class CloseResetPassModal implements Action {
  public readonly type = CLOSE_RESET_PASS_MODAL;
}

export class OpenEnableDisableModal implements Action {
  public readonly type = OPEN_ENABLE_DISABLE_MODAL;
  constructor(public payload: 'Enable' | 'Disable') { }
}
export class CloseEnableDisableModal implements Action {
  public readonly type = CLOSE_ENABLE_DISABLE_MODAL;
}
export class OpenEndOfLifeModal implements Action {
  public readonly type = OPEN_END_OF_LIFE_MODAL;
  constructor(public payload: 'Enable' | 'Notification' | 'Self') { }
}
export class CloseEndOfLifeModal implements Action {
  public readonly type = CLOSE_END_OF_LIFE_MODAL;
}
export class EnableAccountsWithEndOfLife implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE;
  constructor(public payload: { end_of_lifecycle_date: Date, trigger: 'Enable' | 'Notification' | 'Self' }) { }
}
export class EnableAccountsWithEndOfLifeSuccess implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class EnableAccountsWithEndOfLifeFailure implements Action {
  public readonly type = ENABLE_ACCOUNT_END_OF_LIFE_FAILURE;
}
export class UpdateEndOfLifeOfAccount implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE;
  constructor(public payload: { end_of_lifecycle_date: Date }) { }
}
export class UpdateEndOfLifeOfAccountSuccess implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE_SUCCESS;
  constructor(public payload: { stats: API.BulkElemRes[], res: IResStatus }) { }
}
export class UpdateEndOfLifeOfAccountFailure implements Action {
  public readonly type = UPDATE_ACCOUNT_END_OF_LIFE_FAILURE;
}
export class OpenTASAModal implements Action {
  public readonly type = OPEN_TASA_MODAL;
}
export class CloseTASAModal implements Action {
  public readonly type = CLOSE_TASA_MODAL;
}
//=======================================End - Account Actions==============================================

export class LoadBusinessHours implements Action {
  public readonly type = LOAD_BUSINESS_HOURS;
}
export class LoadBusinessHoursFail implements Action {
  public readonly type = LOAD_BUSINESS_HOURS_FAIL;
}
export class LoadBusinessHoursSuccess implements Action {
  public readonly type = LOAD_BUSINESS_HOURS_SUCCESS;
  constructor(public payload: IBusinessHrsUTC) { }
}
//=======================================Start - Edit Description Model==============================================
export class OpenEditDescriptionModal implements Action {
  public readonly type = OPEN_EDIT_DESCRIPTION_MODAL;
}
export class CloseEditDescriptionModal implements Action {
  public readonly type = CLOSE_EDIT_DESCRIPTION_MODAL;
}
export class EditAccountDescription implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION;
  constructor(public payload: string) { }
}
export class EditAccountDescriptionSuccess implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION_SUCCESS;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
export class EditAccountDescriptionFail implements Action {
  public readonly type = EDIT_ACCOUNT_DESCRIPTION_FAIL;
  constructor(public payload: { id: number, res: IResStatus }) { }
}
//=======================================End - Edit Description Model==============================================


export type AccountsListAction =
  | LoadAdminAccountsList
  | LoadAdminAccountsListFail
  | LoadAdminAccountsListSuccess
  | LoadAdminSolutions
  | LoadAdminSolutionsSuccess
  | LoadAdminSolutionsFailed
  | LoadAdminDelegationMember
  | LoadAdminDelegationMemberSuccess
  | LoadAdminDelegationMemberFailed
  | LoadAccountDetail
  | LoadAccountDetailSuccess
  | LoadAccountDetailFail
  | SetFilterValues
  | SetUniueData
  | DetailFilterToggle
  | ResetDetailFilter
  | LoadAdminAccountName
  | LoadAdminAccountNameSuccess
  | SetSelectedAccounts
  //=====================================START - ADD/REMOVE DEPUTY============================================
  | OpenAddRemoveDeputyModal
  | CloseAddRemoveDeputyModal
  | LoadDeputyBlacklist
  | LoadDeputyBlacklistSuccess
  | LoadDeputyBlacklistFail
  | AddAccountDeputies
  | AddAccountDeputiesSuccess
  | AddAccountDeputiesFail
  | RemoveAccountDeputies
  | RemoveAccountDeputiesSuccess
  | RemoveAccountDeputiesFail
  | setSelectedDeputitiesModal
  | SetCanEditDeputiesOfAllSelected
  | searchAccountDeputityForModal
  | searchAccountDeputityForModalSuccess
  | searchAccountDeputityForModalFail
  //=======================================END - ADD/REMOVE DEPUTY==============================================
  | ResetPassword
  | ResetPasswordSuccess
  | ResetPasswordFail
  | EnableAccounts
  | EnableAccountSuccess
  | EnableAccountFail
  | DisableAccounts
  | DisableAccountSuccess
  | DisableAccountFail
  | OpenResetPassModal
  | CloseResetPassModal
  | OpenEnableDisableModal
  | CloseEnableDisableModal
  | OpenEndOfLifeModal
  | CloseEndOfLifeModal
  | EnableAccountsWithEndOfLife
  | EnableAccountsWithEndOfLifeSuccess
  | EnableAccountsWithEndOfLifeFailure
  | UpdateEndOfLifeOfAccount
  | UpdateEndOfLifeOfAccountSuccess
  | UpdateEndOfLifeOfAccountFailure
  | OpenTASAModal
  | CloseTASAModal
  | LoadBusinessHours
  | LoadBusinessHoursFail
  | LoadBusinessHoursSuccess
  | SelectAllAccounts
//=======================================Start - Edit Description Model==============================================
  |OpenEditDescriptionModal
  |CloseEditDescriptionModal
  |EditAccountDescription
  |EditAccountDescriptionFail
  |EditAccountDescriptionSuccess
//=======================================End - Edit Description Model==============================================
