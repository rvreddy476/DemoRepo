import { Action } from '@ngrx/store';
import { ISuperAdminAccountsStats } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats';
import { API } from 'src/app/shared/interfaces/shared/api';
import { CreateAcc_API } from 'src/app/shared/interfaces/create-account/api.namespace';
import { IIdentity } from 'src/app/shared/interfaces/identity/identity';


export const LOAD_ADMIN_ACCOUNTS_STATS = '[ADMIN] get all admin accounts'
export const LOAD_ADMIN_ACCOUNTS_STATS_SUCESS = '[ADMIN] get all admin accounts success'
export const LOAD_ADMIN_ACCOUNTS_STATS_FAILED = '[ADMIN] get all admin accounts failed'


export class LoadAdminStats implements Action {
    public readonly type = LOAD_ADMIN_ACCOUNTS_STATS;
    constructor(public payload: {numberOfDays:number}) { }
}
export class LoadAdminStatsSuccess implements Action {
    public readonly type = LOAD_ADMIN_ACCOUNTS_STATS_SUCESS;
    constructor(public payload: ISuperAdminAccountsStats) { }
}
export class LoadAdminStatsFailed implements Action {
    public readonly type = LOAD_ADMIN_ACCOUNTS_STATS_FAILED;
    constructor(public payload: any) { }
}



export type AdminActions =
    | LoadAdminStats
    | LoadAdminStatsSuccess
    | LoadAdminStatsFailed
