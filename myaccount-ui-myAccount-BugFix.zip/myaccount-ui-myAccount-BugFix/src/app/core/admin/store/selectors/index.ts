import { orderBy, SortDescriptor, filterBy, CompositeFilterDescriptor, FilterDescriptor, State } from '@progress/kendo-data-query';
import { createSelector, createFeatureSelector } from '@ngrx/store';
import { IAdminState } from '../reducers';
import { IAdminAccountListState } from 'src/app/shared/interfaces/super-admin/AdminAccountListState';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { IAdminAccountsListAPI } from 'src/app/shared/interfaces/super-admin/superadmin-accounts-stats-api';
import { IAdminAccountsStats } from 'src/app/shared/interfaces/admin/admin-accounts-stats';
import {IAdminOrphanAccountState,IOrphanAccount} from 'src/app/shared/interfaces/super-admin/admin-orphanlist-state'
import { getIdentity } from 'src/app/shared/store/selectors';


const getAdminState = createFeatureSelector<IAdminState>('adminModule');

export const getAdminAccountStats = createSelector(
    getAdminState,
    (state: IAdminState) => state.adminStats
);

//#region orphan accounts selectors
export const getOrphanAccountsState = createSelector(
    getAdminState,
    (state: IAdminState) =>{
        return state.orphanAccountsList
    }
);
export const getOrphanAccountsMode = createSelector(
    getAdminState,
    (state: IAdminState) => state.orphanAccountsList.orphanAccountMode
);
export const getOrphanAccountsStateLoading = createSelector(
    getAdminState,
    (state: IAdminState) => {
        
        return state.orphanAccountsList.loading;
    }
);
export const getOrphanAccountsViewState = createSelector(
    getOrphanAccountsState,
    (state) => state.viewState
  );
  export const getOrphanAccountsApiState = createSelector(
    getOrphanAccountsViewState,
    (state) => state.apidata
  );
  
  export const getOrphanAccountsGridState = createSelector(
    getOrphanAccountsViewState,
    (state) => state.gridState
  );
  
  export const getOrphanGridSort = createSelector(
    getOrphanAccountsGridState,
    (state) => state.sort
  );
  
  export const getOrphanGridFilters = createSelector(
    getOrphanAccountsGridState,
    (state) => state.filter
  );
  export const getOrphanAccNameFilterValue = createSelector(
    getOrphanGridFilters,
    (filters) => getfilterValueByField(filters ? filters.filters : [], 'account_name')
  );
  export const getOrphanAppliedFilterNumber = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) =>{
        const allFilter={};
        Object.assign(allFilter,state.filters);
        delete allFilter['account_name']
        return  Object.values(allFilter).filter(filter => filter !== null).length
    }
  );
  
  export const getOrphanAccountAssignModal = createSelector(
    getOrphanAccountsState,
    (state) => state.assignOrphanModal
  );

  export const getOrphanAccounts = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) => state.data
);
export const getOrphanAccSolutions = createSelector(
    getOrphanAccounts,
    (state: IOrphanAccount[]) => {
        return state.map((x) => x.solution_name);
    }
);
export const getOrphanAccountNames = createSelector(
    getOrphanAccounts,
    (state: IOrphanAccount[]) => {
        return state.map((x) => x.name);
    }
);
export const getOrphanAccountsVisibleColumns = createSelector(
    getOrphanAccountsViewState,
    (state) => state.visibleColumns
);

export const getOrphanFilters = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) => {
        return state.filters;
    }
)


  

export const getOrphanPrimaryFilterModifyState = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) => {
        return state.isPrimaryFilterModified;
    }
)

export const getOrphanUniqueData = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) => state.unique
);

export const getOrphanAccountsUniqueDirectoryType = createSelector(
    getOrphanAccountsState,
    (state) => state.unique.directoryType
);

export const getOrphanAccountsUniqueDirectoryDomain = createSelector(
    getOrphanAccountsState,
    (state) => state.unique.directoryDomain
  );
  export const getOrphanAccountsUniqueDivision = createSelector(
    getOrphanAccountsState,
    (state) => state.unique.division
  );
  export const getOrphanAccountsUniqueDirectoryEnvironment = createSelector(
    getOrphanAccountsState,
    (state) => state.unique.directoryEnvironment
  );
  export const getOrphanAccountsUniqueType = createSelector(
    getOrphanAccountsState,
    (state) => state.unique.type
  );

  export const getOrphanAdvancedFilterPanelOpen = createSelector(
    getOrphanAccountsState,
    (state) => state.viewState.detail_filter_toggle
  );
  
  export const getOrphanFilterToggle = createSelector(
    getOrphanAccountsState,
    (state) => state.viewState.detail_filter_toggle
  );

  export const getOrphanSelectedAccounts = createSelector(
    getOrphanAccountsState,
    (state) => state.selectedAccounts
);

export const getOrphanGridDataResult = createSelector(
    getOrphanAccountsState,
    (state: IAdminOrphanAccountState) => {
        return <GridDataResult>{
            data: state.data,
            total: state.data.length
        }
    }
);
export const getOrphanSortedAccountList = createSelector(
    getOrphanAccounts,
    getOrphanGridSort,
    (list = [], sort) => {
        return sort ? orderBy(list, sort) : list;
    }
);
export const getOrphanSortedFilteredAccountList = createSelector(
    getOrphanSortedAccountList,
    getOrphanGridFilters,
    (list = [], filter) => {
        return filter ? filterBy(list, filter) : list;
    }
);
const getOrphanAccountsShowOnlyList = createSelector(
    getOrphanAccountsViewState,
    getOrphanSelectedAccounts,
    (view, selected) => view.showOnlySelected ? selected : []
);
export const getOrphanVisibleAccounts = createSelector(
    getOrphanAccountsMode,
    getOrphanSortedAccountList,
    getOrphanSortedFilteredAccountList,
    getOrphanAccountsState,
    getOrphanAccountsShowOnlyList,
    getOrphanAccountsGridState,
    (orphanMode, fullList, filteredList, accstate, showOnly,gridState) => {
       var list = showOnly.length > 0 ? fullList.filter(acc => showOnly.indexOf(acc.id) !== -1) : filteredList;
       //list = list.slice(gridState.skip, gridState.take + gridState.skip);
       let data=list;
        
        if (orphanMode === 'NOENDUSER') {
                    data =list.filter(acc => acc.enduser_id === 0 && acc.solution_id!==0);
                }
                else if (orphanMode === 'NOSOLUTION') {
                    data = list.filter(acc => acc.enduser_id !== 0 && acc.solution_id===0);
                }
                else if (orphanMode === 'NOSOLENDUSER') {
                    data = list.filter(acc => acc.enduser_id === 0 && acc.solution_id===0);
                }
                else {
                    data=list.filter(acc => acc.enduser_id === 0 || acc.solution_id===0);
                }
        return {
            list:data,
            total: list.length,
            maximum: list.length,
            loaded:accstate.loaded,
            loading:accstate.loading
        };

    }
);
export const getOrphanSelectAllStatus = createSelector(
    getOrphanSortedFilteredAccountList,
    getOrphanSelectedAccounts,
    (filtered, selected) => {
        // 'unchecked' | 'indeterminate' | 'checked'

        // none are selected
        if (selected.length === 0) {
            return 'unchecked';
        }

        // less selected than filtered
        if (selected.length < filtered.length) {
            return 'indeterminate';
        }

        // some of the filtered accounts are not selected
        if (filtered.some(acc => selected.indexOf(acc.id) === -1)) {
            return 'indeterminate';
        }
        return 'checked';
    }
);
  

  const getfilterValueByField = (filters: (CompositeFilterDescriptor | FilterDescriptor)[], field: string): string | number | FilterDescriptor[] => {
    // check if there are filters
    if (!filters) {
      return null;
    }
  
    const values = filters.filter(f => {
  
      const fd = f as FilterDescriptor;
      const fcfd = f as CompositeFilterDescriptor;
  
      if (fd.field) {
        return fd.field === field;
      }
      if (fcfd.filters) {
        return fcfd.filters.every((nf: FilterDescriptor) => nf.field ? nf.field === field : false);
      }
    });
  
    if (values.length === 0) {
      return '';
    }
  
    if (values[0].hasOwnProperty('value')) {
      return (values[0] as FilterDescriptor).value;
    } else {
      return (values[0] as CompositeFilterDescriptor).filters.map(cf => {
        return (cf as FilterDescriptor).value;
      });
    }
  
  };

 
  
//Dispatch Seperate Actions for all
export const getOrphanAccountsNoEndUserState = createSelector(
    getAdminState,
    (state: IAdminState) => state.orphanAccountsList.data.
    filter(acc=>acc.enduser_id===null && acc.solution_name!==null)
);
//#endregion
/* start region - admin account list selectors. */
export const getAccountsListState = createSelector(
    getAdminState,
    (state: IAdminState) => state.accountsList
);
export const getAccounts = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => state.accounts
);
export const getSolutions = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => {        
        return state.solutions.map((solution) => solution.code+" "+solution.name+"-"+solution.type);
    }
);
export const getDelegation_Members = createSelector(
    getAccountsListState,   
    (state: IAdminAccountListState) => {       
        return state.delegation_members.map((mem) =>mem.login+" "+ mem.firstname+" "+mem.lastname);
        }
);
export const getAccountNames = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => {
        return state.account_names;
    }
);
export const getFilters = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => {
        return state.filters;
    }
)
export const getGridDataResult = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => {
        return <GridDataResult>{
            data: state.accounts,
            total: state.accounts.length
        }
    }
);
export const getUniqueData = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => state.unique

);
export const getEditDescriptionModal = createSelector(
    getAccountsListState,
    (state) => state.editDescriptionModal
  );
  export const getAccountsDetail = createSelector(
    getAccountsListState,
    (state) => state.selectedAccountsDetails
  );
export const getSolutionSearchData = createSelector(
    getOrphanAccountsState,
    getOrphanUniqueData,
    (state:IAdminOrphanAccountState,unique) => 
        
            {
               return unique.solutions.filter(x=>x.startsWith(state.searchTerm)) 
            }
);
export const getFilterToggle = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => state.view_state.detail_filter_toggle

);

export const getAppliedFilterNumber = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => Object.values(state.filters).filter(filter => filter !== null).length
);

export const getAccountsViewState = createSelector(
    getAccountsListState,
    (state) => state.view_state
);

export const getAccountsGridState = createSelector(
    getAccountsViewState,
    (state) => state.gridState
);
export const getAccountList = createSelector(
    getAccountsListState,
    (state: IAdminAccountListState) => state.accounts
);
export const getGridSort = createSelector(
    getAccountsGridState,
    (state) => state.sort
);
export const getSortedAccountList = createSelector(
    getAccountList,
    getGridSort,
    (list = [], sort) => {
        return sort ? orderBy(list, sort) : list;
    }
);
export const getGridFilters = createSelector(
    getAccountsGridState,
    (state) => state.filter
);
export const getSortedFilteredAccountList = createSelector(
    getSortedAccountList,
    getGridFilters,
    (list = [], filter) => {
        return filter ? filterBy(list, filter) : list;
    }
);

export const getSelectedAccounts = createSelector(
    getAccountsListState,
    (state) => state.selectedAccounts
);

export const getAdminAccountDetail = createSelector(
    getAccountsListState,
    (state)  =>  state.detailAccount 
);

export const getAccountComplianceStatus = createSelector(
    getAdminAccountDetail,
    (state) => state.compliance_status
  );

export const getSelectAllStatus = createSelector(
    getSortedFilteredAccountList,
    getSelectedAccounts,
    (filtered, selected) => {
        //filtered = filtered.filter(acc => (!acc.locked && !acc.hp));
        // 'unchecked' | 'indeterminate' | 'checked'

        // none are selected
        if (selected.length === 0) {
            return 'unchecked';
        }

        // less selected than filtered
        if (selected.length < filtered.length) {
            return 'indeterminate';
        }

        // some of the filtered accounts are not selected
        if (filtered.some(acc => selected.indexOf(acc.id) === -1)) {
            return 'indeterminate';
        }
        return 'checked';
    }
);

export const getAccountsEnabledColumns = createSelector(
    getAccountsListState,
    (state) => state.enabledColumns
);

export const getAccountsVisibleColumns = createSelector(
    getAccountsViewState,
    (state) => state.visibleColumns
);
export const getAccountsListLoading = createSelector(
    getAccountsListState,
    (state) => state.loading
);
const getAccountsShowOnlyList = createSelector(
    getAccountsViewState,
    getSelectedAccounts,
    (view, selected) => view.showOnlySelected ? selected : []
);
export const getVisibleAccounts = createSelector(
    getSortedAccountList,
    getSortedFilteredAccountList,
    getAccountsGridState,
    getAccountsShowOnlyList,
    (fullList, filteredList, gridState, showOnly) => {
        const list = showOnly.length > 0 ? fullList.filter(acc => showOnly.indexOf(acc.id) !== -1) : filteredList;
        const data = list.slice(gridState.skip, gridState.take + gridState.skip);
        return {
            data,
            total: list.length,
            maximum: data.length
        };
    }
);
export const getAccountsUniqueDirectoryType = createSelector(
    getAccountsListState,
    (state) => state.unique.directoryType
);

export const getAccountsUniqueDirectoryDomain = createSelector(
    getAccountsListState,
    (state) => state.unique.directoryDomain
  );
  export const getAccountsUniqueDivision = createSelector(
    getAccountsListState,
    (state) => state.unique.division
  );
  export const getAccountsUniqueDirectoryEnvironment = createSelector(
    getAccountsListState,
    (state) => state.unique.directoryEnvironment
  );
  export const getAccountsUniqueLifeCycleStatus = createSelector(
    getAccountsListState,
    (state) => state.unique.lifeCycleStatus
  );
  export const getAccountsUniqueType = createSelector(
    getAccountsListState,
    (state) => state.unique.type
  );

  export const getAdvancedFilterPanelOpen = createSelector(
    getAccountsListState,
    (state) => state.view_state.detail_filter_toggle
  );
  
/* end region - admin account list selectors */

/**Currenty selected  accounts */
export const getSelectedAccountsList = createSelector(
    getAccountList,
    getSelectedAccounts,
    getAdminAccountDetail,
    (list, selected, detail) => {
      if (detail && list.length === 0 && selected.length === 1) {
        return selected[0] === detail.id ? [detail] : []
      }
      return list.filter(acc => selected.indexOf(acc.id) !== -1);
    }
  );

  export const getSelectedAccountType = createSelector(
    getSelectedAccountsList,
    (list) => {
      if (list.every(a => a.type == 'TECHNICAL')) {
        return 'TECHNICAL'
      }
      if (list.every(a => a.type == 'SERVICE')) {
        return 'SERVICE'
      }
      if (list.some(a => a.type == 'SERVICE') && list.some(a => a.type == 'TECHNICAL')) {
        return 'TASA'
      }
    }
  );

  //#endregion

//#region enable disable account

export const getEnableDisableModal = createSelector(
    getAccountsListState,
    (state) => state.enableDisableAccModal
  );
  
  export const getEnableAccountEnabled = createSelector(
    getSelectedAccountsList,
    getIdentity,
    (selected = [], identity) => {
  
      if (selected.length === 0) {
        return false;
      }
  
      if (selected.some(sel => (sel.locked || sel.hp))) {
        return false;
      }
  
      if (selected.some(sel => sel.lifeCycleStatus !== 'DISABLE')) {
        return false;
      }
  
      return true;
    }
  );
  
  export const getResetPasswordEnabled = createSelector(
    getSelectedAccountsList,
    (selected = []) => {
  
      if (selected.length === 0) {
        return false;
      }
  
      if (selected.length > 1) {
        return true
      }
  
      if (selected.some(sel => (sel.locked || sel.hp))) {
        return false;
      }
  
      if (selected.some(sel => !sel.canReset)) {
        return false;
      }
  
      if (selected.some(sel => sel.pwdRemainingDays === null)) {
        return false;
      }
      return true;
    }
  );
  
  export const getDisableAccountEnabled = createSelector(
    getSelectedAccountsList,
    getIdentity,
    (selected = [], identity) => {
  
      if (selected.length === 0) {
        return false;
      }
  
      if (selected.some(sel => (sel.locked || sel.hp))) {
        return false;
      }
  
      if (selected.some(sel => sel.lifeCycleStatus !== 'ENABLE')) {
        return false;
      }
  
      return true;
    }
  );
  export const getEndofLifeModal = createSelector(
    getAccountsListState,
    (state) => state.endOfLifeModal
  );
  //#region follow up selectors

//#region add-remove deputies

export const getAddRemoveDeputiesModal = createSelector(
    getAccountsListState,
    (state) => state.addRemoveDeputyModal
  );
  export const getAccountsEnfOfLifeModal = createSelector(
    getAdminState,
    (state) => state.accountsList.endOfLifeModal
  );
const permissionToEditDeputiesOfSelection = createSelector(
    getAddRemoveDeputiesModal,
    (state) => state.permissionToEditSelection
  );

export const getEditDeputiesEnabled = createSelector(
    getSelectedAccountsList,
    permissionToEditDeputiesOfSelection,
    (selected, permission) => {
  
      if (selected.length === 0) {
        return false;
      }
      if (selected.some(sel => (sel.locked || sel.hp))) {
        return false;
      }
      if (selected.length > 1) {
        return true;
      }
  
      if (selected.length === 1 && permission) {
        return true;
      }
  
      return false;
    }
  );
  
  
  //#endregion
export const getAdminSelectedAccounts = createSelector(
    getAccountsListState,
    (state) => state.selectedAccounts
);
export const getAdminSelectedAccountsList = createSelector(
    getAccounts,
    getAdminSelectedAccounts,
    getAdminAccountDetail,
    (list, selected, detail) => {
      if (detail && list.length === 0 && selected.length === 1) {
        return selected[0] === detail.id ? [detail] : []
      }
      return list.filter(acc => selected.indexOf(acc.id) !== -1);
    }
);
export const getAdminAddRemoveDeputiesModal = createSelector(
    getAccountsListState,
    (state) => state.addRemoveDeputyModal
);

const adminPermissionToEditDeputiesOfSelection = createSelector(
    getAdminAddRemoveDeputiesModal,
    (state) => state.permissionToEditSelection
);

export const getAdminEditDeputiesEnabled = createSelector(
    getAdminSelectedAccountsList,
    adminPermissionToEditDeputiesOfSelection,
    (selected, permission) => {

        if (selected.length === 0) {
            return false;
        }
        if (selected.some(sel => (sel.locked || sel.hp))) {
            return false;
        }
        if (selected.length > 1) {
            return true;
        }

        if (selected.length === 1 && permission) {
            return true;
        }

        return false;
    }
);



const getFollowUpState = createSelector(
    getAdminState,
    (state: IAdminState) => state.followUpList
);


export const getAdminFollowUpActions = createSelector(
    getFollowUpState,
    (state) => state.actions
);
export const getAdminEnableDisableModal = createSelector(
    getAccountsListState,
    (state) => state.enableDisableAccModal
);
export const getAdminAccountsResetModal = createSelector(
    getAccountsListState,
    (state) => state.resetPassModal
);
export const getAdminBusinessHours = createSelector(
    getAccountsListState,
    (state) => state.businessHrsUTC
);
export const getAdminResetPasswordEnabled = createSelector(
    getAdminSelectedAccountsList,
    (selected = []) => {

        if (selected.length === 0) {
            return false;
        }

        if (selected.length > 1) {
            return true
        }

        if (selected.some(sel => (sel.locked || sel.hp))) {
            return false;
        }

        if (selected.some(sel => !sel.canReset)) {
            return false;
        }

        if (selected.some(sel => sel.pwdRemainingDays === null)) {
            return false;
        }
        return true;
    }
);

export const getAdminDisableAccountEnabled = createSelector(
    getAdminSelectedAccountsList,
    (selected = []) => {

        if (selected.length === 0) {
            return false;
        }

        if (selected.some(sel => (sel.locked || sel.hp))) {
            return false;
        }

        if (selected.some(sel => sel.lifeCycleStatus !== 'ENABLE')) {
            return false;
        }

        return true;
    }
);
export const getAdminEnableAccountEnabled = createSelector(
    getAdminSelectedAccountsList,
    (selected = []) => {

        if (selected.length === 0) {
            return false;
        }

        if (selected.some(sel => (sel.locked || sel.hp))) {
            return false;
        }

        if (selected.some(sel => sel.lifeCycleStatus !== 'DISABLE')) {
            return false;
        }


        return true;
    }
);

export const getAdminFollowUpModal = createSelector(
    getFollowUpState,
    (state) => state.modal
  );


