import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AdminAccountsListComponent } from './components/admin-accounts-list/admin-accounts-list.component';
import { AdminStatsTilesComponent } from './components/admin-stats-tiles/admin-stats-tiles.component';
import { AccessAdmin } from 'src/app/shared/route-guards/access-admin';
import { AdminActionFollowUpComponent } from './components/admin-action-follow-up/admin-action-follow-up.component';
import {AdminOrphanAccountsComponent} from './components/admin-orphan-accounts/admin-orphan-accounts.component'
import { AccountDetailPageComponent } from './detail/account-detail-page/account-detail-page.component';
import { AccountDetailInfoComponent } from './detail/account-detail-info/account-detail-info.component';
import { AccountDetailHistoryComponent } from './detail/account-detail-history/account-detail-history.component';
import { AccountDetailDelegationComponent } from './detail/account-detail-delegation/account-detail-delegation.component';
export const CREATE_ROUTES: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        component: AdminStatsTilesComponent,
        data: {state : 'accounts'}
      },
      {
        path: 'accounts',
        component : AdminAccountsListComponent,
        data: {state : 'accounts'}
      },
      {
        path: 'follow-up',
        component : AdminActionFollowUpComponent,
        data: {state : 'accounts'}
      },
      {
        path: 'orphans',
        component : AdminOrphanAccountsComponent,
        data: {state : 'accounts'}
      },
      {
        path: ':id',
        component: AccountDetailPageComponent,
        children: [
          {
            path: 'info',
            component: AccountDetailInfoComponent,
          },
          {
            path: 'history',
            component: AccountDetailHistoryComponent,
          },
          {
            path: 'delegation',
            component: AccountDetailDelegationComponent,
          },
          {
            path: '**',
            redirectTo: 'info',
          },
        ],
      },
    ],
    canLoad:[AccessAdmin]
  },
];

@NgModule({
  imports: [RouterModule.forChild(CREATE_ROUTES)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
