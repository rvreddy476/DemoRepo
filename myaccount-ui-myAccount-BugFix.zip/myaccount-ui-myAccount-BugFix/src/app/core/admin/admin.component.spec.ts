import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminComponent } from './admin.component';
import { RouterTestingModule } from '@angular/router/testing';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { AppState } from 'src/app/shared/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { AdminResetPasswordModalComponent } from './components/modal/reset-password-modal/reset-password-modal.component';
import { EndOfLifeModalComponent } from './components/modal/end-of-life-modal/end-of-life-modal.component';
import { EditDescriptionModalComponent } from './components/modal/edit-description-modal/edit-description-modal.component';
import { AdminEnableDisableModalComponent } from './components/modal/enable-disable-modal/enable-disable-modal.component';
import { TranslateModule } from '@ngx-translate/core';
import { KendoModule } from 'src/app/modules/kendo.module';
import { IconModule } from 'src/app/modules/icon.module';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { BaseModalComponent } from 'src/app/shared/modals/base-modal/base-modal.component';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminComponent,
        AdminResetPasswordModalComponent,
        EndOfLifeModalComponent,
        EditDescriptionModalComponent,
        AdminEnableDisableModalComponent,
        BaseModalComponent,
        DateDisplayComponent
       ],
      providers: [
        provideMockStore({ initialState })
    ],
      imports: [ RouterTestingModule,
        IconModule,
        TranslateModule.forRoot(), 
        KendoModule]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(AdminComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      elem = fixture.nativeElement;
      store = TestBed.get(Store);
  });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
