import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';
import { delay, map } from 'rxjs/operators';
import { Subscription, Observable } from 'rxjs';
import { IAccountHistory, IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { select, Store } from '@ngrx/store';
import { getAdminAccountDetail } from '../../store/selectors';

@Component({
  selector: 'app-account-detail-history',
  templateUrl: './account-detail-history.component.html',
  styleUrls: ['./account-detail-history.component.scss']
})

export class AccountDetailHistoryComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('adminGridSizer') private adminGridSizer;

  constructor(private store: Store<IAccountsListState>) {}

  /**
 * default height of grid while waiting for calculation
 */
  public adminGridHeight = 500;

  /**
   * history list observale to populate the grid
   */
  public $history: Observable<IAccountHistory[]>;
  private subs: Subscription[];

  public ngOnInit() { 
    this.$history = this.store.pipe(select(getAdminAccountDetail)).pipe(
      map(acc => (acc ? acc.history || [] : []).sort((a,b) => a.dateUtc < b.dateUtc ? 1 : -1))
    );
    
  }

ngAfterViewInit()
{
  this.subs = [
    this.$history.pipe(delay(100)).subscribe(() => {
      this.adminGridHeight = this.adminGridSizer.nativeElement.clientHeight;
    })
  ];
}

  public ngOnDestroy() {
    this.subs.forEach(sub => sub.unsubscribe());
  }
}