import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { FilterDescriptor, CompositeFilterDescriptor, SortDescriptor, orderBy, filterBy } from '@progress/kendo-data-query';
import { combineLatest, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';
import { IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { getAdminAccountDetail } from '../../store';

@Component({
  selector: 'app-account-detail-delegation',
  templateUrl: './account-detail-delegation.component.html',
  styleUrls: ['./account-detail-delegation.component.scss']
})

export class AccountDetailDelegationComponent implements OnInit {


  constructor(private store: Store<IAccountsListState>, private eRef: ElementRef) { }

  @ViewChild('detailPanel') private detailPanelElem

  public sort$: BehaviorSubject<SortDescriptor[]> = new BehaviorSubject([])
  public filter$: BehaviorSubject<CompositeFilterDescriptor> = new BehaviorSubject(null)

  public detailOpen$ = new BehaviorSubject(false)

  public unfilteredDeputies$ = this.store.pipe(select(getAdminAccountDetail)).pipe(
    map((acc) => {
      const linear = acc ? [...acc.indirectDeputies, ...acc.deputies] : []
      return linear.map(delegation => {
        let origionalProfile = delegation.profile.replace(/_/g, ' ').replace(/^(.)(.*)$/,(m,i,o) => `${i.toUpperCase()}${o.toLowerCase()}`)
        const endUserId = acc.endUser ? acc.endUser.id : null
        
        return {
          ...delegation,         
          profile: delegation.id === endUserId ? 'End user':origionalProfile,
          displayName: delegation.displayName.replace(/\(.*\)/, '').replace(/\,/, ''),
        }
      })
    }))

  public data$ = combineLatest(this.unfilteredDeputies$, this.sort$, this.filter$).pipe(
    map(([unfiltered, sort, filter]) => {
      return orderBy(filterBy(unfiltered, filter), sort)
    })
  )

  public profileOptions$ = this.unfilteredDeputies$.pipe(map(data => [...new Set(data.map(d => d.profile))].map(p => {
    return { name: p, value: p }
  }).sort((a,b) => a.name > b.name ? 1 : -1)))

  public profilesSelected$ = combineLatest(this.profileOptions$, this.filter$).pipe(
    map(([opts, filter]) => {
      return opts.filter(opt => {
        return (filter ? filter.filters as CompositeFilterDescriptor[] : [])
        .some(f => f.filters ? f.filters.some((f: FilterDescriptor) => f.field === 'profile' && f.value === opt.value): false)
      }).map(o => o.value)
    })
  )

  public sortChangeHandler(sortEvent: SortDescriptor[]) {
    this.sort$.next(sortEvent)
  }

  public getSortDirection(field) {
    const sort = this.sort$.value ?
      this.sort$.value.filter(s => s.field === field)[0] :
      null;
    return sort ? sort.dir : null;
  }

  public rowClass(row) {
    return 'row'
  }

  public ngOnInit() {
  }

  public updateFilter(field: string, term: string | string[]) {
    const cleanFilter = this.filter$.value ? this.filter$.value.filters.filter(f => {
      if((f as FilterDescriptor).field){
        return (f as FilterDescriptor).field !== field
      }else if((f as CompositeFilterDescriptor).logic){
        return (f as CompositeFilterDescriptor).filters.some((f: FilterDescriptor) => f.field !== field)
      }
    }) : []

    if(Array.isArray(term)){
      if(term.length > 0){
        cleanFilter.push({
          logic:'or',
          filters: (term as string[]).map(t => {
            return {
              field,
              operator: "contains",
              value: t
            }
          })
        })
      }
    }else{
      if (term !== "") {
        cleanFilter.push({
          field,
          operator: "contains",
          value: term
        })
      }
    }
    this.filter$.next({
      logic: 'and',
      filters: cleanFilter
    })

  }

  public selectProfileHandler(term) {
    this.updateFilter('profile', term)
  }

  public searchLoginHandler(term) {
    this.updateFilter('login', term)
  }

  public searchNameHandler(term) {
    this.updateFilter('displayName', term)
  }

  public toggleDetail(){
    this.detailOpen$.next(!this.detailOpen$.value)
  }

  @HostListener('document:click', ['$event'])
  public clickout(event) {
    if(!this.detailOpen$.value) return
    if(event.target.className === 'adv-search-btn') return
    if(event.target.parentNode.className === 'adv-search-btn') return
    if (!this.detailPanelElem.nativeElement.contains(event.target)) {
      this.detailOpen$.next(false)
    }
  }
}