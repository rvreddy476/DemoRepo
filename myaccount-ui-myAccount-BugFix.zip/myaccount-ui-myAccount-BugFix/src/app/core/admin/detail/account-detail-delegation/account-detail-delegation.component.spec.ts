import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDetailDelegationComponent } from './account-detail-delegation.component';
import { AdminAccountsGlobalSearchComponent } from '../../components/accounts-search-panel/accounts-global-search/accounts-global-search.component';
import { KendoModule } from 'src/app/modules/kendo.module';
import { TranslateModule } from '@ngx-translate/core';
import { MultiDropdownListComponent } from 'src/app/modules/custom-kendu-elements/multi-dropdown-list/multi-dropdown-list';
import { SortOrderIconComponent } from 'src/app/shared/icons/sort-order-icon/sort-order-icon.component';
import { CustomKenduModule } from 'src/app/modules/custom-kendu-elements/custom-kendu.module';
import { IconModule } from 'src/app/modules/icon.module';
import { AppState } from 'src/app/shared/store';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';

describe('AccountDetailDelegationComponent', () => {
  let component: AccountDetailDelegationComponent;
  let fixture: ComponentFixture<AccountDetailDelegationComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
    return {
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  });


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        AccountDetailDelegationComponent,
        AdminAccountsGlobalSearchComponent,
      ],
      imports: [CustomKenduModule, IconModule, TranslateModule.forRoot()],
      providers: [
        provideMockStore({ initialState })
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(AccountDetailDelegationComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      store = TestBed.get(Store);
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountDetailDelegationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
