import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDetailPageComponent } from './account-detail-page.component';
import { TestingModule } from 'src/app/modules/testing/testing.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('AccountDetailPageComponent', () => {
  let component: AccountDetailPageComponent;
  let fixture: ComponentFixture<AccountDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountDetailPageComponent ],
      imports: [ TestingModule],
      schemas: [ NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
