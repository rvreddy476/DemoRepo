import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDetailInfoComponent } from './account-detail-info.component';
import { AppState } from 'src/app/shared/store';
import { defaultTestStore } from 'src/app/shared/mock-data';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { IconModule } from 'src/app/modules/icon.module';
import { StaticValueDisplayComponent } from 'src/app/shared/components/static-value-display/static-value-display.component';
import { DateDisplayComponent } from 'src/app/shared/components/date-display/date-display.component';
import { Store } from '@ngrx/store';

describe('AccountDetailInfoComponent', () => {
  let component: AccountDetailInfoComponent;
  let fixture: ComponentFixture<AccountDetailInfoComponent>;
  let elem: HTMLElement;
  const initialState: AppState = defaultTestStore;
  let store: MockStore<AppState>;

  window.matchMedia = jest.fn().mockImplementation(query => {
      return {
          matches: false,
          media: query,
          onchange: null,
          addListener: jest.fn(),
          removeListener: jest.fn(),
      };
  });

  beforeEach(async(() => {
      TestBed.configureTestingModule({
          imports: [CommonModule, TranslateModule.forRoot(), RouterTestingModule, IconModule],
          providers: [
              provideMockStore({ initialState })
          ],
          declarations: [AccountDetailInfoComponent, StaticValueDisplayComponent, DateDisplayComponent]
      }).compileComponents().then(() => {
          fixture = TestBed.createComponent(AccountDetailInfoComponent);
          component = fixture.componentInstance;
          fixture.detectChanges();
          elem = fixture.nativeElement;
          store = TestBed.get(Store);
      });
  }));

  it('expect 23 values to be displayed', () => {
      expect(elem.querySelectorAll('app-2f82-static-value-display').length).toBe(23);
  });
  it('expect account description to be displayed', () => {
      const descriptionText = initialState.accountsModule.accountsList.detailAccount.description;
      expect(descriptionText.length).toBeGreaterThan(20);
      expect(elem.querySelector('#acc-usage').innerHTML).toBe(descriptionText);
  });
  it('editable description text', async () => {
      const newDescription = 'this is a drill';
      elem.querySelector('#acc-usage').innerHTML = newDescription;
      expect(elem.querySelector('#acc-usage').innerHTML).toBe(newDescription);
  });
 
});
