import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs';
import { IAccount, IAccountComplianceStatus, IAccountsListState } from 'src/app/shared/interfaces/shared/account/account';
import { Store, select } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';
import { formatDisplayName } from 'src/app/shared/helper-functions';
import { getAdminAccountDetail, getAccountComplianceStatus } from '../../store';
import { OpenEditDescriptionModal } from '../../store/actions/accounts-list.actions';

@Component({
  selector: 'app-account-detail-info',
  templateUrl: './account-detail-info.component.html',
  styleUrls: ['./account-detail-info.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AccountDetailInfoComponent {

  public $account: Observable<IAccount>;
  public $complianceStatus: Observable<IAccountComplianceStatus>;
  public showDetails = false;

  constructor(private store: Store<IAccountsListState>, private active: ActivatedRoute) {
    this.$account = this.store.pipe(select(getAdminAccountDetail));
  }


  ngOnInit() {
    this.$complianceStatus = this.store.pipe(select(getAccountComplianceStatus))
  }

  public openReason(event: Event, isCompliant) {
    var popup = (<HTMLTextAreaElement>event.currentTarget).firstElementChild;
    if(!popup.classList.contains("show-reason"))
    {
      var lights = document.getElementsByClassName("show-reason");
      while (lights.length)
        lights[0].className = lights[0].className.replace(/\bshow-reason\b/g, "")
    }
    if(!popup.classList.contains("Compliant"))
    popup.classList.toggle("show-reason");
  }

  

  public openDetails(event: Event) {
    var innerDiv = (<HTMLTextAreaElement>event.currentTarget).parentElement.lastElementChild;
    this.showDetails=!this.showDetails;
    innerDiv.classList.toggle("show");
  }

  public openEditModal() {
    this.store.dispatch(new OpenEditDescriptionModal());
  }

  public formatDN(dn){
    return formatDisplayName(dn)
  }

  public derivePasswordStatus(acc: IAccount) {
    if (acc.pwdStatus === 'NO_PASSWORD') {
      return {
        text: `-`,
        value: null
      };
    }
    if (acc.pwdStatus === 'EXPIRED') {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRED_SINCE`,
        value: {d: Math.abs(acc.pwdRemainingDays)}
      };
    } else {
      return {
        text: `ACCOUNT_LIST.ROW_VALUE.PASS_LIFETIME.EXPIRES_IN`,
        value: {d: Math.abs(acc.pwdRemainingDays)}
      };
    }
  }

}
