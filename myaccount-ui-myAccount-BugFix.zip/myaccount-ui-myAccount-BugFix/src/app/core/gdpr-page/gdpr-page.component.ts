import { Component, OnInit, ViewEncapsulation, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { DisclaimerService } from 'src/app/shared/services/user/disclaimer.service';
import { map, switchMap, withLatestFrom, tap, catchError } from 'rxjs/operators';
import { Observable, fromEvent, Subscription } from 'rxjs';
import { IBaseState } from 'src/app/shared/interfaces/base-state';
import { Store, select } from '@ngrx/store';
import { getIdentity } from 'src/app/shared/store/selectors';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gdpr-page',
  templateUrl: './gdpr-page.component.html',
  styleUrls: ['./gdpr-page.component.scss']
})
export class GdprPageComponent implements OnInit, AfterViewInit {

  constructor(private disclaimerService: DisclaimerService, private store: Store<IBaseState>, private router: Router) { }
  @ViewChild('continue') private continueBtn: ElementRef;

  public content$: Observable<string>;
  public accepted = false;

  public continue$: Subscription;

  public ngOnInit() {
    this.content$ = this.disclaimerService.getDisclaimerContent().pipe(
      map(content => content.versionContent.replace(/&lt;/g, '<').replace(/&gt;/g, '>'))
    );
  }

  public ngAfterViewInit() {
    this.continue$ = fromEvent(this.continueBtn.nativeElement, 'click').pipe(
      withLatestFrom(this.store.pipe(select(getIdentity))),
      map(([event, id]) => {
        return id.id;
      }),
      switchMap(id => {
        return this.disclaimerService.validateUser(id).pipe(
          map(res => {
            if (res.validated) {
              this.router.navigate(['/']);
            }
          })
        );
      }),
    ).subscribe();
  }

  public accept(e) {
    this.accepted = e.target.checked;
  }
}
