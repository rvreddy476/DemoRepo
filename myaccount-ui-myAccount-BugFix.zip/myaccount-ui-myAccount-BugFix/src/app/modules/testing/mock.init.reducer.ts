import { ReducerManager } from '@ngrx/store';
import { createMockReducer } from './mock.reducer';

export function initReducer(featureName: string, initialState: unknown) {
  return (reducer: ReducerManager) => {
    return () =>
      // A factory requires to return a promise
      new Promise((resolve, reject) => {
        // Use the reducemanager to add the feature, with mocked out reducer
        reducer.addReducer(featureName, createMockReducer(initialState));
        resolve('mocked reducer');
      });
  };
}
