import { ActionReducerMap, MetaReducer, StoreModule, ReducerManager } from '@ngrx/store';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { ModuleWithProviders } from '@angular/compiler/src/core';
import { initReducer } from './mock.init.reducer';

const reducers: ActionReducerMap<unknown> = {};
const metaReducers: MetaReducer<unknown>[] = [];
@NgModule({
  imports: [
    // For every mockStoreModule we will initialize the root reducers
    StoreModule.forRoot(reducers, { metaReducers }),
  ],
  exports: [StoreModule],
})
export class MockStoreModule {
  // In the imports there is no option to work with variables, so we will initialize
  // the feature through a forRoot method
  public forRoot(featureName: string, initialState: unknown): ModuleWithProviders {
    return {
      ngModule: MockStoreModule,
      providers: [
        {
          provide: APP_INITIALIZER,
          // Before the test is initialize we will take care of the initialisation of
          // the mockReducer
          useFactory: initReducer(featureName, initialState),
          // ReducerManager is provided by @ngrx/store
          deps: [ReducerManager],
          multi: true,
        },
      ],
    };
  }
}
