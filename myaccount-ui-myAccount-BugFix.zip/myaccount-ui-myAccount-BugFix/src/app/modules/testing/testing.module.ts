// Angular Imports
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Component Imports
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { KendoModule } from '../kendo.module';
import { TranslateModule } from '@ngx-translate/core';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { MockStoreModule } from './mock-store.module';

@NgModule({
  imports: [RouterTestingModule, HttpClientModule, TranslateModule.forRoot(), ReactiveFormsModule, KendoModule, CommonModule, FormsModule, MockStoreModule],
  exports: [HttpClientModule, CommonModule, FormsModule, ReactiveFormsModule, RouterTestingModule, KendoModule, TranslateModule, MockStoreModule],
})
export class TestingModule {}
