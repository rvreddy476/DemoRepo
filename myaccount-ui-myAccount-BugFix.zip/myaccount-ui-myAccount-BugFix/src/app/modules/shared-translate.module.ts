import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { LanguageLoader } from '../shared/services/language-loader';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useClass: LanguageLoader
      }
    })
  ],
  exports: [
    TranslateModule
  ]
})
export class SharedTranslateModule { }
