import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { NgModule } from '@angular/core';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { CustomKenduModule } from './custom-kendu-elements/custom-kendu.module';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

@NgModule({
  imports: [DropDownsModule, GridModule, ButtonsModule, CustomKenduModule, TooltipModule, DialogModule, DatePickerModule, LayoutModule, DateInputsModule, ButtonsModule],
  declarations: [
    // DashboardComponent
  ],
  exports: [DropDownsModule, GridModule, ButtonsModule, CustomKenduModule, TooltipModule, DialogModule, DatePickerModule, LayoutModule, DateInputsModule, ButtonsModule],
})
export class KendoModule { }
