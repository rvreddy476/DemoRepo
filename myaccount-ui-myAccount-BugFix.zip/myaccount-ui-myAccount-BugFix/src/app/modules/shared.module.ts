import { MultiSelectAsyncComponent } from './../core/create-account/components/multi-select-async/multi-select-async.component';
import { MultiSelectComponent } from './../core/create-account/components/multi-select/multi-select.component';
import { BaseModalComponent } from './../shared/modals/base-modal/base-modal.component';
import { AccountsBreadcrumbComponent } from './../core/accounts/list/accounts-breadcrumb/accounts-breadcrumb.component';
import { FormDateRangeDropdownComponent } from './../core/accounts/list/accounts-search-panel/filters/form-date-range-dropdown';
// Angular Imports
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Component Imports
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AccountsSearchComponent } from '../shared/components/accounts-search/accounts-search.component';
import { SearchbarComponent } from '../shared/components/searchbar/searchbar.component';
import { TileComponent } from '../shared/components/tile-components/tile/tile.component';
import { LimitLengthDirective } from '../shared/directives/text-limiter';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { KendoModule } from './kendo.module';
import { FormFilterMultiDropdownComponent } from '../core/accounts/list/accounts-search-panel/filters/form-filter-multi-dropdown';
import { StaticValueDisplayComponent } from '../shared/components/static-value-display/static-value-display.component';
import { PageTitleComponent } from '../shared/components/page-title/page-title.component';
import { IconModule } from './icon.module';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { DateDisplayComponent } from '../shared/components/date-display/date-display.component';
import { DelegationSelectionPanelComponent } from '../shared/components/delegation-selection-panel/delegation-selection-panel.component';
import { SharedTranslateModule } from './shared-translate.module';
import { PromptModalComponent } from '../shared/modals/prompt-modal/prompt-modal.component';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { ToggleSwitchComponent } from '../shared/components/toggle-switch/toggleswitch.component';
import { AdminBarChartComponent } from '../shared/components/tile-components/admin-bar-chart/admin-bar-chart.component';

@NgModule({
  imports: [
    RouterModule,
    FormsModule,
    CommonModule,
    DropDownsModule,
    SharedTranslateModule,
    ReactiveFormsModule,
    KendoModule,
    IconModule,
    TooltipModule,
    // NgxMaterialTimepickerModule,
  ],
  declarations: [
    AccountsSearchComponent,
    AccountsBreadcrumbComponent,
    SearchbarComponent,
    TileComponent,
    AdminBarChartComponent,
    LimitLengthDirective,
    FormFilterMultiDropdownComponent,
    FormDateRangeDropdownComponent,
    StaticValueDisplayComponent,
    PageTitleComponent,
    BaseModalComponent,
    MultiSelectComponent,
    MultiSelectAsyncComponent,
    DateDisplayComponent,
    DelegationSelectionPanelComponent,
    PromptModalComponent,
    ToggleSwitchComponent
  ],
  exports: [
    AccountsBreadcrumbComponent,
    CommonModule,
    AccountsSearchComponent,
    FormFilterMultiDropdownComponent,
    FormDateRangeDropdownComponent,
    SearchbarComponent,
    TileComponent,
    AdminBarChartComponent,
    FormsModule,
    ReactiveFormsModule,
    StaticValueDisplayComponent,
    RouterModule,
    LimitLengthDirective,
    KendoModule,
    PageTitleComponent,
    IconModule,
    BaseModalComponent,
    NgxMaterialTimepickerModule,
    MultiSelectComponent,
    MultiSelectAsyncComponent,
    DateDisplayComponent,
    DelegationSelectionPanelComponent,
    PromptModalComponent,
    ToggleSwitchComponent
  ],
})
export class SharedModule { }
