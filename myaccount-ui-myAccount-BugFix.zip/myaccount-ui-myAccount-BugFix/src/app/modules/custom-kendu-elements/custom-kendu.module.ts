import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { TranslateModule } from '@ngx-translate/core';
import { IconModule } from './../icon.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Kendu Imports
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { RippleModule } from '@progress/kendo-angular-ripple';
import { GridModule } from '@progress/kendo-angular-grid';
import { NotificationModule } from '@progress/kendo-angular-notification';

import { FormsModule } from '@angular/forms';
import { MultiDropdownListComponent } from './multi-dropdown-list/multi-dropdown-list';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridFilterDropdownComponent } from './grid-filter-dropdown';
import { ListFilterPillsComponent } from '../../core/accounts/list/list-filter-pills/list-filter-pills.component';
import { VirtualScrollListComponent } from '../../core/accounts/list/virtual-scroll-list/virtual-scroll-list.component';
import { AccountsActionSnackbarComponent } from '../../core/accounts/list/accounts-action-snackbar/accounts-action-snackbar.component';
import { MultiViewCalendarModule } from '@progress/kendo-angular-dateinputs';
import { GridFilterDateRangeDropdownComponent } from './grid-filter-date-range-dropdown';
import { SharedTranslateModule } from '../shared-translate.module';

@NgModule({
  imports: [
    CommonModule,
    DropDownsModule,
    ButtonsModule,
    RippleModule,
    GridModule,
    FormsModule,
    NotificationModule,
    InputsModule,
    DialogModule,
    PopupModule,
    MultiViewCalendarModule,
    IconModule,
    TranslateModule,
    TooltipModule,
    SharedTranslateModule
  ],
  declarations: [
    MultiDropdownListComponent,
    GridFilterDropdownComponent,
    GridFilterDateRangeDropdownComponent,
    ListFilterPillsComponent,
    VirtualScrollListComponent,
    AccountsActionSnackbarComponent,
  ],
  exports: [
    MultiDropdownListComponent,
    GridModule,
    GridFilterDateRangeDropdownComponent,
    NotificationModule,
    ListFilterPillsComponent,
    InputsModule,
    DialogModule,
    PopupModule,
    DropDownsModule,
    VirtualScrollListComponent,
    AccountsActionSnackbarComponent,
    MultiViewCalendarModule,
  ],
})
export class CustomKenduModule {}
