import { BaseFilterCellComponent, FilterService } from '@progress/kendo-angular-grid';
import { Input, Component, ViewChild, HostListener, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { IAccountsState, getAccountsGridState, getFilterPwdRemainingDays } from '../../core/accounts/store';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-2f82-grid-filter-date-range-dropdown',
  template: `
    <span #togglebtn id="togglebtn" class="k-button" (click)="toggleCalander()"
      >{{ buttonLabel }} <span unselectable="on" class="k-select"> <span class="k-i-arrow-s k-icon"></span> </span>
    </span>

    <kendo-popup [anchor]="togglebtn" *ngIf="showCalander">
      <div class="shortcut-button-bar">
        <label>Quick Select:</label> <button class="btn-secondary-sm action-btn" (click)="quickSelect('allBefore')">All Before</button>
        <button class="btn-secondary-sm action-btn" (click)="quickSelect('expired')">Expired</button>
        <button class="btn-secondary-sm action-btn" (click)="quickSelect('allAfter')">All After</button>
      </div>
      <kendo-multiviewcalendar
        [max]="maxDate"
        [min]="minDate"
        (valueChange)="selectDate($event)"
        [value]="calanderValue"
        [selectionRange]="range"
        [focusedDate]="focusedDate || range.start || range.end"
      ></kendo-multiviewcalendar>
      <div class="actions-button-bar">
        <button class="btn-secondary-sm action-btn" (click)="clearSelection()">Clear</button>
        <button class="btn-primary-sm action-btn" (click)="closePopup()">OK</button>
      </div>
    </kendo-popup>

    <button *ngIf="range.start !== null || range.end !== null" class="k-button k-button-icon k-clear-button-visible" title="Clear" (click)="clear()">
      <span class="k-icon k-i-filter-clear"></span>
    </button>
  `,
  styles: [
    `
      .actions-button-bar {
        justify-content: flex-end;
        display: flex;
      }
      .shortcut-button-bar {
        justify-content: flex-end;
        display: flex;
        align-items: center;
      }
      .action-btn,
      label {
        margin: 8px 8px 8px 0;
      }
      #togglebtn {
        max-width: calc(100% - 30px);
        display: flex;
        justify-content: space-between;
      }
      .carrot {
        margin-left: auto;
      }
    `,
  ],
})
export class GridFilterDateRangeDropdownComponent extends BaseFilterCellComponent implements OnInit, OnDestroy {
  constructor(filterService: FilterService, private store: Store<IAccountsState>) {
    super(filterService);
    this.today = new Date(this.today.getTime() - (this.today.getTime() % (1000 * 60 * 60 * 24)) + this.today.getTimezoneOffset() * 60 * 1000);
  }

  //#region variables

  @Input()
  public filter: CompositeFilterDescriptor;

  @Input()
  public data: any[];
  @Input()
  public textField = 'name';
  @Input()
  public valueField = 'value';
  @Input()
  public filterField: string;
  @Input()
  public filterable = true;

  public subscriptions: Subscription[] = [];
  public buttonLabel = 'None';

  private dateLimits = {
    max: 1924902000000,
    min: 1514761200000,
  };
  public maxDate = new Date(this.dateLimits.max);
  public minDate = new Date(this.dateLimits.min);

  public today: Date = new Date();
  public calanderValue: Date = null;
  public showClear = false;
  public nestFilter: CompositeFilterDescriptor = null;

  public showCalander = false;
  public focusedDate = null;
  public range = {
    start: null,
    end: null,
  };

  //#endregion

  //#region init

  public ngOnInit() {
    this.subscriptions.push(
      this.store.select(getFilterPwdRemainingDays).subscribe((x) => {
        const filters = x as FilterDescriptor[];
        const equal = this.dateFromFilterOperator(filters, 'eq');
        const start = this.dateFromFilterOperator(filters, 'gte');
        const end = this.dateFromFilterOperator(filters, 'lte');

        if (start && end) {
          this.range = { start, end };
        } else if (!start && end) {
          this.range = {
            start: new Date(this.dateLimits.min),
            end,
          };
          this.focusedDate = end;
        } else if (start && !end) {
          this.range = {
            start,
            end: new Date(this.dateLimits.max),
          };
          this.focusedDate = start;
        } else if (equal) {
          this.calanderValue = equal;
          this.range = {
            start: null,
            end: null,
          };
        } else if (!filters) {
          this.range = {
            start: null,
            end: null,
          };
        }
        this.buttonLabel = equal
          ? '1 day'
          : start && end
          ? `${(this.dateToDaysFromNow(end) - this.dateToDaysFromNow(start) + 1).toString()} days`
          : end
          ? this.dateToDaysFromNow(end) === 0
            ? 'Expired'
            : 'All Before'
          : start || end
          ? `${start ? 'All After' : 'All Before'}`
          : 'None';
      })
    );
  }

  public ngOnDestroy() {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }

  //#endregion

  //#region calender actions

  public quickSelect(type) {
    let newRange = { ...this.range };
    switch (type) {
      case 'expired':
        newRange = {
          start: new Date(this.dateLimits.min),
          end: this.today,
        };
        this.focusedDate = newRange.end;
        break;
      // case 'week':
      //   newRange = {
      //     start: this.today,
      //     end: new Date(this.today.getTime() + 1000 * 60 * 60 * 24 * 7),
      //   };
      //   this.focusedDate = newRange.start;
      //   break;
      // case 'month':
      //   end = new Date(this.today.getTime());
      //   end.setMonth(this.today.getMonth() + 1);
      //   newRange = {
      //     start: this.today,
      //     end,
      //   };
      //   this.focusedDate = newRange.start;
      //   break;
      case 'allBefore':
        newRange.end = this.calanderValue || this.today;
        newRange.start = new Date(this.dateLimits.min);
        this.focusedDate = newRange.end;
        break;
      case 'allAfter':
        newRange.start = this.calanderValue || this.today;
        newRange.end = new Date(this.dateLimits.max);
        this.focusedDate = newRange.start;
        break;
    }
    this.setFilter(this.createFilterFromRange(newRange));
  }

  public clear() {
    this.clearSelection();
    this.closePopup();
  }

  public clearSelection() {
    this.calanderValue = null;
    this.setFilter(this.createFilterFromRange({ start: null, end: null }));
  }

  public selectDate(e) {
    let newRange = { ...this.range };

    // check if we need to make a range with the next and previous selected calander value
    if (this.calanderValue !== null && (newRange.start === null && newRange.end === null)) {
      newRange = {
        start: new Date(Math.min(e.getTime(), this.calanderValue.getTime())),
        end: new Date(Math.max(e.getTime(), this.calanderValue.getTime())),
      };
    } else {
      newRange = { start: null, end: null };
    }
    this.calanderValue = e;
    this.setFilter(this.createFilterFromRange(newRange));
  }

  public closePopup() {
    this.showCalander = false;
  }

  public toggleCalander() {
    this.showCalander = !this.showCalander;
  }

  //#endregion

  //#region helper function
  private createFilterFromRange(range): CompositeFilterDescriptor {
    if (range.start === null && range.end === null && this.calanderValue === null) {
      return null;
    }

    if (this.calanderValue && (range.start === null && range.end === null)) {
      return {
        logic: 'and',
        filters: [
          {
            field: this.filterField,
            operator: 'eq',
            value: this.dateToDaysFromNow(this.calanderValue),
          },
          {
            field: this.filterField,
            operator: 'neq',
            value: null,
          },
        ],
      };
    }

    if (range.start !== null && range.end !== null) {
      const allBefore = range.start.getTime() === this.dateLimits.min;
      const allAfter = range.end.getTime() >= this.dateLimits.max;

      if (allBefore) {
        return {
          logic: 'and',
          filters: [
            {
              field: this.filterField,
              operator: 'lte',
              value: this.dateToDaysFromNow(range.end),
            },
            {
              field: this.filterField,
              operator: 'neq',
              value: null,
            },
          ],
        };
      } else if (allAfter) {
        return {
          logic: 'and',
          filters: [
            {
              field: this.filterField,
              operator: 'gte',
              value: this.dateToDaysFromNow(range.start),
            },
            {
              field: this.filterField,
              operator: 'neq',
              value: null,
            },
          ],
        };
      } else {
        return {
          logic: 'and',
          filters: [
            {
              field: this.filterField,
              operator: 'gte',
              value: this.dateToDaysFromNow(range.start),
            },
            {
              field: this.filterField,
              operator: 'lte',
              value: this.dateToDaysFromNow(range.end),
            },
            {
              field: this.filterField,
              operator: 'neq',
              value: null,
            },
          ],
        };
      }
    }
  }

  /**
   * Uses the current range to return which date is not at the calander range boundry.
   * defaults to today
   * @param  {'start'|'end'} prefEnd
   */
  private getNonBoundryDate(prefEnd: 'start' | 'end') {
    const d = {
      start: this.range.start ? (this.range.start.getTime() > 0 ? this.range.start : null) : null,
      end: this.range.end ? (this.range.end.getTime() < 1927580400000 ? this.range.end : null) : null,
    };
    const prefDate = d[prefEnd];
    const altDate = d[prefEnd === 'start' ? 'end' : 'start'];

    return prefDate || altDate || this.today;
  }

  /**
   * @param  {CompositeFilterDescriptor} filter
   */
  public setFilter(filter: CompositeFilterDescriptor) {
    let currentFilters: Array<FilterDescriptor | CompositeFilterDescriptor> = this.filter ? this.filter.filters : [];

    // remove existing filters for this field.. are are appending the new filter
    currentFilters = currentFilters.filter((f: CompositeFilterDescriptor) => {
      return f.filters ? (f.filters.some((nested: FilterDescriptor) => nested.field === 'pwdRemainingDays') ? false : true) : true;
    });

    if (filter) {
      currentFilters.push(filter);
    }
    this.applyFilter({
      filters: currentFilters,
      logic: 'and',
    });
  }

  /**
   * @param  {Date} date
   */
  private dateToDaysFromNow(date: Date): number {
    const target = date.getTime();

    // round to nearest day to allow for daylight savings*
    const res = Math.round((target - this.today.getTime()) / (1000 * 60 * 60 * 24));
    return res;
  }

  /**
   * @param  {number} daysFromNow
   */
  private dateFromDaysFromNow(daysFromNow: number): Date {
    return daysFromNow !== null ? new Date(this.today.getTime() + 1000 * 60 * 60 * 24 * daysFromNow) : null;
  }

  private dateFromFilterOperator(filters: FilterDescriptor[], operator: 'eq' | 'gte' | 'lte'): Date {
    if (!filters) {
      return null;
    }
    const opMatch = filters.filter((f) => f.operator === operator)[0];
    if (!opMatch) {
      return null;
    }
    return this.dateFromDaysFromNow(opMatch.value);
  }

  //#endregion
}
