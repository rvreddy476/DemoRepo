import { Input, Component, ViewChild, Output, EventEmitter, OnInit, ViewEncapsulation, OnDestroy, OnChanges } from '@angular/core';
import { style } from '@angular/animations';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';

@Component({
  selector: 'app-2f82-multi-dropdown-list',
  template: `
    <kendo-dropdownlist
    style="min-width:100%;"
      *ngIf="filterable"
      #dropdownlist
      [data]="sortedData"
      [filterable]="filterable"
      [valueField]="'value'"
      [kendoDropDownFilter]="filterSettings"
      (close)="close($event)"
      (blur)="blur()"
    >
      <ng-template kendoDropDownListItemTemplate let-dataItem>
        <div (click)="dropdownSelect(dataItem)" class="multi-select-option">
          <input class="k-checkbox" type="checkbox" [checked]="isItemSelected(dataItem)" /> <label class="k-checkbox-label" translate>{{ textAccessor(dataItem) }}</label>
        </div>
      </ng-template>
      <ng-template kendoDropDownListValueTemplate let-dataItem translate> {{ selectionValue() }} </ng-template>
    </kendo-dropdownlist>

    <kendo-dropdownlist
      *ngIf="!filterable"
      style="min-width:100%;"
      #dropdownlist
      [data]="sortedData"
      [filterable]="filterable"
      [valueField]="'value'"
      (close)="close($event)"
      (blur)="blur()"
    >
      <ng-template kendoDropDownListItemTemplate let-dataItem>
        <div (click)="dropdownSelect(dataItem)" class="multi-select-option">
          <input class="k-checkbox" type="checkbox" [checked]="isItemSelected(dataItem)" /> <label class="k-checkbox-label" translate>{{ textAccessor(dataItem) }}</label>
        </div>
      </ng-template>
      <ng-template kendoDropDownListValueTemplate let-dataItem> <span translate>{{ selectionValue() }} </span></ng-template>
    </kendo-dropdownlist>
  `,
  styleUrls: ['./multi-dropdown-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class MultiDropdownListComponent implements OnInit{
  @ViewChild('dropdownlist') public dropdownlist: any;

  //#region inputs

  @Input()
  public data: any[];
  @Input()
  public initialSelection: any[] = [];
  @Input()
  public textField: string;
  @Input()
  public valueField: string;
  @Input()
  public filterable = true;
  @Input()
  public sortOptions = true;

  @Input()
  public textPrefix: string = null;

  @Input()
  public emptyOnAll = true;
  @Input()
  public emptyTitle = 'None...';
  @Input()
  public fullTitle = 'All...';
  @Input()
  public selection: any[] = [];

  @Output()
  public selectionChange = new EventEmitter();

  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
  };

  public sortedData = []

  ngOnInit(){
    this.sortedData = (this.sortOptions && this.data) ? this.data.sort((a,b) => this.textAccessor(a) < this.textAccessor(b) ? -1 : 1) : this.data
  }

  public close(e) {
    e.preventDefault();
  }
  public blur() {
    this.dropdownlist.toggle(false);
  }

  public valueAccessor = (item) => (item ? item[this.valueField] : 'null');
  public textAccessor = (item) => (item ? `${this.textPrefix ? this.textPrefix : ''}${item[this.textField]}` : this.data.length === 0 ? 'Loading...' : 'null');

  public selectionValue() {
    if (this.selection.length === 1) {
      return this.textAccessor(this.data.filter((d) => d[this.valueField] === this.selection[0])[0]);
    } else if (this.selection.length === 0) {
      return this.emptyTitle;
    } else if (this.selection.length === this.data.length) {
      return this.fullTitle;
    } else {
      return this.selection.length;
    }
  }

  public isItemSelected = (item) => {
    return this.selection.some((s) => s === this.valueAccessor(item));
  }

  public dropdownSelect(e) {
    this.toggleSelected(this.valueAccessor(e));
  }

  public clearSelection(triggerChange = false) {
    if (triggerChange) {
      this.selectionChange.emit([]);
    }
  }

  public toggleSelected(v) {
    let newSelection = [...this.selection];
    const i = newSelection.indexOf(v);
    if (i !== -1) {
      newSelection.splice(i, 1);
    } else {
      newSelection.push(v);
    }

    if (newSelection.length === this.data.length && this.emptyOnAll && this.data.length > 1) {
      newSelection = [];
    }
    this.selectionChange.emit(newSelection);
  }
}
