import { BaseFilterCellComponent, FilterService } from '@progress/kendo-angular-grid';
import { Input, Component } from '@angular/core';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-2f82-grid-filter-dropdown',
  template: `
    <kendo-dropdownlist
      [data]="data"
      (valueChange)="onChange($event)"
      [defaultItem]="defaultItem"
      [value]="selectedValue"
      [valuePrimitive]="true"
      [textField]="textField"
      [valueField]="valueField"
    >
    </kendo-dropdownlist>
  `,
})
export class GridFilterDropdownComponent extends BaseFilterCellComponent {
  constructor(filterService: FilterService) {
    super(filterService);
  }

  @Input()
  public filter: CompositeFilterDescriptor;

  @Input()
  public data: any[];
  @Input()
  public textField: string;
  @Input()
  public valueField: string;
  @Input()
  public filterField: string;
  @Input()
  public operatorField: string = null;

  public selectedValue = null;

  public get defaultItem(): any {
    return {
      [this.textField]: 'Select...',
      [this.valueField]: null,
    };
  }

  public onChange(value: any): void {
    this.applyFilter(
      value === null // if value of the default item
        ? this.removeFilter(this.filterField) // remove the filter
        : this.updateFilter({
            // otherwise add/modify the filter for the field with the value
            field: this.filterField,
            operator: this.filterField || 'eq',
            value: value,
          })
    ); // and update the root filter
  }
}
