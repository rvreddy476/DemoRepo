import { ActionMenuIconComponent } from './../shared/icons/action-menu-icon/action-menu-icon.component';
import { EnableIconComponent } from './../shared/icons/enable-icon/enable-icon.component';
import { SettingsIconComponent } from './../shared/icons/settings-icon/settings-icon.component';
import { CalendarIconComponent } from './../shared/icons/calendar-icon/calendar-icon.component';
import { FailedWireIconComponent } from './../shared/icons/failed-wire-icon/failed-wire-icon.component';

// Angular Imports
import { NgModule } from '@angular/core';
// Component Imports
import { ApproveIconComponent } from './../shared/icons/approve-icon/approve-icon.component';
import { RejectIconComponent } from '../shared/icons/reject-icon/reject-icon.component';
import { TableRowLgIconComponent } from '../shared/icons/table-row-lg-icon/table-row-lg-icon.component';
import { TableRowSmIconComponent } from '../shared/icons/table-row-sm-icon/table-row-sm-icon.component';
import { SuccessWireIconComponent } from '../shared/icons/success-wire-icon/success-wire-icon.component';
import { HourglassIconComponent } from '../shared/icons/hourglass-icon/hourglass-icon.component';
import { TrashIconComponent } from '../shared/icons/trash-icon/trash-icon.component';
import { ResetIconComponent } from '../shared/icons/reset-icon/reset-icon.component';
import { DisableIconComponent } from '../shared/icons/disable-icon/disable-icon.component';
import { DeputyIconComponent } from '../shared/icons/deputy-icon/deputy-icon.component';
import { SortOrderIconComponent } from '../shared/icons/sort-order-icon/sort-order-icon.component';
import { MagnifyingGlassIconComponent } from '../shared/icons/magnifying-glass-icon/magnifying-glass-icon.component';
import { ProfilesBgIconComponent } from '../shared/icons/profiles-bg-icon/profiles-bg-icon.component';
import { WarningWireIconComponent } from '../shared/icons/warning-wire-icon copy/warning-wire-icon.component';
import { QuestionIconComponent } from '../shared/icons/question-icon/question-icon.component';
import { PenIconComponent } from '../shared/icons/pen-icon/pen-icon.component';
import { DuplicateIconComponent } from '../shared/icons/duplicate-icon/duplicate-icon.component';
import {  AddInfoIconComponent } from '../shared/icons/add-info-icon/add-info-icon.component';
import { AddDeputyIconComponent } from '../shared/icons/add-deputy-icon/add-deputy-icon.component';
import { RemoveDeputyIconComponent } from '../shared/icons/remove-deputy-icon/remove-deputy-icon.component';
import { DownloadIconComponent } from '../shared/icons/download-icon/download-icon.component';
import { AssignIconComponent } from '../shared/icons/assign-icon/assign-icon.component';
import { WarningIconComponent } from '../shared/icons/warning-icon/warning-icon.component';



@NgModule({
  imports: [],
  declarations: [
    ApproveIconComponent,
    RejectIconComponent,
    TableRowLgIconComponent,
    TableRowSmIconComponent,
    SuccessWireIconComponent,
    WarningWireIconComponent,
    FailedWireIconComponent,
    CalendarIconComponent,
    SettingsIconComponent,
    HourglassIconComponent,
    TrashIconComponent,
    ResetIconComponent,
    EnableIconComponent,
    DisableIconComponent,
    DeputyIconComponent,
    ActionMenuIconComponent,
    SortOrderIconComponent,
    MagnifyingGlassIconComponent,
    ProfilesBgIconComponent,
    QuestionIconComponent,
    PenIconComponent,
    DuplicateIconComponent,
    AddDeputyIconComponent,
    AddInfoIconComponent,
    RemoveDeputyIconComponent,
    DownloadIconComponent,
    AssignIconComponent,
    WarningIconComponent
  ],
  exports: [
    ApproveIconComponent,
    RejectIconComponent,
    TableRowLgIconComponent,
    TableRowSmIconComponent,
    SuccessWireIconComponent,
    WarningWireIconComponent,
    FailedWireIconComponent,
    CalendarIconComponent,
    SettingsIconComponent,
    HourglassIconComponent,
    TrashIconComponent,
    ResetIconComponent,
    EnableIconComponent,
    DisableIconComponent,
    DeputyIconComponent,
    ActionMenuIconComponent,
    SortOrderIconComponent,
    MagnifyingGlassIconComponent,
    ProfilesBgIconComponent,
    QuestionIconComponent,
    PenIconComponent,
    DuplicateIconComponent,
    AddDeputyIconComponent,
    AddInfoIconComponent,
    RemoveDeputyIconComponent,
    DownloadIconComponent,
    AssignIconComponent,
    WarningIconComponent

  ],
})
export class IconModule {}
