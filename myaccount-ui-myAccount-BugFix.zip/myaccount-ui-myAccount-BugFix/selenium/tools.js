module.exports = {
  wait: (ms) =>
    new Promise((res) => {
      setTimeout(() => {
        res();
      }, ms);
    }),
};
