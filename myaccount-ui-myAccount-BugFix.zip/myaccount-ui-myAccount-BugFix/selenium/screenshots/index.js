const fs = require('fs');
var looksSame = require('looks-same');
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout,
});
const fileExists = (path) =>
  new Promise((res) => {
    fs.exists(path, (exists) => {
      res(exists);
    });
  });
const checkImage = (img1, img2, params = {}) =>
  new Promise((res, rej) => {
    looksSame(img1, img2, params, (err, same) => {
      if (err) {
        rej(err);
      } else {
        res(same.equal);
      }
    });
  });
const createDiff = (ref, curr, diff) =>
  new Promise((res, rej) => {
    looksSame.createDiff(
      {
        reference: ref,
        current: curr,
        diff: diff,
        highlightColor: '#ff00ff',
        strict: true,
        ignoreCaret: true,
      },
      (err) => {
        if (err) {
          rej(err);
        } else {
          res(true);
        }
      }
    );
  });
const askUser = (prompt) =>
  new Promise((res) => {
    readline.question(prompt, (input) => {
      res(input);
      readline.close();
    });
  });

/**
 * Take A screenshot and compare with previous tests
 * @param {ThenableWebDriver} driver The name of the screenshot (do not duplicate)
 * @param {string} name The name of the screenshot (do not duplicate)
 * @return {!Promise<boolean>} A self reference.
 */
module.exports = doScreenShot = async (driver, name) => {
  const srcDir = `${__dirname}/current/${name}.png`;
  const diffDir = `${__dirname}/diff/${name}.png`;

  try {
    const base64 = await driver.takeScreenshot();
    const current = Buffer.from(base64, 'base64');
    const prevExists = await fileExists(srcDir);
    const diffExists = await fileExists(diffDir);
    let sameAsPrevious = prevExists ? await checkImage(srcDir, current, { tolerance: 2.5 }) : true;
    let wroteDiff = !sameAsPrevious ? await createDiff(srcDir, current, diffDir) : false;
    const overwrite = wroteDiff ? (await askUser(`${diffDir} \nAccept screenshot change for ${name} (y / n)? `)) === 'y' : false;

    if ((overwrite && wroteDiff) || !prevExists) fs.writeFileSync(srcDir, base64, 'base64');
    if (overwrite) fs.unlinkSync(diffDir);

    return true;
  } catch (err) {
    console.log('SCREENSHOT ERROR', err);
    throw new Error(err);
  }
};
