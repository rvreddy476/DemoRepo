var looksSame = require('looks-same');

const settings = { strict: false, tolerance: 50 };

looksSame('./firefox/landing-page.png', './firefox/landing-page1.png', settings, (err, cb) => {
  if (err) {
    console.log(err);
  } else {
    console.log('2', cb.equal);
  }
});

looksSame.createDiff(
  {
    reference: './firefox/landing-page.png',
    current: './firefox/landing-page1.png',
    diff: './firefox/landing-page-DIFF.png',
    highlightColor: '#ff00ff',
    strict: true,
    // tolerance:45,
    ignoreCaret: true,
  },
  (err) => {
    if (err) {
      console.log(err);
    }
  }
);

// looksSame('./firefox/landing-page.png',
// './firefox/landing-page3.png',
// settings,
// (err, cb) => {
//     if (err) {
//         console.log(err)
//     } else {
//         console.log("3",cb.equal)
//     }
// })
