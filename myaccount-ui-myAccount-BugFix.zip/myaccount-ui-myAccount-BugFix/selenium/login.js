const fs = require('fs');
const doScreenShot = require('./screenshots');
const wait = require('./tools').wait;
const { By, Key, until } = require('selenium-webdriver');

let driver = require('./create-driver');

module.exports = async (url, sshot) => {
  try {
    credentials = JSON.parse(fs.readFileSync('selenium/credentials.json', 'utf8'));
    await driver.get(url);

    const ngInput = await driver.wait(until.elementLocated(By.id('username')));
    await ngInput.sendKeys(credentials.username, Key.ENTER);
    const passInput = await driver.wait(until.elementLocated(By.id('password')));
    await passInput.sendKeys(credentials.password, Key.ENTER);
    const displayName = await driver.wait(until.elementLocated(By.className('myx-name'))).getText();
    if (displayName.toLowerCase() !== credentials.displayName.toLowerCase()) {
      throw new Error(`display name = ${displayName.getText()} should have been = ${credentials.displayName}`);
    }

    //await for translations and chart animations to load
    await wait(3000);

    sshot ? await doScreenShot(driver, 'landing-page') : false;

    return driver;
  } catch (err) {
    console.log('LOGIN ERROR', err);
    throw new Error(err);
  }
};
