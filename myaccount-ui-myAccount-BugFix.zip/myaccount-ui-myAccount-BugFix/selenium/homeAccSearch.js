const { Builder, By, Key, until } = require('selenium-webdriver');
const doScreenHsot = require('./screenshots');
const wait = require('./tools').wait;

module.exports = async (driver = new Builder().build(), sshot) => {
  try {
    let searchTerm = 'CAVI';
    const searchInput = await driver.wait(until.elementLocated(By.css('#searchbar input')));
    await searchInput.sendKeys(searchTerm, Key.ENTER);
    await driver.wait(until.urlContains(`term=${searchTerm}`));

    const searchFilter = await driver.wait(until.elementsLocated(By.css('[ng-reflect-logical-col-index="1"][ng-reflect-logical-row-index="1"] input')));
    const filterText = await searchFilter[0].getAttribute('value');

    await wait(500);

    sshot ? await doScreenHsot(driver, 'filtered results') : false;

    if (filterText !== searchTerm) {
      throw new Error(`Filter input should equal ${searchTerm}`);
    }
    // const tableRows = await driver.wait(until.elementsLocated(By.css('tr.row.k-master-row')))
    return driver;
  } catch (err) {
    throw new Error(err);
  }
};
