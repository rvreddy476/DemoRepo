const login = require('./login');
const homeAccSearch = require('./homeAccSearch');

(async () => {
  let driver;
  let sshot = process.argv.some((arg) => arg === '--screenshot');
  try {
    driver = await login('http://localhost:4200', sshot);
    await homeAccSearch(driver, sshot);
    console.log('TEST SUCCESS');
  } catch (err) {
    console.log('TEST FAILED', err);
  } finally {
    try {
      await driver.quit();
    } catch (err) {}
    process.exit();
  }
})();
