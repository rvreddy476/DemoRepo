const { Builder, By, Key, until } = require('selenium-webdriver');
const fs = require('fs');

module.exports = async (driver = new Builder().build()) => {
  try {
    // elements check
    const base64screenshot = await driver.takeScreenshot();
  } catch (err) {}
};
