const firefox = require('selenium-webdriver/firefox');
const { Builder } = require('selenium-webdriver');

let firefoxOptions = new firefox.Options();
firefoxOptions.setProfile('C:/Users/NG797A5/Downloads/profile/hvwpo8y6.default');
firefoxOptions.setBinary('C:/Users/NG797A5/AppData/Local/Mozilla Firefox/firefox.exe');

module.exports = new Builder()
  .forBrowser('firefox')
  .setFirefoxOptions(firefoxOptions)
  .build();
